var __accessCheck = (obj, member, msg) => {
  if (!member.has(obj))
    throw TypeError("Cannot " + msg);
};
var __privateGet = (obj, member, getter) => {
  __accessCheck(obj, member, "read from private field");
  return getter ? getter.call(obj) : member.get(obj);
};
var __privateAdd = (obj, member, value) => {
  if (member.has(obj))
    throw TypeError("Cannot add the same private member more than once");
  member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
};
var __privateSet = (obj, member, value, setter) => {
  __accessCheck(obj, member, "write to private field");
  setter ? setter.call(obj, value) : member.set(obj, value);
  return value;
};
var _saveTimeout, _columns;
import { g as getDefaultExportFromCjs, r as reactExports, R as React, a as reactDomExports, C as ClassNameGenerator, c as capitalize, b as createChainedFunction$1, d as createSvgIcon$1, e as debounce$2, i as isMuiElement, o as ownerDocument$1, f as ownerWindow$1, s as setRef$1, u as useEnhancedEffect$1, h as useId, j as useControlled, k as useEventCallback$1, l as useForkRef$1, m as useIsFocusVisible, n as getAugmentedNamespace, p as jsxRuntimeExports, q as generateUtilityClass, t as generateUtilityClasses, v as styled, _ as _extends$1, w as composeClasses, x as clsx$1, y as _objectWithoutPropertiesLoose$1, P as Portal, z as useSlotProps, A as useClassNamesOverride, B as styled$1, I as InputBase, D as useTheme, E as useThemeProps, G as Grow, F as Paper, H as useTheme$1, M as MenuList, J as alpha, L as ListContext, T as Typography, K as ButtonBase, N as rootShouldForwardProp, O as keyframes, Q as css, S as lighten, U as darken, V as useFormControl, W as formControlState, X as Stack, Y as FocusTrap, Z as inputClasses, $ as inputBaseClasses, a0 as outlinedInputClasses, a1 as filledInputClasses, a2 as ArrowDropDownIcon, a3 as CircularProgress, a4 as MUISelect, a5 as isHostComponent, a6 as useTheme$2, a7 as FormControlContext, a8 as appendOwnerState, a9 as TextField, aa as MUIFormControl, ab as Button, ac as MUIInputLabel, ad as someEmpty, ae as fillEmpty, af as exists, ag as Box, ah as createRoot, ai as CssBaseline } from "./Button.js";
import "./index.ts.js";
import { i as i18n, w as write$1, a as readAsLenient, K as KEY } from "./mention-dao.js";
var propTypes = { exports: {} };
var ReactPropTypesSecret$1 = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
var ReactPropTypesSecret_1 = ReactPropTypesSecret$1;
var ReactPropTypesSecret = ReactPropTypesSecret_1;
function emptyFunction() {
}
function emptyFunctionWithReset() {
}
emptyFunctionWithReset.resetWarningCache = emptyFunction;
var factoryWithThrowingShims = function() {
  function shim(props, propName, componentName, location, propFullName, secret) {
    if (secret === ReactPropTypesSecret) {
      return;
    }
    var err = new Error(
      "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
    );
    err.name = "Invariant Violation";
    throw err;
  }
  shim.isRequired = shim;
  function getShim() {
    return shim;
  }
  var ReactPropTypes = {
    array: shim,
    bigint: shim,
    bool: shim,
    func: shim,
    number: shim,
    object: shim,
    string: shim,
    symbol: shim,
    any: shim,
    arrayOf: getShim,
    element: shim,
    elementType: shim,
    instanceOf: getShim,
    node: shim,
    objectOf: getShim,
    oneOf: getShim,
    oneOfType: getShim,
    shape: getShim,
    exact: getShim,
    checkPropTypes: emptyFunctionWithReset,
    resetWarningCache: emptyFunction
  };
  ReactPropTypes.PropTypes = ReactPropTypes;
  return ReactPropTypes;
};
{
  propTypes.exports = factoryWithThrowingShims();
}
var propTypesExports = propTypes.exports;
const PropTypes = /* @__PURE__ */ getDefaultExportFromCjs(propTypesExports);
function chainPropTypes(propType1, propType2) {
  {
    return () => null;
  }
}
function deprecatedPropType(validator, reason) {
  {
    return () => null;
  }
}
function requirePropFactory(componentNameInError, Component) {
  {
    return () => null;
  }
}
function unsupportedProp(props, propName, componentName, location, propFullName) {
  {
    return null;
  }
}
const usePreviousProps = (value) => {
  const ref = reactExports.useRef({});
  reactExports.useEffect(() => {
    ref.current = value;
  });
  return ref.current;
};
const usePreviousProps$1 = usePreviousProps;
function r(e2) {
  var t2, f, n2 = "";
  if ("string" == typeof e2 || "number" == typeof e2)
    n2 += e2;
  else if ("object" == typeof e2)
    if (Array.isArray(e2))
      for (t2 = 0; t2 < e2.length; t2++)
        e2[t2] && (f = r(e2[t2])) && (n2 && (n2 += " "), n2 += f);
    else
      for (t2 in e2)
        e2[t2] && (n2 && (n2 += " "), n2 += t2);
  return n2;
}
function clsx() {
  for (var e2, t2, f = 0, n2 = ""; f < arguments.length; )
    (e2 = arguments[f++]) && (t2 = r(e2)) && (n2 && (n2 += " "), n2 += t2);
  return n2;
}
let e = { data: "" }, t = (t2) => "object" == typeof window ? ((t2 ? t2.querySelector("#_goober") : window._goober) || Object.assign((t2 || document.head).appendChild(document.createElement("style")), { innerHTML: " ", id: "_goober" })).firstChild : t2 || e, l = /(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g, a = /\/\*[^]*?\*\/|  +/g, n = /\n+/g, o = (e2, t2) => {
  let r2 = "", l2 = "", a2 = "";
  for (let n2 in e2) {
    let c2 = e2[n2];
    "@" == n2[0] ? "i" == n2[1] ? r2 = n2 + " " + c2 + ";" : l2 += "f" == n2[1] ? o(c2, n2) : n2 + "{" + o(c2, "k" == n2[1] ? "" : t2) + "}" : "object" == typeof c2 ? l2 += o(c2, t2 ? t2.replace(/([^,])+/g, (e3) => n2.replace(/(^:.*)|([^,])+/g, (t3) => /&/.test(t3) ? t3.replace(/&/g, e3) : e3 ? e3 + " " + t3 : t3)) : n2) : null != c2 && (n2 = /^--/.test(n2) ? n2 : n2.replace(/[A-Z]/g, "-$&").toLowerCase(), a2 += o.p ? o.p(n2, c2) : n2 + ":" + c2 + ";");
  }
  return r2 + (t2 && a2 ? t2 + "{" + a2 + "}" : a2) + l2;
}, c = {}, s = (e2) => {
  if ("object" == typeof e2) {
    let t2 = "";
    for (let r2 in e2)
      t2 += r2 + s(e2[r2]);
    return t2;
  }
  return e2;
}, i = (e2, t2, r2, i2, p2) => {
  let u2 = s(e2), d = c[u2] || (c[u2] = ((e3) => {
    let t3 = 0, r3 = 11;
    for (; t3 < e3.length; )
      r3 = 101 * r3 + e3.charCodeAt(t3++) >>> 0;
    return "go" + r3;
  })(u2));
  if (!c[d]) {
    let t3 = u2 !== e2 ? e2 : ((e3) => {
      let t4, r3, o2 = [{}];
      for (; t4 = l.exec(e3.replace(a, "")); )
        t4[4] ? o2.shift() : t4[3] ? (r3 = t4[3].replace(n, " ").trim(), o2.unshift(o2[0][r3] = o2[0][r3] || {})) : o2[0][t4[1]] = t4[2].replace(n, " ").trim();
      return o2[0];
    })(e2);
    c[d] = o(p2 ? { ["@keyframes " + d]: t3 } : t3, r2 ? "" : "." + d);
  }
  let f = r2 && c.g ? c.g : null;
  return r2 && (c.g = c[d]), ((e3, t3, r3, l2) => {
    l2 ? t3.data = t3.data.replace(l2, e3) : -1 === t3.data.indexOf(e3) && (t3.data = r3 ? e3 + t3.data : t3.data + e3);
  })(c[d], t2, i2, f), d;
}, p = (e2, t2, r2) => e2.reduce((e3, l2, a2) => {
  let n2 = t2[a2];
  if (n2 && n2.call) {
    let e4 = n2(r2), t3 = e4 && e4.props && e4.props.className || /^go/.test(e4) && e4;
    n2 = t3 ? "." + t3 : e4 && "object" == typeof e4 ? e4.props ? "" : o(e4, "") : false === e4 ? "" : e4;
  }
  return e3 + l2 + (null == n2 ? "" : n2);
}, "");
function u(e2) {
  let r2 = this || {}, l2 = e2.call ? e2(r2.p) : e2;
  return i(l2.unshift ? l2.raw ? p(l2, [].slice.call(arguments, 1), r2.p) : l2.reduce((e3, t2) => Object.assign(e3, t2 && t2.call ? t2(r2.p) : t2), {}) : l2, t(r2.target), r2.g, r2.o, r2.k);
}
u.bind({ g: 1 });
u.bind({ k: 1 });
function _defineProperties(target, props) {
  for (var i2 = 0; i2 < props.length; i2++) {
    var descriptor = props[i2];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor)
      descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps)
    _defineProperties(Constructor.prototype, protoProps);
  if (staticProps)
    _defineProperties(Constructor, staticProps);
  return Constructor;
}
function _extends() {
  _extends = Object.assign || function(target) {
    for (var i2 = 1; i2 < arguments.length; i2++) {
      var source = arguments[i2];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}
function _inheritsLoose(subClass, superClass) {
  subClass.prototype = Object.create(superClass.prototype);
  subClass.prototype.constructor = subClass;
  subClass.__proto__ = superClass;
}
function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null)
    return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i2;
  for (i2 = 0; i2 < sourceKeys.length; i2++) {
    key = sourceKeys[i2];
    if (excluded.indexOf(key) >= 0)
      continue;
    target[key] = source[key];
  }
  return target;
}
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return self;
}
var noOp = function noOp2() {
  return "";
};
var SnackbarContext = /* @__PURE__ */ React.createContext({
  enqueueSnackbar: noOp,
  closeSnackbar: noOp
});
var breakpoints = {
  downXs: "@media (max-width:599.95px)",
  upSm: "@media (min-width:600px)"
};
var capitalise = function capitalise2(text) {
  return text.charAt(0).toUpperCase() + text.slice(1);
};
var originKeyExtractor = function originKeyExtractor2(anchor) {
  return "" + capitalise(anchor.vertical) + capitalise(anchor.horizontal);
};
var isDefined = function isDefined2(value) {
  return !!value || value === 0;
};
var UNMOUNTED = "unmounted";
var EXITED = "exited";
var ENTERING = "entering";
var ENTERED = "entered";
var EXITING = "exiting";
var Transition = /* @__PURE__ */ function(_React$Component) {
  _inheritsLoose(Transition2, _React$Component);
  function Transition2(props) {
    var _this;
    _this = _React$Component.call(this, props) || this;
    var appear = props.appear;
    var initialStatus;
    _this.appearStatus = null;
    if (props["in"]) {
      if (appear) {
        initialStatus = EXITED;
        _this.appearStatus = ENTERING;
      } else {
        initialStatus = ENTERED;
      }
    } else if (props.unmountOnExit || props.mountOnEnter) {
      initialStatus = UNMOUNTED;
    } else {
      initialStatus = EXITED;
    }
    _this.state = {
      status: initialStatus
    };
    _this.nextCallback = null;
    return _this;
  }
  Transition2.getDerivedStateFromProps = function getDerivedStateFromProps(_ref, prevState) {
    var nextIn = _ref["in"];
    if (nextIn && prevState.status === UNMOUNTED) {
      return {
        status: EXITED
      };
    }
    return null;
  };
  var _proto = Transition2.prototype;
  _proto.componentDidMount = function componentDidMount() {
    this.updateStatus(true, this.appearStatus);
  };
  _proto.componentDidUpdate = function componentDidUpdate(prevProps) {
    var nextStatus = null;
    if (prevProps !== this.props) {
      var status = this.state.status;
      if (this.props["in"]) {
        if (status !== ENTERING && status !== ENTERED) {
          nextStatus = ENTERING;
        }
      } else if (status === ENTERING || status === ENTERED) {
        nextStatus = EXITING;
      }
    }
    this.updateStatus(false, nextStatus);
  };
  _proto.componentWillUnmount = function componentWillUnmount() {
    this.cancelNextCallback();
  };
  _proto.getTimeouts = function getTimeouts() {
    var timeout2 = this.props.timeout;
    var enter = timeout2;
    var exit = timeout2;
    if (timeout2 != null && typeof timeout2 !== "number" && typeof timeout2 !== "string") {
      exit = timeout2.exit;
      enter = timeout2.enter;
    }
    return {
      exit,
      enter
    };
  };
  _proto.updateStatus = function updateStatus(mounting, nextStatus) {
    if (mounting === void 0) {
      mounting = false;
    }
    if (nextStatus !== null) {
      this.cancelNextCallback();
      if (nextStatus === ENTERING) {
        this.performEnter(mounting);
      } else {
        this.performExit();
      }
    } else if (this.props.unmountOnExit && this.state.status === EXITED) {
      this.setState({
        status: UNMOUNTED
      });
    }
  };
  _proto.performEnter = function performEnter(mounting) {
    var _this2 = this;
    var enter = this.props.enter;
    var isAppearing = mounting;
    var timeouts = this.getTimeouts();
    if (!mounting && !enter) {
      this.safeSetState({
        status: ENTERED
      }, function() {
        if (_this2.props.onEntered) {
          _this2.props.onEntered(_this2.node, isAppearing);
        }
      });
      return;
    }
    if (this.props.onEnter) {
      this.props.onEnter(this.node, isAppearing);
    }
    this.safeSetState({
      status: ENTERING
    }, function() {
      if (_this2.props.onEntering) {
        _this2.props.onEntering(_this2.node, isAppearing);
      }
      _this2.onTransitionEnd(timeouts.enter, function() {
        _this2.safeSetState({
          status: ENTERED
        }, function() {
          if (_this2.props.onEntered) {
            _this2.props.onEntered(_this2.node, isAppearing);
          }
        });
      });
    });
  };
  _proto.performExit = function performExit() {
    var _this3 = this;
    var exit = this.props.exit;
    var timeouts = this.getTimeouts();
    if (!exit) {
      this.safeSetState({
        status: EXITED
      }, function() {
        if (_this3.props.onExited) {
          _this3.props.onExited(_this3.node);
        }
      });
      return;
    }
    if (this.props.onExit) {
      this.props.onExit(this.node);
    }
    this.safeSetState({
      status: EXITING
    }, function() {
      if (_this3.props.onExiting) {
        _this3.props.onExiting(_this3.node);
      }
      _this3.onTransitionEnd(timeouts.exit, function() {
        _this3.safeSetState({
          status: EXITED
        }, function() {
          if (_this3.props.onExited) {
            _this3.props.onExited(_this3.node);
          }
        });
      });
    });
  };
  _proto.cancelNextCallback = function cancelNextCallback() {
    if (this.nextCallback !== null && this.nextCallback.cancel) {
      this.nextCallback.cancel();
      this.nextCallback = null;
    }
  };
  _proto.safeSetState = function safeSetState(nextState, callback) {
    callback = this.setNextCallback(callback);
    this.setState(nextState, callback);
  };
  _proto.setNextCallback = function setNextCallback(callback) {
    var _this4 = this;
    var active = true;
    this.nextCallback = function() {
      if (active) {
        active = false;
        _this4.nextCallback = null;
        callback();
      }
    };
    this.nextCallback.cancel = function() {
      active = false;
    };
    return this.nextCallback;
  };
  _proto.onTransitionEnd = function onTransitionEnd(timeout2, handler) {
    this.setNextCallback(handler);
    var doesNotHaveTimeoutOrListener = timeout2 == null && !this.props.addEndListener;
    if (!this.node || doesNotHaveTimeoutOrListener) {
      setTimeout(this.nextCallback, 0);
      return;
    }
    if (this.props.addEndListener) {
      this.props.addEndListener(this.node, this.nextCallback);
    }
    if (timeout2 != null) {
      setTimeout(this.nextCallback, timeout2);
    }
  };
  _proto.render = function render() {
    var status = this.state.status;
    if (status === UNMOUNTED) {
      return null;
    }
    var _this$props = this.props, children = _this$props.children, childProps = _objectWithoutPropertiesLoose(_this$props, ["children", "in", "mountOnEnter", "unmountOnExit", "appear", "enter", "exit", "timeout", "addEndListener", "onEnter", "onEntering", "onEntered", "onExit", "onExiting", "onExited", "nodeRef"]);
    return children(status, childProps);
  };
  _createClass(Transition2, [{
    key: "node",
    get: function get() {
      var _this$props$nodeRef;
      var node = (_this$props$nodeRef = this.props.nodeRef) === null || _this$props$nodeRef === void 0 ? void 0 : _this$props$nodeRef.current;
      if (!node) {
        throw new Error("notistack - Custom snackbar is not refForwarding");
      }
      return node;
    }
  }]);
  return Transition2;
}(React.Component);
function noop$1() {
}
Transition.defaultProps = {
  "in": false,
  mountOnEnter: false,
  unmountOnExit: false,
  appear: false,
  enter: true,
  exit: true,
  onEnter: noop$1,
  onEntering: noop$1,
  onEntered: noop$1,
  onExit: noop$1,
  onExiting: noop$1,
  onExited: noop$1
};
function setRef(ref, value) {
  if (typeof ref === "function") {
    ref(value);
  } else if (ref) {
    ref.current = value;
  }
}
function useForkRef(refA, refB) {
  return reactExports.useMemo(function() {
    if (refA == null && refB == null) {
      return null;
    }
    return function(refValue) {
      setRef(refA, refValue);
      setRef(refB, refValue);
    };
  }, [refA, refB]);
}
function getTransitionProps(props) {
  var timeout2 = props.timeout, _props$style = props.style, style = _props$style === void 0 ? {} : _props$style, mode = props.mode;
  return {
    duration: typeof timeout2 === "object" ? timeout2[mode] || 0 : timeout2,
    easing: style.transitionTimingFunction,
    delay: style.transitionDelay
  };
}
var defaultEasing = {
  // This is the most common easing curve.
  easeInOut: "cubic-bezier(0.4, 0, 0.2, 1)",
  // Objects enter the screen at full velocity from off-screen and
  // slowly decelerate to a resting point.
  easeOut: "cubic-bezier(0.0, 0, 0.2, 1)",
  // Objects leave the screen at full velocity. They do not decelerate when off-screen.
  easeIn: "cubic-bezier(0.4, 0, 1, 1)",
  // The sharp curve is used by objects that may return to the screen at any time.
  sharp: "cubic-bezier(0.4, 0, 0.6, 1)"
};
var reflow = function reflow2(node) {
  node.scrollTop = node.scrollTop;
};
var formatMs = function formatMs2(milliseconds) {
  return Math.round(milliseconds) + "ms";
};
function createTransition(props, options) {
  if (props === void 0) {
    props = ["all"];
  }
  var _ref = options || {}, _ref$duration = _ref.duration, duration = _ref$duration === void 0 ? 300 : _ref$duration, _ref$easing = _ref.easing, easing = _ref$easing === void 0 ? defaultEasing.easeInOut : _ref$easing, _ref$delay = _ref.delay, delay = _ref$delay === void 0 ? 0 : _ref$delay;
  var properties = Array.isArray(props) ? props : [props];
  return properties.map(function(animatedProp) {
    var formattedDuration = typeof duration === "string" ? duration : formatMs(duration);
    var formattedDelay = typeof delay === "string" ? delay : formatMs(delay);
    return animatedProp + " " + formattedDuration + " " + easing + " " + formattedDelay;
  }).join(",");
}
function ownerDocument(node) {
  return node && node.ownerDocument || document;
}
function ownerWindow(node) {
  var doc = ownerDocument(node);
  return doc.defaultView || window;
}
function debounce$1(func, wait) {
  if (wait === void 0) {
    wait = 166;
  }
  var timeout2;
  function debounced() {
    var _this = this;
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    var later = function later2() {
      func.apply(_this, args);
    };
    clearTimeout(timeout2);
    timeout2 = setTimeout(later, wait);
  }
  debounced.clear = function() {
    clearTimeout(timeout2);
  };
  return debounced;
}
function getTranslateValue(direction2, node) {
  var rect = node.getBoundingClientRect();
  var containerWindow = ownerWindow(node);
  var transform;
  if (node.fakeTransform) {
    transform = node.fakeTransform;
  } else {
    var computedStyle = containerWindow.getComputedStyle(node);
    transform = computedStyle.getPropertyValue("-webkit-transform") || computedStyle.getPropertyValue("transform");
  }
  var offsetX = 0;
  var offsetY = 0;
  if (transform && transform !== "none" && typeof transform === "string") {
    var transformValues = transform.split("(")[1].split(")")[0].split(",");
    offsetX = parseInt(transformValues[4], 10);
    offsetY = parseInt(transformValues[5], 10);
  }
  switch (direction2) {
    case "left":
      return "translateX(" + (containerWindow.innerWidth + offsetX - rect.left) + "px)";
    case "right":
      return "translateX(-" + (rect.left + rect.width - offsetX) + "px)";
    case "up":
      return "translateY(" + (containerWindow.innerHeight + offsetY - rect.top) + "px)";
    default:
      return "translateY(-" + (rect.top + rect.height - offsetY) + "px)";
  }
}
function setTranslateValue(direction2, node) {
  if (!node)
    return;
  var transform = getTranslateValue(direction2, node);
  if (transform) {
    node.style.webkitTransform = transform;
    node.style.transform = transform;
  }
}
var Slide = /* @__PURE__ */ reactExports.forwardRef(function(props, ref) {
  var children = props.children, _props$direction = props.direction, direction2 = _props$direction === void 0 ? "down" : _props$direction, inProp = props["in"], style = props.style, _props$timeout = props.timeout, timeout2 = _props$timeout === void 0 ? 0 : _props$timeout, onEnter = props.onEnter, onEntered = props.onEntered, onExit = props.onExit, onExited = props.onExited, other = _objectWithoutPropertiesLoose(props, ["children", "direction", "in", "style", "timeout", "onEnter", "onEntered", "onExit", "onExited"]);
  var nodeRef = reactExports.useRef(null);
  var handleRefIntermediary = useForkRef(children.ref, nodeRef);
  var handleRef = useForkRef(handleRefIntermediary, ref);
  var handleEnter = function handleEnter2(node, isAppearing) {
    setTranslateValue(direction2, node);
    reflow(node);
    if (onEnter) {
      onEnter(node, isAppearing);
    }
  };
  var handleEntering = function handleEntering2(node) {
    var easing = (style === null || style === void 0 ? void 0 : style.transitionTimingFunction) || defaultEasing.easeOut;
    var transitionProps = getTransitionProps({
      timeout: timeout2,
      mode: "enter",
      style: _extends({}, style, {
        transitionTimingFunction: easing
      })
    });
    node.style.webkitTransition = createTransition("-webkit-transform", transitionProps);
    node.style.transition = createTransition("transform", transitionProps);
    node.style.webkitTransform = "none";
    node.style.transform = "none";
  };
  var handleExit = function handleExit2(node) {
    var easing = (style === null || style === void 0 ? void 0 : style.transitionTimingFunction) || defaultEasing.sharp;
    var transitionProps = getTransitionProps({
      timeout: timeout2,
      mode: "exit",
      style: _extends({}, style, {
        transitionTimingFunction: easing
      })
    });
    node.style.webkitTransition = createTransition("-webkit-transform", transitionProps);
    node.style.transition = createTransition("transform", transitionProps);
    setTranslateValue(direction2, node);
    if (onExit) {
      onExit(node);
    }
  };
  var handleExited = function handleExited2(node) {
    node.style.webkitTransition = "";
    node.style.transition = "";
    if (onExited) {
      onExited(node);
    }
  };
  var updatePosition = reactExports.useCallback(function() {
    if (nodeRef.current) {
      setTranslateValue(direction2, nodeRef.current);
    }
  }, [direction2]);
  reactExports.useEffect(function() {
    if (inProp || direction2 === "down" || direction2 === "right") {
      return void 0;
    }
    var handleResize = debounce$1(function() {
      if (nodeRef.current) {
        setTranslateValue(direction2, nodeRef.current);
      }
    });
    var containerWindow = ownerWindow(nodeRef.current);
    containerWindow.addEventListener("resize", handleResize);
    return function() {
      handleResize.clear();
      containerWindow.removeEventListener("resize", handleResize);
    };
  }, [direction2, inProp]);
  reactExports.useEffect(function() {
    if (!inProp) {
      updatePosition();
    }
  }, [inProp, updatePosition]);
  return reactExports.createElement(Transition, Object.assign({
    appear: true,
    nodeRef,
    onEnter: handleEnter,
    onEntered,
    onEntering: handleEntering,
    onExit: handleExit,
    onExited: handleExited,
    "in": inProp,
    timeout: timeout2
  }, other), function(state, childProps) {
    return reactExports.cloneElement(children, _extends({
      ref: handleRef,
      style: _extends({
        visibility: state === "exited" && !inProp ? "hidden" : void 0
      }, style, {}, children.props.style)
    }, childProps));
  });
});
Slide.displayName = "Slide";
var SvgIcon = function SvgIcon2(props) {
  return React.createElement("svg", Object.assign({
    viewBox: "0 0 24 24",
    focusable: "false",
    style: {
      fontSize: 20,
      marginInlineEnd: 8,
      userSelect: "none",
      width: "1em",
      height: "1em",
      display: "inline-block",
      fill: "currentColor",
      flexShrink: 0
    }
  }, props));
};
var CheckIcon = function CheckIcon2() {
  return React.createElement(SvgIcon, null, React.createElement("path", {
    d: "M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M10 17L5 12L6.41\n        10.59L10 14.17L17.59 6.58L19 8L10 17Z"
  }));
};
var WarningIcon = function WarningIcon2() {
  return React.createElement(SvgIcon, null, React.createElement("path", {
    d: "M13,14H11V10H13M13,18H11V16H13M1,21H23L12,2L1,21Z"
  }));
};
var ErrorIcon = function ErrorIcon2() {
  return React.createElement(SvgIcon, null, React.createElement("path", {
    d: "M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,\n        6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,\n        13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z"
  }));
};
var InfoIcon = function InfoIcon2() {
  return React.createElement(SvgIcon, null, React.createElement("path", {
    d: "M13,9H11V7H13M13,17H11V11H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,\n        0 22,12A10,10 0 0,0 12,2Z"
  }));
};
var defaultIconVariants = {
  "default": void 0,
  success: /* @__PURE__ */ React.createElement(CheckIcon, null),
  warning: /* @__PURE__ */ React.createElement(WarningIcon, null),
  error: /* @__PURE__ */ React.createElement(ErrorIcon, null),
  info: /* @__PURE__ */ React.createElement(InfoIcon, null)
};
var defaults = {
  maxSnack: 3,
  persist: false,
  hideIconVariant: false,
  disableWindowBlurListener: false,
  variant: "default",
  autoHideDuration: 5e3,
  iconVariant: defaultIconVariants,
  anchorOrigin: {
    vertical: "bottom",
    horizontal: "left"
  },
  TransitionComponent: Slide,
  transitionDuration: {
    enter: 225,
    exit: 195
  }
};
var getAutoHideDuration = function getAutoHideDuration2(optionsDuration, propsDuration) {
  var isNumberOrNull = function isNumberOrNull2(numberish) {
    return typeof numberish === "number" || numberish === null;
  };
  if (isNumberOrNull(optionsDuration))
    return optionsDuration;
  if (isNumberOrNull(propsDuration))
    return propsDuration;
  return defaults.autoHideDuration;
};
var getTransitionDuration = function getTransitionDuration2(optionsDuration, propsDuration) {
  var is2 = function is3(item, types) {
    return types.some(function(t2) {
      return typeof item === t2;
    });
  };
  if (is2(optionsDuration, ["string", "number"])) {
    return optionsDuration;
  }
  if (is2(optionsDuration, ["object"])) {
    return _extends({}, defaults.transitionDuration, {}, is2(propsDuration, ["object"]) && propsDuration, {}, optionsDuration);
  }
  if (is2(propsDuration, ["string", "number"])) {
    return propsDuration;
  }
  if (is2(propsDuration, ["object"])) {
    return _extends({}, defaults.transitionDuration, {}, propsDuration);
  }
  return defaults.transitionDuration;
};
var merge = function merge2(options, props) {
  return function(name, shouldObjectMerge) {
    if (shouldObjectMerge === void 0) {
      shouldObjectMerge = false;
    }
    if (shouldObjectMerge) {
      return _extends({}, defaults[name], {}, props[name], {}, options[name]);
    }
    if (name === "autoHideDuration") {
      return getAutoHideDuration(options.autoHideDuration, props.autoHideDuration);
    }
    if (name === "transitionDuration") {
      return getTransitionDuration(options.transitionDuration, props.transitionDuration);
    }
    return options[name] || props[name] || defaults[name];
  };
};
function makeStyles(styles2) {
  return Object.entries(styles2).reduce(function(acc, _ref) {
    var _extends2;
    var key = _ref[0], value = _ref[1];
    return _extends({}, acc, (_extends2 = {}, _extends2[key] = u(value), _extends2));
  }, {});
}
var ComponentClasses = {
  SnackbarContainer: "notistack-SnackbarContainer",
  Snackbar: "notistack-Snackbar",
  CollapseWrapper: "notistack-CollapseWrapper",
  MuiContent: "notistack-MuiContent",
  MuiContentVariant: function MuiContentVariant(variant) {
    return "notistack-MuiContent-" + variant;
  }
};
var classes = /* @__PURE__ */ makeStyles({
  root: {
    height: 0
  },
  entered: {
    height: "auto"
  }
});
var collapsedSize = "0px";
var timeout = 175;
var Collapse = /* @__PURE__ */ reactExports.forwardRef(function(props, ref) {
  var children = props.children, inProp = props["in"], onExited = props.onExited;
  var wrapperRef = reactExports.useRef(null);
  var nodeRef = reactExports.useRef(null);
  var handleRef = useForkRef(ref, nodeRef);
  var getWrapperSize = function getWrapperSize2() {
    return wrapperRef.current ? wrapperRef.current.clientHeight : 0;
  };
  var handleEnter = function handleEnter2(node) {
    node.style.height = collapsedSize;
  };
  var handleEntering = function handleEntering2(node) {
    var wrapperSize = getWrapperSize();
    var _getTransitionProps = getTransitionProps({
      timeout,
      mode: "enter"
    }), transitionDuration = _getTransitionProps.duration, easing = _getTransitionProps.easing;
    node.style.transitionDuration = typeof transitionDuration === "string" ? transitionDuration : transitionDuration + "ms";
    node.style.height = wrapperSize + "px";
    node.style.transitionTimingFunction = easing || "";
  };
  var handleEntered = function handleEntered2(node) {
    node.style.height = "auto";
  };
  var handleExit = function handleExit2(node) {
    node.style.height = getWrapperSize() + "px";
  };
  var handleExiting = function handleExiting2(node) {
    reflow(node);
    var _getTransitionProps2 = getTransitionProps({
      timeout,
      mode: "exit"
    }), transitionDuration = _getTransitionProps2.duration, easing = _getTransitionProps2.easing;
    node.style.transitionDuration = typeof transitionDuration === "string" ? transitionDuration : transitionDuration + "ms";
    node.style.height = collapsedSize;
    node.style.transitionTimingFunction = easing || "";
  };
  return reactExports.createElement(Transition, {
    "in": inProp,
    unmountOnExit: true,
    onEnter: handleEnter,
    onEntered: handleEntered,
    onEntering: handleEntering,
    onExit: handleExit,
    onExited,
    onExiting: handleExiting,
    nodeRef,
    timeout
  }, function(state, childProps) {
    return reactExports.createElement("div", Object.assign({
      ref: handleRef,
      className: clsx(classes.root, state === "entered" && classes.entered),
      style: _extends({
        pointerEvents: "all",
        overflow: "hidden",
        minHeight: collapsedSize,
        transition: createTransition("height")
      }, state === "entered" && {
        overflow: "visible"
      }, {}, state === "exited" && !inProp && {
        visibility: "hidden"
      })
    }, childProps), reactExports.createElement("div", {
      ref: wrapperRef,
      className: ComponentClasses.CollapseWrapper,
      // Hack to get children with a negative margin to not falsify the height computation.
      style: {
        display: "flex",
        width: "100%"
      }
    }, children));
  });
});
Collapse.displayName = "Collapse";
var direction = {
  right: "left",
  left: "right",
  bottom: "up",
  top: "down"
};
var getSlideDirection = function getSlideDirection2(anchorOrigin) {
  if (anchorOrigin.horizontal !== "center") {
    return direction[anchorOrigin.horizontal];
  }
  return direction[anchorOrigin.vertical];
};
var toSnackbarAnchorOrigin = function toSnackbarAnchorOrigin2(anchorOrigin) {
  return "anchorOrigin" + originKeyExtractor(anchorOrigin);
};
var keepSnackbarClassKeys = function keepSnackbarClassKeys2(classes2) {
  if (classes2 === void 0) {
    classes2 = {};
  }
  var containerClasses = {
    containerRoot: true,
    containerAnchorOriginTopCenter: true,
    containerAnchorOriginBottomCenter: true,
    containerAnchorOriginTopRight: true,
    containerAnchorOriginBottomRight: true,
    containerAnchorOriginTopLeft: true,
    containerAnchorOriginBottomLeft: true
  };
  return Object.keys(classes2).filter(function(key) {
    return !containerClasses[key];
  }).reduce(function(obj, key) {
    var _extends2;
    return _extends({}, obj, (_extends2 = {}, _extends2[key] = classes2[key], _extends2));
  }, {});
};
var noOp$1 = function noOp3() {
};
function createChainedFunction(funcs, snackbarId) {
  return funcs.reduce(function(acc, func) {
    if (func === null || func === void 0) {
      return acc;
    }
    return function chainedFunction() {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      var argums = [].concat(args);
      if (snackbarId && argums.indexOf(snackbarId) === -1) {
        argums.push(snackbarId);
      }
      acc.apply(this, argums);
      func.apply(this, argums);
    };
  }, noOp$1);
}
var useEnhancedEffect = typeof window !== "undefined" ? reactExports.useLayoutEffect : reactExports.useEffect;
function useEventCallback(fn2) {
  var ref = reactExports.useRef(fn2);
  useEnhancedEffect(function() {
    ref.current = fn2;
  });
  return reactExports.useCallback(function() {
    return (
      // @ts-expect-error hide `this`
      ref.current.apply(void 0, arguments)
    );
  }, []);
}
var Snackbar = /* @__PURE__ */ reactExports.forwardRef(function(props, ref) {
  var children = props.children, className = props.className, autoHideDuration = props.autoHideDuration, _props$disableWindowB = props.disableWindowBlurListener, disableWindowBlurListener = _props$disableWindowB === void 0 ? false : _props$disableWindowB, onClose = props.onClose, id = props.id, open = props.open, _props$SnackbarProps = props.SnackbarProps, SnackbarProps = _props$SnackbarProps === void 0 ? {} : _props$SnackbarProps;
  var timerAutoHide = reactExports.useRef();
  var handleClose = useEventCallback(function() {
    if (onClose) {
      onClose.apply(void 0, arguments);
    }
  });
  var setAutoHideTimer = useEventCallback(function(autoHideDurationParam) {
    if (!onClose || autoHideDurationParam == null) {
      return;
    }
    if (timerAutoHide.current) {
      clearTimeout(timerAutoHide.current);
    }
    timerAutoHide.current = setTimeout(function() {
      handleClose(null, "timeout", id);
    }, autoHideDurationParam);
  });
  reactExports.useEffect(function() {
    if (open) {
      setAutoHideTimer(autoHideDuration);
    }
    return function() {
      if (timerAutoHide.current) {
        clearTimeout(timerAutoHide.current);
      }
    };
  }, [open, autoHideDuration, setAutoHideTimer]);
  var handlePause = function handlePause2() {
    if (timerAutoHide.current) {
      clearTimeout(timerAutoHide.current);
    }
  };
  var handleResume = reactExports.useCallback(function() {
    if (autoHideDuration != null) {
      setAutoHideTimer(autoHideDuration * 0.5);
    }
  }, [autoHideDuration, setAutoHideTimer]);
  var handleMouseEnter = function handleMouseEnter2(event) {
    if (SnackbarProps.onMouseEnter) {
      SnackbarProps.onMouseEnter(event);
    }
    handlePause();
  };
  var handleMouseLeave = function handleMouseLeave2(event) {
    if (SnackbarProps.onMouseLeave) {
      SnackbarProps.onMouseLeave(event);
    }
    handleResume();
  };
  reactExports.useEffect(function() {
    if (!disableWindowBlurListener && open) {
      window.addEventListener("focus", handleResume);
      window.addEventListener("blur", handlePause);
      return function() {
        window.removeEventListener("focus", handleResume);
        window.removeEventListener("blur", handlePause);
      };
    }
    return void 0;
  }, [disableWindowBlurListener, handleResume, open]);
  return reactExports.createElement("div", Object.assign({
    ref
  }, SnackbarProps, {
    className: clsx(ComponentClasses.Snackbar, className),
    onMouseEnter: handleMouseEnter,
    onMouseLeave: handleMouseLeave
  }), children);
});
Snackbar.displayName = "Snackbar";
var _root;
var classes$1 = /* @__PURE__ */ makeStyles({
  root: (_root = {
    display: "flex",
    flexWrap: "wrap",
    flexGrow: 1
  }, _root[breakpoints.upSm] = {
    flexGrow: "initial",
    minWidth: "288px"
  }, _root)
});
var SnackbarContent = /* @__PURE__ */ reactExports.forwardRef(function(_ref, ref) {
  var className = _ref.className, props = _objectWithoutPropertiesLoose(_ref, ["className"]);
  return React.createElement("div", Object.assign({
    ref,
    className: clsx(classes$1.root, className)
  }, props));
});
SnackbarContent.displayName = "SnackbarContent";
var classes$2 = /* @__PURE__ */ makeStyles({
  root: {
    backgroundColor: "#313131",
    fontSize: "0.875rem",
    lineHeight: 1.43,
    letterSpacing: "0.01071em",
    color: "#fff",
    alignItems: "center",
    padding: "6px 16px",
    borderRadius: "4px",
    boxShadow: "0px 3px 5px -1px rgba(0,0,0,0.2),0px 6px 10px 0px rgba(0,0,0,0.14),0px 1px 18px 0px rgba(0,0,0,0.12)"
  },
  lessPadding: {
    paddingLeft: 8 * 2.5 + "px"
  },
  "default": {
    backgroundColor: "#313131"
  },
  success: {
    backgroundColor: "#43a047"
  },
  error: {
    backgroundColor: "#d32f2f"
  },
  warning: {
    backgroundColor: "#ff9800"
  },
  info: {
    backgroundColor: "#2196f3"
  },
  message: {
    display: "flex",
    alignItems: "center",
    padding: "8px 0"
  },
  action: {
    display: "flex",
    alignItems: "center",
    marginLeft: "auto",
    paddingLeft: "16px",
    marginRight: "-8px"
  }
});
var ariaDescribedby = "notistack-snackbar";
var MaterialDesignContent = /* @__PURE__ */ reactExports.forwardRef(function(props, forwardedRef) {
  var id = props.id, message = props.message, componentOrFunctionAction = props.action, iconVariant = props.iconVariant, variant = props.variant, hideIconVariant = props.hideIconVariant, style = props.style, className = props.className;
  var icon = iconVariant[variant];
  var action = componentOrFunctionAction;
  if (typeof action === "function") {
    action = action(id);
  }
  return React.createElement(SnackbarContent, {
    ref: forwardedRef,
    role: "alert",
    "aria-describedby": ariaDescribedby,
    style,
    className: clsx(ComponentClasses.MuiContent, ComponentClasses.MuiContentVariant(variant), classes$2.root, classes$2[variant], className, !hideIconVariant && icon && classes$2.lessPadding)
  }, React.createElement("div", {
    id: ariaDescribedby,
    className: classes$2.message
  }, !hideIconVariant ? icon : null, message), action && React.createElement("div", {
    className: classes$2.action
  }, action));
});
MaterialDesignContent.displayName = "MaterialDesignContent";
var MaterialDesignContent$1 = /* @__PURE__ */ reactExports.memo(MaterialDesignContent);
var styles = /* @__PURE__ */ makeStyles({
  wrappedRoot: {
    width: "100%",
    position: "relative",
    transform: "translateX(0)",
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    minWidth: "288px"
  }
});
var SnackbarItem = function SnackbarItem2(props) {
  var timeout2 = reactExports.useRef();
  var _useState = reactExports.useState(true), collapsed = _useState[0], setCollapsed = _useState[1];
  var handleClose = createChainedFunction([props.snack.onClose, props.onClose]);
  var handleEntered = function handleEntered2() {
    if (props.snack.requestClose) {
      handleClose(null, "instructed", props.snack.id);
    }
  };
  var handleExitedScreen = reactExports.useCallback(function() {
    timeout2.current = setTimeout(function() {
      setCollapsed(function(col) {
        return !col;
      });
    }, 125);
  }, []);
  reactExports.useEffect(function() {
    return function() {
      if (timeout2.current) {
        clearTimeout(timeout2.current);
      }
    };
  }, []);
  var snack = props.snack, allClasses = props.classes, _props$Component = props.Component, Component = _props$Component === void 0 ? MaterialDesignContent$1 : _props$Component;
  var classes2 = reactExports.useMemo(function() {
    return keepSnackbarClassKeys(allClasses);
  }, [allClasses]);
  var open = snack.open, SnackbarProps = snack.SnackbarProps, TransitionComponent = snack.TransitionComponent, TransitionProps = snack.TransitionProps, transitionDuration = snack.transitionDuration, disableWindowBlurListener = snack.disableWindowBlurListener, componentOrFunctionContent = snack.content, otherSnack = _objectWithoutPropertiesLoose(snack, ["open", "SnackbarProps", "TransitionComponent", "TransitionProps", "transitionDuration", "disableWindowBlurListener", "content", "entered", "requestClose", "onEnter", "onEntered", "onExit", "onExited"]);
  var transitionProps = _extends({
    direction: getSlideDirection(otherSnack.anchorOrigin),
    timeout: transitionDuration
  }, TransitionProps);
  var content = componentOrFunctionContent;
  if (typeof content === "function") {
    content = content(otherSnack.id, otherSnack.message);
  }
  var callbacks = ["onEnter", "onEntered", "onExit", "onExited"].reduce(function(acc, cbName) {
    var _extends2;
    return _extends({}, acc, (_extends2 = {}, _extends2[cbName] = createChainedFunction([props.snack[cbName], props[cbName]], otherSnack.id), _extends2));
  }, {});
  return React.createElement(Collapse, {
    "in": collapsed,
    onExited: callbacks.onExited
  }, React.createElement(Snackbar, {
    open,
    id: otherSnack.id,
    disableWindowBlurListener,
    autoHideDuration: otherSnack.autoHideDuration,
    className: clsx(styles.wrappedRoot, classes2.root, classes2[toSnackbarAnchorOrigin(otherSnack.anchorOrigin)]),
    SnackbarProps,
    onClose: handleClose
  }, React.createElement(TransitionComponent, Object.assign({}, transitionProps, {
    appear: true,
    "in": open,
    onExit: callbacks.onExit,
    onExited: handleExitedScreen,
    onEnter: callbacks.onEnter,
    // order matters. first callbacks.onEntered to set entered: true,
    // then handleEntered to check if there's a request for closing
    onEntered: createChainedFunction([callbacks.onEntered, handleEntered], otherSnack.id)
  }), content || React.createElement(Component, Object.assign({}, otherSnack)))));
};
var _root$1, _rootDense, _left, _right, _center;
var indents = {
  view: {
    "default": 20,
    dense: 4
  },
  snackbar: {
    "default": 6,
    dense: 2
  }
};
var collapseWrapper = "." + ComponentClasses.CollapseWrapper;
var xsWidthMargin = 16;
var styles$1 = /* @__PURE__ */ makeStyles({
  root: (_root$1 = {
    boxSizing: "border-box",
    display: "flex",
    maxHeight: "100%",
    position: "fixed",
    zIndex: 1400,
    height: "auto",
    width: "auto",
    transition: /* @__PURE__ */ createTransition(["top", "right", "bottom", "left", "max-width"], {
      duration: 300,
      easing: "ease"
    }),
    // container itself is invisible and should not block clicks, clicks should be passed to its children
    // a pointerEvents: all is applied in the collapse component
    pointerEvents: "none"
  }, _root$1[collapseWrapper] = {
    padding: indents.snackbar["default"] + "px 0px",
    transition: "padding 300ms ease 0ms"
  }, _root$1.maxWidth = "calc(100% - " + indents.view["default"] * 2 + "px)", _root$1[breakpoints.downXs] = {
    width: "100%",
    maxWidth: "calc(100% - " + xsWidthMargin * 2 + "px)"
  }, _root$1),
  rootDense: (_rootDense = {}, _rootDense[collapseWrapper] = {
    padding: indents.snackbar.dense + "px 0px"
  }, _rootDense),
  top: {
    top: indents.view["default"] - indents.snackbar["default"] + "px",
    flexDirection: "column"
  },
  bottom: {
    bottom: indents.view["default"] - indents.snackbar["default"] + "px",
    flexDirection: "column-reverse"
  },
  left: (_left = {
    left: indents.view["default"] + "px"
  }, _left[breakpoints.upSm] = {
    alignItems: "flex-start"
  }, _left[breakpoints.downXs] = {
    left: xsWidthMargin + "px"
  }, _left),
  right: (_right = {
    right: indents.view["default"] + "px"
  }, _right[breakpoints.upSm] = {
    alignItems: "flex-end"
  }, _right[breakpoints.downXs] = {
    right: xsWidthMargin + "px"
  }, _right),
  center: (_center = {
    left: "50%",
    transform: "translateX(-50%)"
  }, _center[breakpoints.upSm] = {
    alignItems: "center"
  }, _center)
});
var SnackbarContainer = function SnackbarContainer2(props) {
  var _props$classes = props.classes, classes2 = _props$classes === void 0 ? {} : _props$classes, anchorOrigin = props.anchorOrigin, dense = props.dense, children = props.children;
  var combinedClassname = clsx(
    ComponentClasses.SnackbarContainer,
    styles$1[anchorOrigin.vertical],
    styles$1[anchorOrigin.horizontal],
    styles$1.root,
    // root should come after others to override maxWidth
    classes2.containerRoot,
    classes2["containerAnchorOrigin" + originKeyExtractor(anchorOrigin)],
    dense && styles$1.rootDense
  );
  return React.createElement("div", {
    className: combinedClassname
  }, children);
};
var SnackbarContainer$1 = /* @__PURE__ */ reactExports.memo(SnackbarContainer);
var isOptions = function isOptions2(messageOrOptions) {
  var isMessage = typeof messageOrOptions === "string" || reactExports.isValidElement(messageOrOptions);
  return !isMessage;
};
var enqueueSnackbar;
var SnackbarProvider = /* @__PURE__ */ function(_Component) {
  _inheritsLoose(SnackbarProvider2, _Component);
  function SnackbarProvider2(props) {
    var _this;
    _this = _Component.call(this, props) || this;
    _this.enqueueSnackbar = function(messageOrOptions, optsOrUndefined) {
      if (optsOrUndefined === void 0) {
        optsOrUndefined = {};
      }
      if (messageOrOptions === void 0 || messageOrOptions === null) {
        throw new Error("enqueueSnackbar called with invalid argument");
      }
      var opts = isOptions(messageOrOptions) ? messageOrOptions : optsOrUndefined;
      var message = isOptions(messageOrOptions) ? messageOrOptions.message : messageOrOptions;
      var key = opts.key, preventDuplicate = opts.preventDuplicate, options = _objectWithoutPropertiesLoose(opts, ["key", "preventDuplicate"]);
      var hasSpecifiedKey = isDefined(key);
      var id = hasSpecifiedKey ? key : (/* @__PURE__ */ new Date()).getTime() + Math.random();
      var merger = merge(options, _this.props);
      var snack = _extends({
        id
      }, options, {
        message,
        open: true,
        entered: false,
        requestClose: false,
        persist: merger("persist"),
        action: merger("action"),
        content: merger("content"),
        variant: merger("variant"),
        anchorOrigin: merger("anchorOrigin"),
        disableWindowBlurListener: merger("disableWindowBlurListener"),
        autoHideDuration: merger("autoHideDuration"),
        hideIconVariant: merger("hideIconVariant"),
        TransitionComponent: merger("TransitionComponent"),
        transitionDuration: merger("transitionDuration"),
        TransitionProps: merger("TransitionProps", true),
        iconVariant: merger("iconVariant", true),
        style: merger("style", true),
        SnackbarProps: merger("SnackbarProps", true),
        className: clsx(_this.props.className, options.className)
      });
      if (snack.persist) {
        snack.autoHideDuration = void 0;
      }
      _this.setState(function(state) {
        if (preventDuplicate === void 0 && _this.props.preventDuplicate || preventDuplicate) {
          var compareFunction = function compareFunction2(item) {
            return hasSpecifiedKey ? item.id === id : item.message === message;
          };
          var inQueue = state.queue.findIndex(compareFunction) > -1;
          var inView = state.snacks.findIndex(compareFunction) > -1;
          if (inQueue || inView) {
            return state;
          }
        }
        return _this.handleDisplaySnack(_extends({}, state, {
          queue: [].concat(state.queue, [snack])
        }));
      });
      return id;
    };
    _this.handleDisplaySnack = function(state) {
      var snacks = state.snacks;
      if (snacks.length >= _this.maxSnack) {
        return _this.handleDismissOldest(state);
      }
      return _this.processQueue(state);
    };
    _this.processQueue = function(state) {
      var queue = state.queue, snacks = state.snacks;
      if (queue.length > 0) {
        return _extends({}, state, {
          snacks: [].concat(snacks, [queue[0]]),
          queue: queue.slice(1, queue.length)
        });
      }
      return state;
    };
    _this.handleDismissOldest = function(state) {
      if (state.snacks.some(function(item) {
        return !item.open || item.requestClose;
      })) {
        return state;
      }
      var popped = false;
      var ignore = false;
      var persistentCount = state.snacks.reduce(function(acc, current) {
        return acc + (current.open && current.persist ? 1 : 0);
      }, 0);
      if (persistentCount === _this.maxSnack) {
        ignore = true;
      }
      var snacks = state.snacks.map(function(item) {
        if (!popped && (!item.persist || ignore)) {
          popped = true;
          if (!item.entered) {
            return _extends({}, item, {
              requestClose: true
            });
          }
          if (item.onClose) {
            item.onClose(null, "maxsnack", item.id);
          }
          if (_this.props.onClose) {
            _this.props.onClose(null, "maxsnack", item.id);
          }
          return _extends({}, item, {
            open: false
          });
        }
        return _extends({}, item);
      });
      return _extends({}, state, {
        snacks
      });
    };
    _this.handleEnteredSnack = function(node, isAppearing, key) {
      if (!isDefined(key)) {
        throw new Error("handleEnteredSnack Cannot be called with undefined key");
      }
      _this.setState(function(_ref) {
        var snacks = _ref.snacks;
        return {
          snacks: snacks.map(function(item) {
            return item.id === key ? _extends({}, item, {
              entered: true
            }) : _extends({}, item);
          })
        };
      });
    };
    _this.handleCloseSnack = function(event, reason, key) {
      if (_this.props.onClose) {
        _this.props.onClose(event, reason, key);
      }
      var shouldCloseAll = key === void 0;
      _this.setState(function(_ref2) {
        var snacks = _ref2.snacks, queue = _ref2.queue;
        return {
          snacks: snacks.map(function(item) {
            if (!shouldCloseAll && item.id !== key) {
              return _extends({}, item);
            }
            return item.entered ? _extends({}, item, {
              open: false
            }) : _extends({}, item, {
              requestClose: true
            });
          }),
          queue: queue.filter(function(item) {
            return item.id !== key;
          })
        };
      });
    };
    _this.closeSnackbar = function(key) {
      var toBeClosed = _this.state.snacks.find(function(item) {
        return item.id === key;
      });
      if (isDefined(key) && toBeClosed && toBeClosed.onClose) {
        toBeClosed.onClose(null, "instructed", key);
      }
      _this.handleCloseSnack(null, "instructed", key);
    };
    _this.handleExitedSnack = function(node, key) {
      if (!isDefined(key)) {
        throw new Error("handleExitedSnack Cannot be called with undefined key");
      }
      _this.setState(function(state) {
        var newState = _this.processQueue(_extends({}, state, {
          snacks: state.snacks.filter(function(item) {
            return item.id !== key;
          })
        }));
        if (newState.queue.length === 0) {
          return newState;
        }
        return _this.handleDismissOldest(newState);
      });
    };
    enqueueSnackbar = _this.enqueueSnackbar;
    _this.closeSnackbar;
    _this.state = {
      snacks: [],
      queue: [],
      contextValue: {
        enqueueSnackbar: _this.enqueueSnackbar.bind(_assertThisInitialized(_this)),
        closeSnackbar: _this.closeSnackbar.bind(_assertThisInitialized(_this))
      }
    };
    return _this;
  }
  var _proto = SnackbarProvider2.prototype;
  _proto.render = function render() {
    var _this2 = this;
    var contextValue = this.state.contextValue;
    var _this$props = this.props, domRoot = _this$props.domRoot, children = _this$props.children, _this$props$dense = _this$props.dense, dense = _this$props$dense === void 0 ? false : _this$props$dense, _this$props$Component = _this$props.Components, Components = _this$props$Component === void 0 ? {} : _this$props$Component, classes2 = _this$props.classes;
    var categ = this.state.snacks.reduce(function(acc, current) {
      var _extends2;
      var category = originKeyExtractor(current.anchorOrigin);
      var existingOfCategory = acc[category] || [];
      return _extends({}, acc, (_extends2 = {}, _extends2[category] = [].concat(existingOfCategory, [current]), _extends2));
    }, {});
    var snackbars = Object.keys(categ).map(function(origin) {
      var snacks = categ[origin];
      var nomineeSnack = snacks[0];
      return React.createElement(SnackbarContainer$1, {
        key: origin,
        dense,
        anchorOrigin: nomineeSnack.anchorOrigin,
        classes: classes2
      }, snacks.map(function(snack) {
        return React.createElement(SnackbarItem, {
          key: snack.id,
          snack,
          classes: classes2,
          Component: Components[snack.variant],
          onClose: _this2.handleCloseSnack,
          onEnter: _this2.props.onEnter,
          onExit: _this2.props.onExit,
          onExited: createChainedFunction([_this2.handleExitedSnack, _this2.props.onExited], snack.id),
          onEntered: createChainedFunction([_this2.handleEnteredSnack, _this2.props.onEntered], snack.id)
        });
      }));
    });
    return React.createElement(SnackbarContext.Provider, {
      value: contextValue
    }, children, domRoot ? reactDomExports.createPortal(snackbars, domRoot) : snackbars);
  };
  _createClass(SnackbarProvider2, [{
    key: "maxSnack",
    get: function get() {
      return this.props.maxSnack || defaults.maxSnack;
    }
  }]);
  return SnackbarProvider2;
}(reactExports.Component);
var Cancel = {};
var interopRequireDefault = { exports: {} };
(function(module) {
  function _interopRequireDefault2(obj) {
    return obj && obj.__esModule ? obj : {
      "default": obj
    };
  }
  module.exports = _interopRequireDefault2, module.exports.__esModule = true, module.exports["default"] = module.exports;
})(interopRequireDefault);
var interopRequireDefaultExports = interopRequireDefault.exports;
var createSvgIcon = {};
const unstable_ClassNameGenerator = {
  configure: (generator) => {
    ClassNameGenerator.configure(generator);
  }
};
const utils = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  capitalize,
  createChainedFunction: createChainedFunction$1,
  createSvgIcon: createSvgIcon$1,
  debounce: debounce$2,
  deprecatedPropType,
  isMuiElement,
  ownerDocument: ownerDocument$1,
  ownerWindow: ownerWindow$1,
  requirePropFactory,
  setRef: setRef$1,
  unstable_ClassNameGenerator,
  unstable_useEnhancedEffect: useEnhancedEffect$1,
  unstable_useId: useId,
  unsupportedProp,
  useControlled,
  useEventCallback: useEventCallback$1,
  useForkRef: useForkRef$1,
  useIsFocusVisible
}, Symbol.toStringTag, { value: "Module" }));
const require$$0 = /* @__PURE__ */ getAugmentedNamespace(utils);
var hasRequiredCreateSvgIcon;
function requireCreateSvgIcon() {
  if (hasRequiredCreateSvgIcon)
    return createSvgIcon;
  hasRequiredCreateSvgIcon = 1;
  (function(exports) {
    "use client";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    Object.defineProperty(exports, "default", {
      enumerable: true,
      get: function() {
        return _utils.createSvgIcon;
      }
    });
    var _utils = require$$0;
  })(createSvgIcon);
  return createSvgIcon;
}
var _interopRequireDefault$3 = interopRequireDefaultExports;
Object.defineProperty(Cancel, "__esModule", {
  value: true
});
var default_1$3 = Cancel.default = void 0;
var _createSvgIcon$3 = _interopRequireDefault$3(requireCreateSvgIcon());
var _jsxRuntime$3 = jsxRuntimeExports;
var _default$3 = (0, _createSvgIcon$3.default)(/* @__PURE__ */ (0, _jsxRuntime$3.jsx)("path", {
  d: "M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"
}), "Cancel");
default_1$3 = Cancel.default = _default$3;
var Delete = {};
var _interopRequireDefault$2 = interopRequireDefaultExports;
Object.defineProperty(Delete, "__esModule", {
  value: true
});
var default_1$2 = Delete.default = void 0;
var _createSvgIcon$2 = _interopRequireDefault$2(requireCreateSvgIcon());
var _jsxRuntime$2 = jsxRuntimeExports;
var _default$2 = (0, _createSvgIcon$2.default)(/* @__PURE__ */ (0, _jsxRuntime$2.jsx)("path", {
  d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"
}), "Delete");
default_1$2 = Delete.default = _default$2;
var Edit = {};
var _interopRequireDefault$1 = interopRequireDefaultExports;
Object.defineProperty(Edit, "__esModule", {
  value: true
});
var default_1$1 = Edit.default = void 0;
var _createSvgIcon$1 = _interopRequireDefault$1(requireCreateSvgIcon());
var _jsxRuntime$1 = jsxRuntimeExports;
var _default$1 = (0, _createSvgIcon$1.default)(/* @__PURE__ */ (0, _jsxRuntime$1.jsx)("path", {
  d: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"
}), "Edit");
default_1$1 = Edit.default = _default$1;
var Save = {};
var _interopRequireDefault = interopRequireDefaultExports;
Object.defineProperty(Save, "__esModule", {
  value: true
});
var default_1 = Save.default = void 0;
var _createSvgIcon = _interopRequireDefault(requireCreateSvgIcon());
var _jsxRuntime = jsxRuntimeExports;
var _default = (0, _createSvgIcon.default)(/* @__PURE__ */ (0, _jsxRuntime.jsx)("path", {
  d: "M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"
}), "Save");
default_1 = Save.default = _default;
function getUnit(input) {
  return String(input).match(/[\d.\-+]*\s*(.*)/)[1] || "";
}
function toUnitless(length) {
  return parseFloat(length);
}
const GridApiContext = /* @__PURE__ */ reactExports.createContext(void 0);
function useGridApiContext() {
  const apiRef2 = reactExports.useContext(GridApiContext);
  if (apiRef2 === void 0) {
    throw new Error(["MUI: Could not find the data grid context.", "It looks like you rendered your component outside of a DataGrid, DataGridPro or DataGridPremium parent component.", "This can also happen if you are bundling multiple versions of the data grid."].join("\n"));
  }
  return apiRef2;
}
const useGridApiRef = () => reactExports.useRef({});
const GridRootPropsContext = /* @__PURE__ */ reactExports.createContext(void 0);
const useGridRootProps = () => {
  const contextValue = reactExports.useContext(GridRootPropsContext);
  if (!contextValue) {
    throw new Error("MUI: useGridRootProps should only be used inside the DataGrid, DataGridPro or DataGridPremium component.");
  }
  return contextValue;
};
const GridPrivateApiContext = /* @__PURE__ */ reactExports.createContext(void 0);
function useGridPrivateApiContext() {
  const privateApiRef = reactExports.useContext(GridPrivateApiContext);
  if (privateApiRef === void 0) {
    throw new Error(["MUI: Could not find the data grid private context.", "It looks like you rendered your component outside of a DataGrid, DataGridPro or DataGridPremium parent component.", "This can also happen if you are bundling multiple versions of the data grid."].join("\n"));
  }
  return privateApiRef;
}
const UNINITIALIZED = {};
function useLazyRef(init, initArg) {
  const ref = reactExports.useRef(UNINITIALIZED);
  if (ref.current === UNINITIALIZED) {
    ref.current = init(initArg);
  }
  return ref;
}
const EMPTY = [];
function useOnMount(fn2) {
  reactExports.useEffect(fn2, EMPTY);
}
const buildWarning = (message, gravity = "warning") => {
  let alreadyWarned = false;
  const cleanMessage = Array.isArray(message) ? message.join("\n") : message;
  return () => {
    if (!alreadyWarned) {
      alreadyWarned = true;
      if (gravity === "error") {
        console.error(cleanMessage);
      } else {
        console.warn(cleanMessage);
      }
    }
  };
};
const is = Object.is;
function fastObjectShallowCompare(a2, b) {
  if (a2 === b) {
    return true;
  }
  if (!(a2 instanceof Object) || !(b instanceof Object)) {
    return false;
  }
  let aLength = 0;
  let bLength = 0;
  for (const key in a2) {
    aLength += 1;
    if (!is(a2[key], b[key])) {
      return false;
    }
    if (!(key in b)) {
      return false;
    }
  }
  for (const _2 in b) {
    bLength += 1;
  }
  return aLength === bLength;
}
buildWarning(["MUI: `useGridSelector` has been called before the initialization of the state.", "This hook can only be used inside the context of the grid."]);
function isOutputSelector(selector) {
  return selector.acceptsApiRef;
}
function applySelector(apiRef2, selector) {
  if (isOutputSelector(selector)) {
    return selector(apiRef2);
  }
  return selector(apiRef2.current.state);
}
const defaultCompare = Object.is;
const objectShallowCompare = fastObjectShallowCompare;
const createRefs = () => ({
  state: null,
  equals: null,
  selector: null
});
const useGridSelector = (apiRef2, selector, equals = defaultCompare) => {
  const refs = useLazyRef(createRefs);
  const didInit = refs.current.selector !== null;
  const [state, setState] = reactExports.useState(
    // We don't use an initialization function to avoid allocations
    didInit ? null : applySelector(apiRef2, selector)
  );
  refs.current.state = state;
  refs.current.equals = equals;
  refs.current.selector = selector;
  useOnMount(() => {
    return apiRef2.current.store.subscribe(() => {
      const newState = applySelector(apiRef2, refs.current.selector);
      if (!refs.current.equals(refs.current.state, newState)) {
        refs.current.state = newState;
        setState(newState);
      }
    });
  });
  return state;
};
function getDataGridUtilityClass(slot) {
  return generateUtilityClass("MuiDataGrid", slot);
}
const gridClasses = generateUtilityClasses("MuiDataGrid", ["actionsCell", "aggregationColumnHeader", "aggregationColumnHeader--alignLeft", "aggregationColumnHeader--alignCenter", "aggregationColumnHeader--alignRight", "aggregationColumnHeaderLabel", "autoHeight", "booleanCell", "cell--editable", "cell--editing", "cell--textCenter", "cell--textLeft", "cell--textRight", "cell--withRenderer", "cell--rangeTop", "cell--rangeBottom", "cell--rangeLeft", "cell--rangeRight", "cell", "cellContent", "cellCheckbox", "cellSkeleton", "checkboxInput", "columnHeader--alignCenter", "columnHeader--alignLeft", "columnHeader--alignRight", "columnHeader--dragging", "columnHeader--moving", "columnHeader--numeric", "columnHeader--sortable", "columnHeader--sorted", "columnHeader--filtered", "columnHeader", "columnHeaderCheckbox", "columnHeaderDraggableContainer", "columnHeaderDropZone", "columnHeaderTitle", "columnHeaderTitleContainer", "columnHeaderTitleContainerContent", "columnGroupHeader", "columnHeader--filledGroup", "columnHeader--emptyGroup", "columnHeader--showColumnBorder", "columnHeaders", "columnHeadersInner", "columnHeadersInner--scrollable", "columnSeparator--resizable", "columnSeparator--resizing", "columnSeparator--sideLeft", "columnSeparator--sideRight", "columnSeparator", "columnsPanel", "columnsPanelRow", "detailPanel", "detailPanels", "detailPanelToggleCell", "detailPanelToggleCell--expanded", "footerCell", "panel", "panelHeader", "panelWrapper", "panelContent", "panelFooter", "paper", "editBooleanCell", "editInputCell", "filterForm", "filterFormDeleteIcon", "filterFormLogicOperatorInput", "filterFormColumnInput", "filterFormOperatorInput", "filterFormValueInput", "filterIcon", "footerContainer", "headerFilterRow", "iconButtonContainer", "iconSeparator", "main", "menu", "menuIcon", "menuIconButton", "menuOpen", "menuList", "overlay", "overlayWrapper", "overlayWrapperInner", "root", "root--densityStandard", "root--densityComfortable", "root--densityCompact", "root--disableUserSelection", "row", "row--editable", "row--editing", "row--lastVisible", "row--dragging", "row--dynamicHeight", "row--detailPanelExpanded", "rowReorderCellPlaceholder", "rowCount", "rowReorderCellContainer", "rowReorderCell", "rowReorderCell--draggable", "scrollArea--left", "scrollArea--right", "scrollArea", "selectedRowCount", "sortIcon", "toolbarContainer", "toolbarFilterList", "virtualScroller", "virtualScrollerContent", "virtualScrollerContent--overflowed", "virtualScrollerRenderZone", "pinnedColumns", "pinnedColumns--left", "pinnedColumns--right", "pinnedColumnHeaders", "pinnedColumnHeaders--left", "pinnedColumnHeaders--right", "withBorderColor", "cell--withRightBorder", "columnHeader--withRightBorder", "treeDataGroupingCell", "treeDataGroupingCellToggle", "groupingCriteriaCell", "groupingCriteriaCellToggle", "pinnedRows", "pinnedRows--top", "pinnedRows--bottom", "pinnedRowsRenderZone"]);
var NOT_FOUND = "NOT_FOUND";
function createSingletonCache(equals) {
  var entry;
  return {
    get: function get(key) {
      if (entry && equals(entry.key, key)) {
        return entry.value;
      }
      return NOT_FOUND;
    },
    put: function put(key, value) {
      entry = {
        key,
        value
      };
    },
    getEntries: function getEntries() {
      return entry ? [entry] : [];
    },
    clear: function clear() {
      entry = void 0;
    }
  };
}
function createLruCache(maxSize, equals) {
  var entries = [];
  function get(key) {
    var cacheIndex = entries.findIndex(function(entry2) {
      return equals(key, entry2.key);
    });
    if (cacheIndex > -1) {
      var entry = entries[cacheIndex];
      if (cacheIndex > 0) {
        entries.splice(cacheIndex, 1);
        entries.unshift(entry);
      }
      return entry.value;
    }
    return NOT_FOUND;
  }
  function put(key, value) {
    if (get(key) === NOT_FOUND) {
      entries.unshift({
        key,
        value
      });
      if (entries.length > maxSize) {
        entries.pop();
      }
    }
  }
  function getEntries() {
    return entries;
  }
  function clear() {
    entries = [];
  }
  return {
    get,
    put,
    getEntries,
    clear
  };
}
var defaultEqualityCheck = function defaultEqualityCheck2(a2, b) {
  return a2 === b;
};
function createCacheKeyComparator(equalityCheck) {
  return function areArgumentsShallowlyEqual(prev, next) {
    if (prev === null || next === null || prev.length !== next.length) {
      return false;
    }
    var length = prev.length;
    for (var i2 = 0; i2 < length; i2++) {
      if (!equalityCheck(prev[i2], next[i2])) {
        return false;
      }
    }
    return true;
  };
}
function defaultMemoize(func, equalityCheckOrOptions) {
  var providedOptions = typeof equalityCheckOrOptions === "object" ? equalityCheckOrOptions : {
    equalityCheck: equalityCheckOrOptions
  };
  var _providedOptions$equa = providedOptions.equalityCheck, equalityCheck = _providedOptions$equa === void 0 ? defaultEqualityCheck : _providedOptions$equa, _providedOptions$maxS = providedOptions.maxSize, maxSize = _providedOptions$maxS === void 0 ? 1 : _providedOptions$maxS, resultEqualityCheck = providedOptions.resultEqualityCheck;
  var comparator = createCacheKeyComparator(equalityCheck);
  var cache = maxSize === 1 ? createSingletonCache(comparator) : createLruCache(maxSize, comparator);
  function memoized() {
    var value = cache.get(arguments);
    if (value === NOT_FOUND) {
      value = func.apply(null, arguments);
      if (resultEqualityCheck) {
        var entries = cache.getEntries();
        var matchingEntry = entries.find(function(entry) {
          return resultEqualityCheck(entry.value, value);
        });
        if (matchingEntry) {
          value = matchingEntry.value;
        }
      }
      cache.put(arguments, value);
    }
    return value;
  }
  memoized.clearCache = function() {
    return cache.clear();
  };
  return memoized;
}
function getDependencies(funcs) {
  var dependencies = Array.isArray(funcs[0]) ? funcs[0] : funcs;
  if (!dependencies.every(function(dep) {
    return typeof dep === "function";
  })) {
    var dependencyTypes = dependencies.map(function(dep) {
      return typeof dep === "function" ? "function " + (dep.name || "unnamed") + "()" : typeof dep;
    }).join(", ");
    throw new Error("createSelector expects all input-selectors to be functions, but received the following types: [" + dependencyTypes + "]");
  }
  return dependencies;
}
function createSelectorCreator(memoize) {
  for (var _len = arguments.length, memoizeOptionsFromArgs = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    memoizeOptionsFromArgs[_key - 1] = arguments[_key];
  }
  var createSelector2 = function createSelector3() {
    for (var _len2 = arguments.length, funcs = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      funcs[_key2] = arguments[_key2];
    }
    var _recomputations = 0;
    var _lastResult;
    var directlyPassedOptions = {
      memoizeOptions: void 0
    };
    var resultFunc = funcs.pop();
    if (typeof resultFunc === "object") {
      directlyPassedOptions = resultFunc;
      resultFunc = funcs.pop();
    }
    if (typeof resultFunc !== "function") {
      throw new Error("createSelector expects an output function after the inputs, but received: [" + typeof resultFunc + "]");
    }
    var _directlyPassedOption = directlyPassedOptions, _directlyPassedOption2 = _directlyPassedOption.memoizeOptions, memoizeOptions = _directlyPassedOption2 === void 0 ? memoizeOptionsFromArgs : _directlyPassedOption2;
    var finalMemoizeOptions = Array.isArray(memoizeOptions) ? memoizeOptions : [memoizeOptions];
    var dependencies = getDependencies(funcs);
    var memoizedResultFunc = memoize.apply(void 0, [function recomputationWrapper() {
      _recomputations++;
      return resultFunc.apply(null, arguments);
    }].concat(finalMemoizeOptions));
    var selector = memoize(function dependenciesChecker() {
      var params = [];
      var length = dependencies.length;
      for (var i2 = 0; i2 < length; i2++) {
        params.push(dependencies[i2].apply(null, arguments));
      }
      _lastResult = memoizedResultFunc.apply(null, params);
      return _lastResult;
    });
    Object.assign(selector, {
      resultFunc,
      memoizedResultFunc,
      dependencies,
      lastResult: function lastResult() {
        return _lastResult;
      },
      recomputations: function recomputations() {
        return _recomputations;
      },
      resetRecomputations: function resetRecomputations() {
        return _recomputations = 0;
      }
    });
    return selector;
  };
  return createSelector2;
}
var createSelector$1 = /* @__PURE__ */ createSelectorCreator(defaultMemoize);
const cacheContainer = {
  cache: /* @__PURE__ */ new WeakMap()
};
buildWarning(["MUI: A selector was called without passing the instance ID, which may impact the performance of the grid.", "To fix, call it with `apiRef`, e.g. `mySelector(apiRef)`, or pass the instance ID explicitly, e.g. `mySelector(state, apiRef.current.instanceId)`."]);
function checkIsAPIRef(value) {
  return "current" in value && "instanceId" in value.current;
}
const DEFAULT_INSTANCE_ID = {
  id: "default"
};
const createSelector = (a2, b, c2, d, e2, f, ...rest) => {
  if (rest.length > 0) {
    throw new Error("Unsupported number of selectors");
  }
  let selector;
  if (a2 && b && c2 && d && e2 && f) {
    selector = (stateOrApiRef, instanceIdParam) => {
      const isAPIRef = checkIsAPIRef(stateOrApiRef);
      const instanceId = instanceIdParam != null ? instanceIdParam : isAPIRef ? stateOrApiRef.current.instanceId : DEFAULT_INSTANCE_ID;
      const state = isAPIRef ? stateOrApiRef.current.state : stateOrApiRef;
      const va = a2(state, instanceId);
      const vb = b(state, instanceId);
      const vc = c2(state, instanceId);
      const vd = d(state, instanceId);
      const ve = e2(state, instanceId);
      return f(va, vb, vc, vd, ve);
    };
  } else if (a2 && b && c2 && d && e2) {
    selector = (stateOrApiRef, instanceIdParam) => {
      const isAPIRef = checkIsAPIRef(stateOrApiRef);
      const instanceId = instanceIdParam != null ? instanceIdParam : isAPIRef ? stateOrApiRef.current.instanceId : DEFAULT_INSTANCE_ID;
      const state = isAPIRef ? stateOrApiRef.current.state : stateOrApiRef;
      const va = a2(state, instanceId);
      const vb = b(state, instanceId);
      const vc = c2(state, instanceId);
      const vd = d(state, instanceId);
      return e2(va, vb, vc, vd);
    };
  } else if (a2 && b && c2 && d) {
    selector = (stateOrApiRef, instanceIdParam) => {
      const isAPIRef = checkIsAPIRef(stateOrApiRef);
      const instanceId = instanceIdParam != null ? instanceIdParam : isAPIRef ? stateOrApiRef.current.instanceId : DEFAULT_INSTANCE_ID;
      const state = isAPIRef ? stateOrApiRef.current.state : stateOrApiRef;
      const va = a2(state, instanceId);
      const vb = b(state, instanceId);
      const vc = c2(state, instanceId);
      return d(va, vb, vc);
    };
  } else if (a2 && b && c2) {
    selector = (stateOrApiRef, instanceIdParam) => {
      const isAPIRef = checkIsAPIRef(stateOrApiRef);
      const instanceId = instanceIdParam != null ? instanceIdParam : isAPIRef ? stateOrApiRef.current.instanceId : DEFAULT_INSTANCE_ID;
      const state = isAPIRef ? stateOrApiRef.current.state : stateOrApiRef;
      const va = a2(state, instanceId);
      const vb = b(state, instanceId);
      return c2(va, vb);
    };
  } else if (a2 && b) {
    selector = (stateOrApiRef, instanceIdParam) => {
      const isAPIRef = checkIsAPIRef(stateOrApiRef);
      const instanceId = instanceIdParam != null ? instanceIdParam : isAPIRef ? stateOrApiRef.current.instanceId : DEFAULT_INSTANCE_ID;
      const state = isAPIRef ? stateOrApiRef.current.state : stateOrApiRef;
      const va = a2(state, instanceId);
      return b(va);
    };
  } else {
    throw new Error("Missing arguments");
  }
  selector.acceptsApiRef = true;
  return selector;
};
const createSelectorMemoized = (...args) => {
  const selector = (...selectorArgs) => {
    var _cache$get, _cache$get3;
    const [stateOrApiRef, instanceId] = selectorArgs;
    const isAPIRef = checkIsAPIRef(stateOrApiRef);
    const cacheKey = isAPIRef ? stateOrApiRef.current.instanceId : instanceId != null ? instanceId : DEFAULT_INSTANCE_ID;
    const state = isAPIRef ? stateOrApiRef.current.state : stateOrApiRef;
    const {
      cache
    } = cacheContainer;
    if (cache.get(cacheKey) && (_cache$get = cache.get(cacheKey)) != null && _cache$get.get(args)) {
      var _cache$get2;
      return (_cache$get2 = cache.get(cacheKey)) == null ? void 0 : _cache$get2.get(args)(state, cacheKey);
    }
    const newSelector = createSelector$1(...args);
    if (!cache.get(cacheKey)) {
      cache.set(cacheKey, /* @__PURE__ */ new Map());
    }
    (_cache$get3 = cache.get(cacheKey)) == null || _cache$get3.set(args, newSelector);
    return newSelector(state, cacheKey);
  };
  selector.acceptsApiRef = true;
  return selector;
};
const gridColumnsStateSelector = (state) => state.columns;
const gridColumnFieldsSelector = createSelector(gridColumnsStateSelector, (columnsState) => columnsState.orderedFields);
const gridColumnLookupSelector = createSelector(gridColumnsStateSelector, (columnsState) => columnsState.lookup);
const gridColumnDefinitionsSelector = createSelectorMemoized(gridColumnFieldsSelector, gridColumnLookupSelector, (allFields, lookup) => allFields.map((field) => lookup[field]));
const gridColumnVisibilityModelSelector = createSelector(gridColumnsStateSelector, (columnsState) => columnsState.columnVisibilityModel);
const gridVisibleColumnDefinitionsSelector = createSelectorMemoized(gridColumnDefinitionsSelector, gridColumnVisibilityModelSelector, (columns, columnVisibilityModel) => columns.filter((column) => columnVisibilityModel[column.field] !== false));
const gridVisibleColumnFieldsSelector = createSelectorMemoized(gridVisibleColumnDefinitionsSelector, (visibleColumns) => visibleColumns.map((column) => column.field));
const gridColumnPositionsSelector = createSelectorMemoized(gridVisibleColumnDefinitionsSelector, (visibleColumns) => {
  const positions = [];
  let currentPosition = 0;
  for (let i2 = 0; i2 < visibleColumns.length; i2 += 1) {
    positions.push(currentPosition);
    currentPosition += visibleColumns[i2].computedWidth;
  }
  return positions;
});
const gridColumnsTotalWidthSelector = createSelector(gridVisibleColumnDefinitionsSelector, gridColumnPositionsSelector, (visibleColumns, positions) => {
  const colCount = visibleColumns.length;
  if (colCount === 0) {
    return 0;
  }
  return positions[colCount - 1] + visibleColumns[colCount - 1].computedWidth;
});
const gridFilterableColumnDefinitionsSelector = createSelectorMemoized(gridColumnDefinitionsSelector, (columns) => columns.filter((col) => col.filterable));
const gridFilterableColumnLookupSelector = createSelectorMemoized(gridColumnDefinitionsSelector, (columns) => columns.reduce((acc, col) => {
  if (col.filterable) {
    acc[col.field] = col;
  }
  return acc;
}, {}));
const gridColumnGroupingSelector = (state) => state.columnGrouping;
const gridColumnGroupsUnwrappedModelSelector = createSelectorMemoized(gridColumnGroupingSelector, (columnGrouping) => {
  var _columnGrouping$unwra;
  return (_columnGrouping$unwra = columnGrouping == null ? void 0 : columnGrouping.unwrappedGroupingModel) != null ? _columnGrouping$unwra : {};
});
const gridColumnGroupsLookupSelector = createSelectorMemoized(gridColumnGroupingSelector, (columnGrouping) => {
  var _columnGrouping$looku;
  return (_columnGrouping$looku = columnGrouping == null ? void 0 : columnGrouping.lookup) != null ? _columnGrouping$looku : {};
});
const gridColumnGroupsHeaderStructureSelector = createSelectorMemoized(gridColumnGroupingSelector, (columnGrouping) => {
  var _columnGrouping$heade;
  return (_columnGrouping$heade = columnGrouping == null ? void 0 : columnGrouping.headerStructure) != null ? _columnGrouping$heade : [];
});
const gridColumnGroupsHeaderMaxDepthSelector = createSelector(gridColumnGroupingSelector, (columnGrouping) => {
  var _columnGrouping$maxDe;
  return (_columnGrouping$maxDe = columnGrouping == null ? void 0 : columnGrouping.maxDepth) != null ? _columnGrouping$maxDe : 0;
});
const gridRowsStateSelector = (state) => state.rows;
const gridRowCountSelector = createSelector(gridRowsStateSelector, (rows) => rows.totalRowCount);
const gridRowsLoadingSelector = createSelector(gridRowsStateSelector, (rows) => rows.loading);
const gridTopLevelRowCountSelector = createSelector(gridRowsStateSelector, (rows) => rows.totalTopLevelRowCount);
const gridRowsLookupSelector = createSelector(gridRowsStateSelector, (rows) => rows.dataRowIdToModelLookup);
const gridRowsDataRowIdToIdLookupSelector = createSelector(gridRowsStateSelector, (rows) => rows.dataRowIdToIdLookup);
const gridRowTreeSelector = createSelector(gridRowsStateSelector, (rows) => rows.tree);
const gridRowGroupingNameSelector = createSelector(gridRowsStateSelector, (rows) => rows.groupingName);
const gridRowTreeDepthsSelector = createSelector(gridRowsStateSelector, (rows) => rows.treeDepths);
const gridRowMaximumTreeDepthSelector = createSelectorMemoized(gridRowsStateSelector, (rows) => {
  const entries = Object.entries(rows.treeDepths);
  if (entries.length === 0) {
    return 1;
  }
  return entries.filter(([, nodeCount]) => nodeCount > 0).map(([depth]) => Number(depth)).sort((a2, b) => b - a2)[0] + 1;
});
const gridDataRowIdsSelector = createSelector(gridRowsStateSelector, (rows) => rows.dataRowIds);
const gridAdditionalRowGroupsSelector = createSelector(gridRowsStateSelector, (rows) => rows == null ? void 0 : rows.additionalRowGroups);
const gridPinnedRowsSelector = createSelectorMemoized(gridAdditionalRowGroupsSelector, (additionalRowGroups) => {
  var _rawPinnedRows$bottom, _rawPinnedRows$top;
  const rawPinnedRows = additionalRowGroups == null ? void 0 : additionalRowGroups.pinnedRows;
  return {
    bottom: rawPinnedRows == null || (_rawPinnedRows$bottom = rawPinnedRows.bottom) == null ? void 0 : _rawPinnedRows$bottom.map((rowEntry) => {
      var _rowEntry$model;
      return {
        id: rowEntry.id,
        model: (_rowEntry$model = rowEntry.model) != null ? _rowEntry$model : {}
      };
    }),
    top: rawPinnedRows == null || (_rawPinnedRows$top = rawPinnedRows.top) == null ? void 0 : _rawPinnedRows$top.map((rowEntry) => {
      var _rowEntry$model2;
      return {
        id: rowEntry.id,
        model: (_rowEntry$model2 = rowEntry.model) != null ? _rowEntry$model2 : {}
      };
    })
  };
});
const gridPinnedRowsCountSelector = createSelector(gridPinnedRowsSelector, (pinnedRows) => {
  var _pinnedRows$top, _pinnedRows$bottom;
  return ((pinnedRows == null || (_pinnedRows$top = pinnedRows.top) == null ? void 0 : _pinnedRows$top.length) || 0) + ((pinnedRows == null || (_pinnedRows$bottom = pinnedRows.bottom) == null ? void 0 : _pinnedRows$bottom.length) || 0);
});
const useGridAriaAttributes = () => {
  var _rootProps$experiment;
  const apiRef2 = useGridPrivateApiContext();
  const rootProps = useGridRootProps();
  const visibleColumns = useGridSelector(apiRef2, gridVisibleColumnDefinitionsSelector);
  const totalRowCount = useGridSelector(apiRef2, gridRowCountSelector);
  const headerGroupingMaxDepth = useGridSelector(apiRef2, gridColumnGroupsHeaderMaxDepthSelector);
  const pinnedRowsCount = useGridSelector(apiRef2, gridPinnedRowsCountSelector);
  let role = "grid";
  if ((_rootProps$experiment = rootProps.experimentalFeatures) != null && _rootProps$experiment.ariaV7 && rootProps.treeData) {
    role = "treegrid";
  }
  return {
    role,
    "aria-colcount": visibleColumns.length,
    "aria-rowcount": headerGroupingMaxDepth + 1 + pinnedRowsCount + totalRowCount,
    "aria-multiselectable": !rootProps.disableMultipleRowSelection
  };
};
const useUtilityClasses$V = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["main"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridMainContainerRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "Main",
  overridesResolver: (props, styles2) => styles2.main
})(() => ({
  position: "relative",
  flexGrow: 1,
  display: "flex",
  flexDirection: "column",
  overflow: "hidden"
}));
const GridMainContainer = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  var _rootProps$experiment;
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$V(rootProps);
  const getAriaAttributes = (_rootProps$experiment = rootProps.experimentalFeatures) != null && _rootProps$experiment.ariaV7 ? useGridAriaAttributes : null;
  const ariaAttributes = typeof getAriaAttributes === "function" ? getAriaAttributes() : null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridMainContainerRoot, _extends$1({
    ref,
    className: classes2.root,
    ownerState: rootProps
  }, ariaAttributes, {
    children: props.children
  }));
});
const gridSortingStateSelector = (state) => state.sorting;
const gridSortedRowIdsSelector = createSelector(gridSortingStateSelector, (sortingState) => sortingState.sortedRows);
const gridSortedRowEntriesSelector = createSelectorMemoized(
  gridSortedRowIdsSelector,
  gridRowsLookupSelector,
  // TODO rows v6: Is this the best approach ?
  (sortedIds, idRowsLookup) => sortedIds.map((id) => {
    var _idRowsLookup$id;
    return {
      id,
      model: (_idRowsLookup$id = idRowsLookup[id]) != null ? _idRowsLookup$id : {}
    };
  })
);
const gridSortModelSelector = createSelector(gridSortingStateSelector, (sorting) => sorting.sortModel);
const gridSortColumnLookupSelector = createSelectorMemoized(gridSortModelSelector, (sortModel) => {
  const result = sortModel.reduce((res, sortItem, index) => {
    res[sortItem.field] = {
      sortDirection: sortItem.sort,
      sortIndex: sortModel.length > 1 ? index + 1 : void 0
    };
    return res;
  }, {});
  return result;
});
const gridFilterStateSelector = (state) => state.filter;
const gridFilterModelSelector = createSelector(gridFilterStateSelector, (filterState) => filterState.filterModel);
createSelector(gridFilterModelSelector, (filterModel2) => filterModel2.quickFilterValues);
const gridVisibleRowsLookupSelector = (state) => state.visibleRowsLookup;
const gridFilteredRowsLookupSelector = createSelector(gridFilterStateSelector, (filterState) => filterState.filteredRowsLookup);
createSelector(gridFilterStateSelector, (filterState) => filterState.filteredDescendantCountLookup);
const gridExpandedSortedRowEntriesSelector = createSelectorMemoized(gridVisibleRowsLookupSelector, gridSortedRowEntriesSelector, (visibleRowsLookup, sortedRows) => sortedRows.filter((row) => visibleRowsLookup[row.id] !== false));
const gridExpandedSortedRowIdsSelector = createSelectorMemoized(gridExpandedSortedRowEntriesSelector, (visibleSortedRowEntries) => visibleSortedRowEntries.map((row) => row.id));
const gridFilteredSortedRowEntriesSelector = createSelectorMemoized(gridFilteredRowsLookupSelector, gridSortedRowEntriesSelector, (filteredRowsLookup, sortedRows) => sortedRows.filter((row) => filteredRowsLookup[row.id] !== false));
const gridFilteredSortedRowIdsSelector = createSelectorMemoized(gridFilteredSortedRowEntriesSelector, (filteredSortedRowEntries) => filteredSortedRowEntries.map((row) => row.id));
const gridFilteredSortedTopLevelRowEntriesSelector = createSelectorMemoized(gridExpandedSortedRowEntriesSelector, gridRowTreeSelector, gridRowMaximumTreeDepthSelector, (visibleSortedRows, rowTree, rowTreeDepth) => {
  if (rowTreeDepth < 2) {
    return visibleSortedRows;
  }
  return visibleSortedRows.filter((row) => {
    var _rowTree$row$id;
    return ((_rowTree$row$id = rowTree[row.id]) == null ? void 0 : _rowTree$row$id.depth) === 0;
  });
});
const gridExpandedRowCountSelector = createSelector(gridExpandedSortedRowEntriesSelector, (visibleSortedRows) => visibleSortedRows.length);
const gridFilteredTopLevelRowCountSelector = createSelector(gridFilteredSortedTopLevelRowEntriesSelector, (visibleSortedTopLevelRows) => visibleSortedTopLevelRows.length);
const gridFilterActiveItemsSelector = createSelectorMemoized(gridFilterModelSelector, gridColumnLookupSelector, (filterModel2, columnLookup) => {
  var _filterModel$items;
  return (_filterModel$items = filterModel2.items) == null ? void 0 : _filterModel$items.filter((item) => {
    var _column$filterOperato, _item$value;
    if (!item.field) {
      return false;
    }
    const column = columnLookup[item.field];
    if (!(column != null && column.filterOperators) || (column == null || (_column$filterOperato = column.filterOperators) == null ? void 0 : _column$filterOperato.length) === 0) {
      return false;
    }
    const filterOperator = column.filterOperators.find((operator) => operator.value === item.operator);
    if (!filterOperator) {
      return false;
    }
    return !filterOperator.InputComponent || item.value != null && ((_item$value = item.value) == null ? void 0 : _item$value.toString()) !== "";
  });
});
const gridFilterActiveItemsLookupSelector = createSelectorMemoized(gridFilterActiveItemsSelector, (activeFilters) => {
  const result = activeFilters.reduce((res, filterItem2) => {
    if (!res[filterItem2.field]) {
      res[filterItem2.field] = [filterItem2];
    } else {
      res[filterItem2.field].push(filterItem2);
    }
    return res;
  }, {});
  return result;
});
const gridFocusStateSelector = (state) => state.focus;
const gridFocusCellSelector = createSelector(gridFocusStateSelector, (focusState) => focusState.cell);
const gridFocusColumnHeaderSelector = createSelector(gridFocusStateSelector, (focusState) => focusState.columnHeader);
createSelector(gridFocusStateSelector, (focusState) => focusState.columnHeaderFilter);
const unstable_gridFocusColumnGroupHeaderSelector = createSelector(gridFocusStateSelector, (focusState) => focusState.columnGroupHeader);
const gridTabIndexStateSelector = (state) => state.tabIndex;
const gridTabIndexCellSelector = createSelector(gridTabIndexStateSelector, (state) => state.cell);
const gridTabIndexColumnHeaderSelector = createSelector(gridTabIndexStateSelector, (state) => state.columnHeader);
createSelector(gridTabIndexStateSelector, (state) => state.columnHeaderFilter);
const unstable_gridTabIndexColumnGroupHeaderSelector = createSelector(gridTabIndexStateSelector, (state) => state.columnGroupHeader);
const gridDensitySelector = (state) => state.density;
const gridDensityValueSelector = createSelector(gridDensitySelector, (density) => density.value);
const gridDensityFactorSelector = createSelector(gridDensitySelector, (density) => density.factor);
const gridColumnMenuSelector = (state) => state.columnMenu;
function GridBody(props) {
  const {
    VirtualScrollerComponent,
    ColumnHeadersProps,
    children
  } = props;
  const apiRef2 = useGridPrivateApiContext();
  const rootProps = useGridRootProps();
  const rootRef = reactExports.useRef(null);
  const visibleColumns = useGridSelector(apiRef2, gridVisibleColumnDefinitionsSelector);
  const filterColumnLookup = useGridSelector(apiRef2, gridFilterActiveItemsLookupSelector);
  const sortColumnLookup = useGridSelector(apiRef2, gridSortColumnLookupSelector);
  const columnPositions = useGridSelector(apiRef2, gridColumnPositionsSelector);
  const columnHeaderTabIndexState = useGridSelector(apiRef2, gridTabIndexColumnHeaderSelector);
  const cellTabIndexState = useGridSelector(apiRef2, gridTabIndexCellSelector);
  const columnGroupHeaderTabIndexState = useGridSelector(apiRef2, unstable_gridTabIndexColumnGroupHeaderSelector);
  const columnHeaderFocus = useGridSelector(apiRef2, gridFocusColumnHeaderSelector);
  const columnGroupHeaderFocus = useGridSelector(apiRef2, unstable_gridFocusColumnGroupHeaderSelector);
  const densityFactor = useGridSelector(apiRef2, gridDensityFactorSelector);
  const headerGroupingMaxDepth = useGridSelector(apiRef2, gridColumnGroupsHeaderMaxDepthSelector);
  const columnMenuState = useGridSelector(apiRef2, gridColumnMenuSelector);
  const columnVisibility = useGridSelector(apiRef2, gridColumnVisibilityModelSelector);
  const columnGroupsHeaderStructure = useGridSelector(apiRef2, gridColumnGroupsHeaderStructureSelector);
  const hasOtherElementInTabSequence = !(columnGroupHeaderTabIndexState === null && columnHeaderTabIndexState === null && cellTabIndexState === null);
  const [isVirtualizationDisabled, setIsVirtualizationDisabled] = reactExports.useState(rootProps.disableVirtualization);
  useEnhancedEffect$1(() => {
    apiRef2.current.computeSizeAndPublishResizeEvent();
    const elementToObserve = rootRef.current;
    if (typeof ResizeObserver === "undefined") {
      return () => {
      };
    }
    let animationFrame;
    const observer = new ResizeObserver(() => {
      animationFrame = window.requestAnimationFrame(() => {
        apiRef2.current.computeSizeAndPublishResizeEvent();
      });
    });
    if (elementToObserve) {
      observer.observe(elementToObserve);
    }
    return () => {
      if (animationFrame) {
        window.cancelAnimationFrame(animationFrame);
      }
      if (elementToObserve) {
        observer.unobserve(elementToObserve);
      }
    };
  }, [apiRef2]);
  const disableVirtualization = reactExports.useCallback(() => {
    setIsVirtualizationDisabled(true);
  }, []);
  const enableVirtualization = reactExports.useCallback(() => {
    setIsVirtualizationDisabled(false);
  }, []);
  reactExports.useEffect(() => {
    setIsVirtualizationDisabled(rootProps.disableVirtualization);
  }, [rootProps.disableVirtualization]);
  apiRef2.current.unstable_disableVirtualization = disableVirtualization;
  apiRef2.current.unstable_enableVirtualization = enableVirtualization;
  const columnHeadersRef = reactExports.useRef(null);
  const columnsContainerRef = reactExports.useRef(null);
  const virtualScrollerRef = reactExports.useRef(null);
  apiRef2.current.register("private", {
    columnHeadersContainerElementRef: columnsContainerRef,
    columnHeadersElementRef: columnHeadersRef,
    virtualScrollerRef,
    mainElementRef: rootRef
  });
  const hasDimensions = !!apiRef2.current.getRootDimensions();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(GridMainContainer, {
    ref: rootRef,
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.columnHeaders, _extends$1({
      ref: columnsContainerRef,
      innerRef: columnHeadersRef,
      visibleColumns,
      filterColumnLookup,
      sortColumnLookup,
      columnPositions,
      columnHeaderTabIndexState,
      columnGroupHeaderTabIndexState,
      columnHeaderFocus,
      columnGroupHeaderFocus,
      densityFactor,
      headerGroupingMaxDepth,
      columnMenuState,
      columnVisibility,
      columnGroupsHeaderStructure,
      hasOtherElementInTabSequence
    }, ColumnHeadersProps)), hasDimensions && /* @__PURE__ */ jsxRuntimeExports.jsx(
      VirtualScrollerComponent,
      {
        ref: virtualScrollerRef,
        disableVirtualization: isVirtualizationDisabled
      }
    ), children]
  });
}
function GridFooterPlaceholder() {
  var _rootProps$slotProps;
  const rootProps = useGridRootProps();
  if (rootProps.hideFooter) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.footer, _extends$1({}, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.footer));
}
const GRID_ROOT_GROUP_ID = `auto-generated-group-node-root`;
const GRID_ID_AUTOGENERATED = Symbol("mui.id_autogenerated");
const buildRootGroup = () => ({
  type: "group",
  id: GRID_ROOT_GROUP_ID,
  depth: -1,
  groupingField: null,
  groupingKey: null,
  isAutoGenerated: true,
  children: [],
  childrenFromPath: {},
  childrenExpanded: true,
  parent: null
});
function checkGridRowIdIsValid(id, row, detailErrorMessage = "A row was provided without id in the rows prop:") {
  if (id == null) {
    throw new Error(["MUI: The data grid component requires all rows to have a unique `id` property.", "Alternatively, you can use the `getRowId` prop to specify a custom id for each row.", detailErrorMessage, JSON.stringify(row)].join("\n"));
  }
}
const getRowIdFromRowModel = (rowModel, getRowId2, detailErrorMessage) => {
  const id = getRowId2 ? getRowId2(rowModel) : rowModel.id;
  checkGridRowIdIsValid(id, rowModel, detailErrorMessage);
  return id;
};
const createRowsInternalCache = ({
  rows,
  getRowId: getRowId2,
  loading,
  rowCount
}) => {
  const updates = {
    type: "full",
    rows: []
  };
  const dataRowIdToModelLookup = {};
  const dataRowIdToIdLookup = {};
  for (let i2 = 0; i2 < rows.length; i2 += 1) {
    const model = rows[i2];
    const id = getRowIdFromRowModel(model, getRowId2);
    dataRowIdToModelLookup[id] = model;
    dataRowIdToIdLookup[id] = id;
    updates.rows.push(id);
  }
  return {
    rowsBeforePartialUpdates: rows,
    loadingPropBeforePartialUpdates: loading,
    rowCountPropBeforePartialUpdates: rowCount,
    updates,
    dataRowIdToIdLookup,
    dataRowIdToModelLookup
  };
};
const getTopLevelRowCount = ({
  tree,
  rowCountProp = 0
}) => {
  const rootGroupNode = tree[GRID_ROOT_GROUP_ID];
  return Math.max(rowCountProp, rootGroupNode.children.length + (rootGroupNode.footerId == null ? 0 : 1));
};
const getRowsStateFromCache = ({
  apiRef: apiRef2,
  rowCountProp = 0,
  loadingProp,
  previousTree,
  previousTreeDepths
}) => {
  const cache = apiRef2.current.caches.rows;
  const {
    tree: unProcessedTree,
    treeDepths: unProcessedTreeDepths,
    dataRowIds: unProcessedDataRowIds,
    groupingName
  } = apiRef2.current.applyStrategyProcessor("rowTreeCreation", {
    previousTree,
    previousTreeDepths,
    updates: cache.updates,
    dataRowIdToIdLookup: cache.dataRowIdToIdLookup,
    dataRowIdToModelLookup: cache.dataRowIdToModelLookup
  });
  const groupingParamsWithHydrateRows = apiRef2.current.unstable_applyPipeProcessors("hydrateRows", {
    tree: unProcessedTree,
    treeDepths: unProcessedTreeDepths,
    dataRowIdToIdLookup: cache.dataRowIdToIdLookup,
    dataRowIds: unProcessedDataRowIds,
    dataRowIdToModelLookup: cache.dataRowIdToModelLookup
  });
  apiRef2.current.caches.rows.updates = {
    type: "partial",
    actions: {
      insert: [],
      modify: [],
      remove: []
    },
    idToActionLookup: {}
  };
  return _extends$1({}, groupingParamsWithHydrateRows, {
    totalRowCount: Math.max(rowCountProp, groupingParamsWithHydrateRows.dataRowIds.length),
    totalTopLevelRowCount: getTopLevelRowCount({
      tree: groupingParamsWithHydrateRows.tree,
      rowCountProp
    }),
    groupingName,
    loading: loadingProp
  });
};
const isAutoGeneratedRow = (rowNode) => rowNode.type === "skeletonRow" || rowNode.type === "footer" || rowNode.type === "group" && rowNode.isAutoGenerated || rowNode.type === "pinnedRow" && rowNode.isAutoGenerated;
const getTreeNodeDescendants = (tree, parentId, skipAutoGeneratedRows) => {
  const node = tree[parentId];
  if (node.type !== "group") {
    return [];
  }
  const validDescendants = [];
  for (let i2 = 0; i2 < node.children.length; i2 += 1) {
    const child = node.children[i2];
    if (!skipAutoGeneratedRows || !isAutoGeneratedRow(tree[child])) {
      validDescendants.push(child);
    }
    validDescendants.push(...getTreeNodeDescendants(tree, child, skipAutoGeneratedRows));
  }
  if (!skipAutoGeneratedRows && node.footerId != null) {
    validDescendants.push(node.footerId);
  }
  return validDescendants;
};
const updateCacheWithNewRows = ({
  previousCache,
  getRowId: getRowId2,
  updates
}) => {
  var _previousCache$update, _previousCache$update2, _previousCache$update3;
  if (previousCache.updates.type === "full") {
    throw new Error("MUI: Unable to prepare a partial update if a full update is not applied yet");
  }
  const uniqueUpdates = /* @__PURE__ */ new Map();
  updates.forEach((update) => {
    const id = getRowIdFromRowModel(update, getRowId2, "A row was provided without id when calling updateRows():");
    if (uniqueUpdates.has(id)) {
      uniqueUpdates.set(id, _extends$1({}, uniqueUpdates.get(id), update));
    } else {
      uniqueUpdates.set(id, update);
    }
  });
  const partialUpdates = {
    type: "partial",
    actions: {
      insert: [...(_previousCache$update = previousCache.updates.actions.insert) != null ? _previousCache$update : []],
      modify: [...(_previousCache$update2 = previousCache.updates.actions.modify) != null ? _previousCache$update2 : []],
      remove: [...(_previousCache$update3 = previousCache.updates.actions.remove) != null ? _previousCache$update3 : []]
    },
    idToActionLookup: _extends$1({}, previousCache.updates.idToActionLookup)
  };
  const dataRowIdToModelLookup = _extends$1({}, previousCache.dataRowIdToModelLookup);
  const dataRowIdToIdLookup = _extends$1({}, previousCache.dataRowIdToIdLookup);
  const alreadyAppliedActionsToRemove = {
    insert: {},
    modify: {},
    remove: {}
  };
  uniqueUpdates.forEach((partialRow, id) => {
    const actionAlreadyAppliedToRow = partialUpdates.idToActionLookup[id];
    if (partialRow._action === "delete") {
      if (actionAlreadyAppliedToRow === "remove" || !dataRowIdToModelLookup[id]) {
        return;
      }
      if (actionAlreadyAppliedToRow != null) {
        alreadyAppliedActionsToRemove[actionAlreadyAppliedToRow][id] = true;
      }
      partialUpdates.actions.remove.push(id);
      delete dataRowIdToModelLookup[id];
      delete dataRowIdToIdLookup[id];
      return;
    }
    const oldRow = dataRowIdToModelLookup[id];
    if (oldRow) {
      if (actionAlreadyAppliedToRow === "remove") {
        alreadyAppliedActionsToRemove.remove[id] = true;
        partialUpdates.actions.modify.push(id);
      } else if (actionAlreadyAppliedToRow == null) {
        partialUpdates.actions.modify.push(id);
      }
      dataRowIdToModelLookup[id] = _extends$1({}, oldRow, partialRow);
      return;
    }
    if (actionAlreadyAppliedToRow === "remove") {
      alreadyAppliedActionsToRemove.remove[id] = true;
      partialUpdates.actions.insert.push(id);
    } else if (actionAlreadyAppliedToRow == null) {
      partialUpdates.actions.insert.push(id);
    }
    dataRowIdToModelLookup[id] = partialRow;
    dataRowIdToIdLookup[id] = id;
  });
  const actionTypeWithActionsToRemove = Object.keys(alreadyAppliedActionsToRemove);
  for (let i2 = 0; i2 < actionTypeWithActionsToRemove.length; i2 += 1) {
    const actionType = actionTypeWithActionsToRemove[i2];
    const idsToRemove = alreadyAppliedActionsToRemove[actionType];
    if (Object.keys(idsToRemove).length > 0) {
      partialUpdates.actions[actionType] = partialUpdates.actions[actionType].filter((id) => !idsToRemove[id]);
    }
  }
  return {
    dataRowIdToModelLookup,
    dataRowIdToIdLookup,
    updates: partialUpdates,
    rowsBeforePartialUpdates: previousCache.rowsBeforePartialUpdates,
    loadingPropBeforePartialUpdates: previousCache.loadingPropBeforePartialUpdates,
    rowCountPropBeforePartialUpdates: previousCache.rowCountPropBeforePartialUpdates
  };
};
function calculatePinnedRowsHeight(apiRef2) {
  var _pinnedRows$top, _pinnedRows$bottom;
  const pinnedRows = gridPinnedRowsSelector(apiRef2);
  const topPinnedRowsHeight = (pinnedRows == null || (_pinnedRows$top = pinnedRows.top) == null ? void 0 : _pinnedRows$top.reduce((acc, value) => {
    acc += apiRef2.current.unstable_getRowHeight(value.id);
    return acc;
  }, 0)) || 0;
  const bottomPinnedRowsHeight = (pinnedRows == null || (_pinnedRows$bottom = pinnedRows.bottom) == null ? void 0 : _pinnedRows$bottom.reduce((acc, value) => {
    acc += apiRef2.current.unstable_getRowHeight(value.id);
    return acc;
  }, 0)) || 0;
  return {
    top: topPinnedRowsHeight,
    bottom: bottomPinnedRowsHeight
  };
}
function getMinimalContentHeight(apiRef2, rowHeight) {
  const densityFactor = gridDensityFactorSelector(apiRef2);
  return `var(--DataGrid-overlayHeight, ${2 * Math.floor(rowHeight * densityFactor)}px)`;
}
const GridOverlayWrapperRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "OverlayWrapper",
  shouldForwardProp: (prop) => prop !== "overlayType",
  overridesResolver: (props, styles2) => styles2.overlayWrapper
})(({
  overlayType
}) => ({
  position: "sticky",
  // To stay in place while scrolling
  top: 0,
  left: 0,
  width: 0,
  // To stay above the content instead of shifting it down
  height: 0,
  // To stay above the content instead of shifting it down
  zIndex: overlayType === "loadingOverlay" ? 5 : 4
  // Should be above pinned columns and detail panel
}));
const GridOverlayWrapperInner = styled("div", {
  name: "MuiDataGrid",
  slot: "OverlayWrapperInner",
  shouldForwardProp: (prop) => prop !== "overlayType",
  overridesResolver: (props, styles2) => styles2.overlayWrapperInner
})({});
const useUtilityClasses$U = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["overlayWrapper"],
    inner: ["overlayWrapperInner"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
function GridOverlayWrapper(props) {
  var _viewportInnerSize$he, _viewportInnerSize$wi;
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const [viewportInnerSize, setViewportInnerSize] = reactExports.useState(() => {
    var _apiRef$current$getRo, _apiRef$current$getRo2;
    return (_apiRef$current$getRo = (_apiRef$current$getRo2 = apiRef2.current.getRootDimensions()) == null ? void 0 : _apiRef$current$getRo2.viewportInnerSize) != null ? _apiRef$current$getRo : null;
  });
  const handleViewportSizeChange = reactExports.useCallback(() => {
    var _apiRef$current$getRo3, _apiRef$current$getRo4;
    setViewportInnerSize((_apiRef$current$getRo3 = (_apiRef$current$getRo4 = apiRef2.current.getRootDimensions()) == null ? void 0 : _apiRef$current$getRo4.viewportInnerSize) != null ? _apiRef$current$getRo3 : null);
  }, [apiRef2]);
  useEnhancedEffect$1(() => {
    return apiRef2.current.subscribeEvent("viewportInnerSizeChange", handleViewportSizeChange);
  }, [apiRef2, handleViewportSizeChange]);
  let height = (_viewportInnerSize$he = viewportInnerSize == null ? void 0 : viewportInnerSize.height) != null ? _viewportInnerSize$he : 0;
  if (rootProps.autoHeight && height === 0) {
    height = getMinimalContentHeight(apiRef2, rootProps.rowHeight);
  }
  const classes2 = useUtilityClasses$U(_extends$1({}, props, {
    classes: rootProps.classes
  }));
  if (!viewportInnerSize) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridOverlayWrapperRoot, {
    className: clsx$1(classes2.root),
    overlayType: props.overlayType,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(GridOverlayWrapperInner, _extends$1({
      className: clsx$1(classes2.inner),
      style: {
        height,
        width: (_viewportInnerSize$wi = viewportInnerSize == null ? void 0 : viewportInnerSize.width) != null ? _viewportInnerSize$wi : 0
      }
    }, props))
  });
}
function GridOverlays() {
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const totalRowCount = useGridSelector(apiRef2, gridRowCountSelector);
  const visibleRowCount = useGridSelector(apiRef2, gridExpandedRowCountSelector);
  const loading = useGridSelector(apiRef2, gridRowsLoadingSelector);
  const showNoRowsOverlay = !loading && totalRowCount === 0;
  const showNoResultsOverlay = !loading && totalRowCount > 0 && visibleRowCount === 0;
  let overlay = null;
  let overlayType = "";
  if (showNoRowsOverlay) {
    var _rootProps$slotProps;
    overlay = /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.noRowsOverlay, _extends$1({}, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.noRowsOverlay));
    overlayType = "noRowsOverlay";
  }
  if (showNoResultsOverlay) {
    var _rootProps$slotProps2;
    overlay = /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.noResultsOverlay, _extends$1({}, (_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.noResultsOverlay));
    overlayType = "noResultsOverlay";
  }
  if (loading) {
    var _rootProps$slotProps3;
    overlay = /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.loadingOverlay, _extends$1({}, (_rootProps$slotProps3 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps3.loadingOverlay));
    overlayType = "loadingOverlay";
  }
  if (overlay === null) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridOverlayWrapper, {
    overlayType,
    children: overlay
  });
}
function fastMemo(component) {
  return /* @__PURE__ */ reactExports.memo(component, fastObjectShallowCompare);
}
let cachedSupportsPreventScroll;
function doesSupportPreventScroll() {
  if (cachedSupportsPreventScroll === void 0) {
    document.createElement("div").focus({
      get preventScroll() {
        cachedSupportsPreventScroll = true;
        return false;
      }
    });
  }
  return cachedSupportsPreventScroll;
}
var GridEditModes = /* @__PURE__ */ function(GridEditModes2) {
  GridEditModes2["Cell"] = "cell";
  GridEditModes2["Row"] = "row";
  return GridEditModes2;
}(GridEditModes || {});
var GridCellModes = /* @__PURE__ */ function(GridCellModes2) {
  GridCellModes2["Edit"] = "edit";
  GridCellModes2["View"] = "view";
  return GridCellModes2;
}(GridCellModes || {});
var GridRowModes = /* @__PURE__ */ function(GridRowModes2) {
  GridRowModes2["Edit"] = "edit";
  GridRowModes2["View"] = "view";
  return GridRowModes2;
}(GridRowModes || {});
var GridLogicOperator = /* @__PURE__ */ function(GridLogicOperator2) {
  GridLogicOperator2["And"] = "and";
  GridLogicOperator2["Or"] = "or";
  return GridLogicOperator2;
}(GridLogicOperator || {});
var GridCellEditStartReasons = /* @__PURE__ */ function(GridCellEditStartReasons2) {
  GridCellEditStartReasons2["enterKeyDown"] = "enterKeyDown";
  GridCellEditStartReasons2["cellDoubleClick"] = "cellDoubleClick";
  GridCellEditStartReasons2["printableKeyDown"] = "printableKeyDown";
  GridCellEditStartReasons2["deleteKeyDown"] = "deleteKeyDown";
  return GridCellEditStartReasons2;
}(GridCellEditStartReasons || {});
var GridCellEditStopReasons = /* @__PURE__ */ function(GridCellEditStopReasons2) {
  GridCellEditStopReasons2["cellFocusOut"] = "cellFocusOut";
  GridCellEditStopReasons2["escapeKeyDown"] = "escapeKeyDown";
  GridCellEditStopReasons2["enterKeyDown"] = "enterKeyDown";
  GridCellEditStopReasons2["tabKeyDown"] = "tabKeyDown";
  GridCellEditStopReasons2["shiftTabKeyDown"] = "shiftTabKeyDown";
  return GridCellEditStopReasons2;
}(GridCellEditStopReasons || {});
var GridRowEditStartReasons = /* @__PURE__ */ function(GridRowEditStartReasons2) {
  GridRowEditStartReasons2["enterKeyDown"] = "enterKeyDown";
  GridRowEditStartReasons2["cellDoubleClick"] = "cellDoubleClick";
  GridRowEditStartReasons2["printableKeyDown"] = "printableKeyDown";
  GridRowEditStartReasons2["deleteKeyDown"] = "deleteKeyDown";
  return GridRowEditStartReasons2;
}(GridRowEditStartReasons || {});
var GridRowEditStopReasons = /* @__PURE__ */ function(GridRowEditStopReasons2) {
  GridRowEditStopReasons2["rowFocusOut"] = "rowFocusOut";
  GridRowEditStopReasons2["escapeKeyDown"] = "escapeKeyDown";
  GridRowEditStopReasons2["enterKeyDown"] = "enterKeyDown";
  GridRowEditStopReasons2["tabKeyDown"] = "tabKeyDown";
  GridRowEditStopReasons2["shiftTabKeyDown"] = "shiftTabKeyDown";
  return GridRowEditStopReasons2;
}(GridRowEditStopReasons || {});
function isLeaf(node) {
  return node.field !== void 0;
}
function isOverflown(element) {
  return element.scrollHeight > element.clientHeight || element.scrollWidth > element.clientWidth;
}
function findParentElementFromClassName(elem, className) {
  return elem.closest(`.${className}`);
}
function escapeOperandAttributeSelector(operand) {
  return operand.replace(/["\\]/g, "\\$&");
}
function getGridColumnHeaderElement(root, field) {
  return root.querySelector(`[role="columnheader"][data-field="${escapeOperandAttributeSelector(field)}"]`);
}
function getGridRowElementSelector(id) {
  return `.${gridClasses.row}[data-id="${escapeOperandAttributeSelector(String(id))}"]`;
}
function getGridRowElement(root, id) {
  return root.querySelector(getGridRowElementSelector(id));
}
function getGridCellElement(root, {
  id,
  field
}) {
  const rowSelector = getGridRowElementSelector(id);
  const cellSelector = `.${gridClasses.cell}[data-field="${escapeOperandAttributeSelector(field)}"]`;
  const selector = `${rowSelector} ${cellSelector}`;
  return root.querySelector(selector);
}
function useGridApiMethod(privateApiRef, apiMethods, visibility) {
  const isFirstRender = reactExports.useRef(true);
  reactExports.useEffect(() => {
    isFirstRender.current = false;
    privateApiRef.current.register(visibility, apiMethods);
  }, [privateApiRef, visibility, apiMethods]);
  if (isFirstRender.current) {
    privateApiRef.current.register(visibility, apiMethods);
  }
}
class MissingRowIdError extends Error {
}
function useGridParamsApi(apiRef2, props) {
  const {
    getRowId: getRowId2
  } = props;
  const getColumnHeaderParams = reactExports.useCallback((field) => ({
    field,
    colDef: apiRef2.current.getColumn(field)
  }), [apiRef2]);
  const getRowParams = reactExports.useCallback((id) => {
    const row = apiRef2.current.getRow(id);
    if (!row) {
      throw new MissingRowIdError(`No row with id #${id} found`);
    }
    const params = {
      id,
      columns: apiRef2.current.getAllColumns(),
      row
    };
    return params;
  }, [apiRef2]);
  const getBaseCellParams = reactExports.useCallback((id, field) => {
    const row = apiRef2.current.getRow(id);
    const rowNode = apiRef2.current.getRowNode(id);
    if (!row || !rowNode) {
      throw new MissingRowIdError(`No row with id #${id} found`);
    }
    const cellFocus = gridFocusCellSelector(apiRef2);
    const cellTabIndex = gridTabIndexCellSelector(apiRef2);
    const params = {
      id,
      field,
      row,
      rowNode,
      value: row[field],
      colDef: apiRef2.current.getColumn(field),
      cellMode: apiRef2.current.getCellMode(id, field),
      api: apiRef2.current,
      hasFocus: cellFocus !== null && cellFocus.field === field && cellFocus.id === id,
      tabIndex: cellTabIndex && cellTabIndex.field === field && cellTabIndex.id === id ? 0 : -1
    };
    return params;
  }, [apiRef2]);
  const getCellParams = reactExports.useCallback((id, field) => {
    const colDef = apiRef2.current.getColumn(field);
    const value = apiRef2.current.getCellValue(id, field);
    const row = apiRef2.current.getRow(id);
    const rowNode = apiRef2.current.getRowNode(id);
    if (!row || !rowNode) {
      throw new MissingRowIdError(`No row with id #${id} found`);
    }
    const cellFocus = gridFocusCellSelector(apiRef2);
    const cellTabIndex = gridTabIndexCellSelector(apiRef2);
    const params = {
      id,
      field,
      row,
      rowNode,
      colDef,
      cellMode: apiRef2.current.getCellMode(id, field),
      hasFocus: cellFocus !== null && cellFocus.field === field && cellFocus.id === id,
      tabIndex: cellTabIndex && cellTabIndex.field === field && cellTabIndex.id === id ? 0 : -1,
      value,
      formattedValue: value,
      isEditable: false
    };
    if (colDef && colDef.valueFormatter) {
      params.formattedValue = colDef.valueFormatter({
        id,
        field: params.field,
        value: params.value,
        api: apiRef2.current
      });
    }
    params.isEditable = colDef && apiRef2.current.isCellEditable(params);
    return params;
  }, [apiRef2]);
  const getCellValue = reactExports.useCallback((id, field) => {
    const colDef = apiRef2.current.getColumn(field);
    if (!colDef || !colDef.valueGetter) {
      const rowModel = apiRef2.current.getRow(id);
      if (!rowModel) {
        throw new MissingRowIdError(`No row with id #${id} found`);
      }
      return rowModel[field];
    }
    return colDef.valueGetter(getBaseCellParams(id, field));
  }, [apiRef2, getBaseCellParams]);
  const getRowValue = reactExports.useCallback((row, colDef) => {
    var _getRowId;
    const id = GRID_ID_AUTOGENERATED in row ? row[GRID_ID_AUTOGENERATED] : (_getRowId = getRowId2 == null ? void 0 : getRowId2(row)) != null ? _getRowId : row.id;
    const field = colDef.field;
    if (!colDef || !colDef.valueGetter) {
      return row[field];
    }
    return colDef.valueGetter(getBaseCellParams(id, field));
  }, [getBaseCellParams, getRowId2]);
  const getRowFormattedValue = reactExports.useCallback((row, colDef) => {
    var _ref;
    const value = getRowValue(row, colDef);
    if (!colDef || !colDef.valueFormatter) {
      return value;
    }
    const id = (_ref = getRowId2 ? getRowId2(row) : row.id) != null ? _ref : row[GRID_ID_AUTOGENERATED];
    const field = colDef.field;
    return colDef.valueFormatter({
      id,
      field,
      value,
      api: apiRef2.current
    });
  }, [apiRef2, getRowId2, getRowValue]);
  const getColumnHeaderElement = reactExports.useCallback((field) => {
    if (!apiRef2.current.rootElementRef.current) {
      return null;
    }
    return getGridColumnHeaderElement(apiRef2.current.rootElementRef.current, field);
  }, [apiRef2]);
  const getRowElement = reactExports.useCallback((id) => {
    if (!apiRef2.current.rootElementRef.current) {
      return null;
    }
    return getGridRowElement(apiRef2.current.rootElementRef.current, id);
  }, [apiRef2]);
  const getCellElement = reactExports.useCallback((id, field) => {
    if (!apiRef2.current.rootElementRef.current) {
      return null;
    }
    return getGridCellElement(apiRef2.current.rootElementRef.current, {
      id,
      field
    });
  }, [apiRef2]);
  const paramsApi = {
    getCellValue,
    getCellParams,
    getCellElement,
    getRowValue,
    getRowFormattedValue,
    getRowParams,
    getRowElement,
    getColumnHeaderParams,
    getColumnHeaderElement
  };
  useGridApiMethod(apiRef2, paramsApi, "public");
}
const _excluded$1a = ["changeReason", "unstable_updateValueOnRender"], _excluded3 = ["column", "rowId", "editCellState", "align", "children", "colIndex", "height", "width", "className", "showRightBorder", "extendRowFullWidth", "row", "colSpan", "disableDragEvents", "isNotVisible", "onClick", "onDoubleClick", "onMouseDown", "onMouseUp", "onMouseOver", "onKeyDown", "onKeyUp", "onDragEnter", "onDragOver"], _excluded4 = ["changeReason", "unstable_updateValueOnRender"];
const EMPTY_CELL_PARAMS = {
  id: -1,
  field: "__unset__",
  row: {},
  rowNode: {
    id: -1,
    depth: 0,
    type: "leaf",
    parent: -1,
    groupingKey: null
  },
  colDef: {
    type: "string",
    field: "__unset__",
    computedWidth: 0
  },
  cellMode: GridCellModes.View,
  hasFocus: false,
  tabIndex: -1,
  value: null,
  formattedValue: "__unset__",
  isEditable: false,
  api: {}
};
const useUtilityClasses$T = (ownerState) => {
  const {
    align,
    showRightBorder,
    isEditable,
    isSelected,
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["cell", `cell--text${capitalize(align)}`, isEditable && "cell--editable", isSelected && "selected", showRightBorder && "cell--withRightBorder", "withBorderColor"],
    content: ["cellContent"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridCellWrapper = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    column,
    rowId,
    editCellState
  } = props;
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const field = column.field;
  const cellParamsWithAPI = useGridSelector(apiRef2, () => {
    try {
      const cellParams = apiRef2.current.getCellParams(rowId, field);
      const result = cellParams;
      result.api = apiRef2.current;
      return result;
    } catch (e2) {
      if (e2 instanceof MissingRowIdError) {
        return EMPTY_CELL_PARAMS;
      }
      throw e2;
    }
  }, objectShallowCompare);
  const isSelected = useGridSelector(apiRef2, () => apiRef2.current.unstable_applyPipeProcessors("isCellSelected", false, {
    id: rowId,
    field
  }));
  if (cellParamsWithAPI === EMPTY_CELL_PARAMS) {
    return null;
  }
  const {
    cellMode,
    hasFocus,
    isEditable,
    value,
    formattedValue
  } = cellParamsWithAPI;
  const managesOwnFocus = column.type === "actions";
  const tabIndex = (cellMode === "view" || !isEditable) && !managesOwnFocus ? cellParamsWithAPI.tabIndex : -1;
  const {
    classes: rootClasses,
    getCellClassName
  } = rootProps;
  const classNames = apiRef2.current.unstable_applyPipeProcessors("cellClassName", [], {
    id: rowId,
    field
  });
  if (column.cellClassName) {
    classNames.push(typeof column.cellClassName === "function" ? column.cellClassName(cellParamsWithAPI) : column.cellClassName);
  }
  if (getCellClassName) {
    classNames.push(getCellClassName(cellParamsWithAPI));
  }
  let children;
  if (editCellState == null && column.renderCell) {
    children = column.renderCell(cellParamsWithAPI);
    classNames.push(gridClasses["cell--withRenderer"]);
    classNames.push(rootClasses == null ? void 0 : rootClasses["cell--withRenderer"]);
  }
  if (editCellState != null && column.renderEditCell) {
    const updatedRow = apiRef2.current.getRowWithUpdatedValues(rowId, column.field);
    const editCellStateRest = _objectWithoutPropertiesLoose$1(editCellState, _excluded$1a);
    const params = _extends$1({}, cellParamsWithAPI, {
      row: updatedRow
    }, editCellStateRest);
    children = column.renderEditCell(params);
    classNames.push(gridClasses["cell--editing"]);
    classNames.push(rootClasses == null ? void 0 : rootClasses["cell--editing"]);
  }
  const {
    slots
  } = rootProps;
  const CellComponent = slots.cell;
  const cellProps = _extends$1({}, props, {
    ref,
    field,
    formattedValue,
    hasFocus,
    isEditable,
    isSelected,
    value,
    cellMode,
    children,
    tabIndex,
    className: clsx$1(classNames)
  });
  return /* @__PURE__ */ reactExports.createElement(CellComponent, cellProps);
});
const MemoizedCellWrapper = fastMemo(GridCellWrapper);
const GridCellV7 = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  var _rootProps$experiment4;
  const {
    column,
    rowId,
    editCellState,
    align,
    colIndex,
    height,
    width,
    className,
    showRightBorder,
    colSpan,
    disableDragEvents,
    isNotVisible,
    onClick,
    onDoubleClick,
    onMouseDown,
    onMouseUp,
    onMouseOver,
    onKeyDown,
    onKeyUp,
    onDragEnter,
    onDragOver
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded3);
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const field = column.field;
  const cellParamsWithAPI = useGridSelector(apiRef2, () => {
    try {
      const cellParams = apiRef2.current.getCellParams(rowId, field);
      const result = cellParams;
      result.api = apiRef2.current;
      return result;
    } catch (e2) {
      if (e2 instanceof MissingRowIdError) {
        return EMPTY_CELL_PARAMS;
      }
      throw e2;
    }
  }, objectShallowCompare);
  const isSelected = useGridSelector(apiRef2, () => apiRef2.current.unstable_applyPipeProcessors("isCellSelected", false, {
    id: rowId,
    field
  }));
  const {
    cellMode,
    hasFocus,
    isEditable,
    value,
    formattedValue
  } = cellParamsWithAPI;
  const managesOwnFocus = column.type === "actions";
  const tabIndex = (cellMode === "view" || !isEditable) && !managesOwnFocus ? cellParamsWithAPI.tabIndex : -1;
  const {
    classes: rootClasses,
    getCellClassName
  } = rootProps;
  const classNames = apiRef2.current.unstable_applyPipeProcessors("cellClassName", [], {
    id: rowId,
    field
  });
  if (column.cellClassName) {
    classNames.push(typeof column.cellClassName === "function" ? column.cellClassName(cellParamsWithAPI) : column.cellClassName);
  }
  if (getCellClassName) {
    classNames.push(getCellClassName(cellParamsWithAPI));
  }
  const valueToRender = formattedValue == null ? value : formattedValue;
  const cellRef = reactExports.useRef(null);
  const handleRef = useForkRef$1(ref, cellRef);
  const focusElementRef = reactExports.useRef(null);
  const ownerState = {
    align,
    showRightBorder,
    isEditable,
    classes: rootProps.classes,
    isSelected
  };
  const classes2 = useUtilityClasses$T(ownerState);
  const publishMouseUp = reactExports.useCallback((eventName) => (event) => {
    const params = apiRef2.current.getCellParams(rowId, field || "");
    apiRef2.current.publishEvent(eventName, params, event);
    if (onMouseUp) {
      onMouseUp(event);
    }
  }, [apiRef2, field, onMouseUp, rowId]);
  const publishMouseDown = reactExports.useCallback((eventName) => (event) => {
    const params = apiRef2.current.getCellParams(rowId, field || "");
    apiRef2.current.publishEvent(eventName, params, event);
    if (onMouseDown) {
      onMouseDown(event);
    }
  }, [apiRef2, field, onMouseDown, rowId]);
  const publish = reactExports.useCallback((eventName, propHandler) => (event) => {
    if (!apiRef2.current.getRow(rowId)) {
      return;
    }
    const params = apiRef2.current.getCellParams(rowId, field || "");
    apiRef2.current.publishEvent(eventName, params, event);
    if (propHandler) {
      propHandler(event);
    }
  }, [apiRef2, field, rowId]);
  const style = reactExports.useMemo(() => {
    if (isNotVisible) {
      return {
        padding: 0,
        opacity: 0,
        width: 0
      };
    }
    const cellStyle = {
      minWidth: width,
      maxWidth: width,
      minHeight: height,
      maxHeight: height === "auto" ? "none" : height
      // max-height doesn't support "auto"
    };
    return cellStyle;
  }, [width, height, isNotVisible]);
  reactExports.useEffect(() => {
    if (!hasFocus || cellMode === GridCellModes.Edit) {
      return;
    }
    const doc = ownerDocument$1(apiRef2.current.rootElementRef.current);
    if (cellRef.current && !cellRef.current.contains(doc.activeElement)) {
      const focusableElement = cellRef.current.querySelector('[tabindex="0"]');
      const elementToFocus = focusElementRef.current || focusableElement || cellRef.current;
      if (doesSupportPreventScroll()) {
        elementToFocus.focus({
          preventScroll: true
        });
      } else {
        const scrollPosition = apiRef2.current.getScrollPosition();
        elementToFocus.focus();
        apiRef2.current.scroll(scrollPosition);
      }
    }
  }, [hasFocus, cellMode, apiRef2]);
  if (cellParamsWithAPI === EMPTY_CELL_PARAMS) {
    return null;
  }
  let handleFocus = other.onFocus;
  let children;
  if (editCellState == null && column.renderCell) {
    children = column.renderCell(cellParamsWithAPI);
    classNames.push(gridClasses["cell--withRenderer"]);
    classNames.push(rootClasses == null ? void 0 : rootClasses["cell--withRenderer"]);
  }
  if (editCellState != null && column.renderEditCell) {
    const updatedRow = apiRef2.current.getRowWithUpdatedValues(rowId, column.field);
    const editCellStateRest = _objectWithoutPropertiesLoose$1(editCellState, _excluded4);
    const params = _extends$1({}, cellParamsWithAPI, {
      row: updatedRow
    }, editCellStateRest);
    children = column.renderEditCell(params);
    classNames.push(gridClasses["cell--editing"]);
    classNames.push(rootClasses == null ? void 0 : rootClasses["cell--editing"]);
  }
  if (children === void 0) {
    const valueString = valueToRender == null ? void 0 : valueToRender.toString();
    children = /* @__PURE__ */ jsxRuntimeExports.jsx("div", {
      className: classes2.content,
      title: valueString,
      role: "presentation",
      children: valueString
    });
  }
  if (/* @__PURE__ */ reactExports.isValidElement(children) && managesOwnFocus) {
    children = /* @__PURE__ */ reactExports.cloneElement(children, {
      focusElementRef
    });
  }
  const draggableEventHandlers = disableDragEvents ? null : {
    onDragEnter: publish("cellDragEnter", onDragEnter),
    onDragOver: publish("cellDragOver", onDragOver)
  };
  const ariaV7 = (_rootProps$experiment4 = rootProps.experimentalFeatures) == null ? void 0 : _rootProps$experiment4.ariaV7;
  return (
    // eslint-disable-next-line jsx-a11y/no-static-element-interactions
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", _extends$1({
      ref: handleRef,
      className: clsx$1(className, classNames, classes2.root),
      role: ariaV7 ? "gridcell" : "cell",
      "data-field": field,
      "data-colindex": colIndex,
      "aria-colindex": colIndex + 1,
      "aria-colspan": colSpan,
      style,
      tabIndex,
      onClick: publish("cellClick", onClick),
      onDoubleClick: publish("cellDoubleClick", onDoubleClick),
      onMouseOver: publish("cellMouseOver", onMouseOver),
      onMouseDown: publishMouseDown("cellMouseDown"),
      onMouseUp: publishMouseUp("cellMouseUp"),
      onKeyDown: publish("cellKeyDown", onKeyDown),
      onKeyUp: publish("cellKeyUp", onKeyUp)
    }, draggableEventHandlers, other, {
      onFocus: handleFocus,
      children
    }))
  );
});
const MemoizedGridCellV7 = fastMemo(GridCellV7);
const _excluded$19 = ["id", "value", "formattedValue", "api", "field", "row", "rowNode", "colDef", "cellMode", "isEditable", "hasFocus", "tabIndex"];
const useUtilityClasses$S = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["booleanCell"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
function GridBooleanCellRaw(props) {
  const {
    value
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$19);
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const ownerState = {
    classes: rootProps.classes
  };
  const classes2 = useUtilityClasses$S(ownerState);
  const Icon = reactExports.useMemo(() => value ? rootProps.slots.booleanCellTrueIcon : rootProps.slots.booleanCellFalseIcon, [rootProps.slots.booleanCellFalseIcon, rootProps.slots.booleanCellTrueIcon, value]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, _extends$1({
    fontSize: "small",
    className: classes2.root,
    titleAccess: apiRef2.current.getLocaleText(value ? "booleanCellTrueLabel" : "booleanCellFalseLabel"),
    "data-value": Boolean(value)
  }, other));
}
const GridBooleanCell = /* @__PURE__ */ reactExports.memo(GridBooleanCellRaw);
const renderBooleanCell = (params) => {
  if (isAutoGeneratedRow(params.rowNode)) {
    return "";
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridBooleanCell, _extends$1({}, params));
};
const _excluded$18 = ["id", "value", "formattedValue", "api", "field", "row", "rowNode", "colDef", "cellMode", "isEditable", "tabIndex", "className", "hasFocus", "isValidating", "isProcessingProps", "error", "onValueChange"];
const useUtilityClasses$R = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["editBooleanCell"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
function GridEditBooleanCell(props) {
  var _rootProps$slotProps;
  const {
    id: idProp,
    value,
    field,
    className,
    hasFocus,
    onValueChange
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$18);
  const apiRef2 = useGridApiContext();
  const inputRef = reactExports.useRef(null);
  const id = useId();
  const [valueState, setValueState] = reactExports.useState(value);
  const rootProps = useGridRootProps();
  const ownerState = {
    classes: rootProps.classes
  };
  const classes2 = useUtilityClasses$R(ownerState);
  const handleChange = reactExports.useCallback(async (event) => {
    const newValue = event.target.checked;
    if (onValueChange) {
      await onValueChange(event, newValue);
    }
    setValueState(newValue);
    await apiRef2.current.setEditCellValue({
      id: idProp,
      field,
      value: newValue
    }, event);
  }, [apiRef2, field, idProp, onValueChange]);
  reactExports.useEffect(() => {
    setValueState(value);
  }, [value]);
  useEnhancedEffect$1(() => {
    if (hasFocus) {
      inputRef.current.focus();
    }
  }, [hasFocus]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("label", _extends$1({
    htmlFor: id,
    className: clsx$1(classes2.root, className)
  }, other, {
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseCheckbox, _extends$1({
      id,
      inputRef,
      checked: Boolean(valueState),
      onChange: handleChange,
      size: "small"
    }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseCheckbox))
  }));
}
const renderEditBooleanCell = (params) => /* @__PURE__ */ jsxRuntimeExports.jsx(GridEditBooleanCell, _extends$1({}, params));
function useBadge(parameters) {
  const {
    badgeContent: badgeContentProp,
    invisible: invisibleProp = false,
    max: maxProp = 99,
    showZero = false
  } = parameters;
  const prevProps = usePreviousProps$1({
    badgeContent: badgeContentProp,
    max: maxProp
  });
  let invisible = invisibleProp;
  if (invisibleProp === false && badgeContentProp === 0 && !showZero) {
    invisible = true;
  }
  const {
    badgeContent,
    max: max2 = maxProp
  } = invisible ? prevProps : parameters;
  const displayValue = badgeContent && Number(badgeContent) > max2 ? `${max2}+` : badgeContent;
  return {
    badgeContent,
    invisible,
    max: max2,
    displayValue
  };
}
function mapEventPropToEvent(eventProp) {
  return eventProp.substring(2).toLowerCase();
}
function clickedRootScrollbar(event, doc) {
  return doc.documentElement.clientWidth < event.clientX || doc.documentElement.clientHeight < event.clientY;
}
function ClickAwayListener(props) {
  const {
    children,
    disableReactTree = false,
    mouseEvent = "onClick",
    onClickAway,
    touchEvent = "onTouchEnd"
  } = props;
  const movedRef = reactExports.useRef(false);
  const nodeRef = reactExports.useRef(null);
  const activatedRef = reactExports.useRef(false);
  const syntheticEventRef = reactExports.useRef(false);
  reactExports.useEffect(() => {
    setTimeout(() => {
      activatedRef.current = true;
    }, 0);
    return () => {
      activatedRef.current = false;
    };
  }, []);
  const handleRef = useForkRef$1(
    // @ts-expect-error TODO upstream fix
    children.ref,
    nodeRef
  );
  const handleClickAway = useEventCallback$1((event) => {
    const insideReactTree = syntheticEventRef.current;
    syntheticEventRef.current = false;
    const doc = ownerDocument$1(nodeRef.current);
    if (!activatedRef.current || !nodeRef.current || "clientX" in event && clickedRootScrollbar(event, doc)) {
      return;
    }
    if (movedRef.current) {
      movedRef.current = false;
      return;
    }
    let insideDOM;
    if (event.composedPath) {
      insideDOM = event.composedPath().indexOf(nodeRef.current) > -1;
    } else {
      insideDOM = !doc.documentElement.contains(
        // @ts-expect-error returns `false` as intended when not dispatched from a Node
        event.target
      ) || nodeRef.current.contains(
        // @ts-expect-error returns `false` as intended when not dispatched from a Node
        event.target
      );
    }
    if (!insideDOM && (disableReactTree || !insideReactTree)) {
      onClickAway(event);
    }
  });
  const createHandleSynthetic = (handlerName) => (event) => {
    syntheticEventRef.current = true;
    const childrenPropsHandler = children.props[handlerName];
    if (childrenPropsHandler) {
      childrenPropsHandler(event);
    }
  };
  const childrenProps = {
    ref: handleRef
  };
  if (touchEvent !== false) {
    childrenProps[touchEvent] = createHandleSynthetic(touchEvent);
  }
  reactExports.useEffect(() => {
    if (touchEvent !== false) {
      const mappedTouchEvent = mapEventPropToEvent(touchEvent);
      const doc = ownerDocument$1(nodeRef.current);
      const handleTouchMove = () => {
        movedRef.current = true;
      };
      doc.addEventListener(mappedTouchEvent, handleClickAway);
      doc.addEventListener("touchmove", handleTouchMove);
      return () => {
        doc.removeEventListener(mappedTouchEvent, handleClickAway);
        doc.removeEventListener("touchmove", handleTouchMove);
      };
    }
    return void 0;
  }, [handleClickAway, touchEvent]);
  if (mouseEvent !== false) {
    childrenProps[mouseEvent] = createHandleSynthetic(mouseEvent);
  }
  reactExports.useEffect(() => {
    if (mouseEvent !== false) {
      const mappedMouseEvent = mapEventPropToEvent(mouseEvent);
      const doc = ownerDocument$1(nodeRef.current);
      doc.addEventListener(mappedMouseEvent, handleClickAway);
      return () => {
        doc.removeEventListener(mappedMouseEvent, handleClickAway);
      };
    }
    return void 0;
  }, [handleClickAway, mouseEvent]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.Fragment, {
    children: /* @__PURE__ */ reactExports.cloneElement(children, childrenProps)
  });
}
var top = "top";
var bottom = "bottom";
var right = "right";
var left = "left";
var auto = "auto";
var basePlacements = [top, bottom, right, left];
var start = "start";
var end = "end";
var clippingParents = "clippingParents";
var viewport = "viewport";
var popper = "popper";
var reference = "reference";
var variationPlacements = /* @__PURE__ */ basePlacements.reduce(function(acc, placement) {
  return acc.concat([placement + "-" + start, placement + "-" + end]);
}, []);
var placements = /* @__PURE__ */ [].concat(basePlacements, [auto]).reduce(function(acc, placement) {
  return acc.concat([placement, placement + "-" + start, placement + "-" + end]);
}, []);
var beforeRead = "beforeRead";
var read = "read";
var afterRead = "afterRead";
var beforeMain = "beforeMain";
var main = "main";
var afterMain = "afterMain";
var beforeWrite = "beforeWrite";
var write = "write";
var afterWrite = "afterWrite";
var modifierPhases = [beforeRead, read, afterRead, beforeMain, main, afterMain, beforeWrite, write, afterWrite];
function getNodeName(element) {
  return element ? (element.nodeName || "").toLowerCase() : null;
}
function getWindow(node) {
  if (node == null) {
    return window;
  }
  if (node.toString() !== "[object Window]") {
    var ownerDocument2 = node.ownerDocument;
    return ownerDocument2 ? ownerDocument2.defaultView || window : window;
  }
  return node;
}
function isElement(node) {
  var OwnElement = getWindow(node).Element;
  return node instanceof OwnElement || node instanceof Element;
}
function isHTMLElement$1(node) {
  var OwnElement = getWindow(node).HTMLElement;
  return node instanceof OwnElement || node instanceof HTMLElement;
}
function isShadowRoot(node) {
  if (typeof ShadowRoot === "undefined") {
    return false;
  }
  var OwnElement = getWindow(node).ShadowRoot;
  return node instanceof OwnElement || node instanceof ShadowRoot;
}
function applyStyles(_ref) {
  var state = _ref.state;
  Object.keys(state.elements).forEach(function(name) {
    var style = state.styles[name] || {};
    var attributes = state.attributes[name] || {};
    var element = state.elements[name];
    if (!isHTMLElement$1(element) || !getNodeName(element)) {
      return;
    }
    Object.assign(element.style, style);
    Object.keys(attributes).forEach(function(name2) {
      var value = attributes[name2];
      if (value === false) {
        element.removeAttribute(name2);
      } else {
        element.setAttribute(name2, value === true ? "" : value);
      }
    });
  });
}
function effect$2(_ref2) {
  var state = _ref2.state;
  var initialStyles = {
    popper: {
      position: state.options.strategy,
      left: "0",
      top: "0",
      margin: "0"
    },
    arrow: {
      position: "absolute"
    },
    reference: {}
  };
  Object.assign(state.elements.popper.style, initialStyles.popper);
  state.styles = initialStyles;
  if (state.elements.arrow) {
    Object.assign(state.elements.arrow.style, initialStyles.arrow);
  }
  return function() {
    Object.keys(state.elements).forEach(function(name) {
      var element = state.elements[name];
      var attributes = state.attributes[name] || {};
      var styleProperties = Object.keys(state.styles.hasOwnProperty(name) ? state.styles[name] : initialStyles[name]);
      var style = styleProperties.reduce(function(style2, property) {
        style2[property] = "";
        return style2;
      }, {});
      if (!isHTMLElement$1(element) || !getNodeName(element)) {
        return;
      }
      Object.assign(element.style, style);
      Object.keys(attributes).forEach(function(attribute) {
        element.removeAttribute(attribute);
      });
    });
  };
}
const applyStyles$1 = {
  name: "applyStyles",
  enabled: true,
  phase: "write",
  fn: applyStyles,
  effect: effect$2,
  requires: ["computeStyles"]
};
function getBasePlacement(placement) {
  return placement.split("-")[0];
}
var max = Math.max;
var min = Math.min;
var round$1 = Math.round;
function getUAString() {
  var uaData = navigator.userAgentData;
  if (uaData != null && uaData.brands && Array.isArray(uaData.brands)) {
    return uaData.brands.map(function(item) {
      return item.brand + "/" + item.version;
    }).join(" ");
  }
  return navigator.userAgent;
}
function isLayoutViewport() {
  return !/^((?!chrome|android).)*safari/i.test(getUAString());
}
function getBoundingClientRect(element, includeScale, isFixedStrategy) {
  if (includeScale === void 0) {
    includeScale = false;
  }
  if (isFixedStrategy === void 0) {
    isFixedStrategy = false;
  }
  var clientRect = element.getBoundingClientRect();
  var scaleX = 1;
  var scaleY = 1;
  if (includeScale && isHTMLElement$1(element)) {
    scaleX = element.offsetWidth > 0 ? round$1(clientRect.width) / element.offsetWidth || 1 : 1;
    scaleY = element.offsetHeight > 0 ? round$1(clientRect.height) / element.offsetHeight || 1 : 1;
  }
  var _ref = isElement(element) ? getWindow(element) : window, visualViewport = _ref.visualViewport;
  var addVisualOffsets = !isLayoutViewport() && isFixedStrategy;
  var x = (clientRect.left + (addVisualOffsets && visualViewport ? visualViewport.offsetLeft : 0)) / scaleX;
  var y = (clientRect.top + (addVisualOffsets && visualViewport ? visualViewport.offsetTop : 0)) / scaleY;
  var width = clientRect.width / scaleX;
  var height = clientRect.height / scaleY;
  return {
    width,
    height,
    top: y,
    right: x + width,
    bottom: y + height,
    left: x,
    x,
    y
  };
}
function getLayoutRect(element) {
  var clientRect = getBoundingClientRect(element);
  var width = element.offsetWidth;
  var height = element.offsetHeight;
  if (Math.abs(clientRect.width - width) <= 1) {
    width = clientRect.width;
  }
  if (Math.abs(clientRect.height - height) <= 1) {
    height = clientRect.height;
  }
  return {
    x: element.offsetLeft,
    y: element.offsetTop,
    width,
    height
  };
}
function contains(parent, child) {
  var rootNode = child.getRootNode && child.getRootNode();
  if (parent.contains(child)) {
    return true;
  } else if (rootNode && isShadowRoot(rootNode)) {
    var next = child;
    do {
      if (next && parent.isSameNode(next)) {
        return true;
      }
      next = next.parentNode || next.host;
    } while (next);
  }
  return false;
}
function getComputedStyle(element) {
  return getWindow(element).getComputedStyle(element);
}
function isTableElement(element) {
  return ["table", "td", "th"].indexOf(getNodeName(element)) >= 0;
}
function getDocumentElement(element) {
  return ((isElement(element) ? element.ownerDocument : (
    // $FlowFixMe[prop-missing]
    element.document
  )) || window.document).documentElement;
}
function getParentNode(element) {
  if (getNodeName(element) === "html") {
    return element;
  }
  return (
    // this is a quicker (but less type safe) way to save quite some bytes from the bundle
    // $FlowFixMe[incompatible-return]
    // $FlowFixMe[prop-missing]
    element.assignedSlot || // step into the shadow DOM of the parent of a slotted node
    element.parentNode || // DOM Element detected
    (isShadowRoot(element) ? element.host : null) || // ShadowRoot detected
    // $FlowFixMe[incompatible-call]: HTMLElement is a Node
    getDocumentElement(element)
  );
}
function getTrueOffsetParent(element) {
  if (!isHTMLElement$1(element) || // https://github.com/popperjs/popper-core/issues/837
  getComputedStyle(element).position === "fixed") {
    return null;
  }
  return element.offsetParent;
}
function getContainingBlock(element) {
  var isFirefox = /firefox/i.test(getUAString());
  var isIE = /Trident/i.test(getUAString());
  if (isIE && isHTMLElement$1(element)) {
    var elementCss = getComputedStyle(element);
    if (elementCss.position === "fixed") {
      return null;
    }
  }
  var currentNode = getParentNode(element);
  if (isShadowRoot(currentNode)) {
    currentNode = currentNode.host;
  }
  while (isHTMLElement$1(currentNode) && ["html", "body"].indexOf(getNodeName(currentNode)) < 0) {
    var css2 = getComputedStyle(currentNode);
    if (css2.transform !== "none" || css2.perspective !== "none" || css2.contain === "paint" || ["transform", "perspective"].indexOf(css2.willChange) !== -1 || isFirefox && css2.willChange === "filter" || isFirefox && css2.filter && css2.filter !== "none") {
      return currentNode;
    } else {
      currentNode = currentNode.parentNode;
    }
  }
  return null;
}
function getOffsetParent(element) {
  var window2 = getWindow(element);
  var offsetParent = getTrueOffsetParent(element);
  while (offsetParent && isTableElement(offsetParent) && getComputedStyle(offsetParent).position === "static") {
    offsetParent = getTrueOffsetParent(offsetParent);
  }
  if (offsetParent && (getNodeName(offsetParent) === "html" || getNodeName(offsetParent) === "body" && getComputedStyle(offsetParent).position === "static")) {
    return window2;
  }
  return offsetParent || getContainingBlock(element) || window2;
}
function getMainAxisFromPlacement(placement) {
  return ["top", "bottom"].indexOf(placement) >= 0 ? "x" : "y";
}
function within(min$1, value, max$1) {
  return max(min$1, min(value, max$1));
}
function withinMaxClamp(min2, value, max2) {
  var v = within(min2, value, max2);
  return v > max2 ? max2 : v;
}
function getFreshSideObject() {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  };
}
function mergePaddingObject(paddingObject) {
  return Object.assign({}, getFreshSideObject(), paddingObject);
}
function expandToHashMap(value, keys) {
  return keys.reduce(function(hashMap, key) {
    hashMap[key] = value;
    return hashMap;
  }, {});
}
var toPaddingObject = function toPaddingObject2(padding, state) {
  padding = typeof padding === "function" ? padding(Object.assign({}, state.rects, {
    placement: state.placement
  })) : padding;
  return mergePaddingObject(typeof padding !== "number" ? padding : expandToHashMap(padding, basePlacements));
};
function arrow(_ref) {
  var _state$modifiersData$;
  var state = _ref.state, name = _ref.name, options = _ref.options;
  var arrowElement = state.elements.arrow;
  var popperOffsets2 = state.modifiersData.popperOffsets;
  var basePlacement = getBasePlacement(state.placement);
  var axis = getMainAxisFromPlacement(basePlacement);
  var isVertical = [left, right].indexOf(basePlacement) >= 0;
  var len = isVertical ? "height" : "width";
  if (!arrowElement || !popperOffsets2) {
    return;
  }
  var paddingObject = toPaddingObject(options.padding, state);
  var arrowRect = getLayoutRect(arrowElement);
  var minProp = axis === "y" ? top : left;
  var maxProp = axis === "y" ? bottom : right;
  var endDiff = state.rects.reference[len] + state.rects.reference[axis] - popperOffsets2[axis] - state.rects.popper[len];
  var startDiff = popperOffsets2[axis] - state.rects.reference[axis];
  var arrowOffsetParent = getOffsetParent(arrowElement);
  var clientSize = arrowOffsetParent ? axis === "y" ? arrowOffsetParent.clientHeight || 0 : arrowOffsetParent.clientWidth || 0 : 0;
  var centerToReference = endDiff / 2 - startDiff / 2;
  var min2 = paddingObject[minProp];
  var max2 = clientSize - arrowRect[len] - paddingObject[maxProp];
  var center = clientSize / 2 - arrowRect[len] / 2 + centerToReference;
  var offset2 = within(min2, center, max2);
  var axisProp = axis;
  state.modifiersData[name] = (_state$modifiersData$ = {}, _state$modifiersData$[axisProp] = offset2, _state$modifiersData$.centerOffset = offset2 - center, _state$modifiersData$);
}
function effect$1(_ref2) {
  var state = _ref2.state, options = _ref2.options;
  var _options$element = options.element, arrowElement = _options$element === void 0 ? "[data-popper-arrow]" : _options$element;
  if (arrowElement == null) {
    return;
  }
  if (typeof arrowElement === "string") {
    arrowElement = state.elements.popper.querySelector(arrowElement);
    if (!arrowElement) {
      return;
    }
  }
  if (!contains(state.elements.popper, arrowElement)) {
    return;
  }
  state.elements.arrow = arrowElement;
}
const arrow$1 = {
  name: "arrow",
  enabled: true,
  phase: "main",
  fn: arrow,
  effect: effect$1,
  requires: ["popperOffsets"],
  requiresIfExists: ["preventOverflow"]
};
function getVariation(placement) {
  return placement.split("-")[1];
}
var unsetSides = {
  top: "auto",
  right: "auto",
  bottom: "auto",
  left: "auto"
};
function roundOffsetsByDPR(_ref, win) {
  var x = _ref.x, y = _ref.y;
  var dpr = win.devicePixelRatio || 1;
  return {
    x: round$1(x * dpr) / dpr || 0,
    y: round$1(y * dpr) / dpr || 0
  };
}
function mapToStyles(_ref2) {
  var _Object$assign2;
  var popper2 = _ref2.popper, popperRect = _ref2.popperRect, placement = _ref2.placement, variation = _ref2.variation, offsets = _ref2.offsets, position = _ref2.position, gpuAcceleration = _ref2.gpuAcceleration, adaptive = _ref2.adaptive, roundOffsets = _ref2.roundOffsets, isFixed = _ref2.isFixed;
  var _offsets$x = offsets.x, x = _offsets$x === void 0 ? 0 : _offsets$x, _offsets$y = offsets.y, y = _offsets$y === void 0 ? 0 : _offsets$y;
  var _ref3 = typeof roundOffsets === "function" ? roundOffsets({
    x,
    y
  }) : {
    x,
    y
  };
  x = _ref3.x;
  y = _ref3.y;
  var hasX = offsets.hasOwnProperty("x");
  var hasY = offsets.hasOwnProperty("y");
  var sideX = left;
  var sideY = top;
  var win = window;
  if (adaptive) {
    var offsetParent = getOffsetParent(popper2);
    var heightProp = "clientHeight";
    var widthProp = "clientWidth";
    if (offsetParent === getWindow(popper2)) {
      offsetParent = getDocumentElement(popper2);
      if (getComputedStyle(offsetParent).position !== "static" && position === "absolute") {
        heightProp = "scrollHeight";
        widthProp = "scrollWidth";
      }
    }
    offsetParent = offsetParent;
    if (placement === top || (placement === left || placement === right) && variation === end) {
      sideY = bottom;
      var offsetY = isFixed && offsetParent === win && win.visualViewport ? win.visualViewport.height : (
        // $FlowFixMe[prop-missing]
        offsetParent[heightProp]
      );
      y -= offsetY - popperRect.height;
      y *= gpuAcceleration ? 1 : -1;
    }
    if (placement === left || (placement === top || placement === bottom) && variation === end) {
      sideX = right;
      var offsetX = isFixed && offsetParent === win && win.visualViewport ? win.visualViewport.width : (
        // $FlowFixMe[prop-missing]
        offsetParent[widthProp]
      );
      x -= offsetX - popperRect.width;
      x *= gpuAcceleration ? 1 : -1;
    }
  }
  var commonStyles = Object.assign({
    position
  }, adaptive && unsetSides);
  var _ref4 = roundOffsets === true ? roundOffsetsByDPR({
    x,
    y
  }, getWindow(popper2)) : {
    x,
    y
  };
  x = _ref4.x;
  y = _ref4.y;
  if (gpuAcceleration) {
    var _Object$assign;
    return Object.assign({}, commonStyles, (_Object$assign = {}, _Object$assign[sideY] = hasY ? "0" : "", _Object$assign[sideX] = hasX ? "0" : "", _Object$assign.transform = (win.devicePixelRatio || 1) <= 1 ? "translate(" + x + "px, " + y + "px)" : "translate3d(" + x + "px, " + y + "px, 0)", _Object$assign));
  }
  return Object.assign({}, commonStyles, (_Object$assign2 = {}, _Object$assign2[sideY] = hasY ? y + "px" : "", _Object$assign2[sideX] = hasX ? x + "px" : "", _Object$assign2.transform = "", _Object$assign2));
}
function computeStyles(_ref5) {
  var state = _ref5.state, options = _ref5.options;
  var _options$gpuAccelerat = options.gpuAcceleration, gpuAcceleration = _options$gpuAccelerat === void 0 ? true : _options$gpuAccelerat, _options$adaptive = options.adaptive, adaptive = _options$adaptive === void 0 ? true : _options$adaptive, _options$roundOffsets = options.roundOffsets, roundOffsets = _options$roundOffsets === void 0 ? true : _options$roundOffsets;
  var commonStyles = {
    placement: getBasePlacement(state.placement),
    variation: getVariation(state.placement),
    popper: state.elements.popper,
    popperRect: state.rects.popper,
    gpuAcceleration,
    isFixed: state.options.strategy === "fixed"
  };
  if (state.modifiersData.popperOffsets != null) {
    state.styles.popper = Object.assign({}, state.styles.popper, mapToStyles(Object.assign({}, commonStyles, {
      offsets: state.modifiersData.popperOffsets,
      position: state.options.strategy,
      adaptive,
      roundOffsets
    })));
  }
  if (state.modifiersData.arrow != null) {
    state.styles.arrow = Object.assign({}, state.styles.arrow, mapToStyles(Object.assign({}, commonStyles, {
      offsets: state.modifiersData.arrow,
      position: "absolute",
      adaptive: false,
      roundOffsets
    })));
  }
  state.attributes.popper = Object.assign({}, state.attributes.popper, {
    "data-popper-placement": state.placement
  });
}
const computeStyles$1 = {
  name: "computeStyles",
  enabled: true,
  phase: "beforeWrite",
  fn: computeStyles,
  data: {}
};
var passive = {
  passive: true
};
function effect(_ref) {
  var state = _ref.state, instance = _ref.instance, options = _ref.options;
  var _options$scroll = options.scroll, scroll = _options$scroll === void 0 ? true : _options$scroll, _options$resize = options.resize, resize = _options$resize === void 0 ? true : _options$resize;
  var window2 = getWindow(state.elements.popper);
  var scrollParents = [].concat(state.scrollParents.reference, state.scrollParents.popper);
  if (scroll) {
    scrollParents.forEach(function(scrollParent) {
      scrollParent.addEventListener("scroll", instance.update, passive);
    });
  }
  if (resize) {
    window2.addEventListener("resize", instance.update, passive);
  }
  return function() {
    if (scroll) {
      scrollParents.forEach(function(scrollParent) {
        scrollParent.removeEventListener("scroll", instance.update, passive);
      });
    }
    if (resize) {
      window2.removeEventListener("resize", instance.update, passive);
    }
  };
}
const eventListeners = {
  name: "eventListeners",
  enabled: true,
  phase: "write",
  fn: function fn() {
  },
  effect,
  data: {}
};
var hash$1 = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
};
function getOppositePlacement(placement) {
  return placement.replace(/left|right|bottom|top/g, function(matched) {
    return hash$1[matched];
  });
}
var hash = {
  start: "end",
  end: "start"
};
function getOppositeVariationPlacement(placement) {
  return placement.replace(/start|end/g, function(matched) {
    return hash[matched];
  });
}
function getWindowScroll(node) {
  var win = getWindow(node);
  var scrollLeft = win.pageXOffset;
  var scrollTop = win.pageYOffset;
  return {
    scrollLeft,
    scrollTop
  };
}
function getWindowScrollBarX(element) {
  return getBoundingClientRect(getDocumentElement(element)).left + getWindowScroll(element).scrollLeft;
}
function getViewportRect(element, strategy) {
  var win = getWindow(element);
  var html = getDocumentElement(element);
  var visualViewport = win.visualViewport;
  var width = html.clientWidth;
  var height = html.clientHeight;
  var x = 0;
  var y = 0;
  if (visualViewport) {
    width = visualViewport.width;
    height = visualViewport.height;
    var layoutViewport = isLayoutViewport();
    if (layoutViewport || !layoutViewport && strategy === "fixed") {
      x = visualViewport.offsetLeft;
      y = visualViewport.offsetTop;
    }
  }
  return {
    width,
    height,
    x: x + getWindowScrollBarX(element),
    y
  };
}
function getDocumentRect(element) {
  var _element$ownerDocumen;
  var html = getDocumentElement(element);
  var winScroll = getWindowScroll(element);
  var body = (_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body;
  var width = max(html.scrollWidth, html.clientWidth, body ? body.scrollWidth : 0, body ? body.clientWidth : 0);
  var height = max(html.scrollHeight, html.clientHeight, body ? body.scrollHeight : 0, body ? body.clientHeight : 0);
  var x = -winScroll.scrollLeft + getWindowScrollBarX(element);
  var y = -winScroll.scrollTop;
  if (getComputedStyle(body || html).direction === "rtl") {
    x += max(html.clientWidth, body ? body.clientWidth : 0) - width;
  }
  return {
    width,
    height,
    x,
    y
  };
}
function isScrollParent(element) {
  var _getComputedStyle = getComputedStyle(element), overflow = _getComputedStyle.overflow, overflowX = _getComputedStyle.overflowX, overflowY = _getComputedStyle.overflowY;
  return /auto|scroll|overlay|hidden/.test(overflow + overflowY + overflowX);
}
function getScrollParent(node) {
  if (["html", "body", "#document"].indexOf(getNodeName(node)) >= 0) {
    return node.ownerDocument.body;
  }
  if (isHTMLElement$1(node) && isScrollParent(node)) {
    return node;
  }
  return getScrollParent(getParentNode(node));
}
function listScrollParents(element, list) {
  var _element$ownerDocumen;
  if (list === void 0) {
    list = [];
  }
  var scrollParent = getScrollParent(element);
  var isBody = scrollParent === ((_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body);
  var win = getWindow(scrollParent);
  var target = isBody ? [win].concat(win.visualViewport || [], isScrollParent(scrollParent) ? scrollParent : []) : scrollParent;
  var updatedList = list.concat(target);
  return isBody ? updatedList : (
    // $FlowFixMe[incompatible-call]: isBody tells us target will be an HTMLElement here
    updatedList.concat(listScrollParents(getParentNode(target)))
  );
}
function rectToClientRect(rect) {
  return Object.assign({}, rect, {
    left: rect.x,
    top: rect.y,
    right: rect.x + rect.width,
    bottom: rect.y + rect.height
  });
}
function getInnerBoundingClientRect(element, strategy) {
  var rect = getBoundingClientRect(element, false, strategy === "fixed");
  rect.top = rect.top + element.clientTop;
  rect.left = rect.left + element.clientLeft;
  rect.bottom = rect.top + element.clientHeight;
  rect.right = rect.left + element.clientWidth;
  rect.width = element.clientWidth;
  rect.height = element.clientHeight;
  rect.x = rect.left;
  rect.y = rect.top;
  return rect;
}
function getClientRectFromMixedType(element, clippingParent, strategy) {
  return clippingParent === viewport ? rectToClientRect(getViewportRect(element, strategy)) : isElement(clippingParent) ? getInnerBoundingClientRect(clippingParent, strategy) : rectToClientRect(getDocumentRect(getDocumentElement(element)));
}
function getClippingParents(element) {
  var clippingParents2 = listScrollParents(getParentNode(element));
  var canEscapeClipping = ["absolute", "fixed"].indexOf(getComputedStyle(element).position) >= 0;
  var clipperElement = canEscapeClipping && isHTMLElement$1(element) ? getOffsetParent(element) : element;
  if (!isElement(clipperElement)) {
    return [];
  }
  return clippingParents2.filter(function(clippingParent) {
    return isElement(clippingParent) && contains(clippingParent, clipperElement) && getNodeName(clippingParent) !== "body";
  });
}
function getClippingRect(element, boundary, rootBoundary, strategy) {
  var mainClippingParents = boundary === "clippingParents" ? getClippingParents(element) : [].concat(boundary);
  var clippingParents2 = [].concat(mainClippingParents, [rootBoundary]);
  var firstClippingParent = clippingParents2[0];
  var clippingRect = clippingParents2.reduce(function(accRect, clippingParent) {
    var rect = getClientRectFromMixedType(element, clippingParent, strategy);
    accRect.top = max(rect.top, accRect.top);
    accRect.right = min(rect.right, accRect.right);
    accRect.bottom = min(rect.bottom, accRect.bottom);
    accRect.left = max(rect.left, accRect.left);
    return accRect;
  }, getClientRectFromMixedType(element, firstClippingParent, strategy));
  clippingRect.width = clippingRect.right - clippingRect.left;
  clippingRect.height = clippingRect.bottom - clippingRect.top;
  clippingRect.x = clippingRect.left;
  clippingRect.y = clippingRect.top;
  return clippingRect;
}
function computeOffsets(_ref) {
  var reference2 = _ref.reference, element = _ref.element, placement = _ref.placement;
  var basePlacement = placement ? getBasePlacement(placement) : null;
  var variation = placement ? getVariation(placement) : null;
  var commonX = reference2.x + reference2.width / 2 - element.width / 2;
  var commonY = reference2.y + reference2.height / 2 - element.height / 2;
  var offsets;
  switch (basePlacement) {
    case top:
      offsets = {
        x: commonX,
        y: reference2.y - element.height
      };
      break;
    case bottom:
      offsets = {
        x: commonX,
        y: reference2.y + reference2.height
      };
      break;
    case right:
      offsets = {
        x: reference2.x + reference2.width,
        y: commonY
      };
      break;
    case left:
      offsets = {
        x: reference2.x - element.width,
        y: commonY
      };
      break;
    default:
      offsets = {
        x: reference2.x,
        y: reference2.y
      };
  }
  var mainAxis = basePlacement ? getMainAxisFromPlacement(basePlacement) : null;
  if (mainAxis != null) {
    var len = mainAxis === "y" ? "height" : "width";
    switch (variation) {
      case start:
        offsets[mainAxis] = offsets[mainAxis] - (reference2[len] / 2 - element[len] / 2);
        break;
      case end:
        offsets[mainAxis] = offsets[mainAxis] + (reference2[len] / 2 - element[len] / 2);
        break;
    }
  }
  return offsets;
}
function detectOverflow(state, options) {
  if (options === void 0) {
    options = {};
  }
  var _options = options, _options$placement = _options.placement, placement = _options$placement === void 0 ? state.placement : _options$placement, _options$strategy = _options.strategy, strategy = _options$strategy === void 0 ? state.strategy : _options$strategy, _options$boundary = _options.boundary, boundary = _options$boundary === void 0 ? clippingParents : _options$boundary, _options$rootBoundary = _options.rootBoundary, rootBoundary = _options$rootBoundary === void 0 ? viewport : _options$rootBoundary, _options$elementConte = _options.elementContext, elementContext = _options$elementConte === void 0 ? popper : _options$elementConte, _options$altBoundary = _options.altBoundary, altBoundary = _options$altBoundary === void 0 ? false : _options$altBoundary, _options$padding = _options.padding, padding = _options$padding === void 0 ? 0 : _options$padding;
  var paddingObject = mergePaddingObject(typeof padding !== "number" ? padding : expandToHashMap(padding, basePlacements));
  var altContext = elementContext === popper ? reference : popper;
  var popperRect = state.rects.popper;
  var element = state.elements[altBoundary ? altContext : elementContext];
  var clippingClientRect = getClippingRect(isElement(element) ? element : element.contextElement || getDocumentElement(state.elements.popper), boundary, rootBoundary, strategy);
  var referenceClientRect = getBoundingClientRect(state.elements.reference);
  var popperOffsets2 = computeOffsets({
    reference: referenceClientRect,
    element: popperRect,
    strategy: "absolute",
    placement
  });
  var popperClientRect = rectToClientRect(Object.assign({}, popperRect, popperOffsets2));
  var elementClientRect = elementContext === popper ? popperClientRect : referenceClientRect;
  var overflowOffsets = {
    top: clippingClientRect.top - elementClientRect.top + paddingObject.top,
    bottom: elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom,
    left: clippingClientRect.left - elementClientRect.left + paddingObject.left,
    right: elementClientRect.right - clippingClientRect.right + paddingObject.right
  };
  var offsetData = state.modifiersData.offset;
  if (elementContext === popper && offsetData) {
    var offset2 = offsetData[placement];
    Object.keys(overflowOffsets).forEach(function(key) {
      var multiply = [right, bottom].indexOf(key) >= 0 ? 1 : -1;
      var axis = [top, bottom].indexOf(key) >= 0 ? "y" : "x";
      overflowOffsets[key] += offset2[axis] * multiply;
    });
  }
  return overflowOffsets;
}
function computeAutoPlacement(state, options) {
  if (options === void 0) {
    options = {};
  }
  var _options = options, placement = _options.placement, boundary = _options.boundary, rootBoundary = _options.rootBoundary, padding = _options.padding, flipVariations = _options.flipVariations, _options$allowedAutoP = _options.allowedAutoPlacements, allowedAutoPlacements = _options$allowedAutoP === void 0 ? placements : _options$allowedAutoP;
  var variation = getVariation(placement);
  var placements$1 = variation ? flipVariations ? variationPlacements : variationPlacements.filter(function(placement2) {
    return getVariation(placement2) === variation;
  }) : basePlacements;
  var allowedPlacements = placements$1.filter(function(placement2) {
    return allowedAutoPlacements.indexOf(placement2) >= 0;
  });
  if (allowedPlacements.length === 0) {
    allowedPlacements = placements$1;
  }
  var overflows = allowedPlacements.reduce(function(acc, placement2) {
    acc[placement2] = detectOverflow(state, {
      placement: placement2,
      boundary,
      rootBoundary,
      padding
    })[getBasePlacement(placement2)];
    return acc;
  }, {});
  return Object.keys(overflows).sort(function(a2, b) {
    return overflows[a2] - overflows[b];
  });
}
function getExpandedFallbackPlacements(placement) {
  if (getBasePlacement(placement) === auto) {
    return [];
  }
  var oppositePlacement = getOppositePlacement(placement);
  return [getOppositeVariationPlacement(placement), oppositePlacement, getOppositeVariationPlacement(oppositePlacement)];
}
function flip(_ref) {
  var state = _ref.state, options = _ref.options, name = _ref.name;
  if (state.modifiersData[name]._skip) {
    return;
  }
  var _options$mainAxis = options.mainAxis, checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis, _options$altAxis = options.altAxis, checkAltAxis = _options$altAxis === void 0 ? true : _options$altAxis, specifiedFallbackPlacements = options.fallbackPlacements, padding = options.padding, boundary = options.boundary, rootBoundary = options.rootBoundary, altBoundary = options.altBoundary, _options$flipVariatio = options.flipVariations, flipVariations = _options$flipVariatio === void 0 ? true : _options$flipVariatio, allowedAutoPlacements = options.allowedAutoPlacements;
  var preferredPlacement = state.options.placement;
  var basePlacement = getBasePlacement(preferredPlacement);
  var isBasePlacement = basePlacement === preferredPlacement;
  var fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipVariations ? [getOppositePlacement(preferredPlacement)] : getExpandedFallbackPlacements(preferredPlacement));
  var placements2 = [preferredPlacement].concat(fallbackPlacements).reduce(function(acc, placement2) {
    return acc.concat(getBasePlacement(placement2) === auto ? computeAutoPlacement(state, {
      placement: placement2,
      boundary,
      rootBoundary,
      padding,
      flipVariations,
      allowedAutoPlacements
    }) : placement2);
  }, []);
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var checksMap = /* @__PURE__ */ new Map();
  var makeFallbackChecks = true;
  var firstFittingPlacement = placements2[0];
  for (var i2 = 0; i2 < placements2.length; i2++) {
    var placement = placements2[i2];
    var _basePlacement = getBasePlacement(placement);
    var isStartVariation = getVariation(placement) === start;
    var isVertical = [top, bottom].indexOf(_basePlacement) >= 0;
    var len = isVertical ? "width" : "height";
    var overflow = detectOverflow(state, {
      placement,
      boundary,
      rootBoundary,
      altBoundary,
      padding
    });
    var mainVariationSide = isVertical ? isStartVariation ? right : left : isStartVariation ? bottom : top;
    if (referenceRect[len] > popperRect[len]) {
      mainVariationSide = getOppositePlacement(mainVariationSide);
    }
    var altVariationSide = getOppositePlacement(mainVariationSide);
    var checks = [];
    if (checkMainAxis) {
      checks.push(overflow[_basePlacement] <= 0);
    }
    if (checkAltAxis) {
      checks.push(overflow[mainVariationSide] <= 0, overflow[altVariationSide] <= 0);
    }
    if (checks.every(function(check) {
      return check;
    })) {
      firstFittingPlacement = placement;
      makeFallbackChecks = false;
      break;
    }
    checksMap.set(placement, checks);
  }
  if (makeFallbackChecks) {
    var numberOfChecks = flipVariations ? 3 : 1;
    var _loop = function _loop2(_i2) {
      var fittingPlacement = placements2.find(function(placement2) {
        var checks2 = checksMap.get(placement2);
        if (checks2) {
          return checks2.slice(0, _i2).every(function(check) {
            return check;
          });
        }
      });
      if (fittingPlacement) {
        firstFittingPlacement = fittingPlacement;
        return "break";
      }
    };
    for (var _i = numberOfChecks; _i > 0; _i--) {
      var _ret = _loop(_i);
      if (_ret === "break")
        break;
    }
  }
  if (state.placement !== firstFittingPlacement) {
    state.modifiersData[name]._skip = true;
    state.placement = firstFittingPlacement;
    state.reset = true;
  }
}
const flip$1 = {
  name: "flip",
  enabled: true,
  phase: "main",
  fn: flip,
  requiresIfExists: ["offset"],
  data: {
    _skip: false
  }
};
function getSideOffsets(overflow, rect, preventedOffsets) {
  if (preventedOffsets === void 0) {
    preventedOffsets = {
      x: 0,
      y: 0
    };
  }
  return {
    top: overflow.top - rect.height - preventedOffsets.y,
    right: overflow.right - rect.width + preventedOffsets.x,
    bottom: overflow.bottom - rect.height + preventedOffsets.y,
    left: overflow.left - rect.width - preventedOffsets.x
  };
}
function isAnySideFullyClipped(overflow) {
  return [top, right, bottom, left].some(function(side) {
    return overflow[side] >= 0;
  });
}
function hide(_ref) {
  var state = _ref.state, name = _ref.name;
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var preventedOffsets = state.modifiersData.preventOverflow;
  var referenceOverflow = detectOverflow(state, {
    elementContext: "reference"
  });
  var popperAltOverflow = detectOverflow(state, {
    altBoundary: true
  });
  var referenceClippingOffsets = getSideOffsets(referenceOverflow, referenceRect);
  var popperEscapeOffsets = getSideOffsets(popperAltOverflow, popperRect, preventedOffsets);
  var isReferenceHidden = isAnySideFullyClipped(referenceClippingOffsets);
  var hasPopperEscaped = isAnySideFullyClipped(popperEscapeOffsets);
  state.modifiersData[name] = {
    referenceClippingOffsets,
    popperEscapeOffsets,
    isReferenceHidden,
    hasPopperEscaped
  };
  state.attributes.popper = Object.assign({}, state.attributes.popper, {
    "data-popper-reference-hidden": isReferenceHidden,
    "data-popper-escaped": hasPopperEscaped
  });
}
const hide$1 = {
  name: "hide",
  enabled: true,
  phase: "main",
  requiresIfExists: ["preventOverflow"],
  fn: hide
};
function distanceAndSkiddingToXY(placement, rects, offset2) {
  var basePlacement = getBasePlacement(placement);
  var invertDistance = [left, top].indexOf(basePlacement) >= 0 ? -1 : 1;
  var _ref = typeof offset2 === "function" ? offset2(Object.assign({}, rects, {
    placement
  })) : offset2, skidding = _ref[0], distance = _ref[1];
  skidding = skidding || 0;
  distance = (distance || 0) * invertDistance;
  return [left, right].indexOf(basePlacement) >= 0 ? {
    x: distance,
    y: skidding
  } : {
    x: skidding,
    y: distance
  };
}
function offset(_ref2) {
  var state = _ref2.state, options = _ref2.options, name = _ref2.name;
  var _options$offset = options.offset, offset2 = _options$offset === void 0 ? [0, 0] : _options$offset;
  var data = placements.reduce(function(acc, placement) {
    acc[placement] = distanceAndSkiddingToXY(placement, state.rects, offset2);
    return acc;
  }, {});
  var _data$state$placement = data[state.placement], x = _data$state$placement.x, y = _data$state$placement.y;
  if (state.modifiersData.popperOffsets != null) {
    state.modifiersData.popperOffsets.x += x;
    state.modifiersData.popperOffsets.y += y;
  }
  state.modifiersData[name] = data;
}
const offset$1 = {
  name: "offset",
  enabled: true,
  phase: "main",
  requires: ["popperOffsets"],
  fn: offset
};
function popperOffsets(_ref) {
  var state = _ref.state, name = _ref.name;
  state.modifiersData[name] = computeOffsets({
    reference: state.rects.reference,
    element: state.rects.popper,
    strategy: "absolute",
    placement: state.placement
  });
}
const popperOffsets$1 = {
  name: "popperOffsets",
  enabled: true,
  phase: "read",
  fn: popperOffsets,
  data: {}
};
function getAltAxis(axis) {
  return axis === "x" ? "y" : "x";
}
function preventOverflow(_ref) {
  var state = _ref.state, options = _ref.options, name = _ref.name;
  var _options$mainAxis = options.mainAxis, checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis, _options$altAxis = options.altAxis, checkAltAxis = _options$altAxis === void 0 ? false : _options$altAxis, boundary = options.boundary, rootBoundary = options.rootBoundary, altBoundary = options.altBoundary, padding = options.padding, _options$tether = options.tether, tether = _options$tether === void 0 ? true : _options$tether, _options$tetherOffset = options.tetherOffset, tetherOffset = _options$tetherOffset === void 0 ? 0 : _options$tetherOffset;
  var overflow = detectOverflow(state, {
    boundary,
    rootBoundary,
    padding,
    altBoundary
  });
  var basePlacement = getBasePlacement(state.placement);
  var variation = getVariation(state.placement);
  var isBasePlacement = !variation;
  var mainAxis = getMainAxisFromPlacement(basePlacement);
  var altAxis = getAltAxis(mainAxis);
  var popperOffsets2 = state.modifiersData.popperOffsets;
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var tetherOffsetValue = typeof tetherOffset === "function" ? tetherOffset(Object.assign({}, state.rects, {
    placement: state.placement
  })) : tetherOffset;
  var normalizedTetherOffsetValue = typeof tetherOffsetValue === "number" ? {
    mainAxis: tetherOffsetValue,
    altAxis: tetherOffsetValue
  } : Object.assign({
    mainAxis: 0,
    altAxis: 0
  }, tetherOffsetValue);
  var offsetModifierState = state.modifiersData.offset ? state.modifiersData.offset[state.placement] : null;
  var data = {
    x: 0,
    y: 0
  };
  if (!popperOffsets2) {
    return;
  }
  if (checkMainAxis) {
    var _offsetModifierState$;
    var mainSide = mainAxis === "y" ? top : left;
    var altSide = mainAxis === "y" ? bottom : right;
    var len = mainAxis === "y" ? "height" : "width";
    var offset2 = popperOffsets2[mainAxis];
    var min$1 = offset2 + overflow[mainSide];
    var max$1 = offset2 - overflow[altSide];
    var additive = tether ? -popperRect[len] / 2 : 0;
    var minLen = variation === start ? referenceRect[len] : popperRect[len];
    var maxLen = variation === start ? -popperRect[len] : -referenceRect[len];
    var arrowElement = state.elements.arrow;
    var arrowRect = tether && arrowElement ? getLayoutRect(arrowElement) : {
      width: 0,
      height: 0
    };
    var arrowPaddingObject = state.modifiersData["arrow#persistent"] ? state.modifiersData["arrow#persistent"].padding : getFreshSideObject();
    var arrowPaddingMin = arrowPaddingObject[mainSide];
    var arrowPaddingMax = arrowPaddingObject[altSide];
    var arrowLen = within(0, referenceRect[len], arrowRect[len]);
    var minOffset = isBasePlacement ? referenceRect[len] / 2 - additive - arrowLen - arrowPaddingMin - normalizedTetherOffsetValue.mainAxis : minLen - arrowLen - arrowPaddingMin - normalizedTetherOffsetValue.mainAxis;
    var maxOffset = isBasePlacement ? -referenceRect[len] / 2 + additive + arrowLen + arrowPaddingMax + normalizedTetherOffsetValue.mainAxis : maxLen + arrowLen + arrowPaddingMax + normalizedTetherOffsetValue.mainAxis;
    var arrowOffsetParent = state.elements.arrow && getOffsetParent(state.elements.arrow);
    var clientOffset = arrowOffsetParent ? mainAxis === "y" ? arrowOffsetParent.clientTop || 0 : arrowOffsetParent.clientLeft || 0 : 0;
    var offsetModifierValue = (_offsetModifierState$ = offsetModifierState == null ? void 0 : offsetModifierState[mainAxis]) != null ? _offsetModifierState$ : 0;
    var tetherMin = offset2 + minOffset - offsetModifierValue - clientOffset;
    var tetherMax = offset2 + maxOffset - offsetModifierValue;
    var preventedOffset = within(tether ? min(min$1, tetherMin) : min$1, offset2, tether ? max(max$1, tetherMax) : max$1);
    popperOffsets2[mainAxis] = preventedOffset;
    data[mainAxis] = preventedOffset - offset2;
  }
  if (checkAltAxis) {
    var _offsetModifierState$2;
    var _mainSide = mainAxis === "x" ? top : left;
    var _altSide = mainAxis === "x" ? bottom : right;
    var _offset = popperOffsets2[altAxis];
    var _len = altAxis === "y" ? "height" : "width";
    var _min = _offset + overflow[_mainSide];
    var _max = _offset - overflow[_altSide];
    var isOriginSide = [top, left].indexOf(basePlacement) !== -1;
    var _offsetModifierValue = (_offsetModifierState$2 = offsetModifierState == null ? void 0 : offsetModifierState[altAxis]) != null ? _offsetModifierState$2 : 0;
    var _tetherMin = isOriginSide ? _min : _offset - referenceRect[_len] - popperRect[_len] - _offsetModifierValue + normalizedTetherOffsetValue.altAxis;
    var _tetherMax = isOriginSide ? _offset + referenceRect[_len] + popperRect[_len] - _offsetModifierValue - normalizedTetherOffsetValue.altAxis : _max;
    var _preventedOffset = tether && isOriginSide ? withinMaxClamp(_tetherMin, _offset, _tetherMax) : within(tether ? _tetherMin : _min, _offset, tether ? _tetherMax : _max);
    popperOffsets2[altAxis] = _preventedOffset;
    data[altAxis] = _preventedOffset - _offset;
  }
  state.modifiersData[name] = data;
}
const preventOverflow$1 = {
  name: "preventOverflow",
  enabled: true,
  phase: "main",
  fn: preventOverflow,
  requiresIfExists: ["offset"]
};
function getHTMLElementScroll(element) {
  return {
    scrollLeft: element.scrollLeft,
    scrollTop: element.scrollTop
  };
}
function getNodeScroll(node) {
  if (node === getWindow(node) || !isHTMLElement$1(node)) {
    return getWindowScroll(node);
  } else {
    return getHTMLElementScroll(node);
  }
}
function isElementScaled(element) {
  var rect = element.getBoundingClientRect();
  var scaleX = round$1(rect.width) / element.offsetWidth || 1;
  var scaleY = round$1(rect.height) / element.offsetHeight || 1;
  return scaleX !== 1 || scaleY !== 1;
}
function getCompositeRect(elementOrVirtualElement, offsetParent, isFixed) {
  if (isFixed === void 0) {
    isFixed = false;
  }
  var isOffsetParentAnElement = isHTMLElement$1(offsetParent);
  var offsetParentIsScaled = isHTMLElement$1(offsetParent) && isElementScaled(offsetParent);
  var documentElement = getDocumentElement(offsetParent);
  var rect = getBoundingClientRect(elementOrVirtualElement, offsetParentIsScaled, isFixed);
  var scroll = {
    scrollLeft: 0,
    scrollTop: 0
  };
  var offsets = {
    x: 0,
    y: 0
  };
  if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
    if (getNodeName(offsetParent) !== "body" || // https://github.com/popperjs/popper-core/issues/1078
    isScrollParent(documentElement)) {
      scroll = getNodeScroll(offsetParent);
    }
    if (isHTMLElement$1(offsetParent)) {
      offsets = getBoundingClientRect(offsetParent, true);
      offsets.x += offsetParent.clientLeft;
      offsets.y += offsetParent.clientTop;
    } else if (documentElement) {
      offsets.x = getWindowScrollBarX(documentElement);
    }
  }
  return {
    x: rect.left + scroll.scrollLeft - offsets.x,
    y: rect.top + scroll.scrollTop - offsets.y,
    width: rect.width,
    height: rect.height
  };
}
function order(modifiers) {
  var map = /* @__PURE__ */ new Map();
  var visited = /* @__PURE__ */ new Set();
  var result = [];
  modifiers.forEach(function(modifier) {
    map.set(modifier.name, modifier);
  });
  function sort(modifier) {
    visited.add(modifier.name);
    var requires = [].concat(modifier.requires || [], modifier.requiresIfExists || []);
    requires.forEach(function(dep) {
      if (!visited.has(dep)) {
        var depModifier = map.get(dep);
        if (depModifier) {
          sort(depModifier);
        }
      }
    });
    result.push(modifier);
  }
  modifiers.forEach(function(modifier) {
    if (!visited.has(modifier.name)) {
      sort(modifier);
    }
  });
  return result;
}
function orderModifiers(modifiers) {
  var orderedModifiers = order(modifiers);
  return modifierPhases.reduce(function(acc, phase) {
    return acc.concat(orderedModifiers.filter(function(modifier) {
      return modifier.phase === phase;
    }));
  }, []);
}
function debounce(fn2) {
  var pending;
  return function() {
    if (!pending) {
      pending = new Promise(function(resolve) {
        Promise.resolve().then(function() {
          pending = void 0;
          resolve(fn2());
        });
      });
    }
    return pending;
  };
}
function mergeByName(modifiers) {
  var merged = modifiers.reduce(function(merged2, current) {
    var existing = merged2[current.name];
    merged2[current.name] = existing ? Object.assign({}, existing, current, {
      options: Object.assign({}, existing.options, current.options),
      data: Object.assign({}, existing.data, current.data)
    }) : current;
    return merged2;
  }, {});
  return Object.keys(merged).map(function(key) {
    return merged[key];
  });
}
var DEFAULT_OPTIONS = {
  placement: "bottom",
  modifiers: [],
  strategy: "absolute"
};
function areValidElements() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }
  return !args.some(function(element) {
    return !(element && typeof element.getBoundingClientRect === "function");
  });
}
function popperGenerator(generatorOptions) {
  if (generatorOptions === void 0) {
    generatorOptions = {};
  }
  var _generatorOptions = generatorOptions, _generatorOptions$def = _generatorOptions.defaultModifiers, defaultModifiers2 = _generatorOptions$def === void 0 ? [] : _generatorOptions$def, _generatorOptions$def2 = _generatorOptions.defaultOptions, defaultOptions = _generatorOptions$def2 === void 0 ? DEFAULT_OPTIONS : _generatorOptions$def2;
  return function createPopper2(reference2, popper2, options) {
    if (options === void 0) {
      options = defaultOptions;
    }
    var state = {
      placement: "bottom",
      orderedModifiers: [],
      options: Object.assign({}, DEFAULT_OPTIONS, defaultOptions),
      modifiersData: {},
      elements: {
        reference: reference2,
        popper: popper2
      },
      attributes: {},
      styles: {}
    };
    var effectCleanupFns = [];
    var isDestroyed = false;
    var instance = {
      state,
      setOptions: function setOptions(setOptionsAction) {
        var options2 = typeof setOptionsAction === "function" ? setOptionsAction(state.options) : setOptionsAction;
        cleanupModifierEffects();
        state.options = Object.assign({}, defaultOptions, state.options, options2);
        state.scrollParents = {
          reference: isElement(reference2) ? listScrollParents(reference2) : reference2.contextElement ? listScrollParents(reference2.contextElement) : [],
          popper: listScrollParents(popper2)
        };
        var orderedModifiers = orderModifiers(mergeByName([].concat(defaultModifiers2, state.options.modifiers)));
        state.orderedModifiers = orderedModifiers.filter(function(m) {
          return m.enabled;
        });
        runModifierEffects();
        return instance.update();
      },
      // Sync update – it will always be executed, even if not necessary. This
      // is useful for low frequency updates where sync behavior simplifies the
      // logic.
      // For high frequency updates (e.g. `resize` and `scroll` events), always
      // prefer the async Popper#update method
      forceUpdate: function forceUpdate() {
        if (isDestroyed) {
          return;
        }
        var _state$elements = state.elements, reference3 = _state$elements.reference, popper3 = _state$elements.popper;
        if (!areValidElements(reference3, popper3)) {
          return;
        }
        state.rects = {
          reference: getCompositeRect(reference3, getOffsetParent(popper3), state.options.strategy === "fixed"),
          popper: getLayoutRect(popper3)
        };
        state.reset = false;
        state.placement = state.options.placement;
        state.orderedModifiers.forEach(function(modifier) {
          return state.modifiersData[modifier.name] = Object.assign({}, modifier.data);
        });
        for (var index = 0; index < state.orderedModifiers.length; index++) {
          if (state.reset === true) {
            state.reset = false;
            index = -1;
            continue;
          }
          var _state$orderedModifie = state.orderedModifiers[index], fn2 = _state$orderedModifie.fn, _state$orderedModifie2 = _state$orderedModifie.options, _options = _state$orderedModifie2 === void 0 ? {} : _state$orderedModifie2, name = _state$orderedModifie.name;
          if (typeof fn2 === "function") {
            state = fn2({
              state,
              options: _options,
              name,
              instance
            }) || state;
          }
        }
      },
      // Async and optimistically optimized update – it will not be executed if
      // not necessary (debounced to run at most once-per-tick)
      update: debounce(function() {
        return new Promise(function(resolve) {
          instance.forceUpdate();
          resolve(state);
        });
      }),
      destroy: function destroy() {
        cleanupModifierEffects();
        isDestroyed = true;
      }
    };
    if (!areValidElements(reference2, popper2)) {
      return instance;
    }
    instance.setOptions(options).then(function(state2) {
      if (!isDestroyed && options.onFirstUpdate) {
        options.onFirstUpdate(state2);
      }
    });
    function runModifierEffects() {
      state.orderedModifiers.forEach(function(_ref) {
        var name = _ref.name, _ref$options = _ref.options, options2 = _ref$options === void 0 ? {} : _ref$options, effect2 = _ref.effect;
        if (typeof effect2 === "function") {
          var cleanupFn = effect2({
            state,
            name,
            instance,
            options: options2
          });
          var noopFn = function noopFn2() {
          };
          effectCleanupFns.push(cleanupFn || noopFn);
        }
      });
    }
    function cleanupModifierEffects() {
      effectCleanupFns.forEach(function(fn2) {
        return fn2();
      });
      effectCleanupFns = [];
    }
    return instance;
  };
}
var defaultModifiers = [eventListeners, popperOffsets$1, computeStyles$1, applyStyles$1, offset$1, flip$1, preventOverflow$1, arrow$1, hide$1];
var createPopper = /* @__PURE__ */ popperGenerator({
  defaultModifiers
});
function getPopperUtilityClass(slot) {
  return generateUtilityClass("MuiPopper", slot);
}
generateUtilityClasses("MuiPopper", ["root"]);
const _excluded$17 = ["anchorEl", "children", "direction", "disablePortal", "modifiers", "open", "placement", "popperOptions", "popperRef", "slotProps", "slots", "TransitionProps", "ownerState"], _excluded2$7 = ["anchorEl", "children", "container", "direction", "disablePortal", "keepMounted", "modifiers", "open", "placement", "popperOptions", "popperRef", "style", "transition", "slotProps", "slots"];
function flipPlacement(placement, direction2) {
  if (direction2 === "ltr") {
    return placement;
  }
  switch (placement) {
    case "bottom-end":
      return "bottom-start";
    case "bottom-start":
      return "bottom-end";
    case "top-end":
      return "top-start";
    case "top-start":
      return "top-end";
    default:
      return placement;
  }
}
function resolveAnchorEl(anchorEl) {
  return typeof anchorEl === "function" ? anchorEl() : anchorEl;
}
function isHTMLElement(element) {
  return element.nodeType !== void 0;
}
const useUtilityClasses$Q = () => {
  const slots = {
    root: ["root"]
  };
  return composeClasses(slots, useClassNamesOverride(getPopperUtilityClass));
};
const defaultPopperOptions = {};
const PopperTooltip = /* @__PURE__ */ reactExports.forwardRef(function PopperTooltip2(props, forwardedRef) {
  var _slots$root;
  const {
    anchorEl,
    children,
    direction: direction2,
    disablePortal,
    modifiers,
    open,
    placement: initialPlacement,
    popperOptions,
    popperRef: popperRefProp,
    slotProps = {},
    slots = {},
    TransitionProps
    // @ts-ignore internal logic
    // prevent from spreading to DOM, it can come from the parent component e.g. Select.
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$17);
  const tooltipRef = reactExports.useRef(null);
  const ownRef = useForkRef$1(tooltipRef, forwardedRef);
  const popperRef = reactExports.useRef(null);
  const handlePopperRef = useForkRef$1(popperRef, popperRefProp);
  const handlePopperRefRef = reactExports.useRef(handlePopperRef);
  useEnhancedEffect$1(() => {
    handlePopperRefRef.current = handlePopperRef;
  }, [handlePopperRef]);
  reactExports.useImperativeHandle(popperRefProp, () => popperRef.current, []);
  const rtlPlacement = flipPlacement(initialPlacement, direction2);
  const [placement, setPlacement] = reactExports.useState(rtlPlacement);
  const [resolvedAnchorElement, setResolvedAnchorElement] = reactExports.useState(resolveAnchorEl(anchorEl));
  reactExports.useEffect(() => {
    if (popperRef.current) {
      popperRef.current.forceUpdate();
    }
  });
  reactExports.useEffect(() => {
    if (anchorEl) {
      setResolvedAnchorElement(resolveAnchorEl(anchorEl));
    }
  }, [anchorEl]);
  useEnhancedEffect$1(() => {
    if (!resolvedAnchorElement || !open) {
      return void 0;
    }
    const handlePopperUpdate = (data) => {
      setPlacement(data.placement);
    };
    let popperModifiers = [{
      name: "preventOverflow",
      options: {
        altBoundary: disablePortal
      }
    }, {
      name: "flip",
      options: {
        altBoundary: disablePortal
      }
    }, {
      name: "onUpdate",
      enabled: true,
      phase: "afterWrite",
      fn: ({
        state
      }) => {
        handlePopperUpdate(state);
      }
    }];
    if (modifiers != null) {
      popperModifiers = popperModifiers.concat(modifiers);
    }
    if (popperOptions && popperOptions.modifiers != null) {
      popperModifiers = popperModifiers.concat(popperOptions.modifiers);
    }
    const popper2 = createPopper(resolvedAnchorElement, tooltipRef.current, _extends$1({
      placement: rtlPlacement
    }, popperOptions, {
      modifiers: popperModifiers
    }));
    handlePopperRefRef.current(popper2);
    return () => {
      popper2.destroy();
      handlePopperRefRef.current(null);
    };
  }, [resolvedAnchorElement, disablePortal, modifiers, open, popperOptions, rtlPlacement]);
  const childProps = {
    placement
  };
  if (TransitionProps !== null) {
    childProps.TransitionProps = TransitionProps;
  }
  const classes2 = useUtilityClasses$Q();
  const Root = (_slots$root = slots.root) != null ? _slots$root : "div";
  const rootProps = useSlotProps({
    elementType: Root,
    externalSlotProps: slotProps.root,
    externalForwardedProps: other,
    additionalProps: {
      role: "tooltip",
      ref: ownRef
    },
    ownerState: props,
    className: classes2.root
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Root, _extends$1({}, rootProps, {
    children: typeof children === "function" ? children(childProps) : children
  }));
});
const Popper$1 = /* @__PURE__ */ reactExports.forwardRef(function Popper2(props, forwardedRef) {
  const {
    anchorEl,
    children,
    container: containerProp,
    direction: direction2 = "ltr",
    disablePortal = false,
    keepMounted = false,
    modifiers,
    open,
    placement = "bottom",
    popperOptions = defaultPopperOptions,
    popperRef,
    style,
    transition = false,
    slotProps = {},
    slots = {}
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded2$7);
  const [exited, setExited] = reactExports.useState(true);
  const handleEnter = () => {
    setExited(false);
  };
  const handleExited = () => {
    setExited(true);
  };
  if (!keepMounted && !open && (!transition || exited)) {
    return null;
  }
  let container;
  if (containerProp) {
    container = containerProp;
  } else if (anchorEl) {
    const resolvedAnchorEl = resolveAnchorEl(anchorEl);
    container = resolvedAnchorEl && isHTMLElement(resolvedAnchorEl) ? ownerDocument$1(resolvedAnchorEl).body : ownerDocument$1(null).body;
  }
  const display = !open && keepMounted && (!transition || exited) ? "none" : void 0;
  const transitionProps = transition ? {
    in: open,
    onEnter: handleEnter,
    onExited: handleExited
  } : void 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Portal, {
    disablePortal,
    container,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(PopperTooltip, _extends$1({
      anchorEl,
      direction: direction2,
      disablePortal,
      modifiers,
      ref: forwardedRef,
      open: transition ? !exited : open,
      placement,
      popperOptions,
      popperRef,
      slotProps,
      slots
    }, other, {
      style: _extends$1({
        // Prevents scroll issue, waiting for Popper.js to add this style once initiated.
        position: "fixed",
        // Fix Popper.js display issue
        top: 0,
        left: 0,
        display
      }, style),
      TransitionProps: transitionProps,
      children
    }))
  });
});
function stripDiacritics(string) {
  return typeof string.normalize !== "undefined" ? string.normalize("NFD").replace(/[\u0300-\u036f]/g, "") : string;
}
function createFilterOptions(config = {}) {
  const {
    ignoreAccents = true,
    ignoreCase = true,
    limit,
    matchFrom = "any",
    stringify,
    trim = false
  } = config;
  return (options, {
    inputValue,
    getOptionLabel
  }) => {
    let input = trim ? inputValue.trim() : inputValue;
    if (ignoreCase) {
      input = input.toLowerCase();
    }
    if (ignoreAccents) {
      input = stripDiacritics(input);
    }
    const filteredOptions = !input ? options : options.filter((option) => {
      let candidate = (stringify || getOptionLabel)(option);
      if (ignoreCase) {
        candidate = candidate.toLowerCase();
      }
      if (ignoreAccents) {
        candidate = stripDiacritics(candidate);
      }
      return matchFrom === "start" ? candidate.indexOf(input) === 0 : candidate.indexOf(input) > -1;
    });
    return typeof limit === "number" ? filteredOptions.slice(0, limit) : filteredOptions;
  };
}
function findIndex(array, comp) {
  for (let i2 = 0; i2 < array.length; i2 += 1) {
    if (comp(array[i2])) {
      return i2;
    }
  }
  return -1;
}
const defaultFilterOptions = createFilterOptions();
const pageSize = 5;
const defaultIsActiveElementInListbox = (listboxRef) => {
  var _listboxRef$current$p;
  return listboxRef.current !== null && ((_listboxRef$current$p = listboxRef.current.parentElement) == null ? void 0 : _listboxRef$current$p.contains(document.activeElement));
};
function useAutocomplete(props) {
  const {
    // eslint-disable-next-line @typescript-eslint/naming-convention
    unstable_isActiveElementInListbox = defaultIsActiveElementInListbox,
    // eslint-disable-next-line @typescript-eslint/naming-convention
    unstable_classNamePrefix = "Mui",
    autoComplete = false,
    autoHighlight = false,
    autoSelect = false,
    blurOnSelect = false,
    clearOnBlur = !props.freeSolo,
    clearOnEscape = false,
    componentName = "useAutocomplete",
    defaultValue = props.multiple ? [] : null,
    disableClearable = false,
    disableCloseOnSelect = false,
    disabled: disabledProp,
    disabledItemsFocusable = false,
    disableListWrap = false,
    filterOptions = defaultFilterOptions,
    filterSelectedOptions = false,
    freeSolo = false,
    getOptionDisabled,
    getOptionLabel: getOptionLabelProp = (option) => {
      var _option$label;
      return (_option$label = option.label) != null ? _option$label : option;
    },
    groupBy,
    handleHomeEndKeys = !props.freeSolo,
    id: idProp,
    includeInputInList = false,
    inputValue: inputValueProp,
    isOptionEqualToValue = (option, value2) => option === value2,
    multiple = false,
    onChange,
    onClose,
    onHighlightChange,
    onInputChange,
    onOpen,
    open: openProp,
    openOnFocus = false,
    options,
    readOnly = false,
    selectOnFocus = !props.freeSolo,
    value: valueProp
  } = props;
  const id = useId(idProp);
  let getOptionLabel = getOptionLabelProp;
  getOptionLabel = (option) => {
    const optionLabel = getOptionLabelProp(option);
    if (typeof optionLabel !== "string") {
      return String(optionLabel);
    }
    return optionLabel;
  };
  const ignoreFocus = reactExports.useRef(false);
  const firstFocus = reactExports.useRef(true);
  const inputRef = reactExports.useRef(null);
  const listboxRef = reactExports.useRef(null);
  const [anchorEl, setAnchorEl] = reactExports.useState(null);
  const [focusedTag, setFocusedTag] = reactExports.useState(-1);
  const defaultHighlighted = autoHighlight ? 0 : -1;
  const highlightedIndexRef = reactExports.useRef(defaultHighlighted);
  const [value, setValueState] = useControlled({
    controlled: valueProp,
    default: defaultValue,
    name: componentName
  });
  const [inputValue, setInputValueState] = useControlled({
    controlled: inputValueProp,
    default: "",
    name: componentName,
    state: "inputValue"
  });
  const [focused, setFocused] = reactExports.useState(false);
  const resetInputValue = reactExports.useCallback((event, newValue) => {
    const isOptionSelected = multiple ? value.length < newValue.length : newValue !== null;
    if (!isOptionSelected && !clearOnBlur) {
      return;
    }
    let newInputValue;
    if (multiple) {
      newInputValue = "";
    } else if (newValue == null) {
      newInputValue = "";
    } else {
      const optionLabel = getOptionLabel(newValue);
      newInputValue = typeof optionLabel === "string" ? optionLabel : "";
    }
    if (inputValue === newInputValue) {
      return;
    }
    setInputValueState(newInputValue);
    if (onInputChange) {
      onInputChange(event, newInputValue, "reset");
    }
  }, [getOptionLabel, inputValue, multiple, onInputChange, setInputValueState, clearOnBlur, value]);
  const [open, setOpenState] = useControlled({
    controlled: openProp,
    default: false,
    name: componentName,
    state: "open"
  });
  const [inputPristine, setInputPristine] = reactExports.useState(true);
  const inputValueIsSelectedValue = !multiple && value != null && inputValue === getOptionLabel(value);
  const popupOpen = open && !readOnly;
  const filteredOptions = popupOpen ? filterOptions(
    options.filter((option) => {
      if (filterSelectedOptions && (multiple ? value : [value]).some((value2) => value2 !== null && isOptionEqualToValue(option, value2))) {
        return false;
      }
      return true;
    }),
    // we use the empty string to manipulate `filterOptions` to not filter any options
    // i.e. the filter predicate always returns true
    {
      inputValue: inputValueIsSelectedValue && inputPristine ? "" : inputValue,
      getOptionLabel
    }
  ) : [];
  const previousProps = usePreviousProps$1({
    filteredOptions,
    value,
    inputValue
  });
  reactExports.useEffect(() => {
    const valueChange = value !== previousProps.value;
    if (focused && !valueChange) {
      return;
    }
    if (freeSolo && !valueChange) {
      return;
    }
    resetInputValue(null, value);
  }, [value, resetInputValue, focused, previousProps.value, freeSolo]);
  const listboxAvailable = open && filteredOptions.length > 0 && !readOnly;
  const focusTag = useEventCallback$1((tagToFocus) => {
    if (tagToFocus === -1) {
      inputRef.current.focus();
    } else {
      anchorEl.querySelector(`[data-tag-index="${tagToFocus}"]`).focus();
    }
  });
  reactExports.useEffect(() => {
    if (multiple && focusedTag > value.length - 1) {
      setFocusedTag(-1);
      focusTag(-1);
    }
  }, [value, multiple, focusedTag, focusTag]);
  function validOptionIndex(index, direction2) {
    if (!listboxRef.current || index === -1) {
      return -1;
    }
    let nextFocus = index;
    while (true) {
      if (direction2 === "next" && nextFocus === filteredOptions.length || direction2 === "previous" && nextFocus === -1) {
        return -1;
      }
      const option = listboxRef.current.querySelector(`[data-option-index="${nextFocus}"]`);
      const nextFocusDisabled = disabledItemsFocusable ? false : !option || option.disabled || option.getAttribute("aria-disabled") === "true";
      if (option && !option.hasAttribute("tabindex") || nextFocusDisabled) {
        nextFocus += direction2 === "next" ? 1 : -1;
      } else {
        return nextFocus;
      }
    }
  }
  const setHighlightedIndex = useEventCallback$1(({
    event,
    index,
    reason = "auto"
  }) => {
    highlightedIndexRef.current = index;
    if (index === -1) {
      inputRef.current.removeAttribute("aria-activedescendant");
    } else {
      inputRef.current.setAttribute("aria-activedescendant", `${id}-option-${index}`);
    }
    if (onHighlightChange) {
      onHighlightChange(event, index === -1 ? null : filteredOptions[index], reason);
    }
    if (!listboxRef.current) {
      return;
    }
    const prev = listboxRef.current.querySelector(`[role="option"].${unstable_classNamePrefix}-focused`);
    if (prev) {
      prev.classList.remove(`${unstable_classNamePrefix}-focused`);
      prev.classList.remove(`${unstable_classNamePrefix}-focusVisible`);
    }
    let listboxNode = listboxRef.current;
    if (listboxRef.current.getAttribute("role") !== "listbox") {
      listboxNode = listboxRef.current.parentElement.querySelector('[role="listbox"]');
    }
    if (!listboxNode) {
      return;
    }
    if (index === -1) {
      listboxNode.scrollTop = 0;
      return;
    }
    const option = listboxRef.current.querySelector(`[data-option-index="${index}"]`);
    if (!option) {
      return;
    }
    option.classList.add(`${unstable_classNamePrefix}-focused`);
    if (reason === "keyboard") {
      option.classList.add(`${unstable_classNamePrefix}-focusVisible`);
    }
    if (listboxNode.scrollHeight > listboxNode.clientHeight && reason !== "mouse" && reason !== "touch") {
      const element = option;
      const scrollBottom = listboxNode.clientHeight + listboxNode.scrollTop;
      const elementBottom = element.offsetTop + element.offsetHeight;
      if (elementBottom > scrollBottom) {
        listboxNode.scrollTop = elementBottom - listboxNode.clientHeight;
      } else if (element.offsetTop - element.offsetHeight * (groupBy ? 1.3 : 0) < listboxNode.scrollTop) {
        listboxNode.scrollTop = element.offsetTop - element.offsetHeight * (groupBy ? 1.3 : 0);
      }
    }
  });
  const changeHighlightedIndex = useEventCallback$1(({
    event,
    diff,
    direction: direction2 = "next",
    reason = "auto"
  }) => {
    if (!popupOpen) {
      return;
    }
    const getNextIndex = () => {
      const maxIndex = filteredOptions.length - 1;
      if (diff === "reset") {
        return defaultHighlighted;
      }
      if (diff === "start") {
        return 0;
      }
      if (diff === "end") {
        return maxIndex;
      }
      const newIndex = highlightedIndexRef.current + diff;
      if (newIndex < 0) {
        if (newIndex === -1 && includeInputInList) {
          return -1;
        }
        if (disableListWrap && highlightedIndexRef.current !== -1 || Math.abs(diff) > 1) {
          return 0;
        }
        return maxIndex;
      }
      if (newIndex > maxIndex) {
        if (newIndex === maxIndex + 1 && includeInputInList) {
          return -1;
        }
        if (disableListWrap || Math.abs(diff) > 1) {
          return maxIndex;
        }
        return 0;
      }
      return newIndex;
    };
    const nextIndex = validOptionIndex(getNextIndex(), direction2);
    setHighlightedIndex({
      index: nextIndex,
      reason,
      event
    });
    if (autoComplete && diff !== "reset") {
      if (nextIndex === -1) {
        inputRef.current.value = inputValue;
      } else {
        const option = getOptionLabel(filteredOptions[nextIndex]);
        inputRef.current.value = option;
        const index = option.toLowerCase().indexOf(inputValue.toLowerCase());
        if (index === 0 && inputValue.length > 0) {
          inputRef.current.setSelectionRange(inputValue.length, option.length);
        }
      }
    }
  });
  const checkHighlightedOptionExists = () => {
    const isSameValue = (value1, value2) => {
      const label1 = value1 ? getOptionLabel(value1) : "";
      const label2 = value2 ? getOptionLabel(value2) : "";
      return label1 === label2;
    };
    if (highlightedIndexRef.current !== -1 && previousProps.filteredOptions && previousProps.filteredOptions.length !== filteredOptions.length && previousProps.inputValue === inputValue && (multiple ? value.length === previousProps.value.length && previousProps.value.every((val, i2) => getOptionLabel(value[i2]) === getOptionLabel(val)) : isSameValue(previousProps.value, value))) {
      const previousHighlightedOption = previousProps.filteredOptions[highlightedIndexRef.current];
      if (previousHighlightedOption) {
        const previousHighlightedOptionExists = filteredOptions.some((option) => {
          return getOptionLabel(option) === getOptionLabel(previousHighlightedOption);
        });
        if (previousHighlightedOptionExists) {
          return true;
        }
      }
    }
    return false;
  };
  const syncHighlightedIndex = reactExports.useCallback(() => {
    if (!popupOpen) {
      return;
    }
    if (checkHighlightedOptionExists()) {
      return;
    }
    const valueItem = multiple ? value[0] : value;
    if (filteredOptions.length === 0 || valueItem == null) {
      changeHighlightedIndex({
        diff: "reset"
      });
      return;
    }
    if (!listboxRef.current) {
      return;
    }
    if (valueItem != null) {
      const currentOption = filteredOptions[highlightedIndexRef.current];
      if (multiple && currentOption && findIndex(value, (val) => isOptionEqualToValue(currentOption, val)) !== -1) {
        return;
      }
      const itemIndex = findIndex(filteredOptions, (optionItem) => isOptionEqualToValue(optionItem, valueItem));
      if (itemIndex === -1) {
        changeHighlightedIndex({
          diff: "reset"
        });
      } else {
        setHighlightedIndex({
          index: itemIndex
        });
      }
      return;
    }
    if (highlightedIndexRef.current >= filteredOptions.length - 1) {
      setHighlightedIndex({
        index: filteredOptions.length - 1
      });
      return;
    }
    setHighlightedIndex({
      index: highlightedIndexRef.current
    });
  }, [
    // Only sync the highlighted index when the option switch between empty and not
    filteredOptions.length,
    // Don't sync the highlighted index with the value when multiple
    // eslint-disable-next-line react-hooks/exhaustive-deps
    multiple ? false : value,
    filterSelectedOptions,
    changeHighlightedIndex,
    setHighlightedIndex,
    popupOpen,
    inputValue,
    multiple
  ]);
  const handleListboxRef = useEventCallback$1((node) => {
    setRef$1(listboxRef, node);
    if (!node) {
      return;
    }
    syncHighlightedIndex();
  });
  reactExports.useEffect(() => {
    syncHighlightedIndex();
  }, [syncHighlightedIndex]);
  const handleOpen = (event) => {
    if (open) {
      return;
    }
    setOpenState(true);
    setInputPristine(true);
    if (onOpen) {
      onOpen(event);
    }
  };
  const handleClose = (event, reason) => {
    if (!open) {
      return;
    }
    setOpenState(false);
    if (onClose) {
      onClose(event, reason);
    }
  };
  const handleValue = (event, newValue, reason, details) => {
    if (multiple) {
      if (value.length === newValue.length && value.every((val, i2) => val === newValue[i2])) {
        return;
      }
    } else if (value === newValue) {
      return;
    }
    if (onChange) {
      onChange(event, newValue, reason, details);
    }
    setValueState(newValue);
  };
  const isTouch = reactExports.useRef(false);
  const selectNewValue = (event, option, reasonProp = "selectOption", origin = "options") => {
    let reason = reasonProp;
    let newValue = option;
    if (multiple) {
      newValue = Array.isArray(value) ? value.slice() : [];
      const itemIndex = findIndex(newValue, (valueItem) => isOptionEqualToValue(option, valueItem));
      if (itemIndex === -1) {
        newValue.push(option);
      } else if (origin !== "freeSolo") {
        newValue.splice(itemIndex, 1);
        reason = "removeOption";
      }
    }
    resetInputValue(event, newValue);
    handleValue(event, newValue, reason, {
      option
    });
    if (!disableCloseOnSelect && (!event || !event.ctrlKey && !event.metaKey)) {
      handleClose(event, reason);
    }
    if (blurOnSelect === true || blurOnSelect === "touch" && isTouch.current || blurOnSelect === "mouse" && !isTouch.current) {
      inputRef.current.blur();
    }
  };
  function validTagIndex(index, direction2) {
    if (index === -1) {
      return -1;
    }
    let nextFocus = index;
    while (true) {
      if (direction2 === "next" && nextFocus === value.length || direction2 === "previous" && nextFocus === -1) {
        return -1;
      }
      const option = anchorEl.querySelector(`[data-tag-index="${nextFocus}"]`);
      if (!option || !option.hasAttribute("tabindex") || option.disabled || option.getAttribute("aria-disabled") === "true") {
        nextFocus += direction2 === "next" ? 1 : -1;
      } else {
        return nextFocus;
      }
    }
  }
  const handleFocusTag = (event, direction2) => {
    if (!multiple) {
      return;
    }
    if (inputValue === "") {
      handleClose(event, "toggleInput");
    }
    let nextTag = focusedTag;
    if (focusedTag === -1) {
      if (inputValue === "" && direction2 === "previous") {
        nextTag = value.length - 1;
      }
    } else {
      nextTag += direction2 === "next" ? 1 : -1;
      if (nextTag < 0) {
        nextTag = 0;
      }
      if (nextTag === value.length) {
        nextTag = -1;
      }
    }
    nextTag = validTagIndex(nextTag, direction2);
    setFocusedTag(nextTag);
    focusTag(nextTag);
  };
  const handleClear = (event) => {
    ignoreFocus.current = true;
    setInputValueState("");
    if (onInputChange) {
      onInputChange(event, "", "clear");
    }
    handleValue(event, multiple ? [] : null, "clear");
  };
  const handleKeyDown = (other) => (event) => {
    if (other.onKeyDown) {
      other.onKeyDown(event);
    }
    if (event.defaultMuiPrevented) {
      return;
    }
    if (focusedTag !== -1 && ["ArrowLeft", "ArrowRight"].indexOf(event.key) === -1) {
      setFocusedTag(-1);
      focusTag(-1);
    }
    if (event.which !== 229) {
      switch (event.key) {
        case "Home":
          if (popupOpen && handleHomeEndKeys) {
            event.preventDefault();
            changeHighlightedIndex({
              diff: "start",
              direction: "next",
              reason: "keyboard",
              event
            });
          }
          break;
        case "End":
          if (popupOpen && handleHomeEndKeys) {
            event.preventDefault();
            changeHighlightedIndex({
              diff: "end",
              direction: "previous",
              reason: "keyboard",
              event
            });
          }
          break;
        case "PageUp":
          event.preventDefault();
          changeHighlightedIndex({
            diff: -pageSize,
            direction: "previous",
            reason: "keyboard",
            event
          });
          handleOpen(event);
          break;
        case "PageDown":
          event.preventDefault();
          changeHighlightedIndex({
            diff: pageSize,
            direction: "next",
            reason: "keyboard",
            event
          });
          handleOpen(event);
          break;
        case "ArrowDown":
          event.preventDefault();
          changeHighlightedIndex({
            diff: 1,
            direction: "next",
            reason: "keyboard",
            event
          });
          handleOpen(event);
          break;
        case "ArrowUp":
          event.preventDefault();
          changeHighlightedIndex({
            diff: -1,
            direction: "previous",
            reason: "keyboard",
            event
          });
          handleOpen(event);
          break;
        case "ArrowLeft":
          handleFocusTag(event, "previous");
          break;
        case "ArrowRight":
          handleFocusTag(event, "next");
          break;
        case "Enter":
          if (highlightedIndexRef.current !== -1 && popupOpen) {
            const option = filteredOptions[highlightedIndexRef.current];
            const disabled = getOptionDisabled ? getOptionDisabled(option) : false;
            event.preventDefault();
            if (disabled) {
              return;
            }
            selectNewValue(event, option, "selectOption");
            if (autoComplete) {
              inputRef.current.setSelectionRange(inputRef.current.value.length, inputRef.current.value.length);
            }
          } else if (freeSolo && inputValue !== "" && inputValueIsSelectedValue === false) {
            if (multiple) {
              event.preventDefault();
            }
            selectNewValue(event, inputValue, "createOption", "freeSolo");
          }
          break;
        case "Escape":
          if (popupOpen) {
            event.preventDefault();
            event.stopPropagation();
            handleClose(event, "escape");
          } else if (clearOnEscape && (inputValue !== "" || multiple && value.length > 0)) {
            event.preventDefault();
            event.stopPropagation();
            handleClear(event);
          }
          break;
        case "Backspace":
          if (multiple && !readOnly && inputValue === "" && value.length > 0) {
            const index = focusedTag === -1 ? value.length - 1 : focusedTag;
            const newValue = value.slice();
            newValue.splice(index, 1);
            handleValue(event, newValue, "removeOption", {
              option: value[index]
            });
          }
          break;
        case "Delete":
          if (multiple && !readOnly && inputValue === "" && value.length > 0 && focusedTag !== -1) {
            const index = focusedTag;
            const newValue = value.slice();
            newValue.splice(index, 1);
            handleValue(event, newValue, "removeOption", {
              option: value[index]
            });
          }
          break;
      }
    }
  };
  const handleFocus = (event) => {
    setFocused(true);
    if (openOnFocus && !ignoreFocus.current) {
      handleOpen(event);
    }
  };
  const handleBlur = (event) => {
    if (unstable_isActiveElementInListbox(listboxRef)) {
      inputRef.current.focus();
      return;
    }
    setFocused(false);
    firstFocus.current = true;
    ignoreFocus.current = false;
    if (autoSelect && highlightedIndexRef.current !== -1 && popupOpen) {
      selectNewValue(event, filteredOptions[highlightedIndexRef.current], "blur");
    } else if (autoSelect && freeSolo && inputValue !== "") {
      selectNewValue(event, inputValue, "blur", "freeSolo");
    } else if (clearOnBlur) {
      resetInputValue(event, value);
    }
    handleClose(event, "blur");
  };
  const handleInputChange = (event) => {
    const newValue = event.target.value;
    if (inputValue !== newValue) {
      setInputValueState(newValue);
      setInputPristine(false);
      if (onInputChange) {
        onInputChange(event, newValue, "input");
      }
    }
    if (newValue === "") {
      if (!disableClearable && !multiple) {
        handleValue(event, null, "clear");
      }
    } else {
      handleOpen(event);
    }
  };
  const handleOptionMouseMove = (event) => {
    const index = Number(event.currentTarget.getAttribute("data-option-index"));
    if (highlightedIndexRef.current !== index) {
      setHighlightedIndex({
        event,
        index,
        reason: "mouse"
      });
    }
  };
  const handleOptionTouchStart = (event) => {
    setHighlightedIndex({
      event,
      index: Number(event.currentTarget.getAttribute("data-option-index")),
      reason: "touch"
    });
    isTouch.current = true;
  };
  const handleOptionClick = (event) => {
    const index = Number(event.currentTarget.getAttribute("data-option-index"));
    selectNewValue(event, filteredOptions[index], "selectOption");
    isTouch.current = false;
  };
  const handleTagDelete = (index) => (event) => {
    const newValue = value.slice();
    newValue.splice(index, 1);
    handleValue(event, newValue, "removeOption", {
      option: value[index]
    });
  };
  const handlePopupIndicator = (event) => {
    if (open) {
      handleClose(event, "toggleInput");
    } else {
      handleOpen(event);
    }
  };
  const handleMouseDown = (event) => {
    if (!event.currentTarget.contains(event.target)) {
      return;
    }
    if (event.target.getAttribute("id") !== id) {
      event.preventDefault();
    }
  };
  const handleClick = (event) => {
    if (!event.currentTarget.contains(event.target)) {
      return;
    }
    inputRef.current.focus();
    if (selectOnFocus && firstFocus.current && inputRef.current.selectionEnd - inputRef.current.selectionStart === 0) {
      inputRef.current.select();
    }
    firstFocus.current = false;
  };
  const handleInputMouseDown = (event) => {
    if (inputValue === "" || !open) {
      handlePopupIndicator(event);
    }
  };
  let dirty = freeSolo && inputValue.length > 0;
  dirty = dirty || (multiple ? value.length > 0 : value !== null);
  let groupedOptions = filteredOptions;
  if (groupBy) {
    groupedOptions = filteredOptions.reduce((acc, option, index) => {
      const group = groupBy(option);
      if (acc.length > 0 && acc[acc.length - 1].group === group) {
        acc[acc.length - 1].options.push(option);
      } else {
        acc.push({
          key: index,
          index,
          group,
          options: [option]
        });
      }
      return acc;
    }, []);
  }
  if (disabledProp && focused) {
    handleBlur();
  }
  return {
    getRootProps: (other = {}) => _extends$1({
      "aria-owns": listboxAvailable ? `${id}-listbox` : null
    }, other, {
      onKeyDown: handleKeyDown(other),
      onMouseDown: handleMouseDown,
      onClick: handleClick
    }),
    getInputLabelProps: () => ({
      id: `${id}-label`,
      htmlFor: id
    }),
    getInputProps: () => ({
      id,
      value: inputValue,
      onBlur: handleBlur,
      onFocus: handleFocus,
      onChange: handleInputChange,
      onMouseDown: handleInputMouseDown,
      // if open then this is handled imperatively so don't let react override
      // only have an opinion about this when closed
      "aria-activedescendant": popupOpen ? "" : null,
      "aria-autocomplete": autoComplete ? "both" : "list",
      "aria-controls": listboxAvailable ? `${id}-listbox` : void 0,
      "aria-expanded": listboxAvailable,
      // Disable browser's suggestion that might overlap with the popup.
      // Handle autocomplete but not autofill.
      autoComplete: "off",
      ref: inputRef,
      autoCapitalize: "none",
      spellCheck: "false",
      role: "combobox",
      disabled: disabledProp
    }),
    getClearProps: () => ({
      tabIndex: -1,
      onClick: handleClear
    }),
    getPopupIndicatorProps: () => ({
      tabIndex: -1,
      onClick: handlePopupIndicator
    }),
    getTagProps: ({
      index
    }) => _extends$1({
      key: index,
      "data-tag-index": index,
      tabIndex: -1
    }, !readOnly && {
      onDelete: handleTagDelete(index)
    }),
    getListboxProps: () => ({
      role: "listbox",
      id: `${id}-listbox`,
      "aria-labelledby": `${id}-label`,
      ref: handleListboxRef,
      onMouseDown: (event) => {
        event.preventDefault();
      }
    }),
    getOptionProps: ({
      index,
      option
    }) => {
      const selected = (multiple ? value : [value]).some((value2) => value2 != null && isOptionEqualToValue(option, value2));
      const disabled = getOptionDisabled ? getOptionDisabled(option) : false;
      return {
        key: getOptionLabel(option),
        tabIndex: -1,
        role: "option",
        id: `${id}-option-${index}`,
        onMouseMove: handleOptionMouseMove,
        onClick: handleOptionClick,
        onTouchStart: handleOptionTouchStart,
        "data-option-index": index,
        "aria-disabled": disabled,
        "aria-selected": selected
      };
    },
    id,
    inputValue,
    value,
    dirty,
    expanded: popupOpen && anchorEl,
    popupOpen,
    focused: focused || focusedTag !== -1,
    anchorEl,
    setAnchorEl,
    focusedTag,
    groupedOptions
  };
}
const _excluded$16 = ["id", "value", "formattedValue", "api", "field", "row", "rowNode", "colDef", "cellMode", "isEditable", "tabIndex", "hasFocus", "inputProps", "isValidating", "isProcessingProps", "onValueChange"];
const StyledInputBase = styled$1(InputBase)({
  fontSize: "inherit"
});
const useUtilityClasses$P = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["editInputCell"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
function GridEditDateCell(props) {
  const {
    id,
    value: valueProp,
    field,
    colDef,
    hasFocus,
    inputProps,
    onValueChange
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$16);
  const isDateTime = colDef.type === "dateTime";
  const apiRef2 = useGridApiContext();
  const inputRef = reactExports.useRef();
  const valueTransformed = reactExports.useMemo(() => {
    let parsedDate;
    if (valueProp == null) {
      parsedDate = null;
    } else if (valueProp instanceof Date) {
      parsedDate = valueProp;
    } else {
      parsedDate = new Date((valueProp != null ? valueProp : "").toString());
    }
    let formattedDate;
    if (parsedDate == null || Number.isNaN(parsedDate.getTime())) {
      formattedDate = "";
    } else {
      const localDate = new Date(parsedDate.getTime() - parsedDate.getTimezoneOffset() * 60 * 1e3);
      formattedDate = localDate.toISOString().substr(0, isDateTime ? 16 : 10);
    }
    return {
      parsed: parsedDate,
      formatted: formattedDate
    };
  }, [valueProp, isDateTime]);
  const [valueState, setValueState] = reactExports.useState(valueTransformed);
  const rootProps = useGridRootProps();
  const ownerState = {
    classes: rootProps.classes
  };
  const classes2 = useUtilityClasses$P(ownerState);
  const hasUpdatedEditValueOnMount = reactExports.useRef(false);
  const parseValueToDate = reactExports.useCallback((value) => {
    if (value === "") {
      return null;
    }
    const [date, time] = value.split("T");
    const [year, month, day] = date.split("-");
    const parsedDate = /* @__PURE__ */ new Date();
    parsedDate.setFullYear(Number(year), Number(month) - 1, Number(day));
    parsedDate.setHours(0, 0, 0, 0);
    if (time) {
      const [hours, minutes] = time.split(":");
      parsedDate.setHours(Number(hours), Number(minutes), 0, 0);
    }
    return parsedDate;
  }, []);
  const handleChange = reactExports.useCallback(async (event) => {
    const newFormattedDate = event.target.value;
    const newParsedDate = parseValueToDate(newFormattedDate);
    if (onValueChange) {
      await onValueChange(event, newParsedDate);
    }
    setValueState({
      parsed: newParsedDate,
      formatted: newFormattedDate
    });
    apiRef2.current.setEditCellValue({
      id,
      field,
      value: newParsedDate
    }, event);
  }, [apiRef2, field, id, onValueChange, parseValueToDate]);
  reactExports.useEffect(() => {
    setValueState((state) => {
      var _valueTransformed$par, _state$parsed;
      if (valueTransformed.parsed !== state.parsed && ((_valueTransformed$par = valueTransformed.parsed) == null ? void 0 : _valueTransformed$par.getTime()) !== ((_state$parsed = state.parsed) == null ? void 0 : _state$parsed.getTime())) {
        return valueTransformed;
      }
      return state;
    });
  }, [valueTransformed]);
  useEnhancedEffect$1(() => {
    if (hasFocus) {
      inputRef.current.focus();
    }
  }, [hasFocus]);
  const meta = apiRef2.current.unstable_getEditCellMeta(id, field);
  const handleInputRef = (el) => {
    inputRef.current = el;
    if (meta != null && meta.unstable_updateValueOnRender && !hasUpdatedEditValueOnMount.current) {
      const inputValue = inputRef.current.value;
      const parsedDate = parseValueToDate(inputValue);
      setValueState({
        parsed: parsedDate,
        formatted: inputValue
      });
      apiRef2.current.setEditCellValue({
        id,
        field,
        value: parsedDate
      });
      hasUpdatedEditValueOnMount.current = true;
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(StyledInputBase, _extends$1({
    inputRef: handleInputRef,
    fullWidth: true,
    className: classes2.root,
    type: isDateTime ? "datetime-local" : "date",
    inputProps: _extends$1({
      max: isDateTime ? "9999-12-31T23:59" : "9999-12-31"
    }, inputProps),
    value: valueState.formatted,
    onChange: handleChange
  }, other));
}
const renderEditDateCell = (params) => /* @__PURE__ */ jsxRuntimeExports.jsx(GridEditDateCell, _extends$1({}, params));
const _excluded$15 = ["id", "value", "formattedValue", "api", "field", "row", "rowNode", "colDef", "cellMode", "isEditable", "tabIndex", "hasFocus", "isValidating", "debounceMs", "isProcessingProps", "onValueChange"];
const useUtilityClasses$O = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["editInputCell"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridEditInputCellRoot = styled$1(InputBase, {
  name: "MuiDataGrid",
  slot: "EditInputCell",
  overridesResolver: (props, styles2) => styles2.editInputCell
})(({
  theme
}) => _extends$1({}, theme.typography.body2, {
  padding: "1px 0",
  "& input": {
    padding: "0 16px",
    height: "100%"
  }
}));
const GridEditInputCell = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const rootProps = useGridRootProps();
  const {
    id,
    value,
    field,
    colDef,
    hasFocus,
    debounceMs = 200,
    isProcessingProps,
    onValueChange
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$15);
  const apiRef2 = useGridApiContext();
  const inputRef = reactExports.useRef();
  const [valueState, setValueState] = reactExports.useState(value);
  const classes2 = useUtilityClasses$O(rootProps);
  const handleChange = reactExports.useCallback(async (event) => {
    const newValue = event.target.value;
    if (onValueChange) {
      await onValueChange(event, newValue);
    }
    const column = apiRef2.current.getColumn(field);
    let parsedValue = newValue;
    if (column.valueParser) {
      parsedValue = column.valueParser(newValue, apiRef2.current.getCellParams(id, field));
    }
    setValueState(parsedValue);
    apiRef2.current.setEditCellValue({
      id,
      field,
      value: parsedValue,
      debounceMs,
      unstable_skipValueParser: true
    }, event);
  }, [apiRef2, debounceMs, field, id, onValueChange]);
  const meta = apiRef2.current.unstable_getEditCellMeta(id, field);
  reactExports.useEffect(() => {
    if ((meta == null ? void 0 : meta.changeReason) !== "debouncedSetEditCellValue") {
      setValueState(value);
    }
  }, [meta, value]);
  useEnhancedEffect$1(() => {
    if (hasFocus) {
      inputRef.current.focus();
    }
  }, [hasFocus]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridEditInputCellRoot, _extends$1({
    ref,
    inputRef,
    className: classes2.root,
    ownerState: rootProps,
    fullWidth: true,
    type: colDef.type === "number" ? colDef.type : "text",
    value: valueState != null ? valueState : "",
    onChange: handleChange,
    endAdornment: isProcessingProps ? /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.loadIcon, {
      fontSize: "small",
      color: "action"
    }) : void 0
  }, other));
});
const renderEditInputCell = (params) => /* @__PURE__ */ jsxRuntimeExports.jsx(GridEditInputCell, _extends$1({}, params));
const isEscapeKey = (key) => key === "Escape";
const isEnterKey = (key) => key === "Enter";
const isTabKey = (key) => key === "Tab";
const isSpaceKey = (key) => key === " ";
const isArrowKeys = (key) => key.indexOf("Arrow") === 0;
const isHomeOrEndKeys = (key) => key === "Home" || key === "End";
const isPageKeys = (key) => key.indexOf("Page") === 0;
function isPrintableKey(event) {
  return event.key.length === 1 && !event.ctrlKey && !event.metaKey;
}
const isNavigationKey = (key) => isHomeOrEndKeys(key) || isArrowKeys(key) || isPageKeys(key) || isSpaceKey(key);
const isKeyboardEvent$1 = (event) => !!event.key;
const isHideMenuKey = (key) => isTabKey(key) || isEscapeKey(key);
function isSingleSelectColDef(colDef) {
  return (colDef == null ? void 0 : colDef.type) === "singleSelect";
}
function getValueFromValueOptions(value, valueOptions, getOptionValue) {
  if (valueOptions === void 0) {
    return void 0;
  }
  const result = valueOptions.find((option) => {
    const optionValue = getOptionValue(option);
    return String(optionValue) === String(value);
  });
  return getOptionValue(result);
}
const _excluded$14 = ["id", "value", "formattedValue", "api", "field", "row", "rowNode", "colDef", "cellMode", "isEditable", "tabIndex", "className", "hasFocus", "isValidating", "isProcessingProps", "error", "onValueChange", "initialOpen", "getOptionLabel", "getOptionValue"], _excluded2$6 = ["MenuProps"];
function isKeyboardEvent(event) {
  return !!event.key;
}
function GridEditSingleSelectCell(props) {
  var _rootProps$slotProps, _baseSelectProps$nati, _rootProps$slotProps2;
  const rootProps = useGridRootProps();
  const {
    id,
    value: valueProp,
    field,
    row,
    colDef,
    hasFocus,
    error,
    onValueChange,
    initialOpen = rootProps.editMode === GridEditModes.Cell,
    getOptionLabel: getOptionLabelProp,
    getOptionValue: getOptionValueProp
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$14);
  const apiRef2 = useGridApiContext();
  const ref = reactExports.useRef();
  const inputRef = reactExports.useRef();
  const [open, setOpen] = reactExports.useState(initialOpen);
  const baseSelectProps = ((_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseSelect) || {};
  const isSelectNative = (_baseSelectProps$nati = baseSelectProps.native) != null ? _baseSelectProps$nati : false;
  const _ref = ((_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.baseSelect) || {}, {
    MenuProps
  } = _ref, otherBaseSelectProps = _objectWithoutPropertiesLoose$1(_ref, _excluded2$6);
  useEnhancedEffect$1(() => {
    if (hasFocus) {
      var _inputRef$current;
      (_inputRef$current = inputRef.current) == null || _inputRef$current.focus();
    }
  }, [hasFocus]);
  if (!isSingleSelectColDef(colDef)) {
    return null;
  }
  let valueOptions;
  if (typeof (colDef == null ? void 0 : colDef.valueOptions) === "function") {
    valueOptions = colDef == null ? void 0 : colDef.valueOptions({
      id,
      row,
      field
    });
  } else {
    valueOptions = colDef == null ? void 0 : colDef.valueOptions;
  }
  if (!valueOptions) {
    return null;
  }
  const getOptionValue = getOptionValueProp || colDef.getOptionValue;
  const getOptionLabel = getOptionLabelProp || colDef.getOptionLabel;
  const handleChange = async (event) => {
    if (!isSingleSelectColDef(colDef) || !valueOptions) {
      return;
    }
    setOpen(false);
    const target = event.target;
    const formattedTargetValue = getValueFromValueOptions(target.value, valueOptions, getOptionValue);
    if (onValueChange) {
      await onValueChange(event, formattedTargetValue);
    }
    await apiRef2.current.setEditCellValue({
      id,
      field,
      value: formattedTargetValue
    }, event);
  };
  const handleClose = (event, reason) => {
    if (rootProps.editMode === GridEditModes.Row) {
      setOpen(false);
      return;
    }
    if (reason === "backdropClick" || isEscapeKey(event.key)) {
      const params = apiRef2.current.getCellParams(id, field);
      apiRef2.current.publishEvent("cellEditStop", _extends$1({}, params, {
        reason: isEscapeKey(event.key) ? GridCellEditStopReasons.escapeKeyDown : GridCellEditStopReasons.cellFocusOut
      }));
    }
  };
  const handleOpen = (event) => {
    if (isKeyboardEvent(event) && event.key === "Enter") {
      return;
    }
    setOpen(true);
  };
  if (!valueOptions || !colDef) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseSelect, _extends$1({
    ref,
    inputRef,
    value: valueProp,
    onChange: handleChange,
    open,
    onOpen: handleOpen,
    MenuProps: _extends$1({
      onClose: handleClose
    }, MenuProps),
    error,
    native: isSelectNative,
    fullWidth: true
  }, other, otherBaseSelectProps, {
    children: valueOptions.map((valueOption) => {
      var _rootProps$slotProps3;
      const value = getOptionValue(valueOption);
      return /* @__PURE__ */ reactExports.createElement(rootProps.slots.baseSelectOption, _extends$1({}, ((_rootProps$slotProps3 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps3.baseSelectOption) || {}, {
        native: isSelectNative,
        key: value,
        value
      }), getOptionLabel(valueOption));
    })
  }));
}
const renderEditSingleSelectCell = (params) => /* @__PURE__ */ jsxRuntimeExports.jsx(GridEditSingleSelectCell, _extends$1({}, params));
const _excluded$13 = ["anchorEl", "component", "components", "componentsProps", "container", "disablePortal", "keepMounted", "modifiers", "open", "placement", "popperOptions", "popperRef", "transition", "slots", "slotProps"];
const PopperRoot = styled$1(Popper$1, {
  name: "MuiPopper",
  slot: "Root",
  overridesResolver: (props, styles2) => styles2.root
})({});
const Popper = /* @__PURE__ */ reactExports.forwardRef(function Popper3(inProps, ref) {
  var _slots$root;
  const theme = useTheme();
  const props = useThemeProps({
    props: inProps,
    name: "MuiPopper"
  });
  const {
    anchorEl,
    component,
    components,
    componentsProps,
    container,
    disablePortal,
    keepMounted,
    modifiers,
    open,
    placement,
    popperOptions,
    popperRef,
    transition,
    slots,
    slotProps
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$13);
  const RootComponent = (_slots$root = slots == null ? void 0 : slots.root) != null ? _slots$root : components == null ? void 0 : components.Root;
  const otherProps = _extends$1({
    anchorEl,
    container,
    disablePortal,
    keepMounted,
    modifiers,
    open,
    placement,
    popperOptions,
    popperRef,
    transition
  }, other);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(PopperRoot, _extends$1({
    as: component,
    direction: theme == null ? void 0 : theme.direction,
    slots: {
      root: RootComponent
    },
    slotProps: slotProps != null ? slotProps : componentsProps
  }, otherProps, {
    ref
  }));
});
const MUIPopper = Popper;
const _excluded$12 = ["open", "target", "onClickAway", "children", "position", "className", "onExited"];
const useUtilityClasses$N = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["menu"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridMenuRoot = styled$1(MUIPopper, {
  name: "MuiDataGrid",
  slot: "Menu",
  overridesResolver: (_2, styles2) => styles2.menu
})(({
  theme
}) => ({
  zIndex: theme.zIndex.modal,
  [`& .${gridClasses.menuList}`]: {
    outline: 0
  }
}));
const transformOrigin = {
  "bottom-start": "top left",
  "bottom-end": "top right"
};
function GridMenu(props) {
  var _rootProps$slotProps;
  const {
    open,
    target,
    onClickAway,
    children,
    position,
    className,
    onExited
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$12);
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$N(rootProps);
  reactExports.useEffect(() => {
    const eventName = open ? "menuOpen" : "menuClose";
    apiRef2.current.publishEvent(eventName, {
      target
    });
  }, [apiRef2, open, target]);
  const handleExited = (popperOnExited) => (node) => {
    if (popperOnExited) {
      popperOnExited();
    }
    if (onExited) {
      onExited(node);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridMenuRoot, _extends$1({
    as: rootProps.slots.basePopper,
    className: clsx$1(className, classes2.root),
    ownerState: rootProps,
    open,
    anchorEl: target,
    transition: true,
    placement: position
  }, other, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.basePopper, {
    children: ({
      TransitionProps,
      placement
    }) => /* @__PURE__ */ jsxRuntimeExports.jsx(ClickAwayListener, {
      onClickAway,
      mouseEvent: "onMouseDown",
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(Grow, _extends$1({}, TransitionProps, {
        style: {
          transformOrigin: transformOrigin[placement]
        },
        onExited: handleExited(TransitionProps == null ? void 0 : TransitionProps.onExited),
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Paper, {
          children
        })
      }))
    })
  }));
}
const _excluded$11 = ["api", "colDef", "id", "hasFocus", "isEditable", "field", "value", "formattedValue", "row", "rowNode", "cellMode", "tabIndex", "position", "focusElementRef"];
const hasActions = (colDef) => typeof colDef.getActions === "function";
function GridActionsCell(props) {
  var _rootProps$slotProps;
  const {
    colDef,
    id,
    hasFocus,
    tabIndex,
    position = "bottom-end",
    focusElementRef
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$11);
  const [focusedButtonIndex, setFocusedButtonIndex] = reactExports.useState(-1);
  const [open, setOpen] = reactExports.useState(false);
  const apiRef2 = useGridApiContext();
  const rootRef = reactExports.useRef(null);
  const buttonRef = reactExports.useRef(null);
  const ignoreCallToFocus = reactExports.useRef(false);
  const touchRippleRefs = reactExports.useRef({});
  const theme = useTheme$1();
  const menuId = useId();
  const buttonId = useId();
  const rootProps = useGridRootProps();
  if (!hasActions(colDef)) {
    throw new Error("MUI: Missing the `getActions` property in the `GridColDef`.");
  }
  const options = colDef.getActions(apiRef2.current.getRowParams(id));
  const iconButtons = options.filter((option) => !option.props.showInMenu);
  const menuButtons = options.filter((option) => option.props.showInMenu);
  const numberOfButtons = iconButtons.length + (menuButtons.length ? 1 : 0);
  reactExports.useLayoutEffect(() => {
    if (!hasFocus) {
      Object.entries(touchRippleRefs.current).forEach(([index, ref]) => {
        ref == null || ref.stop({}, () => {
          delete touchRippleRefs.current[index];
        });
      });
    }
  }, [hasFocus]);
  reactExports.useEffect(() => {
    if (focusedButtonIndex < 0 || !rootRef.current) {
      return;
    }
    if (focusedButtonIndex >= rootRef.current.children.length) {
      return;
    }
    const child = rootRef.current.children[focusedButtonIndex];
    child.focus({
      preventScroll: true
    });
  }, [focusedButtonIndex]);
  reactExports.useEffect(() => {
    if (!hasFocus) {
      setFocusedButtonIndex(-1);
      ignoreCallToFocus.current = false;
    }
  }, [hasFocus]);
  reactExports.useImperativeHandle(focusElementRef, () => ({
    focus() {
      if (!ignoreCallToFocus.current) {
        setFocusedButtonIndex(0);
      }
    }
  }), []);
  reactExports.useEffect(() => {
    if (focusedButtonIndex >= numberOfButtons) {
      setFocusedButtonIndex(numberOfButtons - 1);
    }
  }, [focusedButtonIndex, numberOfButtons]);
  const showMenu = () => {
    setOpen(true);
    setFocusedButtonIndex(numberOfButtons - 1);
    ignoreCallToFocus.current = true;
  };
  const hideMenu = () => {
    setOpen(false);
  };
  const handleTouchRippleRef = (index) => (instance) => {
    touchRippleRefs.current[index] = instance;
  };
  const handleButtonClick = (index, onClick) => (event) => {
    setFocusedButtonIndex(index);
    ignoreCallToFocus.current = true;
    if (onClick) {
      onClick(event);
    }
  };
  const handleRootKeyDown = (event) => {
    if (numberOfButtons <= 1) {
      return;
    }
    let newIndex = focusedButtonIndex;
    if (event.key === "ArrowRight") {
      if (theme.direction === "rtl") {
        newIndex -= 1;
      } else {
        newIndex += 1;
      }
    } else if (event.key === "ArrowLeft") {
      if (theme.direction === "rtl") {
        newIndex += 1;
      } else {
        newIndex -= 1;
      }
    }
    if (newIndex < 0 || newIndex >= numberOfButtons) {
      return;
    }
    if (newIndex !== focusedButtonIndex) {
      event.preventDefault();
      event.stopPropagation();
      setFocusedButtonIndex(newIndex);
    }
  };
  const handleListKeyDown = (event) => {
    if (event.key === "Tab") {
      event.preventDefault();
    }
    if (["Tab", "Enter", "Escape"].includes(event.key)) {
      hideMenu();
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", _extends$1({
    role: "menu",
    ref: rootRef,
    tabIndex: -1,
    className: gridClasses.actionsCell,
    onKeyDown: handleRootKeyDown
  }, other, {
    children: [iconButtons.map((button, index) => /* @__PURE__ */ reactExports.cloneElement(button, {
      key: index,
      touchRippleRef: handleTouchRippleRef(index),
      onClick: handleButtonClick(index, button.props.onClick),
      tabIndex: focusedButtonIndex === index ? tabIndex : -1
    })), menuButtons.length > 0 && buttonId && /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseIconButton, _extends$1({
      ref: buttonRef,
      id: buttonId,
      "aria-label": apiRef2.current.getLocaleText("actionsCellMore"),
      "aria-haspopup": "menu",
      "aria-expanded": open,
      "aria-controls": open ? menuId : void 0,
      role: "menuitem",
      size: "small",
      onClick: showMenu,
      touchRippleRef: handleTouchRippleRef(buttonId),
      tabIndex: focusedButtonIndex === iconButtons.length ? tabIndex : -1
    }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseIconButton, {
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.moreActionsIcon, {
        fontSize: "small"
      })
    })), menuButtons.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(GridMenu, {
      onClickAway: hideMenu,
      onClick: hideMenu,
      open,
      target: buttonRef.current,
      position,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(MenuList, {
        id: menuId,
        className: gridClasses.menuList,
        onKeyDown: handleListKeyDown,
        "aria-labelledby": buttonId,
        variant: "menu",
        autoFocusItem: true,
        children: menuButtons.map((button, index) => /* @__PURE__ */ reactExports.cloneElement(button, {
          key: index
        }))
      })
    })]
  }));
}
const renderActionsCell = (params) => /* @__PURE__ */ jsxRuntimeExports.jsx(GridActionsCell, _extends$1({}, params));
function getDividerUtilityClass(slot) {
  return generateUtilityClass("MuiDivider", slot);
}
const dividerClasses = generateUtilityClasses("MuiDivider", ["root", "absolute", "fullWidth", "inset", "middle", "flexItem", "light", "vertical", "withChildren", "withChildrenVertical", "textAlignRight", "textAlignLeft", "wrapper", "wrapperVertical"]);
const dividerClasses$1 = dividerClasses;
const _excluded$10 = ["absolute", "children", "className", "component", "flexItem", "light", "orientation", "role", "textAlign", "variant"];
const useUtilityClasses$M = (ownerState) => {
  const {
    absolute,
    children,
    classes: classes2,
    flexItem,
    light,
    orientation,
    textAlign,
    variant
  } = ownerState;
  const slots = {
    root: ["root", absolute && "absolute", variant, light && "light", orientation === "vertical" && "vertical", flexItem && "flexItem", children && "withChildren", children && orientation === "vertical" && "withChildrenVertical", textAlign === "right" && orientation !== "vertical" && "textAlignRight", textAlign === "left" && orientation !== "vertical" && "textAlignLeft"],
    wrapper: ["wrapper", orientation === "vertical" && "wrapperVertical"]
  };
  return composeClasses(slots, getDividerUtilityClass, classes2);
};
const DividerRoot = styled$1("div", {
  name: "MuiDivider",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, ownerState.absolute && styles2.absolute, styles2[ownerState.variant], ownerState.light && styles2.light, ownerState.orientation === "vertical" && styles2.vertical, ownerState.flexItem && styles2.flexItem, ownerState.children && styles2.withChildren, ownerState.children && ownerState.orientation === "vertical" && styles2.withChildrenVertical, ownerState.textAlign === "right" && ownerState.orientation !== "vertical" && styles2.textAlignRight, ownerState.textAlign === "left" && ownerState.orientation !== "vertical" && styles2.textAlignLeft];
  }
})(({
  theme,
  ownerState
}) => _extends$1({
  margin: 0,
  // Reset browser default style.
  flexShrink: 0,
  borderWidth: 0,
  borderStyle: "solid",
  borderColor: (theme.vars || theme).palette.divider,
  borderBottomWidth: "thin"
}, ownerState.absolute && {
  position: "absolute",
  bottom: 0,
  left: 0,
  width: "100%"
}, ownerState.light && {
  borderColor: theme.vars ? `rgba(${theme.vars.palette.dividerChannel} / 0.08)` : alpha(theme.palette.divider, 0.08)
}, ownerState.variant === "inset" && {
  marginLeft: 72
}, ownerState.variant === "middle" && ownerState.orientation === "horizontal" && {
  marginLeft: theme.spacing(2),
  marginRight: theme.spacing(2)
}, ownerState.variant === "middle" && ownerState.orientation === "vertical" && {
  marginTop: theme.spacing(1),
  marginBottom: theme.spacing(1)
}, ownerState.orientation === "vertical" && {
  height: "100%",
  borderBottomWidth: 0,
  borderRightWidth: "thin"
}, ownerState.flexItem && {
  alignSelf: "stretch",
  height: "auto"
}), ({
  ownerState
}) => _extends$1({}, ownerState.children && {
  display: "flex",
  whiteSpace: "nowrap",
  textAlign: "center",
  border: 0,
  "&::before, &::after": {
    content: '""',
    alignSelf: "center"
  }
}), ({
  theme,
  ownerState
}) => _extends$1({}, ownerState.children && ownerState.orientation !== "vertical" && {
  "&::before, &::after": {
    width: "100%",
    borderTop: `thin solid ${(theme.vars || theme).palette.divider}`
  }
}), ({
  theme,
  ownerState
}) => _extends$1({}, ownerState.children && ownerState.orientation === "vertical" && {
  flexDirection: "column",
  "&::before, &::after": {
    height: "100%",
    borderLeft: `thin solid ${(theme.vars || theme).palette.divider}`
  }
}), ({
  ownerState
}) => _extends$1({}, ownerState.textAlign === "right" && ownerState.orientation !== "vertical" && {
  "&::before": {
    width: "90%"
  },
  "&::after": {
    width: "10%"
  }
}, ownerState.textAlign === "left" && ownerState.orientation !== "vertical" && {
  "&::before": {
    width: "10%"
  },
  "&::after": {
    width: "90%"
  }
}));
const DividerWrapper = styled$1("span", {
  name: "MuiDivider",
  slot: "Wrapper",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.wrapper, ownerState.orientation === "vertical" && styles2.wrapperVertical];
  }
})(({
  theme,
  ownerState
}) => _extends$1({
  display: "inline-block",
  paddingLeft: `calc(${theme.spacing(1)} * 1.2)`,
  paddingRight: `calc(${theme.spacing(1)} * 1.2)`
}, ownerState.orientation === "vertical" && {
  paddingTop: `calc(${theme.spacing(1)} * 1.2)`,
  paddingBottom: `calc(${theme.spacing(1)} * 1.2)`
}));
const Divider = /* @__PURE__ */ reactExports.forwardRef(function Divider2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiDivider"
  });
  const {
    absolute = false,
    children,
    className,
    component = children ? "div" : "hr",
    flexItem = false,
    light = false,
    orientation = "horizontal",
    role = component !== "hr" ? "separator" : void 0,
    textAlign = "center",
    variant = "fullWidth"
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$10);
  const ownerState = _extends$1({}, props, {
    absolute,
    component,
    flexItem,
    light,
    orientation,
    role,
    textAlign,
    variant
  });
  const classes2 = useUtilityClasses$M(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(DividerRoot, _extends$1({
    as: component,
    className: clsx$1(classes2.root, className),
    role,
    ref,
    ownerState
  }, other, {
    children: children ? /* @__PURE__ */ jsxRuntimeExports.jsx(DividerWrapper, {
      className: classes2.wrapper,
      ownerState,
      children
    }) : null
  }));
});
Divider.muiSkipListHighlight = true;
const Divider$1 = Divider;
function getListItemIconUtilityClass(slot) {
  return generateUtilityClass("MuiListItemIcon", slot);
}
const listItemIconClasses = generateUtilityClasses("MuiListItemIcon", ["root", "alignItemsFlexStart"]);
const listItemIconClasses$1 = listItemIconClasses;
const _excluded$$ = ["className"];
const useUtilityClasses$L = (ownerState) => {
  const {
    alignItems,
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["root", alignItems === "flex-start" && "alignItemsFlexStart"]
  };
  return composeClasses(slots, getListItemIconUtilityClass, classes2);
};
const ListItemIconRoot = styled$1("div", {
  name: "MuiListItemIcon",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, ownerState.alignItems === "flex-start" && styles2.alignItemsFlexStart];
  }
})(({
  theme,
  ownerState
}) => _extends$1({
  minWidth: 56,
  color: (theme.vars || theme).palette.action.active,
  flexShrink: 0,
  display: "inline-flex"
}, ownerState.alignItems === "flex-start" && {
  marginTop: 8
}));
const ListItemIcon = /* @__PURE__ */ reactExports.forwardRef(function ListItemIcon2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiListItemIcon"
  });
  const {
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$$);
  const context = reactExports.useContext(ListContext);
  const ownerState = _extends$1({}, props, {
    alignItems: context.alignItems
  });
  const classes2 = useUtilityClasses$L(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ListItemIconRoot, _extends$1({
    className: clsx$1(classes2.root, className),
    ownerState,
    ref
  }, other));
});
const ListItemIcon$1 = ListItemIcon;
function getListItemTextUtilityClass(slot) {
  return generateUtilityClass("MuiListItemText", slot);
}
const listItemTextClasses = generateUtilityClasses("MuiListItemText", ["root", "multiline", "dense", "inset", "primary", "secondary"]);
const listItemTextClasses$1 = listItemTextClasses;
const _excluded$_ = ["children", "className", "disableTypography", "inset", "primary", "primaryTypographyProps", "secondary", "secondaryTypographyProps"];
const useUtilityClasses$K = (ownerState) => {
  const {
    classes: classes2,
    inset,
    primary,
    secondary,
    dense
  } = ownerState;
  const slots = {
    root: ["root", inset && "inset", dense && "dense", primary && secondary && "multiline"],
    primary: ["primary"],
    secondary: ["secondary"]
  };
  return composeClasses(slots, getListItemTextUtilityClass, classes2);
};
const ListItemTextRoot = styled$1("div", {
  name: "MuiListItemText",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [{
      [`& .${listItemTextClasses$1.primary}`]: styles2.primary
    }, {
      [`& .${listItemTextClasses$1.secondary}`]: styles2.secondary
    }, styles2.root, ownerState.inset && styles2.inset, ownerState.primary && ownerState.secondary && styles2.multiline, ownerState.dense && styles2.dense];
  }
})(({
  ownerState
}) => _extends$1({
  flex: "1 1 auto",
  minWidth: 0,
  marginTop: 4,
  marginBottom: 4
}, ownerState.primary && ownerState.secondary && {
  marginTop: 6,
  marginBottom: 6
}, ownerState.inset && {
  paddingLeft: 56
}));
const ListItemText = /* @__PURE__ */ reactExports.forwardRef(function ListItemText2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiListItemText"
  });
  const {
    children,
    className,
    disableTypography = false,
    inset = false,
    primary: primaryProp,
    primaryTypographyProps,
    secondary: secondaryProp,
    secondaryTypographyProps
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$_);
  const {
    dense
  } = reactExports.useContext(ListContext);
  let primary = primaryProp != null ? primaryProp : children;
  let secondary = secondaryProp;
  const ownerState = _extends$1({}, props, {
    disableTypography,
    inset,
    primary: !!primary,
    secondary: !!secondary,
    dense
  });
  const classes2 = useUtilityClasses$K(ownerState);
  if (primary != null && primary.type !== Typography && !disableTypography) {
    primary = /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, _extends$1({
      variant: dense ? "body2" : "body1",
      className: classes2.primary,
      component: primaryTypographyProps != null && primaryTypographyProps.variant ? void 0 : "span",
      display: "block"
    }, primaryTypographyProps, {
      children: primary
    }));
  }
  if (secondary != null && secondary.type !== Typography && !disableTypography) {
    secondary = /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, _extends$1({
      variant: "body2",
      className: classes2.secondary,
      color: "text.secondary",
      display: "block"
    }, secondaryTypographyProps, {
      children: secondary
    }));
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(ListItemTextRoot, _extends$1({
    className: clsx$1(classes2.root, className),
    ownerState,
    ref
  }, other, {
    children: [primary, secondary]
  }));
});
const ListItemText$1 = ListItemText;
function getMenuItemUtilityClass(slot) {
  return generateUtilityClass("MuiMenuItem", slot);
}
const menuItemClasses = generateUtilityClasses("MuiMenuItem", ["root", "focusVisible", "dense", "disabled", "divider", "gutters", "selected"]);
const menuItemClasses$1 = menuItemClasses;
const _excluded$Z = ["autoFocus", "component", "dense", "divider", "disableGutters", "focusVisibleClassName", "role", "tabIndex", "className"];
const overridesResolver$1 = (props, styles2) => {
  const {
    ownerState
  } = props;
  return [styles2.root, ownerState.dense && styles2.dense, ownerState.divider && styles2.divider, !ownerState.disableGutters && styles2.gutters];
};
const useUtilityClasses$J = (ownerState) => {
  const {
    disabled,
    dense,
    divider,
    disableGutters,
    selected,
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["root", dense && "dense", disabled && "disabled", !disableGutters && "gutters", divider && "divider", selected && "selected"]
  };
  const composedClasses = composeClasses(slots, getMenuItemUtilityClass, classes2);
  return _extends$1({}, classes2, composedClasses);
};
const MenuItemRoot = styled$1(ButtonBase, {
  shouldForwardProp: (prop) => rootShouldForwardProp(prop) || prop === "classes",
  name: "MuiMenuItem",
  slot: "Root",
  overridesResolver: overridesResolver$1
})(({
  theme,
  ownerState
}) => _extends$1({}, theme.typography.body1, {
  display: "flex",
  justifyContent: "flex-start",
  alignItems: "center",
  position: "relative",
  textDecoration: "none",
  minHeight: 48,
  paddingTop: 6,
  paddingBottom: 6,
  boxSizing: "border-box",
  whiteSpace: "nowrap"
}, !ownerState.disableGutters && {
  paddingLeft: 16,
  paddingRight: 16
}, ownerState.divider && {
  borderBottom: `1px solid ${(theme.vars || theme).palette.divider}`,
  backgroundClip: "padding-box"
}, {
  "&:hover": {
    textDecoration: "none",
    backgroundColor: (theme.vars || theme).palette.action.hover,
    // Reset on touch devices, it doesn't add specificity
    "@media (hover: none)": {
      backgroundColor: "transparent"
    }
  },
  [`&.${menuItemClasses$1.selected}`]: {
    backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity),
    [`&.${menuItemClasses$1.focusVisible}`]: {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.focusOpacity}))` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.focusOpacity)
    }
  },
  [`&.${menuItemClasses$1.selected}:hover`]: {
    backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.hoverOpacity}))` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.hoverOpacity),
    // Reset on touch devices, it doesn't add specificity
    "@media (hover: none)": {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity)
    }
  },
  [`&.${menuItemClasses$1.focusVisible}`]: {
    backgroundColor: (theme.vars || theme).palette.action.focus
  },
  [`&.${menuItemClasses$1.disabled}`]: {
    opacity: (theme.vars || theme).palette.action.disabledOpacity
  },
  [`& + .${dividerClasses$1.root}`]: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1)
  },
  [`& + .${dividerClasses$1.inset}`]: {
    marginLeft: 52
  },
  [`& .${listItemTextClasses$1.root}`]: {
    marginTop: 0,
    marginBottom: 0
  },
  [`& .${listItemTextClasses$1.inset}`]: {
    paddingLeft: 36
  },
  [`& .${listItemIconClasses$1.root}`]: {
    minWidth: 36
  }
}, !ownerState.dense && {
  [theme.breakpoints.up("sm")]: {
    minHeight: "auto"
  }
}, ownerState.dense && _extends$1({
  minHeight: 32,
  // https://m2.material.io/components/menus#specs > Dense
  paddingTop: 4,
  paddingBottom: 4
}, theme.typography.body2, {
  [`& .${listItemIconClasses$1.root} svg`]: {
    fontSize: "1.25rem"
  }
})));
const MenuItem = /* @__PURE__ */ reactExports.forwardRef(function MenuItem2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiMenuItem"
  });
  const {
    autoFocus = false,
    component = "li",
    dense = false,
    divider = false,
    disableGutters = false,
    focusVisibleClassName,
    role = "menuitem",
    tabIndex: tabIndexProp,
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$Z);
  const context = reactExports.useContext(ListContext);
  const childContext = reactExports.useMemo(() => ({
    dense: dense || context.dense || false,
    disableGutters
  }), [context.dense, dense, disableGutters]);
  const menuItemRef = reactExports.useRef(null);
  useEnhancedEffect$1(() => {
    if (autoFocus) {
      if (menuItemRef.current) {
        menuItemRef.current.focus();
      }
    }
  }, [autoFocus]);
  const ownerState = _extends$1({}, props, {
    dense: childContext.dense,
    divider,
    disableGutters
  });
  const classes2 = useUtilityClasses$J(props);
  const handleRef = useForkRef$1(menuItemRef, ref);
  let tabIndex;
  if (!props.disabled) {
    tabIndex = tabIndexProp !== void 0 ? tabIndexProp : -1;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ListContext.Provider, {
    value: childContext,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(MenuItemRoot, _extends$1({
      ref: handleRef,
      role,
      tabIndex,
      component,
      focusVisibleClassName: clsx$1(classes2.focusVisible, focusVisibleClassName),
      className: clsx$1(classes2.root, className)
    }, other, {
      ownerState,
      classes: classes2
    }))
  });
});
const MUIMenuItem = MenuItem;
const _excluded$Y = ["label", "icon", "showInMenu", "onClick"];
const GridActionsCellItem = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    label,
    icon,
    showInMenu,
    onClick
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$Y);
  const rootProps = useGridRootProps();
  const handleClick = (event) => {
    if (onClick) {
      onClick(event);
    }
  };
  if (!showInMenu) {
    var _rootProps$slotProps;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseIconButton, _extends$1({
      ref,
      size: "small",
      role: "menuitem",
      "aria-label": label
    }, other, {
      onClick: handleClick
    }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseIconButton, {
      children: /* @__PURE__ */ reactExports.cloneElement(icon, {
        fontSize: "small"
      })
    }));
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(MUIMenuItem, _extends$1({
    ref
  }, other, {
    onClick,
    children: [icon && /* @__PURE__ */ jsxRuntimeExports.jsx(ListItemIcon$1, {
      children: icon
    }), label]
  }));
});
function getSkeletonUtilityClass(slot) {
  return generateUtilityClass("MuiSkeleton", slot);
}
generateUtilityClasses("MuiSkeleton", ["root", "text", "rectangular", "rounded", "circular", "pulse", "wave", "withChildren", "fitContent", "heightAuto"]);
const _excluded$X = ["animation", "className", "component", "height", "style", "variant", "width"];
let _ = (t2) => t2, _t, _t2, _t3, _t4;
const useUtilityClasses$I = (ownerState) => {
  const {
    classes: classes2,
    variant,
    animation,
    hasChildren,
    width,
    height
  } = ownerState;
  const slots = {
    root: ["root", variant, animation, hasChildren && "withChildren", hasChildren && !width && "fitContent", hasChildren && !height && "heightAuto"]
  };
  return composeClasses(slots, getSkeletonUtilityClass, classes2);
};
const pulseKeyframe = keyframes(_t || (_t = _`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`));
const waveKeyframe = keyframes(_t2 || (_t2 = _`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`));
const SkeletonRoot = styled$1("span", {
  name: "MuiSkeleton",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, styles2[ownerState.variant], ownerState.animation !== false && styles2[ownerState.animation], ownerState.hasChildren && styles2.withChildren, ownerState.hasChildren && !ownerState.width && styles2.fitContent, ownerState.hasChildren && !ownerState.height && styles2.heightAuto];
  }
})(({
  theme,
  ownerState
}) => {
  const radiusUnit = getUnit(theme.shape.borderRadius) || "px";
  const radiusValue = toUnitless(theme.shape.borderRadius);
  return _extends$1({
    display: "block",
    // Create a "on paper" color with sufficient contrast retaining the color
    backgroundColor: theme.vars ? theme.vars.palette.Skeleton.bg : alpha(theme.palette.text.primary, theme.palette.mode === "light" ? 0.11 : 0.13),
    height: "1.2em"
  }, ownerState.variant === "text" && {
    marginTop: 0,
    marginBottom: 0,
    height: "auto",
    transformOrigin: "0 55%",
    transform: "scale(1, 0.60)",
    borderRadius: `${radiusValue}${radiusUnit}/${Math.round(radiusValue / 0.6 * 10) / 10}${radiusUnit}`,
    "&:empty:before": {
      content: '"\\00a0"'
    }
  }, ownerState.variant === "circular" && {
    borderRadius: "50%"
  }, ownerState.variant === "rounded" && {
    borderRadius: (theme.vars || theme).shape.borderRadius
  }, ownerState.hasChildren && {
    "& > *": {
      visibility: "hidden"
    }
  }, ownerState.hasChildren && !ownerState.width && {
    maxWidth: "fit-content"
  }, ownerState.hasChildren && !ownerState.height && {
    height: "auto"
  });
}, ({
  ownerState
}) => ownerState.animation === "pulse" && css(_t3 || (_t3 = _`
      animation: ${0} 1.5s ease-in-out 0.5s infinite;
    `), pulseKeyframe), ({
  ownerState,
  theme
}) => ownerState.animation === "wave" && css(_t4 || (_t4 = _`
      position: relative;
      overflow: hidden;

      /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
      -webkit-mask-image: -webkit-radial-gradient(white, black);

      &::after {
        animation: ${0} 1.6s linear 0.5s infinite;
        background: linear-gradient(
          90deg,
          transparent,
          ${0},
          transparent
        );
        content: '';
        position: absolute;
        transform: translateX(-100%); /* Avoid flash during server-side hydration */
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
      }
    `), waveKeyframe, (theme.vars || theme).palette.action.hover));
const Skeleton = /* @__PURE__ */ reactExports.forwardRef(function Skeleton2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiSkeleton"
  });
  const {
    animation = "pulse",
    className,
    component = "span",
    height,
    style,
    variant = "text",
    width
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$X);
  const ownerState = _extends$1({}, props, {
    animation,
    component,
    variant,
    hasChildren: Boolean(other.children)
  });
  const classes2 = useUtilityClasses$I(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(SkeletonRoot, _extends$1({
    as: component,
    ref,
    className: clsx$1(classes2.root, className),
    ownerState
  }, other, {
    style: _extends$1({
      width,
      height
    }, style)
  }));
});
const Skeleton$1 = Skeleton;
const _excluded$W = ["field", "align", "width", "contentWidth"];
const useUtilityClasses$H = (ownerState) => {
  const {
    align,
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["cell", "cellSkeleton", `cell--text${capitalize(align)}`, "withBorderColor"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
function GridSkeletonCell(props) {
  const {
    align,
    width,
    contentWidth
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$W);
  const rootProps = useGridRootProps();
  const ownerState = {
    classes: rootProps.classes,
    align
  };
  const classes2 = useUtilityClasses$H(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", _extends$1({
    className: classes2.root,
    style: {
      width
    }
  }, other, {
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Skeleton$1, {
      width: `${contentWidth}%`
    })
  }));
}
function getBorderColor(theme) {
  if (theme.vars) {
    return theme.vars.palette.TableCell.border;
  }
  if (theme.palette.mode === "light") {
    return lighten(alpha(theme.palette.divider, 1), 0.88);
  }
  return darken(alpha(theme.palette.divider, 1), 0.68);
}
const columnHeadersStyles = {
  [`.${gridClasses.columnSeparator}, .${gridClasses["columnSeparator--resizing"]}`]: {
    visibility: "visible",
    width: "auto"
  }
};
const columnHeaderStyles = {
  [`& .${gridClasses.iconButtonContainer}`]: {
    visibility: "visible",
    width: "auto"
  },
  [`& .${gridClasses.menuIcon}`]: {
    width: "auto",
    visibility: "visible"
  }
};
const GridRootStyles = styled$1("div", {
  name: "MuiDataGrid",
  slot: "Root",
  overridesResolver: (props, styles2) => [
    {
      [`&.${gridClasses.autoHeight}`]: styles2.autoHeight
    },
    {
      [`&.${gridClasses.aggregationColumnHeader}`]: styles2.aggregationColumnHeader
    },
    {
      [`&.${gridClasses["aggregationColumnHeader--alignLeft"]}`]: styles2["aggregationColumnHeader--alignLeft"]
    },
    {
      [`&.${gridClasses["aggregationColumnHeader--alignCenter"]}`]: styles2["aggregationColumnHeader--alignCenter"]
    },
    {
      [`&.${gridClasses["aggregationColumnHeader--alignRight"]}`]: styles2["aggregationColumnHeader--alignRight"]
    },
    {
      [`&.${gridClasses.aggregationColumnHeaderLabel}`]: styles2.aggregationColumnHeaderLabel
    },
    {
      [`&.${gridClasses["root--disableUserSelection"]} .${gridClasses.cell}`]: styles2["root--disableUserSelection"]
    },
    {
      [`& .${gridClasses.editBooleanCell}`]: styles2.editBooleanCell
    },
    {
      [`& .${gridClasses["cell--editing"]}`]: styles2["cell--editing"]
    },
    {
      [`& .${gridClasses["cell--textCenter"]}`]: styles2["cell--textCenter"]
    },
    {
      [`& .${gridClasses["cell--textLeft"]}`]: styles2["cell--textLeft"]
    },
    {
      [`& .${gridClasses["cell--textRight"]}`]: styles2["cell--textRight"]
    },
    // TODO v6: Remove
    {
      [`& .${gridClasses["cell--withRenderer"]}`]: styles2["cell--withRenderer"]
    },
    {
      [`& .${gridClasses.cell}`]: styles2.cell
    },
    {
      [`& .${gridClasses["cell--rangeTop"]}`]: styles2["cell--rangeTop"]
    },
    {
      [`& .${gridClasses["cell--rangeBottom"]}`]: styles2["cell--rangeBottom"]
    },
    {
      [`& .${gridClasses["cell--rangeLeft"]}`]: styles2["cell--rangeLeft"]
    },
    {
      [`& .${gridClasses["cell--rangeRight"]}`]: styles2["cell--rangeRight"]
    },
    {
      [`& .${gridClasses["cell--withRightBorder"]}`]: styles2["cell--withRightBorder"]
    },
    {
      [`& .${gridClasses.cellContent}`]: styles2.cellContent
    },
    {
      [`& .${gridClasses.cellCheckbox}`]: styles2.cellCheckbox
    },
    {
      [`& .${gridClasses.cellSkeleton}`]: styles2.cellSkeleton
    },
    {
      [`& .${gridClasses.checkboxInput}`]: styles2.checkboxInput
    },
    {
      [`& .${gridClasses["columnHeader--alignCenter"]}`]: styles2["columnHeader--alignCenter"]
    },
    {
      [`& .${gridClasses["columnHeader--alignLeft"]}`]: styles2["columnHeader--alignLeft"]
    },
    {
      [`& .${gridClasses["columnHeader--alignRight"]}`]: styles2["columnHeader--alignRight"]
    },
    {
      [`& .${gridClasses["columnHeader--dragging"]}`]: styles2["columnHeader--dragging"]
    },
    {
      [`& .${gridClasses["columnHeader--moving"]}`]: styles2["columnHeader--moving"]
    },
    {
      [`& .${gridClasses["columnHeader--numeric"]}`]: styles2["columnHeader--numeric"]
    },
    {
      [`& .${gridClasses["columnHeader--sortable"]}`]: styles2["columnHeader--sortable"]
    },
    {
      [`& .${gridClasses["columnHeader--sorted"]}`]: styles2["columnHeader--sorted"]
    },
    {
      [`& .${gridClasses["columnHeader--withRightBorder"]}`]: styles2["columnHeader--withRightBorder"]
    },
    {
      [`& .${gridClasses.columnHeader}`]: styles2.columnHeader
    },
    {
      [`& .${gridClasses.headerFilterRow}`]: styles2.headerFilterRow
    },
    {
      [`& .${gridClasses.columnHeaderCheckbox}`]: styles2.columnHeaderCheckbox
    },
    {
      [`& .${gridClasses.columnHeaderDraggableContainer}`]: styles2.columnHeaderDraggableContainer
    },
    {
      [`& .${gridClasses.columnHeaderTitleContainer}`]: styles2.columnHeaderTitleContainer
    },
    {
      [`& .${gridClasses["columnSeparator--resizable"]}`]: styles2["columnSeparator--resizable"]
    },
    {
      [`& .${gridClasses["columnSeparator--resizing"]}`]: styles2["columnSeparator--resizing"]
    },
    {
      [`& .${gridClasses.columnSeparator}`]: styles2.columnSeparator
    },
    {
      [`& .${gridClasses.filterIcon}`]: styles2.filterIcon
    },
    {
      [`& .${gridClasses.iconSeparator}`]: styles2.iconSeparator
    },
    {
      [`& .${gridClasses.menuIcon}`]: styles2.menuIcon
    },
    {
      [`& .${gridClasses.menuIconButton}`]: styles2.menuIconButton
    },
    {
      [`& .${gridClasses.menuOpen}`]: styles2.menuOpen
    },
    {
      [`& .${gridClasses.menuList}`]: styles2.menuList
    },
    {
      [`& .${gridClasses["row--editable"]}`]: styles2["row--editable"]
    },
    {
      [`& .${gridClasses["row--editing"]}`]: styles2["row--editing"]
    },
    {
      [`& .${gridClasses["row--dragging"]}`]: styles2["row--dragging"]
    },
    {
      [`& .${gridClasses.row}`]: styles2.row
    },
    {
      [`& .${gridClasses.rowReorderCellPlaceholder}`]: styles2.rowReorderCellPlaceholder
    },
    {
      [`& .${gridClasses.rowReorderCell}`]: styles2.rowReorderCell
    },
    {
      [`& .${gridClasses["rowReorderCell--draggable"]}`]: styles2["rowReorderCell--draggable"]
    },
    {
      [`& .${gridClasses.sortIcon}`]: styles2.sortIcon
    },
    {
      [`& .${gridClasses.withBorderColor}`]: styles2.withBorderColor
    },
    {
      [`& .${gridClasses.treeDataGroupingCell}`]: styles2.treeDataGroupingCell
    },
    {
      [`& .${gridClasses.treeDataGroupingCellToggle}`]: styles2.treeDataGroupingCellToggle
    },
    {
      [`& .${gridClasses.detailPanelToggleCell}`]: styles2.detailPanelToggleCell
    },
    {
      [`& .${gridClasses["detailPanelToggleCell--expanded"]}`]: styles2["detailPanelToggleCell--expanded"]
    },
    styles2.root
  ]
})(({
  theme
}) => {
  const borderColor = getBorderColor(theme);
  const radius = theme.shape.borderRadius;
  const gridStyle = _extends$1({
    "--unstable_DataGrid-radius": typeof radius === "number" ? `${radius}px` : radius,
    "--unstable_DataGrid-headWeight": theme.typography.fontWeightMedium,
    "--unstable_DataGrid-overlayBackground": theme.vars ? `rgba(${theme.vars.palette.background.defaultChannel} / ${theme.vars.palette.action.disabledOpacity})` : alpha(theme.palette.background.default, theme.palette.action.disabledOpacity),
    "--DataGrid-cellOffsetMultiplier": 2,
    flex: 1,
    boxSizing: "border-box",
    position: "relative",
    borderWidth: "1px",
    borderStyle: "solid",
    borderColor,
    borderRadius: "var(--unstable_DataGrid-radius)",
    color: (theme.vars || theme).palette.text.primary
  }, theme.typography.body2, {
    outline: "none",
    height: "100%",
    display: "flex",
    minWidth: 0,
    // See https://github.com/mui/mui-x/issues/8547
    minHeight: 0,
    flexDirection: "column",
    overflowAnchor: "none",
    // Keep the same scrolling position
    [`&.${gridClasses.autoHeight}`]: {
      height: "auto",
      [`& .${gridClasses["row--lastVisible"]} .${gridClasses.cell}`]: {
        borderBottomColor: "transparent"
      }
    },
    [`& .${gridClasses["virtualScrollerContent--overflowed"]} .${gridClasses["row--lastVisible"]} .${gridClasses.cell}`]: {
      borderBottomColor: "transparent"
    },
    [`& .${gridClasses.columnHeader}, & .${gridClasses.cell}`]: {
      WebkitTapHighlightColor: "transparent",
      lineHeight: null,
      padding: "0 10px",
      boxSizing: "border-box"
    },
    [`& .${gridClasses.columnHeader}:focus-within, & .${gridClasses.cell}:focus-within`]: {
      outline: `solid ${theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / 0.5)` : alpha(theme.palette.primary.main, 0.5)} 1px`,
      outlineWidth: 1,
      outlineOffset: -1
    },
    [`& .${gridClasses.columnHeader}:focus, & .${gridClasses.cell}:focus`]: {
      outline: `solid ${theme.palette.primary.main} 1px`
    },
    [`& .${gridClasses.columnHeaderCheckbox}, & .${gridClasses.cellCheckbox}`]: {
      padding: 0,
      justifyContent: "center",
      alignItems: "center"
    },
    [`& .${gridClasses.columnHeader}`]: {
      position: "relative",
      display: "flex",
      alignItems: "center"
    },
    [`& .${gridClasses["columnHeader--sorted"]} .${gridClasses.iconButtonContainer}, & .${gridClasses["columnHeader--filtered"]} .${gridClasses.iconButtonContainer}`]: {
      visibility: "visible",
      width: "auto"
    },
    [`& .${gridClasses.columnHeader}:not(.${gridClasses["columnHeader--sorted"]}) .${gridClasses.sortIcon}`]: {
      opacity: 0,
      transition: theme.transitions.create(["opacity"], {
        duration: theme.transitions.duration.shorter
      })
    },
    [`& .${gridClasses.columnHeaderTitleContainer}`]: {
      display: "flex",
      alignItems: "center",
      minWidth: 0,
      flex: 1,
      whiteSpace: "nowrap",
      overflow: "hidden",
      // to anchor the aggregation label
      position: "relative"
    },
    [`& .${gridClasses.columnHeaderTitleContainerContent}`]: {
      overflow: "hidden",
      display: "flex",
      alignItems: "center"
    },
    [`& .${gridClasses["columnHeader--filledGroup"]} .${gridClasses.columnHeaderTitleContainer}`]: {
      borderBottomWidth: "1px",
      borderBottomStyle: "solid",
      boxSizing: "border-box"
    },
    [`& .${gridClasses["columnHeader--filledGroup"]}.${gridClasses["columnHeader--showColumnBorder"]} .${gridClasses.columnHeaderTitleContainer}`]: {
      borderBottom: `none`
    },
    [`& .${gridClasses["columnHeader--filledGroup"]}.${gridClasses["columnHeader--showColumnBorder"]}`]: {
      borderBottomWidth: "1px",
      borderBottomStyle: "solid",
      boxSizing: "border-box"
    },
    [`& .${gridClasses.headerFilterRow}`]: {
      borderTop: `1px solid ${borderColor}`
    },
    [`& .${gridClasses.sortIcon}, & .${gridClasses.filterIcon}`]: {
      fontSize: "inherit"
    },
    [`& .${gridClasses["columnHeader--sortable"]}`]: {
      cursor: "pointer"
    },
    [`& .${gridClasses["columnHeader--alignCenter"]} .${gridClasses.columnHeaderTitleContainer}`]: {
      justifyContent: "center"
    },
    [`& .${gridClasses["columnHeader--alignRight"]} .${gridClasses.columnHeaderDraggableContainer}, & .${gridClasses["columnHeader--alignRight"]} .${gridClasses.columnHeaderTitleContainer}`]: {
      flexDirection: "row-reverse"
    },
    [`& .${gridClasses["columnHeader--alignCenter"]} .${gridClasses.menuIcon}, & .${gridClasses["columnHeader--alignRight"]} .${gridClasses.menuIcon}`]: {
      marginRight: "auto",
      marginLeft: -6
    },
    [`& .${gridClasses["columnHeader--alignRight"]} .${gridClasses.menuIcon}, & .${gridClasses["columnHeader--alignRight"]} .${gridClasses.menuIcon}`]: {
      marginRight: "auto",
      marginLeft: -10
    },
    [`& .${gridClasses["columnHeader--moving"]}`]: {
      backgroundColor: (theme.vars || theme).palette.action.hover
    },
    [`& .${gridClasses.columnSeparator}`]: {
      visibility: "hidden",
      position: "absolute",
      zIndex: 100,
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      color: borderColor
    },
    "@media (hover: hover)": {
      [`& .${gridClasses.columnHeaders}:hover`]: columnHeadersStyles,
      [`& .${gridClasses.columnHeader}:hover`]: columnHeaderStyles,
      [`& .${gridClasses.columnHeader}:not(.${gridClasses["columnHeader--sorted"]}):hover .${gridClasses.sortIcon}`]: {
        opacity: 0.5
      }
    },
    "@media (hover: none)": {
      [`& .${gridClasses.columnHeaders}`]: columnHeadersStyles,
      [`& .${gridClasses.columnHeader}`]: columnHeaderStyles
    },
    [`& .${gridClasses["columnSeparator--sideLeft"]}`]: {
      left: -12
    },
    [`& .${gridClasses["columnSeparator--sideRight"]}`]: {
      right: -12
    },
    [`& .${gridClasses["columnSeparator--resizable"]}`]: {
      cursor: "col-resize",
      touchAction: "none",
      "&:hover": {
        color: (theme.vars || theme).palette.text.primary,
        // Reset on touch devices, it doesn't add specificity
        "@media (hover: none)": {
          color: borderColor
        }
      },
      [`&.${gridClasses["columnSeparator--resizing"]}`]: {
        color: (theme.vars || theme).palette.text.primary
      },
      "& svg": {
        pointerEvents: "none"
      }
    },
    [`& .${gridClasses.iconSeparator}`]: {
      color: "inherit"
    },
    [`& .${gridClasses.menuIcon}`]: {
      width: 0,
      visibility: "hidden",
      fontSize: 20,
      marginRight: -10,
      display: "flex",
      alignItems: "center"
    },
    [`.${gridClasses.menuOpen}`]: {
      visibility: "visible",
      width: "auto"
    },
    [`& .${gridClasses.row}`]: {
      display: "flex",
      width: "fit-content",
      breakInside: "avoid",
      // Avoid the row to be broken in two different print pages.
      "&:hover, &.Mui-hovered": {
        backgroundColor: (theme.vars || theme).palette.action.hover,
        // Reset on touch devices, it doesn't add specificity
        "@media (hover: none)": {
          backgroundColor: "transparent"
        }
      },
      "&.Mui-selected": {
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity),
        "&:hover, &.Mui-hovered": {
          backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(
                ${theme.vars.palette.action.selectedOpacity} + 
                ${theme.vars.palette.action.hoverOpacity}
              ))` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.hoverOpacity),
          // Reset on touch devices, it doesn't add specificity
          "@media (hover: none)": {
            backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity)
          }
        }
      }
    },
    [`& .${gridClasses.cell}`]: {
      display: "flex",
      alignItems: "center",
      borderBottom: "1px solid",
      "&.Mui-selected": {
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity),
        "&:hover, &.Mui-hovered": {
          backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity + theme.palette.action.hoverOpacity})` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.hoverOpacity),
          // Reset on touch devices, it doesn't add specificity
          "@media (hover: none)": {
            backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity)
          }
        }
      }
    },
    [`&.${gridClasses["root--disableUserSelection"]} .${gridClasses.cell}`]: {
      userSelect: "none"
    },
    [`& .${gridClasses.row}:not(.${gridClasses["row--dynamicHeight"]}) > .${gridClasses.cell}`]: {
      overflow: "hidden",
      whiteSpace: "nowrap"
    },
    [`& .${gridClasses.cellContent}`]: {
      overflow: "hidden",
      textOverflow: "ellipsis"
    },
    [`& .${gridClasses.cell}.${gridClasses["cell--editing"]}`]: {
      padding: 1,
      display: "flex",
      boxShadow: theme.shadows[2],
      backgroundColor: (theme.vars || theme).palette.background.paper,
      "&:focus-within": {
        outline: `solid ${(theme.vars || theme).palette.primary.main} 1px`,
        outlineOffset: "-1px"
      }
    },
    [`& .${gridClasses["row--editing"]}`]: {
      boxShadow: theme.shadows[2]
    },
    [`& .${gridClasses["row--editing"]} .${gridClasses.cell}`]: {
      boxShadow: theme.shadows[0],
      backgroundColor: (theme.vars || theme).palette.background.paper
    },
    [`& .${gridClasses.editBooleanCell}`]: {
      display: "flex",
      height: "100%",
      width: "100%",
      alignItems: "center",
      justifyContent: "center"
    },
    [`& .${gridClasses.booleanCell}[data-value="true"]`]: {
      color: (theme.vars || theme).palette.text.secondary
    },
    [`& .${gridClasses.booleanCell}[data-value="false"]`]: {
      color: (theme.vars || theme).palette.text.disabled
    },
    [`& .${gridClasses.actionsCell}`]: {
      display: "inline-flex",
      alignItems: "center",
      gridGap: theme.spacing(1)
    },
    [`& .${gridClasses.rowReorderCell}`]: {
      display: "inline-flex",
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      opacity: (theme.vars || theme).palette.action.disabledOpacity
    },
    [`& .${gridClasses["rowReorderCell--draggable"]}`]: {
      cursor: "move",
      opacity: 1
    },
    [`& .${gridClasses.rowReorderCellContainer}`]: {
      padding: 0,
      alignItems: "stretch"
    },
    [`.${gridClasses.withBorderColor}`]: {
      borderColor
    },
    [`& .${gridClasses["cell--withRightBorder"]}`]: {
      borderRightWidth: "1px",
      borderRightStyle: "solid"
    },
    [`& .${gridClasses["columnHeader--withRightBorder"]}`]: {
      borderRightWidth: "1px",
      borderRightStyle: "solid"
    },
    [`& .${gridClasses["cell--textLeft"]}`]: {
      justifyContent: "flex-start"
    },
    [`& .${gridClasses["cell--textRight"]}`]: {
      justifyContent: "flex-end"
    },
    [`& .${gridClasses["cell--textCenter"]}`]: {
      justifyContent: "center"
    },
    [`& .${gridClasses.columnHeaderDraggableContainer}`]: {
      display: "flex",
      width: "100%",
      height: "100%"
    },
    [`& .${gridClasses.rowReorderCellPlaceholder}`]: {
      display: "none"
    },
    [`& .${gridClasses["columnHeader--dragging"]}, & .${gridClasses["row--dragging"]}`]: {
      background: (theme.vars || theme).palette.background.paper,
      padding: "0 12px",
      borderRadius: "var(--unstable_DataGrid-radius)",
      opacity: (theme.vars || theme).palette.action.disabledOpacity
    },
    [`& .${gridClasses["row--dragging"]}`]: {
      background: (theme.vars || theme).palette.background.paper,
      padding: "0 12px",
      borderRadius: "var(--unstable_DataGrid-radius)",
      opacity: (theme.vars || theme).palette.action.disabledOpacity,
      [`& .${gridClasses.rowReorderCellPlaceholder}`]: {
        display: "flex"
      }
    },
    [`& .${gridClasses.treeDataGroupingCell}`]: {
      display: "flex",
      alignItems: "center",
      width: "100%"
    },
    [`& .${gridClasses.treeDataGroupingCellToggle}`]: {
      flex: "0 0 28px",
      alignSelf: "stretch",
      marginRight: theme.spacing(2)
    },
    [`& .${gridClasses.groupingCriteriaCell}`]: {
      display: "flex",
      alignItems: "center",
      width: "100%"
    },
    [`& .${gridClasses.groupingCriteriaCellToggle}`]: {
      flex: "0 0 28px",
      alignSelf: "stretch",
      marginRight: theme.spacing(2)
    }
  });
  return gridStyle;
});
const _excluded$V = ["children", "className"];
const useUtilityClasses$G = (ownerState) => {
  const {
    autoHeight,
    density,
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["root", autoHeight && "autoHeight", `root--density${capitalize(density)}`, "withBorderColor"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridRoot = /* @__PURE__ */ reactExports.forwardRef(function GridRoot2(props, ref) {
  var _rootProps$experiment;
  const rootProps = useGridRootProps();
  const {
    children,
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$V);
  const apiRef2 = useGridPrivateApiContext();
  const densityValue = useGridSelector(apiRef2, gridDensityValueSelector);
  const rootContainerRef = reactExports.useRef(null);
  const handleRef = useForkRef$1(rootContainerRef, ref);
  const getAriaAttributes = (_rootProps$experiment = rootProps.experimentalFeatures) != null && _rootProps$experiment.ariaV7 ? null : useGridAriaAttributes;
  const ariaAttributes = typeof getAriaAttributes === "function" ? getAriaAttributes() : null;
  const ownerState = _extends$1({}, rootProps, {
    density: densityValue
  });
  const classes2 = useUtilityClasses$G(ownerState);
  apiRef2.current.register("public", {
    rootElementRef: rootContainerRef
  });
  const [mountedState, setMountedState] = reactExports.useState(false);
  useEnhancedEffect$1(() => {
    setMountedState(true);
  }, []);
  if (!mountedState) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridRootStyles, _extends$1({
    ref: handleRef,
    className: clsx$1(className, classes2.root),
    ownerState
  }, ariaAttributes, other, {
    children
  }));
});
const _excluded$U = ["className"];
const useUtilityClasses$F = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["footerContainer", "withBorderColor"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridFooterContainerRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "FooterContainer",
  overridesResolver: (props, styles2) => styles2.footerContainer
})({
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  minHeight: 52,
  borderTop: "1px solid"
});
const GridFooterContainer = /* @__PURE__ */ reactExports.forwardRef(function GridFooterContainer2(props, ref) {
  const {
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$U);
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$F(rootProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridFooterContainerRoot, _extends$1({
    ref,
    className: clsx$1(classes2.root, className),
    ownerState: rootProps
  }, other));
});
const _excluded$T = ["className"];
const useUtilityClasses$E = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["overlay"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridOverlayRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "Overlay",
  overridesResolver: (_2, styles2) => styles2.overlay
})({
  width: "100%",
  height: "100%",
  display: "flex",
  alignSelf: "center",
  alignItems: "center",
  justifyContent: "center",
  backgroundColor: "var(--unstable_DataGrid-overlayBackground)"
});
const GridOverlay = /* @__PURE__ */ reactExports.forwardRef(function GridOverlay2(props, ref) {
  const {
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$T);
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$E(rootProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridOverlayRoot, _extends$1({
    ref,
    className: clsx$1(classes2.root, className),
    ownerState: rootProps
  }, other));
});
function getBadgeUtilityClass(slot) {
  return generateUtilityClass("MuiBadge", slot);
}
const badgeClasses = generateUtilityClasses("MuiBadge", [
  "root",
  "badge",
  "dot",
  "standard",
  "anchorOriginTopRight",
  "anchorOriginBottomRight",
  "anchorOriginTopLeft",
  "anchorOriginBottomLeft",
  "invisible",
  "colorError",
  "colorInfo",
  "colorPrimary",
  "colorSecondary",
  "colorSuccess",
  "colorWarning",
  "overlapRectangular",
  "overlapCircular",
  // TODO: v6 remove the overlap value from these class keys
  "anchorOriginTopLeftCircular",
  "anchorOriginTopLeftRectangular",
  "anchorOriginTopRightCircular",
  "anchorOriginTopRightRectangular",
  "anchorOriginBottomLeftCircular",
  "anchorOriginBottomLeftRectangular",
  "anchorOriginBottomRightCircular",
  "anchorOriginBottomRightRectangular"
]);
const badgeClasses$1 = badgeClasses;
const _excluded$S = ["anchorOrigin", "className", "classes", "component", "components", "componentsProps", "children", "overlap", "color", "invisible", "max", "badgeContent", "slots", "slotProps", "showZero", "variant"];
const RADIUS_STANDARD = 10;
const RADIUS_DOT = 4;
const useUtilityClasses$D = (ownerState) => {
  const {
    color,
    anchorOrigin,
    invisible,
    overlap,
    variant,
    classes: classes2 = {}
  } = ownerState;
  const slots = {
    root: ["root"],
    badge: ["badge", variant, invisible && "invisible", `anchorOrigin${capitalize(anchorOrigin.vertical)}${capitalize(anchorOrigin.horizontal)}`, `anchorOrigin${capitalize(anchorOrigin.vertical)}${capitalize(anchorOrigin.horizontal)}${capitalize(overlap)}`, `overlap${capitalize(overlap)}`, color !== "default" && `color${capitalize(color)}`]
  };
  return composeClasses(slots, getBadgeUtilityClass, classes2);
};
const BadgeRoot = styled$1("span", {
  name: "MuiBadge",
  slot: "Root",
  overridesResolver: (props, styles2) => styles2.root
})({
  position: "relative",
  display: "inline-flex",
  // For correct alignment with the text.
  verticalAlign: "middle",
  flexShrink: 0
});
const BadgeBadge = styled$1("span", {
  name: "MuiBadge",
  slot: "Badge",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.badge, styles2[ownerState.variant], styles2[`anchorOrigin${capitalize(ownerState.anchorOrigin.vertical)}${capitalize(ownerState.anchorOrigin.horizontal)}${capitalize(ownerState.overlap)}`], ownerState.color !== "default" && styles2[`color${capitalize(ownerState.color)}`], ownerState.invisible && styles2.invisible];
  }
})(({
  theme,
  ownerState
}) => _extends$1({
  display: "flex",
  flexDirection: "row",
  flexWrap: "wrap",
  justifyContent: "center",
  alignContent: "center",
  alignItems: "center",
  position: "absolute",
  boxSizing: "border-box",
  fontFamily: theme.typography.fontFamily,
  fontWeight: theme.typography.fontWeightMedium,
  fontSize: theme.typography.pxToRem(12),
  minWidth: RADIUS_STANDARD * 2,
  lineHeight: 1,
  padding: "0 6px",
  height: RADIUS_STANDARD * 2,
  borderRadius: RADIUS_STANDARD,
  zIndex: 1,
  // Render the badge on top of potential ripples.
  transition: theme.transitions.create("transform", {
    easing: theme.transitions.easing.easeInOut,
    duration: theme.transitions.duration.enteringScreen
  })
}, ownerState.color !== "default" && {
  backgroundColor: (theme.vars || theme).palette[ownerState.color].main,
  color: (theme.vars || theme).palette[ownerState.color].contrastText
}, ownerState.variant === "dot" && {
  borderRadius: RADIUS_DOT,
  height: RADIUS_DOT * 2,
  minWidth: RADIUS_DOT * 2,
  padding: 0
}, ownerState.anchorOrigin.vertical === "top" && ownerState.anchorOrigin.horizontal === "right" && ownerState.overlap === "rectangular" && {
  top: 0,
  right: 0,
  transform: "scale(1) translate(50%, -50%)",
  transformOrigin: "100% 0%",
  [`&.${badgeClasses$1.invisible}`]: {
    transform: "scale(0) translate(50%, -50%)"
  }
}, ownerState.anchorOrigin.vertical === "bottom" && ownerState.anchorOrigin.horizontal === "right" && ownerState.overlap === "rectangular" && {
  bottom: 0,
  right: 0,
  transform: "scale(1) translate(50%, 50%)",
  transformOrigin: "100% 100%",
  [`&.${badgeClasses$1.invisible}`]: {
    transform: "scale(0) translate(50%, 50%)"
  }
}, ownerState.anchorOrigin.vertical === "top" && ownerState.anchorOrigin.horizontal === "left" && ownerState.overlap === "rectangular" && {
  top: 0,
  left: 0,
  transform: "scale(1) translate(-50%, -50%)",
  transformOrigin: "0% 0%",
  [`&.${badgeClasses$1.invisible}`]: {
    transform: "scale(0) translate(-50%, -50%)"
  }
}, ownerState.anchorOrigin.vertical === "bottom" && ownerState.anchorOrigin.horizontal === "left" && ownerState.overlap === "rectangular" && {
  bottom: 0,
  left: 0,
  transform: "scale(1) translate(-50%, 50%)",
  transformOrigin: "0% 100%",
  [`&.${badgeClasses$1.invisible}`]: {
    transform: "scale(0) translate(-50%, 50%)"
  }
}, ownerState.anchorOrigin.vertical === "top" && ownerState.anchorOrigin.horizontal === "right" && ownerState.overlap === "circular" && {
  top: "14%",
  right: "14%",
  transform: "scale(1) translate(50%, -50%)",
  transformOrigin: "100% 0%",
  [`&.${badgeClasses$1.invisible}`]: {
    transform: "scale(0) translate(50%, -50%)"
  }
}, ownerState.anchorOrigin.vertical === "bottom" && ownerState.anchorOrigin.horizontal === "right" && ownerState.overlap === "circular" && {
  bottom: "14%",
  right: "14%",
  transform: "scale(1) translate(50%, 50%)",
  transformOrigin: "100% 100%",
  [`&.${badgeClasses$1.invisible}`]: {
    transform: "scale(0) translate(50%, 50%)"
  }
}, ownerState.anchorOrigin.vertical === "top" && ownerState.anchorOrigin.horizontal === "left" && ownerState.overlap === "circular" && {
  top: "14%",
  left: "14%",
  transform: "scale(1) translate(-50%, -50%)",
  transformOrigin: "0% 0%",
  [`&.${badgeClasses$1.invisible}`]: {
    transform: "scale(0) translate(-50%, -50%)"
  }
}, ownerState.anchorOrigin.vertical === "bottom" && ownerState.anchorOrigin.horizontal === "left" && ownerState.overlap === "circular" && {
  bottom: "14%",
  left: "14%",
  transform: "scale(1) translate(-50%, 50%)",
  transformOrigin: "0% 100%",
  [`&.${badgeClasses$1.invisible}`]: {
    transform: "scale(0) translate(-50%, 50%)"
  }
}, ownerState.invisible && {
  transition: theme.transitions.create("transform", {
    easing: theme.transitions.easing.easeInOut,
    duration: theme.transitions.duration.leavingScreen
  })
}));
const Badge = /* @__PURE__ */ reactExports.forwardRef(function Badge2(inProps, ref) {
  var _ref, _slots$root, _ref2, _slots$badge, _slotProps$root, _slotProps$badge;
  const props = useThemeProps({
    props: inProps,
    name: "MuiBadge"
  });
  const {
    anchorOrigin: anchorOriginProp = {
      vertical: "top",
      horizontal: "right"
    },
    className,
    component,
    components = {},
    componentsProps = {},
    children,
    overlap: overlapProp = "rectangular",
    color: colorProp = "default",
    invisible: invisibleProp = false,
    max: maxProp = 99,
    badgeContent: badgeContentProp,
    slots,
    slotProps,
    showZero = false,
    variant: variantProp = "standard"
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$S);
  const {
    badgeContent,
    invisible: invisibleFromHook,
    max: max2,
    displayValue: displayValueFromHook
  } = useBadge({
    max: maxProp,
    invisible: invisibleProp,
    badgeContent: badgeContentProp,
    showZero
  });
  const prevProps = usePreviousProps$1({
    anchorOrigin: anchorOriginProp,
    color: colorProp,
    overlap: overlapProp,
    variant: variantProp,
    badgeContent: badgeContentProp
  });
  const invisible = invisibleFromHook || badgeContent == null && variantProp !== "dot";
  const {
    color = colorProp,
    overlap = overlapProp,
    anchorOrigin = anchorOriginProp,
    variant = variantProp
  } = invisible ? prevProps : props;
  const displayValue = variant !== "dot" ? displayValueFromHook : void 0;
  const ownerState = _extends$1({}, props, {
    badgeContent,
    invisible,
    max: max2,
    displayValue,
    showZero,
    anchorOrigin,
    color,
    overlap,
    variant
  });
  const classes2 = useUtilityClasses$D(ownerState);
  const RootSlot = (_ref = (_slots$root = slots == null ? void 0 : slots.root) != null ? _slots$root : components.Root) != null ? _ref : BadgeRoot;
  const BadgeSlot = (_ref2 = (_slots$badge = slots == null ? void 0 : slots.badge) != null ? _slots$badge : components.Badge) != null ? _ref2 : BadgeBadge;
  const rootSlotProps = (_slotProps$root = slotProps == null ? void 0 : slotProps.root) != null ? _slotProps$root : componentsProps.root;
  const badgeSlotProps = (_slotProps$badge = slotProps == null ? void 0 : slotProps.badge) != null ? _slotProps$badge : componentsProps.badge;
  const rootProps = useSlotProps({
    elementType: RootSlot,
    externalSlotProps: rootSlotProps,
    externalForwardedProps: other,
    additionalProps: {
      ref,
      as: component
    },
    ownerState,
    className: clsx$1(rootSlotProps == null ? void 0 : rootSlotProps.className, classes2.root, className)
  });
  const badgeProps = useSlotProps({
    elementType: BadgeSlot,
    externalSlotProps: badgeSlotProps,
    ownerState,
    className: clsx$1(classes2.badge, badgeSlotProps == null ? void 0 : badgeSlotProps.className)
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(RootSlot, _extends$1({}, rootProps, {
    children: [children, /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeSlot, _extends$1({}, badgeProps, {
      children: displayValue
    }))]
  }));
});
const Badge$1 = Badge;
const _excluded$R = ["className"];
const useUtilityClasses$C = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["iconButtonContainer"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridIconButtonContainerRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "IconButtonContainer",
  overridesResolver: (props, styles2) => styles2.iconButtonContainer
})(() => ({
  display: "flex",
  visibility: "hidden",
  width: 0
}));
const GridIconButtonContainer = /* @__PURE__ */ reactExports.forwardRef(function GridIconButtonContainer2(props, ref) {
  const {
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$R);
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$C(rootProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridIconButtonContainerRoot, _extends$1({
    ref,
    className: clsx$1(classes2.root, className),
    ownerState: rootProps
  }, other));
});
const useUtilityClasses$B = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    icon: ["sortIcon"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
function getIcon(icons, direction2, className, sortingOrder) {
  let Icon;
  const iconProps = {};
  if (direction2 === "asc") {
    Icon = icons.columnSortedAscendingIcon;
  } else if (direction2 === "desc") {
    Icon = icons.columnSortedDescendingIcon;
  } else {
    Icon = icons.columnUnsortedIcon;
    iconProps.sortingOrder = sortingOrder;
  }
  return Icon ? /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, _extends$1({
    fontSize: "small",
    className
  }, iconProps)) : null;
}
function GridColumnHeaderSortIconRaw(props) {
  var _rootProps$slotProps;
  const {
    direction: direction2,
    index,
    sortingOrder
  } = props;
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const ownerState = _extends$1({}, props, {
    classes: rootProps.classes
  });
  const classes2 = useUtilityClasses$B(ownerState);
  const iconElement = getIcon(rootProps.slots, direction2, classes2.icon, sortingOrder);
  if (!iconElement) {
    return null;
  }
  const iconButton = /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseIconButton, _extends$1({
    tabIndex: -1,
    "aria-label": apiRef2.current.getLocaleText("columnHeaderSortIconLabel"),
    title: apiRef2.current.getLocaleText("columnHeaderSortIconLabel"),
    size: "small"
  }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseIconButton, {
    children: iconElement
  }));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(GridIconButtonContainer, {
    children: [index != null && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge$1, {
      badgeContent: index,
      color: "default",
      children: iconButton
    }), index == null && iconButton]
  });
}
const GridColumnHeaderSortIcon = /* @__PURE__ */ reactExports.memo(GridColumnHeaderSortIconRaw);
const useUtilityClasses$A = (ownerState) => {
  const {
    classes: classes2,
    open
  } = ownerState;
  const slots = {
    root: ["menuIcon", open && "menuOpen"],
    button: ["menuIconButton"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const ColumnHeaderMenuIcon = /* @__PURE__ */ reactExports.memo((props) => {
  var _rootProps$slotProps, _rootProps$slotProps2;
  const {
    colDef,
    open,
    columnMenuId,
    columnMenuButtonId,
    iconButtonRef
  } = props;
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const ownerState = _extends$1({}, props, {
    classes: rootProps.classes
  });
  const classes2 = useUtilityClasses$A(ownerState);
  const handleMenuIconClick = reactExports.useCallback((event) => {
    event.preventDefault();
    event.stopPropagation();
    apiRef2.current.toggleColumnMenu(colDef.field);
  }, [apiRef2, colDef.field]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", {
    className: classes2.root,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseTooltip, _extends$1({
      title: apiRef2.current.getLocaleText("columnMenuLabel"),
      enterDelay: 1e3
    }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseTooltip, {
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseIconButton, _extends$1({
        ref: iconButtonRef,
        tabIndex: -1,
        className: classes2.button,
        "aria-label": apiRef2.current.getLocaleText("columnMenuLabel"),
        size: "small",
        onClick: handleMenuIconClick,
        "aria-haspopup": "menu",
        "aria-expanded": open,
        "aria-controls": open ? columnMenuId : void 0,
        id: columnMenuButtonId
      }, (_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.baseIconButton, {
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.columnMenuIcon, {
          fontSize: "small"
        })
      }))
    }))
  });
});
function GridColumnHeaderMenu({
  columnMenuId,
  columnMenuButtonId,
  ContentComponent,
  contentComponentProps,
  field,
  open,
  target,
  onExited
}) {
  const apiRef2 = useGridApiContext();
  const colDef = apiRef2.current.getColumn(field);
  const hideMenu = reactExports.useCallback((event) => {
    event.stopPropagation();
    if (!(target != null && target.contains(event.target))) {
      apiRef2.current.hideColumnMenu();
    }
  }, [apiRef2, target]);
  if (!target || !colDef) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridMenu, {
    placement: `bottom-${colDef.align === "right" ? "start" : "end"}`,
    open,
    target,
    onClickAway: hideMenu,
    onExited,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(ContentComponent, _extends$1({
      colDef,
      hideMenu,
      open,
      id: columnMenuId,
      labelledby: columnMenuButtonId
    }, contentComponentProps))
  });
}
const _excluded$Q = ["className"];
const useUtilityClasses$z = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["columnHeaderTitle"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridColumnHeaderTitleRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "ColumnHeaderTitle",
  overridesResolver: (props, styles2) => styles2.columnHeaderTitle
})({
  textOverflow: "ellipsis",
  overflow: "hidden",
  whiteSpace: "nowrap",
  fontWeight: "var(--unstable_DataGrid-headWeight)"
});
const ColumnHeaderInnerTitle = /* @__PURE__ */ reactExports.forwardRef(function ColumnHeaderInnerTitle2(props, ref) {
  const {
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$Q);
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$z(rootProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnHeaderTitleRoot, _extends$1({
    ref,
    className: clsx$1(classes2.root, className),
    ownerState: rootProps
  }, other));
});
function GridColumnHeaderTitle(props) {
  var _rootProps$slotProps;
  const {
    label,
    description
  } = props;
  const rootProps = useGridRootProps();
  const titleRef = reactExports.useRef(null);
  const [tooltip, setTooltip] = reactExports.useState("");
  const handleMouseOver = reactExports.useCallback(() => {
    if (!description && titleRef != null && titleRef.current) {
      const isOver = isOverflown(titleRef.current);
      if (isOver) {
        setTooltip(label);
      } else {
        setTooltip("");
      }
    }
  }, [description, label]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseTooltip, _extends$1({
    title: description || tooltip
  }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseTooltip, {
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(ColumnHeaderInnerTitle, {
      onMouseOver: handleMouseOver,
      ref: titleRef,
      children: label
    })
  }));
}
const _excluded$P = ["resizable", "resizing", "height", "side"];
var GridColumnHeaderSeparatorSides = /* @__PURE__ */ function(GridColumnHeaderSeparatorSides2) {
  GridColumnHeaderSeparatorSides2["Left"] = "left";
  GridColumnHeaderSeparatorSides2["Right"] = "right";
  return GridColumnHeaderSeparatorSides2;
}(GridColumnHeaderSeparatorSides || {});
const useUtilityClasses$y = (ownerState) => {
  const {
    resizable,
    resizing,
    classes: classes2,
    side
  } = ownerState;
  const slots = {
    root: ["columnSeparator", resizable && "columnSeparator--resizable", resizing && "columnSeparator--resizing", side && `columnSeparator--side${capitalize(side)}`],
    icon: ["iconSeparator"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
function GridColumnHeaderSeparatorRaw(props) {
  const {
    height,
    side = GridColumnHeaderSeparatorSides.Right
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$P);
  const rootProps = useGridRootProps();
  const ownerState = _extends$1({}, props, {
    side,
    classes: rootProps.classes
  });
  const classes2 = useUtilityClasses$y(ownerState);
  const stopClick = reactExports.useCallback((event) => {
    event.preventDefault();
    event.stopPropagation();
  }, []);
  return (
    // eslint-disable-next-line jsx-a11y/click-events-have-key-events,jsx-a11y/no-static-element-interactions
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", _extends$1({
      className: classes2.root,
      style: {
        minHeight: height,
        opacity: rootProps.showColumnVerticalBorder ? 0 : 1
      }
    }, other, {
      onClick: stopClick,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.columnResizeIcon, {
        className: classes2.icon
      })
    }))
  );
}
const GridColumnHeaderSeparator = /* @__PURE__ */ reactExports.memo(GridColumnHeaderSeparatorRaw);
const _excluded$O = ["classes", "columnMenuOpen", "colIndex", "height", "isResizing", "sortDirection", "hasFocus", "tabIndex", "separatorSide", "isDraggable", "headerComponent", "description", "elementId", "width", "columnMenuIconButton", "columnMenu", "columnTitleIconButtons", "headerClassName", "label", "resizable", "draggableContainerProps", "columnHeaderSeparatorProps"];
const GridGenericColumnHeaderItem = /* @__PURE__ */ reactExports.forwardRef(function GridGenericColumnHeaderItem2(props, ref) {
  const {
    classes: classes2,
    columnMenuOpen,
    colIndex,
    height,
    isResizing,
    sortDirection,
    hasFocus,
    tabIndex,
    separatorSide,
    isDraggable,
    headerComponent,
    description,
    width,
    columnMenuIconButton = null,
    columnMenu = null,
    columnTitleIconButtons = null,
    headerClassName,
    label,
    resizable,
    draggableContainerProps,
    columnHeaderSeparatorProps
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$O);
  const apiRef2 = useGridPrivateApiContext();
  const rootProps = useGridRootProps();
  const headerCellRef = reactExports.useRef(null);
  const [showColumnMenuIcon, setShowColumnMenuIcon] = reactExports.useState(columnMenuOpen);
  const handleRef = useForkRef$1(headerCellRef, ref);
  let ariaSort = "none";
  if (sortDirection != null) {
    ariaSort = sortDirection === "asc" ? "ascending" : "descending";
  }
  reactExports.useEffect(() => {
    if (!showColumnMenuIcon) {
      setShowColumnMenuIcon(columnMenuOpen);
    }
  }, [showColumnMenuIcon, columnMenuOpen]);
  reactExports.useLayoutEffect(() => {
    const columnMenuState = apiRef2.current.state.columnMenu;
    if (hasFocus && !columnMenuState.open) {
      const focusableElement = headerCellRef.current.querySelector('[tabindex="0"]');
      const elementToFocus = focusableElement || headerCellRef.current;
      elementToFocus == null || elementToFocus.focus();
      apiRef2.current.columnHeadersContainerElementRef.current.scrollLeft = 0;
    }
  }, [apiRef2, hasFocus]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", _extends$1({
    ref: handleRef,
    className: clsx$1(classes2.root, headerClassName),
    style: {
      height,
      width,
      minWidth: width,
      maxWidth: width
    },
    role: "columnheader",
    tabIndex,
    "aria-colindex": colIndex + 1,
    "aria-sort": ariaSort,
    "aria-label": headerComponent == null ? label : void 0
  }, other, {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsxs("div", _extends$1({
      className: classes2.draggableContainer,
      draggable: isDraggable,
      role: "presentation"
    }, draggableContainerProps, {
      children: [/* @__PURE__ */ jsxRuntimeExports.jsxs("div", {
        className: classes2.titleContainer,
        role: "presentation",
        children: [/* @__PURE__ */ jsxRuntimeExports.jsx("div", {
          className: classes2.titleContainerContent,
          children: headerComponent !== void 0 ? headerComponent : /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnHeaderTitle, {
            label,
            description,
            columnWidth: width
          })
        }), columnTitleIconButtons]
      }), columnMenuIconButton]
    })), /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnHeaderSeparator, _extends$1({
      resizable: !rootProps.disableColumnResize && !!resizable,
      resizing: isResizing,
      height,
      side: separatorSide
    }, columnHeaderSeparatorProps)), columnMenu]
  }));
});
const useUtilityClasses$x = (ownerState) => {
  const {
    colDef,
    classes: classes2,
    isDragging,
    sortDirection,
    showRightBorder,
    filterItemsCounter
  } = ownerState;
  const isColumnSorted = sortDirection != null;
  const isColumnFiltered = filterItemsCounter != null && filterItemsCounter > 0;
  const isColumnNumeric = colDef.type === "number";
  const slots = {
    root: ["columnHeader", colDef.headerAlign === "left" && "columnHeader--alignLeft", colDef.headerAlign === "center" && "columnHeader--alignCenter", colDef.headerAlign === "right" && "columnHeader--alignRight", colDef.sortable && "columnHeader--sortable", isDragging && "columnHeader--moving", isColumnSorted && "columnHeader--sorted", isColumnFiltered && "columnHeader--filtered", isColumnNumeric && "columnHeader--numeric", "withBorderColor", showRightBorder && "columnHeader--withRightBorder"],
    draggableContainer: ["columnHeaderDraggableContainer"],
    titleContainer: ["columnHeaderTitleContainer"],
    titleContainerContent: ["columnHeaderTitleContainerContent"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
function GridColumnHeaderItem(props) {
  var _rootProps$slotProps, _colDef$sortingOrder, _rootProps$slotProps2, _colDef$headerName;
  const {
    colDef,
    columnMenuOpen,
    colIndex,
    headerHeight,
    isResizing,
    sortDirection,
    sortIndex,
    filterItemsCounter,
    hasFocus,
    tabIndex,
    disableReorder,
    separatorSide
  } = props;
  const apiRef2 = useGridPrivateApiContext();
  const rootProps = useGridRootProps();
  const headerCellRef = reactExports.useRef(null);
  const columnMenuId = useId();
  const columnMenuButtonId = useId();
  const iconButtonRef = reactExports.useRef(null);
  const [showColumnMenuIcon, setShowColumnMenuIcon] = reactExports.useState(columnMenuOpen);
  const isDraggable = reactExports.useMemo(() => !rootProps.disableColumnReorder && !disableReorder && !colDef.disableReorder, [rootProps.disableColumnReorder, disableReorder, colDef.disableReorder]);
  let headerComponent;
  if (colDef.renderHeader) {
    headerComponent = colDef.renderHeader(apiRef2.current.getColumnHeaderParams(colDef.field));
  }
  const ownerState = _extends$1({}, props, {
    classes: rootProps.classes,
    showRightBorder: rootProps.showColumnVerticalBorder
  });
  const classes2 = useUtilityClasses$x(ownerState);
  const publish = reactExports.useCallback((eventName) => (event) => {
    if (!event.currentTarget.contains(event.target)) {
      return;
    }
    apiRef2.current.publishEvent(eventName, apiRef2.current.getColumnHeaderParams(colDef.field), event);
  }, [apiRef2, colDef.field]);
  const mouseEventsHandlers = reactExports.useMemo(() => ({
    onClick: publish("columnHeaderClick"),
    onDoubleClick: publish("columnHeaderDoubleClick"),
    onMouseOver: publish("columnHeaderOver"),
    // TODO remove as it's not used
    onMouseOut: publish("columnHeaderOut"),
    // TODO remove as it's not used
    onMouseEnter: publish("columnHeaderEnter"),
    // TODO remove as it's not used
    onMouseLeave: publish("columnHeaderLeave"),
    // TODO remove as it's not used
    onKeyDown: publish("columnHeaderKeyDown"),
    onFocus: publish("columnHeaderFocus"),
    onBlur: publish("columnHeaderBlur")
  }), [publish]);
  const draggableEventHandlers = reactExports.useMemo(() => isDraggable ? {
    onDragStart: publish("columnHeaderDragStart"),
    onDragEnter: publish("columnHeaderDragEnter"),
    onDragOver: publish("columnHeaderDragOver"),
    onDragEnd: publish("columnHeaderDragEnd")
  } : {}, [isDraggable, publish]);
  const columnHeaderSeparatorProps = reactExports.useMemo(() => ({
    onMouseDown: publish("columnSeparatorMouseDown")
  }), [publish]);
  reactExports.useEffect(() => {
    if (!showColumnMenuIcon) {
      setShowColumnMenuIcon(columnMenuOpen);
    }
  }, [showColumnMenuIcon, columnMenuOpen]);
  const handleExited = reactExports.useCallback(() => {
    setShowColumnMenuIcon(false);
  }, []);
  const columnMenuIconButton = !rootProps.disableColumnMenu && !colDef.disableColumnMenu && /* @__PURE__ */ jsxRuntimeExports.jsx(ColumnHeaderMenuIcon, {
    colDef,
    columnMenuId,
    columnMenuButtonId,
    open: showColumnMenuIcon,
    iconButtonRef
  });
  const columnMenu = /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnHeaderMenu, {
    columnMenuId,
    columnMenuButtonId,
    field: colDef.field,
    open: columnMenuOpen,
    target: iconButtonRef.current,
    ContentComponent: rootProps.slots.columnMenu,
    contentComponentProps: (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.columnMenu,
    onExited: handleExited
  });
  const sortingOrder = (_colDef$sortingOrder = colDef.sortingOrder) != null ? _colDef$sortingOrder : rootProps.sortingOrder;
  const columnTitleIconButtons = /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, {
    children: [!rootProps.disableColumnFilter && /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.columnHeaderFilterIconButton, _extends$1({
      field: colDef.field,
      counter: filterItemsCounter
    }, (_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.columnHeaderFilterIconButton)), colDef.sortable && !colDef.hideSortIcons && /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnHeaderSortIcon, {
      direction: sortDirection,
      index: sortIndex,
      sortingOrder
    })]
  });
  reactExports.useLayoutEffect(() => {
    const columnMenuState = apiRef2.current.state.columnMenu;
    if (hasFocus && !columnMenuState.open) {
      const focusableElement = headerCellRef.current.querySelector('[tabindex="0"]');
      const elementToFocus = focusableElement || headerCellRef.current;
      elementToFocus == null || elementToFocus.focus();
      apiRef2.current.columnHeadersContainerElementRef.current.scrollLeft = 0;
    }
  }, [apiRef2, hasFocus]);
  const headerClassName = typeof colDef.headerClassName === "function" ? colDef.headerClassName({
    field: colDef.field,
    colDef
  }) : colDef.headerClassName;
  const label = (_colDef$headerName = colDef.headerName) != null ? _colDef$headerName : colDef.field;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridGenericColumnHeaderItem, _extends$1({
    ref: headerCellRef,
    classes: classes2,
    columnMenuOpen,
    colIndex,
    height: headerHeight,
    isResizing,
    sortDirection,
    hasFocus,
    tabIndex,
    separatorSide,
    isDraggable,
    headerComponent,
    description: colDef.description,
    elementId: colDef.field,
    width: colDef.computedWidth,
    columnMenuIconButton,
    columnTitleIconButtons,
    headerClassName,
    label,
    resizable: !rootProps.disableColumnResize && !!colDef.resizable,
    "data-field": colDef.field,
    columnMenu,
    draggableContainerProps: draggableEventHandlers,
    columnHeaderSeparatorProps
  }, mouseEventsHandlers));
}
const getDefaultGridFilterModel = () => ({
  items: [],
  logicOperator: GridLogicOperator.And,
  quickFilterValues: [],
  quickFilterLogicOperator: GridLogicOperator.And
});
const CLEANUP_TIMER_LOOP_MILLIS = 1e3;
class TimerBasedCleanupTracking {
  constructor(timeout2 = CLEANUP_TIMER_LOOP_MILLIS) {
    this.timeouts = /* @__PURE__ */ new Map();
    this.cleanupTimeout = CLEANUP_TIMER_LOOP_MILLIS;
    this.cleanupTimeout = timeout2;
  }
  register(object, unsubscribe, unregisterToken) {
    if (!this.timeouts) {
      this.timeouts = /* @__PURE__ */ new Map();
    }
    const timeout2 = setTimeout(() => {
      if (typeof unsubscribe === "function") {
        unsubscribe();
      }
      this.timeouts.delete(unregisterToken.cleanupToken);
    }, this.cleanupTimeout);
    this.timeouts.set(unregisterToken.cleanupToken, timeout2);
  }
  unregister(unregisterToken) {
    const timeout2 = this.timeouts.get(unregisterToken.cleanupToken);
    if (timeout2) {
      this.timeouts.delete(unregisterToken.cleanupToken);
      clearTimeout(timeout2);
    }
  }
  reset() {
    if (this.timeouts) {
      this.timeouts.forEach((value, key) => {
        this.unregister({
          cleanupToken: key
        });
      });
      this.timeouts = void 0;
    }
  }
}
class FinalizationRegistryBasedCleanupTracking {
  constructor() {
    this.registry = new FinalizationRegistry((unsubscribe) => {
      if (typeof unsubscribe === "function") {
        unsubscribe();
      }
    });
  }
  register(object, unsubscribe, unregisterToken) {
    this.registry.register(object, unsubscribe, unregisterToken);
  }
  unregister(unregisterToken) {
    this.registry.unregister(unregisterToken);
  }
  // eslint-disable-next-line class-methods-use-this
  reset() {
  }
}
var GridSignature = /* @__PURE__ */ function(GridSignature2) {
  GridSignature2["DataGrid"] = "DataGrid";
  GridSignature2["DataGridPro"] = "DataGridPro";
  return GridSignature2;
}(GridSignature || {});
class ObjectToBeRetainedByReact {
}
function createUseGridApiEventHandler(registryContainer2) {
  let cleanupTokensCounter = 0;
  return function useGridApiEventHandler2(apiRef2, eventName, handler, options) {
    if (registryContainer2.registry === null) {
      registryContainer2.registry = typeof FinalizationRegistry !== "undefined" ? new FinalizationRegistryBasedCleanupTracking() : new TimerBasedCleanupTracking();
    }
    const [objectRetainedByReact] = reactExports.useState(new ObjectToBeRetainedByReact());
    const subscription = reactExports.useRef(null);
    const handlerRef = reactExports.useRef();
    handlerRef.current = handler;
    const cleanupTokenRef = reactExports.useRef(null);
    if (!subscription.current && handlerRef.current) {
      const enhancedHandler = (params, event, details) => {
        if (!event.defaultMuiPrevented) {
          var _handlerRef$current;
          (_handlerRef$current = handlerRef.current) == null || _handlerRef$current.call(handlerRef, params, event, details);
        }
      };
      subscription.current = apiRef2.current.subscribeEvent(eventName, enhancedHandler, options);
      cleanupTokensCounter += 1;
      cleanupTokenRef.current = {
        cleanupToken: cleanupTokensCounter
      };
      registryContainer2.registry.register(
        objectRetainedByReact,
        // The callback below will be called once this reference stops being retained
        () => {
          var _subscription$current;
          (_subscription$current = subscription.current) == null || _subscription$current.call(subscription);
          subscription.current = null;
          cleanupTokenRef.current = null;
        },
        cleanupTokenRef.current
      );
    } else if (!handlerRef.current && subscription.current) {
      subscription.current();
      subscription.current = null;
      if (cleanupTokenRef.current) {
        registryContainer2.registry.unregister(cleanupTokenRef.current);
        cleanupTokenRef.current = null;
      }
    }
    reactExports.useEffect(() => {
      if (!subscription.current && handlerRef.current) {
        const enhancedHandler = (params, event, details) => {
          if (!event.defaultMuiPrevented) {
            var _handlerRef$current2;
            (_handlerRef$current2 = handlerRef.current) == null || _handlerRef$current2.call(handlerRef, params, event, details);
          }
        };
        subscription.current = apiRef2.current.subscribeEvent(eventName, enhancedHandler, options);
      }
      if (cleanupTokenRef.current && registryContainer2.registry) {
        registryContainer2.registry.unregister(cleanupTokenRef.current);
        cleanupTokenRef.current = null;
      }
      return () => {
        var _subscription$current2;
        (_subscription$current2 = subscription.current) == null || _subscription$current2.call(subscription);
        subscription.current = null;
      };
    }, [apiRef2, eventName, options]);
  };
}
const registryContainer = {
  registry: null
};
const useGridApiEventHandler = createUseGridApiEventHandler(registryContainer);
const optionsSubscriberOptions = {
  isFirst: true
};
function useGridApiOptionHandler(apiRef2, eventName, handler) {
  useGridApiEventHandler(apiRef2, eventName, handler, optionsSubscriberOptions);
}
function useGridLogger(privateApiRef, name) {
  const logger = reactExports.useRef(null);
  if (logger.current) {
    return logger.current;
  }
  const newLogger = privateApiRef.current.getLogger(name);
  logger.current = newLogger;
  return newLogger;
}
function isNumber(value) {
  return typeof value === "number";
}
function isFunction(value) {
  return typeof value === "function";
}
function isObject(value) {
  return typeof value === "object" && value !== null;
}
function localStorageAvailable() {
  try {
    const key = "__some_random_key_you_are_not_going_to_use__";
    window.localStorage.setItem(key, key);
    window.localStorage.removeItem(key);
    return true;
  } catch (err) {
    return false;
  }
}
function escapeRegExp(value) {
  return value.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
}
const clamp = (value, min2, max2) => Math.max(min2, Math.min(max2, value));
function isDeepEqual(a2, b) {
  if (a2 === b) {
    return true;
  }
  if (a2 && b && typeof a2 === "object" && typeof b === "object") {
    if (a2.constructor !== b.constructor) {
      return false;
    }
    if (Array.isArray(a2)) {
      const length2 = a2.length;
      if (length2 !== b.length) {
        return false;
      }
      for (let i2 = 0; i2 < length2; i2 += 1) {
        if (!isDeepEqual(a2[i2], b[i2])) {
          return false;
        }
      }
      return true;
    }
    if (a2 instanceof Map && b instanceof Map) {
      if (a2.size !== b.size) {
        return false;
      }
      const entriesA = Array.from(a2.entries());
      for (let i2 = 0; i2 < entriesA.length; i2 += 1) {
        if (!b.has(entriesA[i2][0])) {
          return false;
        }
      }
      for (let i2 = 0; i2 < entriesA.length; i2 += 1) {
        const entryA = entriesA[i2];
        if (!isDeepEqual(entryA[1], b.get(entryA[0]))) {
          return false;
        }
      }
      return true;
    }
    if (a2 instanceof Set && b instanceof Set) {
      if (a2.size !== b.size) {
        return false;
      }
      const entries = Array.from(a2.entries());
      for (let i2 = 0; i2 < entries.length; i2 += 1) {
        if (!b.has(entries[i2][0])) {
          return false;
        }
      }
      return true;
    }
    if (ArrayBuffer.isView(a2) && ArrayBuffer.isView(b)) {
      const length2 = a2.length;
      if (length2 !== b.length) {
        return false;
      }
      for (let i2 = 0; i2 < length2; i2 += 1) {
        if (a2[i2] !== b[i2]) {
          return false;
        }
      }
      return true;
    }
    if (a2.constructor === RegExp) {
      return a2.source === b.source && a2.flags === b.flags;
    }
    if (a2.valueOf !== Object.prototype.valueOf) {
      return a2.valueOf() === b.valueOf();
    }
    if (a2.toString !== Object.prototype.toString) {
      return a2.toString() === b.toString();
    }
    const keys = Object.keys(a2);
    const length = keys.length;
    if (length !== Object.keys(b).length) {
      return false;
    }
    for (let i2 = 0; i2 < length; i2 += 1) {
      if (!Object.prototype.hasOwnProperty.call(b, keys[i2])) {
        return false;
      }
    }
    for (let i2 = 0; i2 < length; i2 += 1) {
      const key = keys[i2];
      if (!isDeepEqual(a2[key], b[key])) {
        return false;
      }
    }
    return true;
  }
  return a2 !== a2 && b !== b;
}
function mulberry32(a2) {
  return () => {
    let t2 = a2 += 1831565813;
    t2 = Math.imul(t2 ^ t2 >>> 15, t2 | 1);
    t2 ^= t2 + Math.imul(t2 ^ t2 >>> 7, t2 | 61);
    return ((t2 ^ t2 >>> 14) >>> 0) / 4294967296;
  };
}
function randomNumberBetween(seed, min2, max2) {
  const random = mulberry32(seed);
  return () => min2 + (max2 - min2) * random();
}
function deepClone(obj) {
  if (typeof structuredClone === "function") {
    return structuredClone(obj);
  }
  return JSON.parse(JSON.stringify(obj));
}
const useGridNativeEventListener = (apiRef2, ref, eventName, handler, options) => {
  const logger = useGridLogger(apiRef2, "useNativeEventListener");
  const [added, setAdded] = reactExports.useState(false);
  const handlerRef = reactExports.useRef(handler);
  const wrapHandler = reactExports.useCallback((event) => {
    return handlerRef.current && handlerRef.current(event);
  }, []);
  reactExports.useEffect(() => {
    handlerRef.current = handler;
  }, [handler]);
  reactExports.useEffect(() => {
    let targetElement;
    if (isFunction(ref)) {
      targetElement = ref();
    } else {
      targetElement = ref && ref.current ? ref.current : null;
    }
    if (targetElement && eventName && !added) {
      logger.debug(`Binding native ${eventName} event`);
      targetElement.addEventListener(eventName, wrapHandler, options);
      const boundElem = targetElement;
      setAdded(true);
      const unsubscribe = () => {
        logger.debug(`Clearing native ${eventName} event`);
        boundElem.removeEventListener(eventName, wrapHandler, options);
      };
      apiRef2.current.subscribeEvent("unmount", unsubscribe);
    }
  }, [ref, wrapHandler, eventName, added, logger, options, apiRef2]);
};
const useFirstRender = (callback) => {
  const isFirstRender = reactExports.useRef(true);
  if (isFirstRender.current) {
    isFirstRender.current = false;
    callback();
  }
};
const MAX_PAGE_SIZE = 100;
const defaultPageSize = (autoPageSize) => autoPageSize ? 0 : 100;
const getPageCount = (rowCount, pageSize2) => {
  if (pageSize2 > 0 && rowCount > 0) {
    return Math.ceil(rowCount / pageSize2);
  }
  return 0;
};
buildWarning(["MUI: the 'rowCount' prop is undefined while using paginationMode='server'", "For more detail, see http://mui.com/components/data-grid/pagination/#basic-implementation"], "error");
const getDefaultGridPaginationModel = (autoPageSize) => ({
  page: 0,
  pageSize: autoPageSize ? 0 : 100
});
const getValidPage = (page, pageCount = 0) => {
  if (pageCount === 0) {
    return page;
  }
  return Math.max(Math.min(page, pageCount - 1), 0);
};
const throwIfPageSizeExceedsTheLimit = (pageSize2, signatureProp) => {
  if (signatureProp === GridSignature.DataGrid && pageSize2 > MAX_PAGE_SIZE) {
    throw new Error(["MUI: `pageSize` cannot exceed 100 in the MIT version of the DataGrid.", "You need to upgrade to DataGridPro or DataGridPremium component to unlock this feature."].join("\n"));
  }
};
const gridPaginationSelector = (state) => state.pagination;
const gridPaginationModelSelector = createSelector(gridPaginationSelector, (pagination) => pagination.paginationModel);
const gridPageSelector = createSelector(gridPaginationModelSelector, (paginationModel) => paginationModel.page);
const gridPageSizeSelector = createSelector(gridPaginationModelSelector, (paginationModel) => paginationModel.pageSize);
createSelector(gridPaginationModelSelector, gridFilteredTopLevelRowCountSelector, (paginationModel, visibleTopLevelRowCount) => getPageCount(visibleTopLevelRowCount, paginationModel.pageSize));
const gridPaginationRowRangeSelector = createSelectorMemoized(gridPaginationModelSelector, gridRowTreeSelector, gridRowMaximumTreeDepthSelector, gridExpandedSortedRowEntriesSelector, gridFilteredSortedTopLevelRowEntriesSelector, (paginationModel, rowTree, rowTreeDepth, visibleSortedRowEntries, visibleSortedTopLevelRowEntries) => {
  const visibleTopLevelRowCount = visibleSortedTopLevelRowEntries.length;
  const topLevelFirstRowIndex = Math.min(paginationModel.pageSize * paginationModel.page, visibleTopLevelRowCount - 1);
  const topLevelLastRowIndex = Math.min(topLevelFirstRowIndex + paginationModel.pageSize - 1, visibleTopLevelRowCount - 1);
  if (topLevelFirstRowIndex === -1 || topLevelLastRowIndex === -1) {
    return null;
  }
  if (rowTreeDepth < 2) {
    return {
      firstRowIndex: topLevelFirstRowIndex,
      lastRowIndex: topLevelLastRowIndex
    };
  }
  const topLevelFirstRow = visibleSortedTopLevelRowEntries[topLevelFirstRowIndex];
  const topLevelRowsInCurrentPageCount = topLevelLastRowIndex - topLevelFirstRowIndex + 1;
  const firstRowIndex = visibleSortedRowEntries.findIndex((row) => row.id === topLevelFirstRow.id);
  let lastRowIndex = firstRowIndex;
  let topLevelRowAdded = 0;
  while (lastRowIndex < visibleSortedRowEntries.length && topLevelRowAdded <= topLevelRowsInCurrentPageCount) {
    var _rowTree$row$id;
    const row = visibleSortedRowEntries[lastRowIndex];
    const depth = (_rowTree$row$id = rowTree[row.id]) == null ? void 0 : _rowTree$row$id.depth;
    if (depth === void 0) {
      lastRowIndex += 1;
    } else {
      if (topLevelRowAdded < topLevelRowsInCurrentPageCount || depth > 0) {
        lastRowIndex += 1;
      }
      if (depth === 0) {
        topLevelRowAdded += 1;
      }
    }
  }
  return {
    firstRowIndex,
    lastRowIndex: lastRowIndex - 1
  };
});
const gridPaginatedVisibleSortedGridRowEntriesSelector = createSelectorMemoized(gridExpandedSortedRowEntriesSelector, gridPaginationRowRangeSelector, (visibleSortedRowEntries, paginationRange) => {
  if (!paginationRange) {
    return [];
  }
  return visibleSortedRowEntries.slice(paginationRange.firstRowIndex, paginationRange.lastRowIndex + 1);
});
const gridPaginatedVisibleSortedGridRowIdsSelector = createSelectorMemoized(gridExpandedSortedRowIdsSelector, gridPaginationRowRangeSelector, (visibleSortedRowIds, paginationRange) => {
  if (!paginationRange) {
    return [];
  }
  return visibleSortedRowIds.slice(paginationRange.firstRowIndex, paginationRange.lastRowIndex + 1);
});
const gridPreferencePanelStateSelector = (state) => state.preferencePanel;
var GridPreferencePanelsValue = /* @__PURE__ */ function(GridPreferencePanelsValue2) {
  GridPreferencePanelsValue2["filters"] = "filters";
  GridPreferencePanelsValue2["columns"] = "columns";
  return GridPreferencePanelsValue2;
}(GridPreferencePanelsValue || {});
const gridRowsMetaSelector = (state) => state.rowsMeta;
const gridRowSelectionStateSelector = (state) => state.rowSelection;
const selectedGridRowsCountSelector = createSelector(gridRowSelectionStateSelector, (selection) => selection.length);
const selectedGridRowsSelector = createSelectorMemoized(gridRowSelectionStateSelector, gridRowsLookupSelector, (selectedRows, rowsLookup) => new Map(selectedRows.map((id) => [id, rowsLookup[id]])));
const selectedIdsLookupSelector = createSelectorMemoized(gridRowSelectionStateSelector, (selection) => selection.reduce((lookup, rowId) => {
  lookup[rowId] = rowId;
  return lookup;
}, {}));
const sortModelDisableMultiColumnsSortingWarning = buildWarning(["MUI: The `sortModel` can only contain a single item when the `disableMultipleColumnsSorting` prop is set to `true`.", "If you are using the community version of the `DataGrid`, this prop is always `true`."], "error");
const sanitizeSortModel = (model, disableMultipleColumnsSorting) => {
  if (disableMultipleColumnsSorting && model.length > 1) {
    sortModelDisableMultiColumnsSortingWarning();
    return [model[0]];
  }
  return model;
};
const mergeStateWithSortModel = (sortModel, disableMultipleColumnsSorting) => (state) => _extends$1({}, state, {
  sorting: _extends$1({}, state.sorting, {
    sortModel: sanitizeSortModel(sortModel, disableMultipleColumnsSorting)
  })
});
const isDesc = (direction2) => direction2 === "desc";
const parseSortItem = (sortItem, apiRef2) => {
  const column = apiRef2.current.getColumn(sortItem.field);
  if (!column) {
    return null;
  }
  const comparator = isDesc(sortItem.sort) ? (...args) => -1 * column.sortComparator(...args) : column.sortComparator;
  const getSortCellParams = (id) => ({
    id,
    field: column.field,
    rowNode: apiRef2.current.getRowNode(id),
    value: apiRef2.current.getCellValue(id, column.field),
    api: apiRef2.current
  });
  return {
    getSortCellParams,
    comparator
  };
};
const compareRows = (parsedSortItems, row1, row2) => {
  return parsedSortItems.reduce((res, item, index) => {
    if (res !== 0) {
      return res;
    }
    const sortCellParams1 = row1.params[index];
    const sortCellParams2 = row2.params[index];
    res = item.comparator(sortCellParams1.value, sortCellParams2.value, sortCellParams1, sortCellParams2);
    return res;
  }, 0);
};
const buildAggregatedSortingApplier = (sortModel, apiRef2) => {
  const comparatorList = sortModel.map((item) => parseSortItem(item, apiRef2)).filter((comparator) => !!comparator);
  if (comparatorList.length === 0) {
    return null;
  }
  return (rowList) => rowList.map((node) => ({
    node,
    params: comparatorList.map((el) => el.getSortCellParams(node.id))
  })).sort((a2, b) => compareRows(comparatorList, a2, b)).map((row) => row.node.id);
};
const getNextGridSortDirection = (sortingOrder, current) => {
  const currentIdx = sortingOrder.indexOf(current);
  if (!current || currentIdx === -1 || currentIdx + 1 === sortingOrder.length) {
    return sortingOrder[0];
  }
  return sortingOrder[currentIdx + 1];
};
const gridNillComparator = (v1, v2) => {
  if (v1 == null && v2 != null) {
    return -1;
  }
  if (v2 == null && v1 != null) {
    return 1;
  }
  if (v1 == null && v2 == null) {
    return 0;
  }
  return null;
};
const collator$2 = new Intl.Collator();
const gridStringOrNumberComparator = (value1, value2) => {
  const nillResult = gridNillComparator(value1, value2);
  if (nillResult !== null) {
    return nillResult;
  }
  if (typeof value1 === "string") {
    return collator$2.compare(value1.toString(), value2.toString());
  }
  return value1 - value2;
};
const gridNumberComparator = (value1, value2) => {
  const nillResult = gridNillComparator(value1, value2);
  if (nillResult !== null) {
    return nillResult;
  }
  return Number(value1) - Number(value2);
};
const gridDateComparator = (value1, value2) => {
  const nillResult = gridNillComparator(value1, value2);
  if (nillResult !== null) {
    return nillResult;
  }
  if (value1 > value2) {
    return 1;
  }
  if (value1 < value2) {
    return -1;
  }
  return 0;
};
const unstable_gridHeaderFilteringStateSelector = (state) => state.headerFiltering;
const unstable_gridHeaderFilteringEditFieldSelector = createSelector(unstable_gridHeaderFilteringStateSelector, (headerFilteringState) => headerFilteringState.editing);
const unstable_gridHeaderFilteringMenuSelector = createSelector(unstable_gridHeaderFilteringStateSelector, (headerFilteringState) => headerFilteringState.menuOpen);
const useUtilityClasses$w = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    icon: ["filterIcon"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
function GridColumnHeaderFilterIconButton(props) {
  var _rootProps$slotProps, _rootProps$slotProps2;
  const {
    counter,
    field,
    onClick
  } = props;
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const ownerState = _extends$1({}, props, {
    classes: rootProps.classes
  });
  const classes2 = useUtilityClasses$w(ownerState);
  const preferencePanel = useGridSelector(apiRef2, gridPreferencePanelStateSelector);
  const labelId = useId();
  const panelId = useId();
  const toggleFilter = reactExports.useCallback((event) => {
    event.preventDefault();
    event.stopPropagation();
    const {
      open: open2,
      openedPanelValue
    } = gridPreferencePanelStateSelector(apiRef2.current.state);
    if (open2 && openedPanelValue === GridPreferencePanelsValue.filters) {
      apiRef2.current.hideFilterPanel();
    } else {
      apiRef2.current.showFilterPanel(void 0, panelId, labelId);
    }
    if (onClick) {
      onClick(apiRef2.current.getColumnHeaderParams(field), event);
    }
  }, [apiRef2, field, onClick, panelId, labelId]);
  if (!counter) {
    return null;
  }
  const open = preferencePanel.open && preferencePanel.labelId === labelId;
  const iconButton = /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseIconButton, _extends$1({
    id: labelId,
    onClick: toggleFilter,
    color: "default",
    "aria-label": apiRef2.current.getLocaleText("columnHeaderFiltersLabel"),
    size: "small",
    tabIndex: -1,
    "aria-haspopup": "menu",
    "aria-expanded": open,
    "aria-controls": open ? panelId : void 0
  }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseIconButton, {
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.columnFilteredIcon, {
      className: classes2.icon,
      fontSize: "small"
    })
  }));
  return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseTooltip, _extends$1({
    title: apiRef2.current.getLocaleText("columnHeaderFiltersTooltipActive")(counter),
    enterDelay: 1e3
  }, (_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.baseTooltip, {
    children: /* @__PURE__ */ jsxRuntimeExports.jsxs(GridIconButtonContainer, {
      children: [counter > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge$1, {
        badgeContent: counter,
        color: "default",
        children: iconButton
      }), counter === 1 && iconButton]
    })
  }));
}
const _excluded$N = ["field", "id", "value", "formattedValue", "row", "rowNode", "colDef", "isEditable", "cellMode", "hasFocus", "tabIndex", "api"];
const useUtilityClasses$v = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["checkboxInput"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridCellCheckboxForwardRef = /* @__PURE__ */ reactExports.forwardRef(function GridCellCheckboxRenderer2(props, ref) {
  var _rootProps$slotProps;
  const {
    field,
    id,
    value: isChecked,
    rowNode,
    hasFocus,
    tabIndex
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$N);
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const ownerState = {
    classes: rootProps.classes
  };
  const classes2 = useUtilityClasses$v(ownerState);
  const checkboxElement = reactExports.useRef(null);
  const rippleRef = reactExports.useRef(null);
  const handleRef = useForkRef$1(checkboxElement, ref);
  const element = apiRef2.current.getCellElement(id, field);
  const handleChange = (event) => {
    const params = {
      value: event.target.checked,
      id
    };
    apiRef2.current.publishEvent("rowSelectionCheckboxChange", params, event);
  };
  reactExports.useLayoutEffect(() => {
    if (tabIndex === 0 && element) {
      element.tabIndex = -1;
    }
  }, [element, tabIndex]);
  reactExports.useEffect(() => {
    if (hasFocus) {
      var _checkboxElement$curr;
      const input = (_checkboxElement$curr = checkboxElement.current) == null ? void 0 : _checkboxElement$curr.querySelector("input");
      input == null || input.focus({
        preventScroll: true
      });
    } else if (rippleRef.current) {
      rippleRef.current.stop({});
    }
  }, [hasFocus]);
  const handleKeyDown = reactExports.useCallback((event) => {
    if (isSpaceKey(event.key)) {
      event.stopPropagation();
    }
  }, []);
  if (rowNode.type === "footer" || rowNode.type === "pinnedRow") {
    return null;
  }
  const isSelectable = apiRef2.current.isRowSelectable(id);
  const label = apiRef2.current.getLocaleText(isChecked ? "checkboxSelectionUnselectRow" : "checkboxSelectionSelectRow");
  return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseCheckbox, _extends$1({
    ref: handleRef,
    tabIndex,
    checked: isChecked,
    onChange: handleChange,
    className: classes2.root,
    inputProps: {
      "aria-label": label
    },
    onKeyDown: handleKeyDown,
    disabled: !isSelectable,
    touchRippleRef: rippleRef
  }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseCheckbox, other));
});
const GridCellCheckboxRenderer = GridCellCheckboxForwardRef;
const _excluded$M = ["field", "colDef"];
const useUtilityClasses$u = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["checkboxInput"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridHeaderCheckbox = /* @__PURE__ */ reactExports.forwardRef(function GridHeaderCheckbox2(props, ref) {
  var _rootProps$slotProps;
  const other = _objectWithoutPropertiesLoose$1(props, _excluded$M);
  const [, forceUpdate] = reactExports.useState(false);
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const ownerState = {
    classes: rootProps.classes
  };
  const classes2 = useUtilityClasses$u(ownerState);
  const tabIndexState = useGridSelector(apiRef2, gridTabIndexColumnHeaderSelector);
  const selection = useGridSelector(apiRef2, gridRowSelectionStateSelector);
  const visibleRowIds = useGridSelector(apiRef2, gridExpandedSortedRowIdsSelector);
  const paginatedVisibleRowIds = useGridSelector(apiRef2, gridPaginatedVisibleSortedGridRowIdsSelector);
  const filteredSelection = reactExports.useMemo(() => {
    if (typeof rootProps.isRowSelectable !== "function") {
      return selection;
    }
    return selection.filter((id) => {
      if (!apiRef2.current.getRow(id)) {
        return false;
      }
      return rootProps.isRowSelectable(apiRef2.current.getRowParams(id));
    });
  }, [apiRef2, rootProps.isRowSelectable, selection]);
  const selectionCandidates = reactExports.useMemo(() => {
    const rowIds = !rootProps.pagination || !rootProps.checkboxSelectionVisibleOnly ? visibleRowIds : paginatedVisibleRowIds;
    return rowIds.reduce((acc, id) => {
      acc[id] = true;
      return acc;
    }, {});
  }, [rootProps.pagination, rootProps.checkboxSelectionVisibleOnly, paginatedVisibleRowIds, visibleRowIds]);
  const currentSelectionSize = reactExports.useMemo(() => filteredSelection.filter((id) => selectionCandidates[id]).length, [filteredSelection, selectionCandidates]);
  const isIndeterminate = currentSelectionSize > 0 && currentSelectionSize < Object.keys(selectionCandidates).length;
  const isChecked = currentSelectionSize > 0;
  const handleChange = (event) => {
    const params = {
      value: event.target.checked
    };
    apiRef2.current.publishEvent("headerSelectionCheckboxChange", params);
  };
  const tabIndex = tabIndexState !== null && tabIndexState.field === props.field ? 0 : -1;
  reactExports.useLayoutEffect(() => {
    const element = apiRef2.current.getColumnHeaderElement(props.field);
    if (tabIndex === 0 && element) {
      element.tabIndex = -1;
    }
  }, [tabIndex, apiRef2, props.field]);
  const handleKeyDown = reactExports.useCallback((event) => {
    if (event.key === " ") {
      apiRef2.current.publishEvent("headerSelectionCheckboxChange", {
        value: !isChecked
      });
    }
  }, [apiRef2, isChecked]);
  const handleSelectionChange = reactExports.useCallback(() => {
    forceUpdate((p2) => !p2);
  }, []);
  reactExports.useEffect(() => {
    return apiRef2.current.subscribeEvent("rowSelectionChange", handleSelectionChange);
  }, [apiRef2, handleSelectionChange]);
  const label = apiRef2.current.getLocaleText(isChecked ? "checkboxSelectionUnselectAllRows" : "checkboxSelectionSelectAllRows");
  return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseCheckbox, _extends$1({
    ref,
    indeterminate: isIndeterminate,
    checked: isChecked,
    onChange: handleChange,
    className: classes2.root,
    inputProps: {
      "aria-label": label
    },
    tabIndex,
    onKeyDown: handleKeyDown
  }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseCheckbox, other));
});
const GridArrowUpwardIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"
}), "ArrowUpward");
const GridArrowDownwardIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M20 12l-1.41-1.41L13 16.17V4h-2v12.17l-5.58-5.59L4 12l8 8 8-8z"
}), "ArrowDownward");
const GridKeyboardArrowRight = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M8.59 16.59 13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"
}), "KeyboardArrowRight");
const GridExpandMoreIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M16.59 8.59 12 13.17 7.41 8.59 6 10l6 6 6-6z"
}), "ExpandMore");
const GridFilterListIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z"
}), "FilterList");
const GridFilterAltIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M4.25 5.61C6.27 8.2 10 13 10 13v6c0 .55.45 1 1 1h2c.55 0 1-.45 1-1v-6s3.72-4.8 5.74-7.39c.51-.66.04-1.61-.79-1.61H5.04c-.83 0-1.3.95-.79 1.61z"
}), "FilterAlt");
const GridSearchIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"
}), "Search");
createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"
}), "Menu");
createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"
}), "CheckCircle");
const GridColumnIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M6 5H3c-.55 0-1 .45-1 1v12c0 .55.45 1 1 1h3c.55 0 1-.45 1-1V6c0-.55-.45-1-1-1zm14 0h-3c-.55 0-1 .45-1 1v12c0 .55.45 1 1 1h3c.55 0 1-.45 1-1V6c0-.55-.45-1-1-1zm-7 0h-3c-.55 0-1 .45-1 1v12c0 .55.45 1 1 1h3c.55 0 1-.45 1-1V6c0-.55-.45-1-1-1z"
}), "ColumnIcon");
const GridSeparatorIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M11 19V5h2v14z"
}), "Separator");
const GridViewHeadlineIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M4 15h16v-2H4v2zm0 4h16v-2H4v2zm0-8h16V9H4v2zm0-6v2h16V5H4z"
}), "ViewHeadline");
const GridTableRowsIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M21,8H3V4h18V8z M21,10H3v4h18V10z M21,16H3v4h18V16z"
}), "TableRows");
const GridViewStreamIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M4 18h17v-6H4v6zM4 5v6h17V5H4z"
}), "ViewStream");
const GridTripleDotsVerticalIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"
}), "TripleDotsVertical");
const GridCloseIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
}), "Close");
const GridAddIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"
}), "Add");
const GridRemoveIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M19 13H5v-2h14v2z"
}), "Remove");
const GridLoadIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"
}), "Load");
const GridDragIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M11 18c0 1.1-.9 2-2 2s-2-.9-2-2 .9-2 2-2 2 .9 2 2zm-2-8c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm6 4c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"
}), "Drag");
const GridSaveAltIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M19 12v7H5v-7H3v7c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-7h-2zm-6 .67l2.59-2.58L17 11.5l-5 5-5-5 1.41-1.41L11 12.67V3h2z"
}), "SaveAlt");
const GridCheckIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"
}), "Check");
const GridMoreVertIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"
}), "MoreVert");
const GridVisibilityOffIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"
}), "VisibilityOff");
const GridViewColumnIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("g", {
  children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", {
    d: "M14.67,5v14H9.33V5H14.67z M15.67,19H21V5h-5.33V19z M8.33,19V5H3v14H8.33z"
  })
}), "ViewColumn");
const GridClearIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
}), "Clear");
createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"
}), "Delete");
const GridDeleteForeverIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zm2.46-7.12l1.41-1.41L12 12.59l2.12-2.12 1.41 1.41L13.41 14l2.12 2.12-1.41 1.41L12 15.41l-2.12 2.12-1.41-1.41L10.59 14l-2.13-2.12zM15.5 4l-1-1h-5l-1 1H5v2h14V4z"
}), "Delete");
const _excluded$L = ["hideMenu", "colDef", "id", "labelledby", "className", "children", "open"];
const StyledMenuList = styled$1(MenuList)(() => ({
  minWidth: 248
}));
const GridColumnMenuContainer = /* @__PURE__ */ reactExports.forwardRef(function GridColumnMenuContainer2(props, ref) {
  const {
    hideMenu,
    id,
    labelledby,
    className,
    children,
    open
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$L);
  const handleListKeyDown = reactExports.useCallback((event) => {
    if (isTabKey(event.key)) {
      event.preventDefault();
    }
    if (isHideMenuKey(event.key)) {
      hideMenu(event);
    }
  }, [hideMenu]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(StyledMenuList, _extends$1({
    id,
    ref,
    className: clsx$1(gridClasses.menuList, className),
    "aria-labelledby": labelledby,
    onKeyDown: handleListKeyDown,
    autoFocus: open
  }, other, {
    children
  }));
});
const _excluded$K = ["displayOrder"];
const useGridColumnMenuSlots = (props) => {
  const apiRef2 = useGridPrivateApiContext();
  const {
    defaultSlots: defaultSlots2,
    defaultSlotProps,
    slots = {},
    slotProps = {},
    hideMenu,
    colDef,
    addDividers = true
  } = props;
  const processedComponents = reactExports.useMemo(() => _extends$1({}, defaultSlots2, slots), [defaultSlots2, slots]);
  const processedSlotProps = reactExports.useMemo(() => {
    if (!slotProps || Object.keys(slotProps).length === 0) {
      return defaultSlotProps;
    }
    const mergedProps = _extends$1({}, slotProps);
    Object.entries(defaultSlotProps).forEach(([key, currentSlotProps]) => {
      mergedProps[key] = _extends$1({}, currentSlotProps, slotProps[key] || {});
    });
    return mergedProps;
  }, [defaultSlotProps, slotProps]);
  const defaultItems = apiRef2.current.unstable_applyPipeProcessors("columnMenu", [], props.colDef);
  const userItems = reactExports.useMemo(() => {
    const defaultComponentKeys = Object.keys(defaultSlots2);
    return Object.keys(slots).filter((key) => !defaultComponentKeys.includes(key));
  }, [slots, defaultSlots2]);
  return reactExports.useMemo(() => {
    const uniqueItems = Array.from(/* @__PURE__ */ new Set([...defaultItems, ...userItems]));
    const cleansedItems = uniqueItems.filter((key) => processedComponents[key] != null);
    const sorted = cleansedItems.sort((a2, b) => {
      const leftItemProps = processedSlotProps[a2];
      const rightItemProps = processedSlotProps[b];
      const leftDisplayOrder = Number.isFinite(leftItemProps == null ? void 0 : leftItemProps.displayOrder) ? leftItemProps.displayOrder : 100;
      const rightDisplayOrder = Number.isFinite(rightItemProps == null ? void 0 : rightItemProps.displayOrder) ? rightItemProps.displayOrder : 100;
      return leftDisplayOrder - rightDisplayOrder;
    });
    return sorted.reduce((acc, key, index) => {
      let itemProps = {
        colDef,
        onClick: hideMenu
      };
      const processedComponentProps = processedSlotProps[key];
      if (processedComponentProps) {
        const customProps = _objectWithoutPropertiesLoose$1(processedComponentProps, _excluded$K);
        itemProps = _extends$1({}, itemProps, customProps);
      }
      return addDividers && index !== sorted.length - 1 ? [...acc, [processedComponents[key], itemProps], [Divider$1, {}]] : [...acc, [processedComponents[key], itemProps]];
    }, []);
  }, [addDividers, colDef, defaultItems, hideMenu, processedComponents, processedSlotProps, userItems]);
};
function GridColumnMenuHideItem(props) {
  const {
    colDef,
    onClick
  } = props;
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const visibleColumns = gridVisibleColumnDefinitionsSelector(apiRef2);
  const columnsWithMenu = visibleColumns.filter((col) => col.disableColumnMenu !== true);
  const disabled = columnsWithMenu.length === 1;
  const toggleColumn = reactExports.useCallback((event) => {
    if (disabled) {
      return;
    }
    apiRef2.current.setColumnVisibility(colDef.field, false);
    onClick(event);
  }, [apiRef2, colDef.field, onClick, disabled]);
  if (rootProps.disableColumnSelector) {
    return null;
  }
  if (colDef.hideable === false) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(MUIMenuItem, {
    onClick: toggleColumn,
    disabled,
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(ListItemIcon$1, {
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.columnMenuHideIcon, {
        fontSize: "small"
      })
    }), /* @__PURE__ */ jsxRuntimeExports.jsx(ListItemText$1, {
      children: apiRef2.current.getLocaleText("columnMenuHideColumn")
    })]
  });
}
function GridColumnMenuManageItem(props) {
  const {
    onClick
  } = props;
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const showColumns = reactExports.useCallback((event) => {
    onClick(event);
    apiRef2.current.showPreferences(GridPreferencePanelsValue.columns);
  }, [apiRef2, onClick]);
  if (rootProps.disableColumnSelector) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(MUIMenuItem, {
    onClick: showColumns,
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(ListItemIcon$1, {
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.columnMenuManageColumnsIcon, {
        fontSize: "small"
      })
    }), /* @__PURE__ */ jsxRuntimeExports.jsx(ListItemText$1, {
      children: apiRef2.current.getLocaleText("columnMenuManageColumns")
    })]
  });
}
function GridColumnMenuColumnsItem(props) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnMenuHideItem, _extends$1({}, props)), /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnMenuManageItem, _extends$1({}, props))]
  });
}
function GridColumnMenuFilterItem(props) {
  const {
    colDef,
    onClick
  } = props;
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const showFilter = reactExports.useCallback((event) => {
    onClick(event);
    apiRef2.current.showFilterPanel(colDef.field);
  }, [apiRef2, colDef.field, onClick]);
  if (rootProps.disableColumnFilter || !colDef.filterable) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(MUIMenuItem, {
    onClick: showFilter,
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(ListItemIcon$1, {
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.columnMenuFilterIcon, {
        fontSize: "small"
      })
    }), /* @__PURE__ */ jsxRuntimeExports.jsx(ListItemText$1, {
      children: apiRef2.current.getLocaleText("columnMenuFilter")
    })]
  });
}
function GridColumnMenuSortItem(props) {
  var _colDef$sortingOrder;
  const {
    colDef,
    onClick
  } = props;
  const apiRef2 = useGridApiContext();
  const sortModel = useGridSelector(apiRef2, gridSortModelSelector);
  const rootProps = useGridRootProps();
  const sortDirection = reactExports.useMemo(() => {
    if (!colDef) {
      return null;
    }
    const sortItem = sortModel.find((item) => item.field === colDef.field);
    return sortItem == null ? void 0 : sortItem.sort;
  }, [colDef, sortModel]);
  const sortingOrder = (_colDef$sortingOrder = colDef.sortingOrder) != null ? _colDef$sortingOrder : rootProps.sortingOrder;
  const onSortMenuItemClick = reactExports.useCallback((event) => {
    onClick(event);
    const direction2 = event.currentTarget.getAttribute("data-value") || null;
    apiRef2.current.sortColumn(colDef, direction2 === sortDirection ? null : direction2);
  }, [apiRef2, colDef, onClick, sortDirection]);
  if (!colDef || !colDef.sortable || !sortingOrder.some((item) => !!item)) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, {
    children: [sortingOrder.includes("asc") && sortDirection !== "asc" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(MUIMenuItem, {
      onClick: onSortMenuItemClick,
      "data-value": "asc",
      children: [/* @__PURE__ */ jsxRuntimeExports.jsx(ListItemIcon$1, {
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.columnMenuSortAscendingIcon, {
          fontSize: "small"
        })
      }), /* @__PURE__ */ jsxRuntimeExports.jsx(ListItemText$1, {
        children: apiRef2.current.getLocaleText("columnMenuSortAsc")
      })]
    }) : null, sortingOrder.includes("desc") && sortDirection !== "desc" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(MUIMenuItem, {
      onClick: onSortMenuItemClick,
      "data-value": "desc",
      children: [/* @__PURE__ */ jsxRuntimeExports.jsx(ListItemIcon$1, {
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.columnMenuSortDescendingIcon, {
          fontSize: "small"
        })
      }), /* @__PURE__ */ jsxRuntimeExports.jsx(ListItemText$1, {
        children: apiRef2.current.getLocaleText("columnMenuSortDesc")
      })]
    }) : null, sortingOrder.includes(null) && sortDirection != null ? /* @__PURE__ */ jsxRuntimeExports.jsxs(MUIMenuItem, {
      onClick: onSortMenuItemClick,
      children: [/* @__PURE__ */ jsxRuntimeExports.jsx(ListItemIcon$1, {}), /* @__PURE__ */ jsxRuntimeExports.jsx(ListItemText$1, {
        children: apiRef2.current.getLocaleText("columnMenuUnsort")
      })]
    }) : null]
  });
}
const _excluded$J = ["defaultSlots", "defaultSlotProps", "slots", "slotProps"];
const GRID_COLUMN_MENU_SLOTS = {
  columnMenuSortItem: GridColumnMenuSortItem,
  columnMenuFilterItem: GridColumnMenuFilterItem,
  columnMenuColumnsItem: GridColumnMenuColumnsItem
};
const GRID_COLUMN_MENU_SLOT_PROPS = {
  columnMenuSortItem: {
    displayOrder: 10
  },
  columnMenuFilterItem: {
    displayOrder: 20
  },
  columnMenuColumnsItem: {
    displayOrder: 30
  }
};
const GridGenericColumnMenu = /* @__PURE__ */ reactExports.forwardRef(function GridGenericColumnMenu2(props, ref) {
  const {
    defaultSlots: defaultSlots2,
    defaultSlotProps,
    slots,
    slotProps
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$J);
  const orderedSlots = useGridColumnMenuSlots(_extends$1({}, other, {
    defaultSlots: defaultSlots2,
    defaultSlotProps,
    slots,
    slotProps
  }));
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnMenuContainer, _extends$1({
    ref
  }, other, {
    children: orderedSlots.map(([Component, otherProps], index) => /* @__PURE__ */ jsxRuntimeExports.jsx(Component, _extends$1({}, otherProps), index))
  }));
});
const GridColumnMenu = /* @__PURE__ */ reactExports.forwardRef(function GridColumnMenu2(props, ref) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridGenericColumnMenu, _extends$1({}, props, {
    ref,
    defaultSlots: GRID_COLUMN_MENU_SLOTS,
    defaultSlotProps: GRID_COLUMN_MENU_SLOT_PROPS
  }));
});
function getIconButtonUtilityClass(slot) {
  return generateUtilityClass("MuiIconButton", slot);
}
const iconButtonClasses = generateUtilityClasses("MuiIconButton", ["root", "disabled", "colorInherit", "colorPrimary", "colorSecondary", "colorError", "colorInfo", "colorSuccess", "colorWarning", "edgeStart", "edgeEnd", "sizeSmall", "sizeMedium", "sizeLarge"]);
const iconButtonClasses$1 = iconButtonClasses;
const _excluded$I = ["edge", "children", "className", "color", "disabled", "disableFocusRipple", "size"];
const useUtilityClasses$t = (ownerState) => {
  const {
    classes: classes2,
    disabled,
    color,
    edge,
    size
  } = ownerState;
  const slots = {
    root: ["root", disabled && "disabled", color !== "default" && `color${capitalize(color)}`, edge && `edge${capitalize(edge)}`, `size${capitalize(size)}`]
  };
  return composeClasses(slots, getIconButtonUtilityClass, classes2);
};
const IconButtonRoot = styled$1(ButtonBase, {
  name: "MuiIconButton",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, ownerState.color !== "default" && styles2[`color${capitalize(ownerState.color)}`], ownerState.edge && styles2[`edge${capitalize(ownerState.edge)}`], styles2[`size${capitalize(ownerState.size)}`]];
  }
})(({
  theme,
  ownerState
}) => _extends$1({
  textAlign: "center",
  flex: "0 0 auto",
  fontSize: theme.typography.pxToRem(24),
  padding: 8,
  borderRadius: "50%",
  overflow: "visible",
  // Explicitly set the default value to solve a bug on IE11.
  color: (theme.vars || theme).palette.action.active,
  transition: theme.transitions.create("background-color", {
    duration: theme.transitions.duration.shortest
  })
}, !ownerState.disableRipple && {
  "&:hover": {
    backgroundColor: theme.vars ? `rgba(${theme.vars.palette.action.activeChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(theme.palette.action.active, theme.palette.action.hoverOpacity),
    // Reset on touch devices, it doesn't add specificity
    "@media (hover: none)": {
      backgroundColor: "transparent"
    }
  }
}, ownerState.edge === "start" && {
  marginLeft: ownerState.size === "small" ? -3 : -12
}, ownerState.edge === "end" && {
  marginRight: ownerState.size === "small" ? -3 : -12
}), ({
  theme,
  ownerState
}) => {
  var _palette;
  const palette = (_palette = (theme.vars || theme).palette) == null ? void 0 : _palette[ownerState.color];
  return _extends$1({}, ownerState.color === "inherit" && {
    color: "inherit"
  }, ownerState.color !== "inherit" && ownerState.color !== "default" && _extends$1({
    color: palette == null ? void 0 : palette.main
  }, !ownerState.disableRipple && {
    "&:hover": _extends$1({}, palette && {
      backgroundColor: theme.vars ? `rgba(${palette.mainChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(palette.main, theme.palette.action.hoverOpacity)
    }, {
      // Reset on touch devices, it doesn't add specificity
      "@media (hover: none)": {
        backgroundColor: "transparent"
      }
    })
  }), ownerState.size === "small" && {
    padding: 5,
    fontSize: theme.typography.pxToRem(18)
  }, ownerState.size === "large" && {
    padding: 12,
    fontSize: theme.typography.pxToRem(28)
  }, {
    [`&.${iconButtonClasses$1.disabled}`]: {
      backgroundColor: "transparent",
      color: (theme.vars || theme).palette.action.disabled
    }
  });
});
const IconButton = /* @__PURE__ */ reactExports.forwardRef(function IconButton2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiIconButton"
  });
  const {
    edge = false,
    children,
    className,
    color = "default",
    disabled = false,
    disableFocusRipple = false,
    size = "medium"
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$I);
  const ownerState = _extends$1({}, props, {
    edge,
    color,
    disabled,
    disableFocusRipple,
    size
  });
  const classes2 = useUtilityClasses$t(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(IconButtonRoot, _extends$1({
    className: clsx$1(classes2.root, className),
    centerRipple: true,
    focusRipple: !disableFocusRipple,
    disabled,
    ref,
    ownerState
  }, other, {
    children
  }));
});
const IconButton$1 = IconButton;
function getSwitchBaseUtilityClass(slot) {
  return generateUtilityClass("PrivateSwitchBase", slot);
}
generateUtilityClasses("PrivateSwitchBase", ["root", "checked", "disabled", "input", "edgeStart", "edgeEnd"]);
const _excluded$H = ["autoFocus", "checked", "checkedIcon", "className", "defaultChecked", "disabled", "disableFocusRipple", "edge", "icon", "id", "inputProps", "inputRef", "name", "onBlur", "onChange", "onFocus", "readOnly", "required", "tabIndex", "type", "value"];
const useUtilityClasses$s = (ownerState) => {
  const {
    classes: classes2,
    checked,
    disabled,
    edge
  } = ownerState;
  const slots = {
    root: ["root", checked && "checked", disabled && "disabled", edge && `edge${capitalize(edge)}`],
    input: ["input"]
  };
  return composeClasses(slots, getSwitchBaseUtilityClass, classes2);
};
const SwitchBaseRoot = styled$1(ButtonBase)(({
  ownerState
}) => _extends$1({
  padding: 9,
  borderRadius: "50%"
}, ownerState.edge === "start" && {
  marginLeft: ownerState.size === "small" ? -3 : -12
}, ownerState.edge === "end" && {
  marginRight: ownerState.size === "small" ? -3 : -12
}));
const SwitchBaseInput = styled$1("input")({
  cursor: "inherit",
  position: "absolute",
  opacity: 0,
  width: "100%",
  height: "100%",
  top: 0,
  left: 0,
  margin: 0,
  padding: 0,
  zIndex: 1
});
const SwitchBase = /* @__PURE__ */ reactExports.forwardRef(function SwitchBase2(props, ref) {
  const {
    autoFocus,
    checked: checkedProp,
    checkedIcon,
    className,
    defaultChecked,
    disabled: disabledProp,
    disableFocusRipple = false,
    edge = false,
    icon,
    id,
    inputProps,
    inputRef,
    name,
    onBlur,
    onChange,
    onFocus,
    readOnly,
    required = false,
    tabIndex,
    type,
    value
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$H);
  const [checked, setCheckedState] = useControlled({
    controlled: checkedProp,
    default: Boolean(defaultChecked),
    name: "SwitchBase",
    state: "checked"
  });
  const muiFormControl = useFormControl();
  const handleFocus = (event) => {
    if (onFocus) {
      onFocus(event);
    }
    if (muiFormControl && muiFormControl.onFocus) {
      muiFormControl.onFocus(event);
    }
  };
  const handleBlur = (event) => {
    if (onBlur) {
      onBlur(event);
    }
    if (muiFormControl && muiFormControl.onBlur) {
      muiFormControl.onBlur(event);
    }
  };
  const handleInputChange = (event) => {
    if (event.nativeEvent.defaultPrevented) {
      return;
    }
    const newChecked = event.target.checked;
    setCheckedState(newChecked);
    if (onChange) {
      onChange(event, newChecked);
    }
  };
  let disabled = disabledProp;
  if (muiFormControl) {
    if (typeof disabled === "undefined") {
      disabled = muiFormControl.disabled;
    }
  }
  const hasLabelFor = type === "checkbox" || type === "radio";
  const ownerState = _extends$1({}, props, {
    checked,
    disabled,
    disableFocusRipple,
    edge
  });
  const classes2 = useUtilityClasses$s(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SwitchBaseRoot, _extends$1({
    component: "span",
    className: clsx$1(classes2.root, className),
    centerRipple: true,
    focusRipple: !disableFocusRipple,
    disabled,
    tabIndex: null,
    role: void 0,
    onFocus: handleFocus,
    onBlur: handleBlur,
    ownerState,
    ref
  }, other, {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(SwitchBaseInput, _extends$1({
      autoFocus,
      checked: checkedProp,
      defaultChecked,
      className: classes2.input,
      disabled,
      id: hasLabelFor ? id : void 0,
      name,
      onChange: handleInputChange,
      readOnly,
      ref: inputRef,
      required,
      ownerState,
      tabIndex,
      type
    }, type === "checkbox" && value === void 0 ? {} : {
      value
    }, inputProps)), checked ? checkedIcon : icon]
  }));
});
const SwitchBase$1 = SwitchBase;
function getSwitchUtilityClass(slot) {
  return generateUtilityClass("MuiSwitch", slot);
}
const switchClasses = generateUtilityClasses("MuiSwitch", ["root", "edgeStart", "edgeEnd", "switchBase", "colorPrimary", "colorSecondary", "sizeSmall", "sizeMedium", "checked", "disabled", "input", "thumb", "track"]);
const switchClasses$1 = switchClasses;
const _excluded$G = ["className", "color", "edge", "size", "sx"];
const useUtilityClasses$r = (ownerState) => {
  const {
    classes: classes2,
    edge,
    size,
    color,
    checked,
    disabled
  } = ownerState;
  const slots = {
    root: ["root", edge && `edge${capitalize(edge)}`, `size${capitalize(size)}`],
    switchBase: ["switchBase", `color${capitalize(color)}`, checked && "checked", disabled && "disabled"],
    thumb: ["thumb"],
    track: ["track"],
    input: ["input"]
  };
  const composedClasses = composeClasses(slots, getSwitchUtilityClass, classes2);
  return _extends$1({}, classes2, composedClasses);
};
const SwitchRoot = styled$1("span", {
  name: "MuiSwitch",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, ownerState.edge && styles2[`edge${capitalize(ownerState.edge)}`], styles2[`size${capitalize(ownerState.size)}`]];
  }
})(({
  ownerState
}) => _extends$1({
  display: "inline-flex",
  width: 34 + 12 * 2,
  height: 14 + 12 * 2,
  overflow: "hidden",
  padding: 12,
  boxSizing: "border-box",
  position: "relative",
  flexShrink: 0,
  zIndex: 0,
  // Reset the stacking context.
  verticalAlign: "middle",
  // For correct alignment with the text.
  "@media print": {
    colorAdjust: "exact"
  }
}, ownerState.edge === "start" && {
  marginLeft: -8
}, ownerState.edge === "end" && {
  marginRight: -8
}, ownerState.size === "small" && {
  width: 40,
  height: 24,
  padding: 7,
  [`& .${switchClasses$1.thumb}`]: {
    width: 16,
    height: 16
  },
  [`& .${switchClasses$1.switchBase}`]: {
    padding: 4,
    [`&.${switchClasses$1.checked}`]: {
      transform: "translateX(16px)"
    }
  }
}));
const SwitchSwitchBase = styled$1(SwitchBase$1, {
  name: "MuiSwitch",
  slot: "SwitchBase",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.switchBase, {
      [`& .${switchClasses$1.input}`]: styles2.input
    }, ownerState.color !== "default" && styles2[`color${capitalize(ownerState.color)}`]];
  }
})(({
  theme
}) => ({
  position: "absolute",
  top: 0,
  left: 0,
  zIndex: 1,
  // Render above the focus ripple.
  color: theme.vars ? theme.vars.palette.Switch.defaultColor : `${theme.palette.mode === "light" ? theme.palette.common.white : theme.palette.grey[300]}`,
  transition: theme.transitions.create(["left", "transform"], {
    duration: theme.transitions.duration.shortest
  }),
  [`&.${switchClasses$1.checked}`]: {
    transform: "translateX(20px)"
  },
  [`&.${switchClasses$1.disabled}`]: {
    color: theme.vars ? theme.vars.palette.Switch.defaultDisabledColor : `${theme.palette.mode === "light" ? theme.palette.grey[100] : theme.palette.grey[600]}`
  },
  [`&.${switchClasses$1.checked} + .${switchClasses$1.track}`]: {
    opacity: 0.5
  },
  [`&.${switchClasses$1.disabled} + .${switchClasses$1.track}`]: {
    opacity: theme.vars ? theme.vars.opacity.switchTrackDisabled : `${theme.palette.mode === "light" ? 0.12 : 0.2}`
  },
  [`& .${switchClasses$1.input}`]: {
    left: "-100%",
    width: "300%"
  }
}), ({
  theme,
  ownerState
}) => _extends$1({
  "&:hover": {
    backgroundColor: theme.vars ? `rgba(${theme.vars.palette.action.activeChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(theme.palette.action.active, theme.palette.action.hoverOpacity),
    // Reset on touch devices, it doesn't add specificity
    "@media (hover: none)": {
      backgroundColor: "transparent"
    }
  }
}, ownerState.color !== "default" && {
  [`&.${switchClasses$1.checked}`]: {
    color: (theme.vars || theme).palette[ownerState.color].main,
    "&:hover": {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(theme.palette[ownerState.color].main, theme.palette.action.hoverOpacity),
      "@media (hover: none)": {
        backgroundColor: "transparent"
      }
    },
    [`&.${switchClasses$1.disabled}`]: {
      color: theme.vars ? theme.vars.palette.Switch[`${ownerState.color}DisabledColor`] : `${theme.palette.mode === "light" ? lighten(theme.palette[ownerState.color].main, 0.62) : darken(theme.palette[ownerState.color].main, 0.55)}`
    }
  },
  [`&.${switchClasses$1.checked} + .${switchClasses$1.track}`]: {
    backgroundColor: (theme.vars || theme).palette[ownerState.color].main
  }
}));
const SwitchTrack = styled$1("span", {
  name: "MuiSwitch",
  slot: "Track",
  overridesResolver: (props, styles2) => styles2.track
})(({
  theme
}) => ({
  height: "100%",
  width: "100%",
  borderRadius: 14 / 2,
  zIndex: -1,
  transition: theme.transitions.create(["opacity", "background-color"], {
    duration: theme.transitions.duration.shortest
  }),
  backgroundColor: theme.vars ? theme.vars.palette.common.onBackground : `${theme.palette.mode === "light" ? theme.palette.common.black : theme.palette.common.white}`,
  opacity: theme.vars ? theme.vars.opacity.switchTrack : `${theme.palette.mode === "light" ? 0.38 : 0.3}`
}));
const SwitchThumb = styled$1("span", {
  name: "MuiSwitch",
  slot: "Thumb",
  overridesResolver: (props, styles2) => styles2.thumb
})(({
  theme
}) => ({
  boxShadow: (theme.vars || theme).shadows[1],
  backgroundColor: "currentColor",
  width: 20,
  height: 20,
  borderRadius: "50%"
}));
const Switch = /* @__PURE__ */ reactExports.forwardRef(function Switch2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiSwitch"
  });
  const {
    className,
    color = "primary",
    edge = false,
    size = "medium",
    sx
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$G);
  const ownerState = _extends$1({}, props, {
    color,
    edge,
    size
  });
  const classes2 = useUtilityClasses$r(ownerState);
  const icon = /* @__PURE__ */ jsxRuntimeExports.jsx(SwitchThumb, {
    className: classes2.thumb,
    ownerState
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SwitchRoot, {
    className: clsx$1(classes2.root, className),
    sx,
    ownerState,
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(SwitchSwitchBase, _extends$1({
      type: "checkbox",
      icon,
      checkedIcon: icon,
      ref,
      ownerState
    }, other, {
      classes: _extends$1({}, classes2, {
        root: classes2.switchBase
      })
    })), /* @__PURE__ */ jsxRuntimeExports.jsx(SwitchTrack, {
      className: classes2.track,
      ownerState
    })]
  });
});
const MUISwitch = Switch;
function getFormControlLabelUtilityClasses(slot) {
  return generateUtilityClass("MuiFormControlLabel", slot);
}
const formControlLabelClasses = generateUtilityClasses("MuiFormControlLabel", ["root", "labelPlacementStart", "labelPlacementTop", "labelPlacementBottom", "disabled", "label", "error", "required", "asterisk"]);
const formControlLabelClasses$1 = formControlLabelClasses;
const _excluded$F = ["checked", "className", "componentsProps", "control", "disabled", "disableTypography", "inputRef", "label", "labelPlacement", "name", "onChange", "required", "slotProps", "value"];
const useUtilityClasses$q = (ownerState) => {
  const {
    classes: classes2,
    disabled,
    labelPlacement,
    error,
    required
  } = ownerState;
  const slots = {
    root: ["root", disabled && "disabled", `labelPlacement${capitalize(labelPlacement)}`, error && "error", required && "required"],
    label: ["label", disabled && "disabled"],
    asterisk: ["asterisk", error && "error"]
  };
  return composeClasses(slots, getFormControlLabelUtilityClasses, classes2);
};
const FormControlLabelRoot = styled$1("label", {
  name: "MuiFormControlLabel",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [{
      [`& .${formControlLabelClasses$1.label}`]: styles2.label
    }, styles2.root, styles2[`labelPlacement${capitalize(ownerState.labelPlacement)}`]];
  }
})(({
  theme,
  ownerState
}) => _extends$1({
  display: "inline-flex",
  alignItems: "center",
  cursor: "pointer",
  // For correct alignment with the text.
  verticalAlign: "middle",
  WebkitTapHighlightColor: "transparent",
  marginLeft: -11,
  marginRight: 16,
  // used for row presentation of radio/checkbox
  [`&.${formControlLabelClasses$1.disabled}`]: {
    cursor: "default"
  }
}, ownerState.labelPlacement === "start" && {
  flexDirection: "row-reverse",
  marginLeft: 16,
  // used for row presentation of radio/checkbox
  marginRight: -11
}, ownerState.labelPlacement === "top" && {
  flexDirection: "column-reverse",
  marginLeft: 16
}, ownerState.labelPlacement === "bottom" && {
  flexDirection: "column",
  marginLeft: 16
}, {
  [`& .${formControlLabelClasses$1.label}`]: {
    [`&.${formControlLabelClasses$1.disabled}`]: {
      color: (theme.vars || theme).palette.text.disabled
    }
  }
}));
const AsteriskComponent = styled$1("span", {
  name: "MuiFormControlLabel",
  slot: "Asterisk",
  overridesResolver: (props, styles2) => styles2.asterisk
})(({
  theme
}) => ({
  [`&.${formControlLabelClasses$1.error}`]: {
    color: (theme.vars || theme).palette.error.main
  }
}));
const FormControlLabel = /* @__PURE__ */ reactExports.forwardRef(function FormControlLabel2(inProps, ref) {
  var _ref, _slotProps$typography;
  const props = useThemeProps({
    props: inProps,
    name: "MuiFormControlLabel"
  });
  const {
    className,
    componentsProps = {},
    control,
    disabled: disabledProp,
    disableTypography,
    label: labelProp,
    labelPlacement = "end",
    required: requiredProp,
    slotProps = {}
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$F);
  const muiFormControl = useFormControl();
  const disabled = (_ref = disabledProp != null ? disabledProp : control.props.disabled) != null ? _ref : muiFormControl == null ? void 0 : muiFormControl.disabled;
  const required = requiredProp != null ? requiredProp : control.props.required;
  const controlProps = {
    disabled,
    required
  };
  ["checked", "name", "onChange", "value", "inputRef"].forEach((key) => {
    if (typeof control.props[key] === "undefined" && typeof props[key] !== "undefined") {
      controlProps[key] = props[key];
    }
  });
  const fcs = formControlState({
    props,
    muiFormControl,
    states: ["error"]
  });
  const ownerState = _extends$1({}, props, {
    disabled,
    labelPlacement,
    required,
    error: fcs.error
  });
  const classes2 = useUtilityClasses$q(ownerState);
  const typographySlotProps = (_slotProps$typography = slotProps.typography) != null ? _slotProps$typography : componentsProps.typography;
  let label = labelProp;
  if (label != null && label.type !== Typography && !disableTypography) {
    label = /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, _extends$1({
      component: "span"
    }, typographySlotProps, {
      className: clsx$1(classes2.label, typographySlotProps == null ? void 0 : typographySlotProps.className),
      children: label
    }));
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(FormControlLabelRoot, _extends$1({
    className: clsx$1(classes2.root, className),
    ownerState,
    ref
  }, other, {
    children: [/* @__PURE__ */ reactExports.cloneElement(control, controlProps), required ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack, {
      direction: "row",
      alignItems: "center",
      children: [label, /* @__PURE__ */ jsxRuntimeExports.jsxs(AsteriskComponent, {
        ownerState,
        "aria-hidden": true,
        className: classes2.asterisk,
        children: [" ", "*"]
      })]
    }) : label]
  }));
});
const FormControlLabel$1 = FormControlLabel;
const _excluded$E = ["className"];
const useUtilityClasses$p = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["panelContent"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridPanelContentRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "PanelContent",
  overridesResolver: (props, styles2) => styles2.panelContent
})({
  display: "flex",
  flexDirection: "column",
  overflow: "auto",
  flex: "1 1",
  maxHeight: 400
});
function GridPanelContent(props) {
  const {
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$E);
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$p(rootProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridPanelContentRoot, _extends$1({
    className: clsx$1(className, classes2.root),
    ownerState: rootProps
  }, other));
}
const _excluded$D = ["className"];
const useUtilityClasses$o = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["panelFooter"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridPanelFooterRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "PanelFooter",
  overridesResolver: (props, styles2) => styles2.panelFooter
})(({
  theme
}) => ({
  padding: theme.spacing(0.5),
  display: "flex",
  justifyContent: "space-between"
}));
function GridPanelFooter(props) {
  const {
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$D);
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$o(rootProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridPanelFooterRoot, _extends$1({
    className: clsx$1(className, classes2.root),
    ownerState: rootProps
  }, other));
}
const _excluded$C = ["className"];
const useUtilityClasses$n = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["panelHeader"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridPanelHeaderRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "PanelHeader",
  overridesResolver: (props, styles2) => styles2.panelHeader
})(({
  theme
}) => ({
  padding: theme.spacing(1)
}));
function GridPanelHeader(props) {
  const {
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$C);
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$n(rootProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridPanelHeaderRoot, _extends$1({
    className: clsx$1(className, classes2.root),
    ownerState: rootProps
  }, other));
}
const _excluded$B = ["className", "slotProps"];
const useUtilityClasses$m = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["panelWrapper"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridPanelWrapperRoot = styled$1("div", {
  name: "MuiDataGrid",
  slot: "PanelWrapper",
  overridesResolver: (props, styles2) => styles2.panelWrapper
})({
  display: "flex",
  flexDirection: "column",
  flex: 1,
  "&:focus": {
    outline: 0
  }
});
const isEnabled = () => true;
const GridPanelWrapper = /* @__PURE__ */ reactExports.forwardRef(function GridPanelWrapper2(props, ref) {
  const {
    className,
    slotProps = {}
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$B);
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$m(rootProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(FocusTrap, _extends$1({
    open: true,
    disableEnforceFocus: true,
    isEnabled
  }, slotProps.TrapFocus, {
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(GridPanelWrapperRoot, _extends$1({
      ref,
      tabIndex: -1,
      className: clsx$1(className, classes2.root),
      ownerState: rootProps
    }, other))
  }));
});
const GRID_EXPERIMENTAL_ENABLED = false;
const _excluded$A = ["sort", "searchPredicate", "autoFocusSearchField", "disableHideAllButton", "disableShowAllButton", "getTogglableColumns"];
const useUtilityClasses$l = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["columnsPanel"],
    columnsPanelRow: ["columnsPanelRow"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridColumnsPanelRoot = styled$1("div", {
  name: "MuiDataGrid",
  slot: "ColumnsPanel",
  overridesResolver: (props, styles2) => styles2.columnsPanel
})({
  padding: "8px 0px 8px 8px"
});
const GridColumnsPanelRowRoot = styled$1("div", {
  name: "MuiDataGrid",
  slot: "ColumnsPanelRow",
  overridesResolver: (props, styles2) => styles2.columnsPanelRow
})(({
  theme
}) => ({
  display: "flex",
  justifyContent: "space-between",
  padding: "1px 8px 1px 7px",
  [`& .${switchClasses$1.root}`]: {
    marginRight: theme.spacing(0.5)
  }
}));
const GridIconButtonRoot = styled$1(IconButton$1)({
  justifyContent: "flex-end"
});
const collator$1 = new Intl.Collator();
const defaultSearchPredicate = (column, searchValue) => {
  return (column.headerName || column.field).toLowerCase().indexOf(searchValue) > -1;
};
function GridColumnsPanel(props) {
  var _rootProps$slotProps, _rootProps$slotProps3, _rootProps$slotProps4;
  const apiRef2 = useGridApiContext();
  const searchInputRef = reactExports.useRef(null);
  const columns = useGridSelector(apiRef2, gridColumnDefinitionsSelector);
  const columnVisibilityModel = useGridSelector(apiRef2, gridColumnVisibilityModelSelector);
  const rootProps = useGridRootProps();
  const [searchValue, setSearchValue] = reactExports.useState("");
  const classes2 = useUtilityClasses$l(rootProps);
  const {
    sort,
    searchPredicate = defaultSearchPredicate,
    autoFocusSearchField = true,
    disableHideAllButton = false,
    disableShowAllButton = false,
    getTogglableColumns
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$A);
  const sortedColumns = reactExports.useMemo(() => {
    switch (sort) {
      case "asc":
        return [...columns].sort((a2, b) => collator$1.compare(a2.headerName || a2.field, b.headerName || b.field));
      case "desc":
        return [...columns].sort((a2, b) => -collator$1.compare(a2.headerName || a2.field, b.headerName || b.field));
      default:
        return columns;
    }
  }, [columns, sort]);
  const toggleColumn = (event) => {
    const {
      name: field
    } = event.target;
    apiRef2.current.setColumnVisibility(field, columnVisibilityModel[field] === false);
  };
  const toggleAllColumns = reactExports.useCallback((isVisible) => {
    const currentModel = gridColumnVisibilityModelSelector(apiRef2);
    const newModel = _extends$1({}, currentModel);
    const togglableColumns = getTogglableColumns ? getTogglableColumns(columns) : null;
    columns.forEach((col) => {
      if (col.hideable && (togglableColumns == null || togglableColumns.includes(col.field))) {
        if (isVisible) {
          delete newModel[col.field];
        } else {
          newModel[col.field] = false;
        }
      }
    });
    return apiRef2.current.setColumnVisibilityModel(newModel);
  }, [apiRef2, columns, getTogglableColumns]);
  const handleSearchValueChange = reactExports.useCallback((event) => {
    setSearchValue(event.target.value);
  }, []);
  const currentColumns = reactExports.useMemo(() => {
    const togglableColumns = getTogglableColumns ? getTogglableColumns(sortedColumns) : null;
    const togglableSortedColumns = togglableColumns ? sortedColumns.filter(({
      field
    }) => togglableColumns.includes(field)) : sortedColumns;
    if (!searchValue) {
      return togglableSortedColumns;
    }
    return togglableSortedColumns.filter((column) => searchPredicate(column, searchValue.toLowerCase()));
  }, [sortedColumns, searchValue, searchPredicate, getTogglableColumns]);
  const firstSwitchRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    if (autoFocusSearchField) {
      searchInputRef.current.focus();
    } else if (firstSwitchRef.current && typeof firstSwitchRef.current.focus === "function") {
      firstSwitchRef.current.focus();
    }
  }, [autoFocusSearchField]);
  let firstHideableColumnFound = false;
  const isFirstHideableColumn = (column) => {
    if (firstHideableColumnFound === false && column.hideable !== false) {
      firstHideableColumnFound = true;
      return true;
    }
    return false;
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(GridPanelWrapper, _extends$1({}, other, {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(GridPanelHeader, {
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseTextField, _extends$1({
        label: apiRef2.current.getLocaleText("columnsPanelTextFieldLabel"),
        placeholder: apiRef2.current.getLocaleText("columnsPanelTextFieldPlaceholder"),
        inputRef: searchInputRef,
        value: searchValue,
        onChange: handleSearchValueChange,
        variant: "standard",
        fullWidth: true
      }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseTextField))
    }), /* @__PURE__ */ jsxRuntimeExports.jsx(GridPanelContent, {
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnsPanelRoot, {
        className: classes2.root,
        ownerState: rootProps,
        children: currentColumns.map((column) => {
          var _rootProps$slotProps2;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(GridColumnsPanelRowRoot, {
            className: classes2.columnsPanelRow,
            ownerState: rootProps,
            children: [/* @__PURE__ */ jsxRuntimeExports.jsx(FormControlLabel$1, {
              control: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseSwitch, _extends$1({
                disabled: column.hideable === false,
                checked: columnVisibilityModel[column.field] !== false,
                onClick: toggleColumn,
                name: column.field,
                size: "small",
                inputRef: isFirstHideableColumn(column) ? firstSwitchRef : void 0
              }, (_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.baseSwitch)),
              label: column.headerName || column.field
            }), !rootProps.disableColumnReorder && GRID_EXPERIMENTAL_ENABLED && /* @__PURE__ */ jsxRuntimeExports.jsx(GridIconButtonRoot, {
              draggable: true,
              "aria-label": apiRef2.current.getLocaleText("columnsPanelDragIconLabel"),
              title: apiRef2.current.getLocaleText("columnsPanelDragIconLabel"),
              size: "small",
              disabled: true,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.columnReorderIcon, {})
            })]
          }, column.field);
        })
      })
    }), disableShowAllButton && disableHideAllButton ? null : /* @__PURE__ */ jsxRuntimeExports.jsxs(GridPanelFooter, {
      children: [!disableHideAllButton ? /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseButton, _extends$1({
        onClick: () => toggleAllColumns(false)
      }, (_rootProps$slotProps3 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps3.baseButton, {
        disabled: disableHideAllButton,
        children: apiRef2.current.getLocaleText("columnsPanelHideAllButton")
      })) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", {}), !disableShowAllButton ? /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseButton, _extends$1({
        onClick: () => toggleAllColumns(true)
      }, (_rootProps$slotProps4 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps4.baseButton, {
        disabled: disableShowAllButton,
        children: apiRef2.current.getLocaleText("columnsPanelShowAllButton")
      })) : null]
    })]
  }));
}
const _excluded$z = ["children", "className", "classes"];
const gridPanelClasses = generateUtilityClasses("MuiDataGrid", ["panel", "paper"]);
const GridPanelRoot = styled$1(MUIPopper, {
  name: "MuiDataGrid",
  slot: "Panel",
  overridesResolver: (props, styles2) => styles2.panel
})(({
  theme
}) => ({
  zIndex: theme.zIndex.modal
}));
const GridPaperRoot = styled$1(Paper, {
  name: "MuiDataGrid",
  slot: "Paper",
  overridesResolver: (props, styles2) => styles2.paper
})(({
  theme
}) => ({
  backgroundColor: (theme.vars || theme).palette.background.paper,
  minWidth: 300,
  maxHeight: 450,
  display: "flex"
}));
const GridPanel = /* @__PURE__ */ reactExports.forwardRef((props, ref) => {
  const {
    children,
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$z);
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const classes2 = gridPanelClasses;
  const [isPlaced, setIsPlaced] = reactExports.useState(false);
  const handleClickAway = reactExports.useCallback(() => {
    apiRef2.current.hidePreferences();
  }, [apiRef2]);
  const handleKeyDown = reactExports.useCallback((event) => {
    if (isEscapeKey(event.key)) {
      apiRef2.current.hidePreferences();
    }
  }, [apiRef2]);
  const modifiers = reactExports.useMemo(() => [{
    name: "flip",
    enabled: false
  }, {
    name: "isPlaced",
    enabled: true,
    phase: "main",
    fn: () => {
      setIsPlaced(true);
    },
    effect: () => () => {
      setIsPlaced(false);
    }
  }], []);
  const [anchorEl, setAnchorEl] = reactExports.useState(null);
  reactExports.useEffect(() => {
    var _apiRef$current$rootE;
    const columnHeadersElement = (_apiRef$current$rootE = apiRef2.current.rootElementRef) == null || (_apiRef$current$rootE = _apiRef$current$rootE.current) == null ? void 0 : _apiRef$current$rootE.querySelector(`.${gridClasses.columnHeaders}`);
    if (columnHeadersElement) {
      setAnchorEl(columnHeadersElement);
    }
  }, [apiRef2]);
  if (!anchorEl) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridPanelRoot, _extends$1({
    ref,
    placement: "bottom-start",
    className: clsx$1(className, classes2.panel),
    ownerState: rootProps,
    anchorEl,
    modifiers
  }, other, {
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(ClickAwayListener, {
      mouseEvent: "onMouseUp",
      onClickAway: handleClickAway,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(GridPaperRoot, {
        className: classes2.paper,
        ownerState: rootProps,
        elevation: 8,
        onKeyDown: handleKeyDown,
        children: isPlaced && children
      })
    })
  }));
});
const GridPreferencesPanel = /* @__PURE__ */ reactExports.forwardRef(function GridPreferencesPanel2(props, ref) {
  var _preferencePanelState, _rootProps$slotProps, _rootProps$slotProps2;
  const apiRef2 = useGridApiContext();
  const columns = useGridSelector(apiRef2, gridColumnDefinitionsSelector);
  const rootProps = useGridRootProps();
  const preferencePanelState = useGridSelector(apiRef2, gridPreferencePanelStateSelector);
  const panelContent = apiRef2.current.unstable_applyPipeProcessors("preferencePanel", null, (_preferencePanelState = preferencePanelState.openedPanelValue) != null ? _preferencePanelState : GridPreferencePanelsValue.filters);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.panel, _extends$1({
    ref,
    as: rootProps.slots.basePopper,
    open: columns.length > 0 && preferencePanelState.open,
    id: preferencePanelState.panelId,
    "aria-labelledby": preferencePanelState.labelId
  }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.panel, props, (_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.basePopper, {
    children: panelContent
  }));
});
const _excluded$y = ["item", "hasMultipleFilters", "deleteFilter", "applyFilterChanges", "multiFilterOperator", "showMultiFilterOperators", "disableMultiFilterOperator", "applyMultiFilterOperatorChanges", "focusElementRef", "logicOperators", "columnsSort", "filterColumns", "deleteIconProps", "logicOperatorInputProps", "operatorInputProps", "columnInputProps", "valueInputProps", "children"], _excluded2$5 = ["InputComponentProps"];
const useUtilityClasses$k = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["filterForm"],
    deleteIcon: ["filterFormDeleteIcon"],
    logicOperatorInput: ["filterFormLogicOperatorInput"],
    columnInput: ["filterFormColumnInput"],
    operatorInput: ["filterFormOperatorInput"],
    valueInput: ["filterFormValueInput"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridFilterFormRoot = styled$1("div", {
  name: "MuiDataGrid",
  slot: "FilterForm",
  overridesResolver: (props, styles2) => styles2.filterForm
})(({
  theme
}) => ({
  display: "flex",
  padding: theme.spacing(1)
}));
const FilterFormDeleteIcon = styled$1("div", {
  name: "MuiDataGrid",
  slot: "FilterFormDeleteIcon",
  overridesResolver: (_2, styles2) => styles2.filterFormDeleteIcon
})(({
  theme
}) => ({
  flexShrink: 0,
  justifyContent: "flex-end",
  marginRight: theme.spacing(0.5),
  marginBottom: theme.spacing(0.2)
}));
const FilterFormLogicOperatorInput = styled$1("div", {
  name: "MuiDataGrid",
  slot: "FilterFormLogicOperatorInput",
  overridesResolver: (_2, styles2) => styles2.filterFormLogicOperatorInput
})({
  minWidth: 55,
  marginRight: 5,
  justifyContent: "end"
});
const FilterFormColumnInput = styled$1("div", {
  name: "MuiDataGrid",
  slot: "FilterFormColumnInput",
  overridesResolver: (_2, styles2) => styles2.filterFormColumnInput
})({
  width: 150
});
const FilterFormOperatorInput = styled$1("div", {
  name: "MuiDataGrid",
  slot: "FilterFormOperatorInput",
  overridesResolver: (_2, styles2) => styles2.filterFormOperatorInput
})({
  width: 120
});
const FilterFormValueInput = styled$1("div", {
  name: "MuiDataGrid",
  slot: "FilterFormValueInput",
  overridesResolver: (_2, styles2) => styles2.filterFormValueInput
})({
  width: 190
});
const getLogicOperatorLocaleKey = (logicOperator) => {
  switch (logicOperator) {
    case GridLogicOperator.And:
      return "filterPanelOperatorAnd";
    case GridLogicOperator.Or:
      return "filterPanelOperatorOr";
    default:
      throw new Error("MUI: Invalid `logicOperator` property in the `GridFilterPanel`.");
  }
};
const getColumnLabel = (col) => col.headerName || col.field;
const collator = new Intl.Collator();
const GridFilterForm = /* @__PURE__ */ reactExports.forwardRef(function GridFilterForm2(props, ref) {
  var _rootProps$slotProps, _rootProps$slotProps2, _baseSelectProps$nati, _rootProps$slotProps3, _rootProps$slotProps4, _rootProps$slotProps5, _rootProps$slotProps6, _rootProps$slotProps7, _rootProps$slotProps8, _currentColumn$filter2;
  const {
    item,
    hasMultipleFilters,
    deleteFilter,
    applyFilterChanges,
    multiFilterOperator,
    showMultiFilterOperators,
    disableMultiFilterOperator,
    applyMultiFilterOperatorChanges,
    focusElementRef,
    logicOperators = [GridLogicOperator.And, GridLogicOperator.Or],
    columnsSort,
    filterColumns,
    deleteIconProps = {},
    logicOperatorInputProps = {},
    operatorInputProps = {},
    columnInputProps = {},
    valueInputProps = {}
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$y);
  const apiRef2 = useGridApiContext();
  const filterableColumns = useGridSelector(apiRef2, gridFilterableColumnDefinitionsSelector);
  const filterModel2 = useGridSelector(apiRef2, gridFilterModelSelector);
  const columnSelectId = useId();
  const columnSelectLabelId = useId();
  const operatorSelectId = useId();
  const operatorSelectLabelId = useId();
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$k(rootProps);
  const valueRef = reactExports.useRef(null);
  const filterSelectorRef = reactExports.useRef(null);
  const hasLogicOperatorColumn = hasMultipleFilters && logicOperators.length > 0;
  const baseFormControlProps = ((_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseFormControl) || {};
  const baseSelectProps = ((_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.baseSelect) || {};
  const isBaseSelectNative = (_baseSelectProps$nati = baseSelectProps.native) != null ? _baseSelectProps$nati : true;
  const baseInputLabelProps = ((_rootProps$slotProps3 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps3.baseInputLabel) || {};
  const baseSelectOptionProps = ((_rootProps$slotProps4 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps4.baseSelectOption) || {};
  const {
    InputComponentProps
  } = valueInputProps, valueInputPropsOther = _objectWithoutPropertiesLoose$1(valueInputProps, _excluded2$5);
  const filteredColumns = reactExports.useMemo(() => {
    if (filterColumns === void 0 || typeof filterColumns !== "function") {
      return filterableColumns;
    }
    const filteredFields = filterColumns({
      field: item.field,
      columns: filterableColumns,
      currentFilters: (filterModel2 == null ? void 0 : filterModel2.items) || []
    });
    return filterableColumns.filter((column) => filteredFields.includes(column.field));
  }, [filterColumns, filterModel2 == null ? void 0 : filterModel2.items, filterableColumns, item.field]);
  const sortedFilteredColumns = reactExports.useMemo(() => {
    switch (columnsSort) {
      case "asc":
        return filteredColumns.sort((a2, b) => collator.compare(getColumnLabel(a2), getColumnLabel(b)));
      case "desc":
        return filteredColumns.sort((a2, b) => -collator.compare(getColumnLabel(a2), getColumnLabel(b)));
      default:
        return filteredColumns;
    }
  }, [filteredColumns, columnsSort]);
  const currentColumn = item.field ? apiRef2.current.getColumn(item.field) : null;
  const currentOperator = reactExports.useMemo(() => {
    var _currentColumn$filter;
    if (!item.operator || !currentColumn) {
      return null;
    }
    return (_currentColumn$filter = currentColumn.filterOperators) == null ? void 0 : _currentColumn$filter.find((operator) => operator.value === item.operator);
  }, [item, currentColumn]);
  const changeColumn = reactExports.useCallback((event) => {
    const field = event.target.value;
    const column = apiRef2.current.getColumn(field);
    if (column.field === currentColumn.field) {
      return;
    }
    const newOperator = column.filterOperators.find((operator) => operator.value === item.operator) || column.filterOperators[0];
    const eraseItemValue = !newOperator.InputComponent || newOperator.InputComponent !== (currentOperator == null ? void 0 : currentOperator.InputComponent);
    applyFilterChanges(_extends$1({}, item, {
      field,
      operator: newOperator.value,
      value: eraseItemValue ? void 0 : item.value
    }));
  }, [apiRef2, applyFilterChanges, item, currentColumn, currentOperator]);
  const changeOperator = reactExports.useCallback((event) => {
    const operator = event.target.value;
    const newOperator = currentColumn == null ? void 0 : currentColumn.filterOperators.find((op) => op.value === operator);
    const eraseItemValue = !(newOperator != null && newOperator.InputComponent) || (newOperator == null ? void 0 : newOperator.InputComponent) !== (currentOperator == null ? void 0 : currentOperator.InputComponent);
    applyFilterChanges(_extends$1({}, item, {
      operator,
      value: eraseItemValue ? void 0 : item.value
    }));
  }, [applyFilterChanges, item, currentColumn, currentOperator]);
  const changeLogicOperator = reactExports.useCallback((event) => {
    const logicOperator = event.target.value === GridLogicOperator.And.toString() ? GridLogicOperator.And : GridLogicOperator.Or;
    applyMultiFilterOperatorChanges(logicOperator);
  }, [applyMultiFilterOperatorChanges]);
  const handleDeleteFilter = () => {
    if (rootProps.disableMultipleColumnsFiltering) {
      if (item.value === void 0) {
        deleteFilter(item);
      } else {
        applyFilterChanges(_extends$1({}, item, {
          value: void 0
        }));
      }
    } else {
      deleteFilter(item);
    }
  };
  reactExports.useImperativeHandle(focusElementRef, () => ({
    focus: () => {
      if (currentOperator != null && currentOperator.InputComponent) {
        var _valueRef$current;
        valueRef == null || (_valueRef$current = valueRef.current) == null || _valueRef$current.focus();
      } else {
        filterSelectorRef.current.focus();
      }
    }
  }), [currentOperator]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(GridFilterFormRoot, _extends$1({
    ref,
    className: classes2.root,
    "data-id": item.id,
    ownerState: rootProps
  }, other, {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(FilterFormDeleteIcon, _extends$1({
      variant: "standard",
      as: rootProps.slots.baseFormControl
    }, baseFormControlProps, deleteIconProps, {
      className: clsx$1(classes2.deleteIcon, baseFormControlProps.className, deleteIconProps.className),
      ownerState: rootProps,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseIconButton, _extends$1({
        "aria-label": apiRef2.current.getLocaleText("filterPanelDeleteIconLabel"),
        title: apiRef2.current.getLocaleText("filterPanelDeleteIconLabel"),
        onClick: handleDeleteFilter,
        size: "small"
      }, (_rootProps$slotProps5 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps5.baseIconButton, {
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.filterPanelDeleteIcon, {
          fontSize: "small"
        })
      }))
    })), /* @__PURE__ */ jsxRuntimeExports.jsx(FilterFormLogicOperatorInput, _extends$1({
      variant: "standard",
      as: rootProps.slots.baseFormControl
    }, baseFormControlProps, logicOperatorInputProps, {
      sx: _extends$1({
        display: hasLogicOperatorColumn ? "flex" : "none",
        visibility: showMultiFilterOperators ? "visible" : "hidden"
      }, baseFormControlProps.sx || {}, logicOperatorInputProps.sx || {}),
      className: clsx$1(classes2.logicOperatorInput, baseFormControlProps.className, logicOperatorInputProps.className),
      ownerState: rootProps,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseSelect, _extends$1({
        inputProps: {
          "aria-label": apiRef2.current.getLocaleText("filterPanelLogicOperator")
        },
        value: multiFilterOperator,
        onChange: changeLogicOperator,
        disabled: !!disableMultiFilterOperator || logicOperators.length === 1,
        native: isBaseSelectNative
      }, (_rootProps$slotProps6 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps6.baseSelect, {
        children: logicOperators.map((logicOperator) => /* @__PURE__ */ reactExports.createElement(rootProps.slots.baseSelectOption, _extends$1({}, baseSelectOptionProps, {
          native: isBaseSelectNative,
          key: logicOperator.toString(),
          value: logicOperator.toString()
        }), apiRef2.current.getLocaleText(getLogicOperatorLocaleKey(logicOperator))))
      }))
    })), /* @__PURE__ */ jsxRuntimeExports.jsxs(FilterFormColumnInput, _extends$1({
      variant: "standard",
      as: rootProps.slots.baseFormControl
    }, baseFormControlProps, columnInputProps, {
      className: clsx$1(classes2.columnInput, baseFormControlProps.className, columnInputProps.className),
      ownerState: rootProps,
      children: [/* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseInputLabel, _extends$1({}, baseInputLabelProps, {
        htmlFor: columnSelectId,
        id: columnSelectLabelId,
        children: apiRef2.current.getLocaleText("filterPanelColumns")
      })), /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseSelect, _extends$1({
        labelId: columnSelectLabelId,
        id: columnSelectId,
        label: apiRef2.current.getLocaleText("filterPanelColumns"),
        value: item.field || "",
        onChange: changeColumn,
        native: isBaseSelectNative
      }, (_rootProps$slotProps7 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps7.baseSelect, {
        children: sortedFilteredColumns.map((col) => /* @__PURE__ */ reactExports.createElement(rootProps.slots.baseSelectOption, _extends$1({}, baseSelectOptionProps, {
          native: isBaseSelectNative,
          key: col.field,
          value: col.field
        }), getColumnLabel(col)))
      }))]
    })), /* @__PURE__ */ jsxRuntimeExports.jsxs(FilterFormOperatorInput, _extends$1({
      variant: "standard",
      as: rootProps.slots.baseFormControl
    }, baseFormControlProps, operatorInputProps, {
      className: clsx$1(classes2.operatorInput, baseFormControlProps.className, operatorInputProps.className),
      ownerState: rootProps,
      children: [/* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseInputLabel, _extends$1({}, baseInputLabelProps, {
        htmlFor: operatorSelectId,
        id: operatorSelectLabelId,
        children: apiRef2.current.getLocaleText("filterPanelOperator")
      })), /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseSelect, _extends$1({
        labelId: operatorSelectLabelId,
        label: apiRef2.current.getLocaleText("filterPanelOperator"),
        id: operatorSelectId,
        value: item.operator,
        onChange: changeOperator,
        native: isBaseSelectNative,
        inputRef: filterSelectorRef
      }, (_rootProps$slotProps8 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps8.baseSelect, {
        children: currentColumn == null || (_currentColumn$filter2 = currentColumn.filterOperators) == null ? void 0 : _currentColumn$filter2.map((operator) => /* @__PURE__ */ reactExports.createElement(rootProps.slots.baseSelectOption, _extends$1({}, baseSelectOptionProps, {
          native: isBaseSelectNative,
          key: operator.value,
          value: operator.value
        }), operator.label || apiRef2.current.getLocaleText(`filterOperator${capitalize(operator.value)}`)))
      }))]
    })), /* @__PURE__ */ jsxRuntimeExports.jsx(FilterFormValueInput, _extends$1({
      variant: "standard",
      as: rootProps.slots.baseFormControl
    }, baseFormControlProps, valueInputPropsOther, {
      className: clsx$1(classes2.valueInput, baseFormControlProps.className, valueInputPropsOther.className),
      ownerState: rootProps,
      children: currentOperator != null && currentOperator.InputComponent ? /* @__PURE__ */ jsxRuntimeExports.jsx(currentOperator.InputComponent, _extends$1({
        apiRef: apiRef2,
        item,
        applyValue: applyFilterChanges,
        focusElementRef: valueRef
      }, currentOperator.InputComponentProps, InputComponentProps)) : null
    }))]
  }));
});
class Timeout {
  constructor() {
    this.currentId = 0;
    this.clear = () => {
      if (this.currentId !== 0) {
        clearTimeout(this.currentId);
        this.currentId = 0;
      }
    };
    this.disposeEffect = () => {
      return this.clear;
    };
  }
  static create() {
    return new Timeout();
  }
  start(delay, fn2) {
    this.clear();
    this.currentId = setTimeout(fn2, delay);
  }
}
function useTimeout() {
  const timeout2 = useLazyRef(Timeout.create).current;
  useOnMount(timeout2.disposeEffect);
  return timeout2;
}
const _excluded$x = ["item", "applyValue", "type", "apiRef", "focusElementRef", "tabIndex", "disabled", "isFilterActive", "clearButton", "InputProps"];
function GridFilterInputValue(props) {
  var _item$value, _rootProps$slotProps;
  const {
    item,
    applyValue,
    type,
    apiRef: apiRef2,
    focusElementRef,
    tabIndex,
    disabled,
    clearButton,
    InputProps
  } = props, others = _objectWithoutPropertiesLoose$1(props, _excluded$x);
  const filterTimeout = useTimeout();
  const [filterValueState, setFilterValueState] = reactExports.useState((_item$value = item.value) != null ? _item$value : "");
  const [applying, setIsApplying] = reactExports.useState(false);
  const id = useId();
  const rootProps = useGridRootProps();
  const onFilterChange = reactExports.useCallback((event) => {
    const {
      value
    } = event.target;
    setFilterValueState(String(value));
    setIsApplying(true);
    filterTimeout.start(rootProps.filterDebounceMs, () => {
      const newItem = _extends$1({}, item, {
        value,
        fromInput: id
      });
      applyValue(newItem);
      setIsApplying(false);
    });
  }, [id, applyValue, item, rootProps.filterDebounceMs, filterTimeout]);
  reactExports.useEffect(() => {
    const itemPlusTag = item;
    if (itemPlusTag.fromInput !== id) {
      var _item$value2;
      setFilterValueState(String((_item$value2 = item.value) != null ? _item$value2 : ""));
    }
  }, [id, item]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseTextField, _extends$1({
    id,
    label: apiRef2.current.getLocaleText("filterPanelInputLabel"),
    placeholder: apiRef2.current.getLocaleText("filterPanelInputPlaceholder"),
    value: filterValueState,
    onChange: onFilterChange,
    variant: "standard",
    type: type || "text",
    InputProps: _extends$1({}, applying || clearButton ? {
      endAdornment: applying ? /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.loadIcon, {
        fontSize: "small",
        color: "action"
      }) : clearButton
    } : {}, {
      disabled
    }, InputProps, {
      inputProps: _extends$1({
        tabIndex
      }, InputProps == null ? void 0 : InputProps.inputProps)
    }),
    InputLabelProps: {
      shrink: true
    },
    inputRef: focusElementRef
  }, others, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseTextField));
}
const _excluded$w = ["item", "applyValue", "type", "apiRef", "focusElementRef", "InputProps", "isFilterActive", "clearButton", "tabIndex", "disabled"];
function GridFilterInputDate(props) {
  var _item$value, _rootProps$slotProps;
  const {
    item,
    applyValue,
    type,
    apiRef: apiRef2,
    focusElementRef,
    InputProps,
    clearButton,
    tabIndex,
    disabled
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$w);
  const filterTimeout = useTimeout();
  const [filterValueState, setFilterValueState] = reactExports.useState((_item$value = item.value) != null ? _item$value : "");
  const [applying, setIsApplying] = reactExports.useState(false);
  const id = useId();
  const rootProps = useGridRootProps();
  const onFilterChange = reactExports.useCallback((event) => {
    const value = event.target.value;
    setFilterValueState(String(value));
    setIsApplying(true);
    filterTimeout.start(rootProps.filterDebounceMs, () => {
      applyValue(_extends$1({}, item, {
        value
      }));
      setIsApplying(false);
    });
  }, [applyValue, item, rootProps.filterDebounceMs, filterTimeout]);
  reactExports.useEffect(() => {
    var _item$value2;
    const itemValue = (_item$value2 = item.value) != null ? _item$value2 : "";
    setFilterValueState(String(itemValue));
  }, [item.value]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseTextField, _extends$1({
    fullWidth: true,
    id,
    label: apiRef2.current.getLocaleText("filterPanelInputLabel"),
    placeholder: apiRef2.current.getLocaleText("filterPanelInputPlaceholder"),
    value: filterValueState,
    onChange: onFilterChange,
    variant: "standard",
    type: type || "text",
    InputLabelProps: {
      shrink: true
    },
    inputRef: focusElementRef,
    InputProps: _extends$1({}, applying || clearButton ? {
      endAdornment: applying ? /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.loadIcon, {
        fontSize: "small",
        color: "action"
      }) : clearButton
    } : {}, {
      disabled
    }, InputProps, {
      inputProps: _extends$1({
        max: type === "datetime-local" ? "9999-12-31T23:59" : "9999-12-31",
        tabIndex
      }, InputProps == null ? void 0 : InputProps.inputProps)
    })
  }, other, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseTextField));
}
const _excluded$v = ["item", "applyValue", "type", "apiRef", "focusElementRef", "getOptionLabel", "getOptionValue", "placeholder", "tabIndex", "label", "isFilterActive", "clearButton"];
const renderSingleSelectOptions = ({
  column: {
    valueOptions,
    field
  },
  OptionComponent,
  getOptionLabel,
  getOptionValue,
  isSelectNative,
  baseSelectOptionProps
}) => {
  const iterableColumnValues = typeof valueOptions === "function" ? ["", ...valueOptions({
    field
  })] : ["", ...valueOptions || []];
  return iterableColumnValues.map((option) => {
    const value = getOptionValue(option);
    const label = getOptionLabel(option);
    return /* @__PURE__ */ reactExports.createElement(OptionComponent, _extends$1({}, baseSelectOptionProps, {
      native: isSelectNative,
      key: value,
      value
    }), label);
  });
};
const SingleSelectOperatorContainer = styled$1("div")({
  display: "flex",
  alignItems: "flex-end",
  width: "100%",
  [`& button`]: {
    margin: "auto 0px 5px 5px"
  }
});
function GridFilterInputSingleSelect(props) {
  var _item$value, _rootProps$slotProps$, _rootProps$slotProps, _resolvedColumn, _resolvedColumn2, _rootProps$slotProps2, _rootProps$slotProps3, _rootProps$slotProps4;
  const {
    item,
    applyValue,
    type,
    apiRef: apiRef2,
    focusElementRef,
    getOptionLabel: getOptionLabelProp,
    getOptionValue: getOptionValueProp,
    placeholder,
    tabIndex,
    label: labelProp,
    clearButton
  } = props, others = _objectWithoutPropertiesLoose$1(props, _excluded$v);
  const [filterValueState, setFilterValueState] = reactExports.useState((_item$value = item.value) != null ? _item$value : "");
  const id = useId();
  const labelId = useId();
  const rootProps = useGridRootProps();
  const isSelectNative = (_rootProps$slotProps$ = (_rootProps$slotProps = rootProps.slotProps) == null || (_rootProps$slotProps = _rootProps$slotProps.baseSelect) == null ? void 0 : _rootProps$slotProps.native) != null ? _rootProps$slotProps$ : true;
  let resolvedColumn = null;
  if (item.field) {
    const column = apiRef2.current.getColumn(item.field);
    if (isSingleSelectColDef(column)) {
      resolvedColumn = column;
    }
  }
  const getOptionValue = getOptionValueProp || ((_resolvedColumn = resolvedColumn) == null ? void 0 : _resolvedColumn.getOptionValue);
  const getOptionLabel = getOptionLabelProp || ((_resolvedColumn2 = resolvedColumn) == null ? void 0 : _resolvedColumn2.getOptionLabel);
  const currentValueOptions = reactExports.useMemo(() => {
    if (!resolvedColumn) {
      return void 0;
    }
    return typeof resolvedColumn.valueOptions === "function" ? resolvedColumn.valueOptions({
      field: resolvedColumn.field
    }) : resolvedColumn.valueOptions;
  }, [resolvedColumn]);
  const onFilterChange = reactExports.useCallback((event) => {
    let value = event.target.value;
    value = getValueFromValueOptions(value, currentValueOptions, getOptionValue);
    setFilterValueState(String(value));
    applyValue(_extends$1({}, item, {
      value
    }));
  }, [currentValueOptions, getOptionValue, applyValue, item]);
  reactExports.useEffect(() => {
    var _itemValue;
    let itemValue;
    if (currentValueOptions !== void 0) {
      itemValue = getValueFromValueOptions(item.value, currentValueOptions, getOptionValue);
      if (itemValue !== item.value) {
        applyValue(_extends$1({}, item, {
          value: itemValue
        }));
        return;
      }
    } else {
      itemValue = item.value;
    }
    itemValue = (_itemValue = itemValue) != null ? _itemValue : "";
    setFilterValueState(String(itemValue));
  }, [item, currentValueOptions, applyValue, getOptionValue]);
  if (!isSingleSelectColDef(resolvedColumn)) {
    return null;
  }
  if (!isSingleSelectColDef(resolvedColumn)) {
    return null;
  }
  const label = labelProp != null ? labelProp : apiRef2.current.getLocaleText("filterPanelInputLabel");
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(SingleSelectOperatorContainer, {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsxs(rootProps.slots.baseFormControl, {
      children: [/* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseInputLabel, _extends$1({}, (_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.baseInputLabel, {
        id: labelId,
        htmlFor: id,
        shrink: true,
        variant: "standard",
        children: label
      })), /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseSelect, _extends$1({
        id,
        label,
        labelId,
        value: filterValueState,
        onChange: onFilterChange,
        variant: "standard",
        type: type || "text",
        inputProps: {
          tabIndex,
          ref: focusElementRef,
          placeholder: placeholder != null ? placeholder : apiRef2.current.getLocaleText("filterPanelInputPlaceholder")
        },
        native: isSelectNative
      }, others, (_rootProps$slotProps3 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps3.baseSelect, {
        children: renderSingleSelectOptions({
          column: resolvedColumn,
          OptionComponent: rootProps.slots.baseSelectOption,
          getOptionLabel,
          getOptionValue,
          isSelectNative,
          baseSelectOptionProps: (_rootProps$slotProps4 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps4.baseSelectOption
        })
      }))]
    }), clearButton]
  });
}
const _excluded$u = ["item", "applyValue", "apiRef", "focusElementRef", "isFilterActive", "clearButton", "tabIndex", "label"];
const BooleanOperatorContainer = styled$1("div")({
  display: "flex",
  alignItems: "center",
  width: "100%",
  [`& button`]: {
    margin: "auto 0px 5px 5px"
  }
});
function GridFilterInputBoolean(props) {
  var _rootProps$slotProps, _baseSelectProps$nati, _rootProps$slotProps2, _rootProps$slotProps3;
  const {
    item,
    applyValue,
    apiRef: apiRef2,
    focusElementRef,
    clearButton,
    tabIndex,
    label: labelProp
  } = props, others = _objectWithoutPropertiesLoose$1(props, _excluded$u);
  const [filterValueState, setFilterValueState] = reactExports.useState(item.value || "");
  const rootProps = useGridRootProps();
  const labelId = useId();
  const selectId = useId();
  const baseSelectProps = ((_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseSelect) || {};
  const isSelectNative = (_baseSelectProps$nati = baseSelectProps.native) != null ? _baseSelectProps$nati : true;
  const baseSelectOptionProps = ((_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.baseSelectOption) || {};
  const onFilterChange = reactExports.useCallback((event) => {
    const value = event.target.value;
    setFilterValueState(value);
    applyValue(_extends$1({}, item, {
      value
    }));
  }, [applyValue, item]);
  reactExports.useEffect(() => {
    setFilterValueState(item.value || "");
  }, [item.value]);
  const label = labelProp != null ? labelProp : apiRef2.current.getLocaleText("filterPanelInputLabel");
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(BooleanOperatorContainer, {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsxs(rootProps.slots.baseFormControl, {
      fullWidth: true,
      children: [/* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseInputLabel, _extends$1({}, (_rootProps$slotProps3 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps3.baseInputLabel, {
        id: labelId,
        shrink: true,
        variant: "standard",
        children: label
      })), /* @__PURE__ */ jsxRuntimeExports.jsxs(rootProps.slots.baseSelect, _extends$1({
        labelId,
        id: selectId,
        label,
        value: filterValueState,
        onChange: onFilterChange,
        variant: "standard",
        native: isSelectNative,
        displayEmpty: true,
        inputProps: {
          ref: focusElementRef,
          tabIndex
        }
      }, others, baseSelectProps, {
        children: [/* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseSelectOption, _extends$1({}, baseSelectOptionProps, {
          native: isSelectNative,
          value: "",
          children: apiRef2.current.getLocaleText("filterValueAny")
        })), /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseSelectOption, _extends$1({}, baseSelectOptionProps, {
          native: isSelectNative,
          value: "true",
          children: apiRef2.current.getLocaleText("filterValueTrue")
        })), /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseSelectOption, _extends$1({}, baseSelectOptionProps, {
          native: isSelectNative,
          value: "false",
          children: apiRef2.current.getLocaleText("filterValueFalse")
        }))]
      }))]
    }), clearButton]
  });
}
const _excluded$t = ["logicOperators", "columnsSort", "filterFormProps", "getColumnForNewFilter", "children", "disableAddFilterButton", "disableRemoveAllButton"];
const getGridFilter = (col) => ({
  field: col.field,
  operator: col.filterOperators[0].value,
  id: Math.round(Math.random() * 1e5)
});
const GridFilterPanel = /* @__PURE__ */ reactExports.forwardRef(function GridFilterPanel2(props, ref) {
  var _rootProps$slotProps, _rootProps$slotProps2;
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const filterModel2 = useGridSelector(apiRef2, gridFilterModelSelector);
  const filterableColumns = useGridSelector(apiRef2, gridFilterableColumnDefinitionsSelector);
  const lastFilterRef = reactExports.useRef(null);
  const placeholderFilter = reactExports.useRef(null);
  const {
    logicOperators = [GridLogicOperator.And, GridLogicOperator.Or],
    columnsSort,
    filterFormProps,
    getColumnForNewFilter,
    disableAddFilterButton = false,
    disableRemoveAllButton = false
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$t);
  const applyFilter = apiRef2.current.upsertFilterItem;
  const applyFilterLogicOperator = reactExports.useCallback((operator) => {
    apiRef2.current.setFilterLogicOperator(operator);
  }, [apiRef2]);
  const getDefaultFilter = reactExports.useCallback(() => {
    let nextColumnWithOperator;
    if (getColumnForNewFilter && typeof getColumnForNewFilter === "function") {
      const nextFieldName = getColumnForNewFilter({
        currentFilters: (filterModel2 == null ? void 0 : filterModel2.items) || [],
        columns: filterableColumns
      });
      if (nextFieldName === null) {
        return null;
      }
      nextColumnWithOperator = filterableColumns.find(({
        field
      }) => field === nextFieldName);
    } else {
      nextColumnWithOperator = filterableColumns.find((colDef) => {
        var _colDef$filterOperato;
        return (_colDef$filterOperato = colDef.filterOperators) == null ? void 0 : _colDef$filterOperato.length;
      });
    }
    if (!nextColumnWithOperator) {
      return null;
    }
    return getGridFilter(nextColumnWithOperator);
  }, [filterModel2 == null ? void 0 : filterModel2.items, filterableColumns, getColumnForNewFilter]);
  const getNewFilter = reactExports.useCallback(() => {
    if (getColumnForNewFilter === void 0 || typeof getColumnForNewFilter !== "function") {
      return getDefaultFilter();
    }
    const currentFilters = filterModel2.items.length ? filterModel2.items : [getDefaultFilter()].filter(Boolean);
    const nextColumnFieldName = getColumnForNewFilter({
      currentFilters,
      columns: filterableColumns
    });
    if (nextColumnFieldName === null) {
      return null;
    }
    const nextColumnWithOperator = filterableColumns.find(({
      field
    }) => field === nextColumnFieldName);
    if (!nextColumnWithOperator) {
      return null;
    }
    return getGridFilter(nextColumnWithOperator);
  }, [filterModel2.items, filterableColumns, getColumnForNewFilter, getDefaultFilter]);
  const items2 = reactExports.useMemo(() => {
    if (filterModel2.items.length) {
      return filterModel2.items;
    }
    if (!placeholderFilter.current) {
      placeholderFilter.current = getDefaultFilter();
    }
    return placeholderFilter.current ? [placeholderFilter.current] : [];
  }, [filterModel2.items, getDefaultFilter]);
  const hasMultipleFilters = items2.length > 1;
  const addNewFilter = () => {
    const newFilter = getNewFilter();
    if (!newFilter) {
      return;
    }
    apiRef2.current.upsertFilterItems([...items2, newFilter]);
  };
  const deleteFilter = reactExports.useCallback((item) => {
    const shouldCloseFilterPanel = items2.length === 1;
    apiRef2.current.deleteFilterItem(item);
    if (shouldCloseFilterPanel) {
      apiRef2.current.hideFilterPanel();
    }
  }, [apiRef2, items2.length]);
  const handleRemoveAll = () => {
    if (items2.length === 1 && items2[0].value === void 0) {
      apiRef2.current.deleteFilterItem(items2[0]);
      apiRef2.current.hideFilterPanel();
    }
    apiRef2.current.setFilterModel(_extends$1({}, filterModel2, {
      items: []
    }));
  };
  reactExports.useEffect(() => {
    if (logicOperators.length > 0 && filterModel2.logicOperator && !logicOperators.includes(filterModel2.logicOperator)) {
      applyFilterLogicOperator(logicOperators[0]);
    }
  }, [logicOperators, applyFilterLogicOperator, filterModel2.logicOperator]);
  reactExports.useEffect(() => {
    if (items2.length > 0) {
      lastFilterRef.current.focus();
    }
  }, [items2.length]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(GridPanelWrapper, _extends$1({
    ref
  }, other, {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(GridPanelContent, {
      children: items2.map((item, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(GridFilterForm, _extends$1({
        item,
        applyFilterChanges: applyFilter,
        deleteFilter,
        hasMultipleFilters,
        showMultiFilterOperators: index > 0,
        multiFilterOperator: filterModel2.logicOperator,
        disableMultiFilterOperator: index !== 1,
        applyMultiFilterOperatorChanges: applyFilterLogicOperator,
        focusElementRef: index === items2.length - 1 ? lastFilterRef : null,
        logicOperators,
        columnsSort
      }, filterFormProps), item.id == null ? index : item.id))
    }), !rootProps.disableMultipleColumnsFiltering && !(disableAddFilterButton && disableRemoveAllButton) ? /* @__PURE__ */ jsxRuntimeExports.jsxs(GridPanelFooter, {
      children: [!disableAddFilterButton ? /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseButton, _extends$1({
        onClick: addNewFilter,
        startIcon: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.filterPanelAddIcon, {})
      }, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseButton, {
        children: apiRef2.current.getLocaleText("filterPanelAddFilter")
      })) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", {}), !disableRemoveAllButton ? /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseButton, _extends$1({
        onClick: handleRemoveAll,
        startIcon: /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.filterPanelRemoveAllIcon, {})
      }, (_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.baseButton, {
        children: apiRef2.current.getLocaleText("filterPanelRemoveAll")
      })) : null]
    }) : null]
  }));
});
function getListSubheaderUtilityClass(slot) {
  return generateUtilityClass("MuiListSubheader", slot);
}
generateUtilityClasses("MuiListSubheader", ["root", "colorPrimary", "colorInherit", "gutters", "inset", "sticky"]);
const _excluded$s = ["className", "color", "component", "disableGutters", "disableSticky", "inset"];
const useUtilityClasses$j = (ownerState) => {
  const {
    classes: classes2,
    color,
    disableGutters,
    inset,
    disableSticky
  } = ownerState;
  const slots = {
    root: ["root", color !== "default" && `color${capitalize(color)}`, !disableGutters && "gutters", inset && "inset", !disableSticky && "sticky"]
  };
  return composeClasses(slots, getListSubheaderUtilityClass, classes2);
};
const ListSubheaderRoot = styled$1("li", {
  name: "MuiListSubheader",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, ownerState.color !== "default" && styles2[`color${capitalize(ownerState.color)}`], !ownerState.disableGutters && styles2.gutters, ownerState.inset && styles2.inset, !ownerState.disableSticky && styles2.sticky];
  }
})(({
  theme,
  ownerState
}) => _extends$1({
  boxSizing: "border-box",
  lineHeight: "48px",
  listStyle: "none",
  color: (theme.vars || theme).palette.text.secondary,
  fontFamily: theme.typography.fontFamily,
  fontWeight: theme.typography.fontWeightMedium,
  fontSize: theme.typography.pxToRem(14)
}, ownerState.color === "primary" && {
  color: (theme.vars || theme).palette.primary.main
}, ownerState.color === "inherit" && {
  color: "inherit"
}, !ownerState.disableGutters && {
  paddingLeft: 16,
  paddingRight: 16
}, ownerState.inset && {
  paddingLeft: 72
}, !ownerState.disableSticky && {
  position: "sticky",
  top: 0,
  zIndex: 1,
  backgroundColor: (theme.vars || theme).palette.background.paper
}));
const ListSubheader = /* @__PURE__ */ reactExports.forwardRef(function ListSubheader2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiListSubheader"
  });
  const {
    className,
    color = "default",
    component = "li",
    disableGutters = false,
    disableSticky = false,
    inset = false
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$s);
  const ownerState = _extends$1({}, props, {
    color,
    component,
    disableGutters,
    disableSticky,
    inset
  });
  const classes2 = useUtilityClasses$j(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ListSubheaderRoot, _extends$1({
    as: component,
    className: clsx$1(classes2.root, className),
    ref,
    ownerState
  }, other));
});
ListSubheader.muiSkipListHighlight = true;
const ListSubheader$1 = ListSubheader;
const CancelIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z"
}), "Cancel");
function getChipUtilityClass(slot) {
  return generateUtilityClass("MuiChip", slot);
}
const chipClasses = generateUtilityClasses("MuiChip", ["root", "sizeSmall", "sizeMedium", "colorError", "colorInfo", "colorPrimary", "colorSecondary", "colorSuccess", "colorWarning", "disabled", "clickable", "clickableColorPrimary", "clickableColorSecondary", "deletable", "deletableColorPrimary", "deletableColorSecondary", "outlined", "filled", "outlinedPrimary", "outlinedSecondary", "filledPrimary", "filledSecondary", "avatar", "avatarSmall", "avatarMedium", "avatarColorPrimary", "avatarColorSecondary", "icon", "iconSmall", "iconMedium", "iconColorPrimary", "iconColorSecondary", "label", "labelSmall", "labelMedium", "deleteIcon", "deleteIconSmall", "deleteIconMedium", "deleteIconColorPrimary", "deleteIconColorSecondary", "deleteIconOutlinedColorPrimary", "deleteIconOutlinedColorSecondary", "deleteIconFilledColorPrimary", "deleteIconFilledColorSecondary", "focusVisible"]);
const chipClasses$1 = chipClasses;
const _excluded$r = ["avatar", "className", "clickable", "color", "component", "deleteIcon", "disabled", "icon", "label", "onClick", "onDelete", "onKeyDown", "onKeyUp", "size", "variant", "tabIndex", "skipFocusWhenDisabled"];
const useUtilityClasses$i = (ownerState) => {
  const {
    classes: classes2,
    disabled,
    size,
    color,
    iconColor,
    onDelete,
    clickable,
    variant
  } = ownerState;
  const slots = {
    root: ["root", variant, disabled && "disabled", `size${capitalize(size)}`, `color${capitalize(color)}`, clickable && "clickable", clickable && `clickableColor${capitalize(color)}`, onDelete && "deletable", onDelete && `deletableColor${capitalize(color)}`, `${variant}${capitalize(color)}`],
    label: ["label", `label${capitalize(size)}`],
    avatar: ["avatar", `avatar${capitalize(size)}`, `avatarColor${capitalize(color)}`],
    icon: ["icon", `icon${capitalize(size)}`, `iconColor${capitalize(iconColor)}`],
    deleteIcon: ["deleteIcon", `deleteIcon${capitalize(size)}`, `deleteIconColor${capitalize(color)}`, `deleteIcon${capitalize(variant)}Color${capitalize(color)}`]
  };
  return composeClasses(slots, getChipUtilityClass, classes2);
};
const ChipRoot = styled$1("div", {
  name: "MuiChip",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    const {
      color,
      iconColor,
      clickable,
      onDelete,
      size,
      variant
    } = ownerState;
    return [{
      [`& .${chipClasses$1.avatar}`]: styles2.avatar
    }, {
      [`& .${chipClasses$1.avatar}`]: styles2[`avatar${capitalize(size)}`]
    }, {
      [`& .${chipClasses$1.avatar}`]: styles2[`avatarColor${capitalize(color)}`]
    }, {
      [`& .${chipClasses$1.icon}`]: styles2.icon
    }, {
      [`& .${chipClasses$1.icon}`]: styles2[`icon${capitalize(size)}`]
    }, {
      [`& .${chipClasses$1.icon}`]: styles2[`iconColor${capitalize(iconColor)}`]
    }, {
      [`& .${chipClasses$1.deleteIcon}`]: styles2.deleteIcon
    }, {
      [`& .${chipClasses$1.deleteIcon}`]: styles2[`deleteIcon${capitalize(size)}`]
    }, {
      [`& .${chipClasses$1.deleteIcon}`]: styles2[`deleteIconColor${capitalize(color)}`]
    }, {
      [`& .${chipClasses$1.deleteIcon}`]: styles2[`deleteIcon${capitalize(variant)}Color${capitalize(color)}`]
    }, styles2.root, styles2[`size${capitalize(size)}`], styles2[`color${capitalize(color)}`], clickable && styles2.clickable, clickable && color !== "default" && styles2[`clickableColor${capitalize(color)})`], onDelete && styles2.deletable, onDelete && color !== "default" && styles2[`deletableColor${capitalize(color)}`], styles2[variant], styles2[`${variant}${capitalize(color)}`]];
  }
})(({
  theme,
  ownerState
}) => {
  const textColor = theme.palette.mode === "light" ? theme.palette.grey[700] : theme.palette.grey[300];
  return _extends$1({
    maxWidth: "100%",
    fontFamily: theme.typography.fontFamily,
    fontSize: theme.typography.pxToRem(13),
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    height: 32,
    color: (theme.vars || theme).palette.text.primary,
    backgroundColor: (theme.vars || theme).palette.action.selected,
    borderRadius: 32 / 2,
    whiteSpace: "nowrap",
    transition: theme.transitions.create(["background-color", "box-shadow"]),
    // We disable the focus ring for mouse, touch and keyboard users.
    outline: 0,
    textDecoration: "none",
    border: 0,
    // Remove `button` border
    padding: 0,
    // Remove `button` padding
    verticalAlign: "middle",
    boxSizing: "border-box",
    [`&.${chipClasses$1.disabled}`]: {
      opacity: (theme.vars || theme).palette.action.disabledOpacity,
      pointerEvents: "none"
    },
    [`& .${chipClasses$1.avatar}`]: {
      marginLeft: 5,
      marginRight: -6,
      width: 24,
      height: 24,
      color: theme.vars ? theme.vars.palette.Chip.defaultAvatarColor : textColor,
      fontSize: theme.typography.pxToRem(12)
    },
    [`& .${chipClasses$1.avatarColorPrimary}`]: {
      color: (theme.vars || theme).palette.primary.contrastText,
      backgroundColor: (theme.vars || theme).palette.primary.dark
    },
    [`& .${chipClasses$1.avatarColorSecondary}`]: {
      color: (theme.vars || theme).palette.secondary.contrastText,
      backgroundColor: (theme.vars || theme).palette.secondary.dark
    },
    [`& .${chipClasses$1.avatarSmall}`]: {
      marginLeft: 4,
      marginRight: -4,
      width: 18,
      height: 18,
      fontSize: theme.typography.pxToRem(10)
    },
    [`& .${chipClasses$1.icon}`]: _extends$1({
      marginLeft: 5,
      marginRight: -6
    }, ownerState.size === "small" && {
      fontSize: 18,
      marginLeft: 4,
      marginRight: -4
    }, ownerState.iconColor === ownerState.color && _extends$1({
      color: theme.vars ? theme.vars.palette.Chip.defaultIconColor : textColor
    }, ownerState.color !== "default" && {
      color: "inherit"
    })),
    [`& .${chipClasses$1.deleteIcon}`]: _extends$1({
      WebkitTapHighlightColor: "transparent",
      color: theme.vars ? `rgba(${theme.vars.palette.text.primaryChannel} / 0.26)` : alpha(theme.palette.text.primary, 0.26),
      fontSize: 22,
      cursor: "pointer",
      margin: "0 5px 0 -6px",
      "&:hover": {
        color: theme.vars ? `rgba(${theme.vars.palette.text.primaryChannel} / 0.4)` : alpha(theme.palette.text.primary, 0.4)
      }
    }, ownerState.size === "small" && {
      fontSize: 16,
      marginRight: 4,
      marginLeft: -4
    }, ownerState.color !== "default" && {
      color: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].contrastTextChannel} / 0.7)` : alpha(theme.palette[ownerState.color].contrastText, 0.7),
      "&:hover, &:active": {
        color: (theme.vars || theme).palette[ownerState.color].contrastText
      }
    })
  }, ownerState.size === "small" && {
    height: 24
  }, ownerState.color !== "default" && {
    backgroundColor: (theme.vars || theme).palette[ownerState.color].main,
    color: (theme.vars || theme).palette[ownerState.color].contrastText
  }, ownerState.onDelete && {
    [`&.${chipClasses$1.focusVisible}`]: {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.action.selectedChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.focusOpacity}))` : alpha(theme.palette.action.selected, theme.palette.action.selectedOpacity + theme.palette.action.focusOpacity)
    }
  }, ownerState.onDelete && ownerState.color !== "default" && {
    [`&.${chipClasses$1.focusVisible}`]: {
      backgroundColor: (theme.vars || theme).palette[ownerState.color].dark
    }
  });
}, ({
  theme,
  ownerState
}) => _extends$1({}, ownerState.clickable && {
  userSelect: "none",
  WebkitTapHighlightColor: "transparent",
  cursor: "pointer",
  "&:hover": {
    backgroundColor: theme.vars ? `rgba(${theme.vars.palette.action.selectedChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.hoverOpacity}))` : alpha(theme.palette.action.selected, theme.palette.action.selectedOpacity + theme.palette.action.hoverOpacity)
  },
  [`&.${chipClasses$1.focusVisible}`]: {
    backgroundColor: theme.vars ? `rgba(${theme.vars.palette.action.selectedChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.focusOpacity}))` : alpha(theme.palette.action.selected, theme.palette.action.selectedOpacity + theme.palette.action.focusOpacity)
  },
  "&:active": {
    boxShadow: (theme.vars || theme).shadows[1]
  }
}, ownerState.clickable && ownerState.color !== "default" && {
  [`&:hover, &.${chipClasses$1.focusVisible}`]: {
    backgroundColor: (theme.vars || theme).palette[ownerState.color].dark
  }
}), ({
  theme,
  ownerState
}) => _extends$1({}, ownerState.variant === "outlined" && {
  backgroundColor: "transparent",
  border: theme.vars ? `1px solid ${theme.vars.palette.Chip.defaultBorder}` : `1px solid ${theme.palette.mode === "light" ? theme.palette.grey[400] : theme.palette.grey[700]}`,
  [`&.${chipClasses$1.clickable}:hover`]: {
    backgroundColor: (theme.vars || theme).palette.action.hover
  },
  [`&.${chipClasses$1.focusVisible}`]: {
    backgroundColor: (theme.vars || theme).palette.action.focus
  },
  [`& .${chipClasses$1.avatar}`]: {
    marginLeft: 4
  },
  [`& .${chipClasses$1.avatarSmall}`]: {
    marginLeft: 2
  },
  [`& .${chipClasses$1.icon}`]: {
    marginLeft: 4
  },
  [`& .${chipClasses$1.iconSmall}`]: {
    marginLeft: 2
  },
  [`& .${chipClasses$1.deleteIcon}`]: {
    marginRight: 5
  },
  [`& .${chipClasses$1.deleteIconSmall}`]: {
    marginRight: 3
  }
}, ownerState.variant === "outlined" && ownerState.color !== "default" && {
  color: (theme.vars || theme).palette[ownerState.color].main,
  border: `1px solid ${theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / 0.7)` : alpha(theme.palette[ownerState.color].main, 0.7)}`,
  [`&.${chipClasses$1.clickable}:hover`]: {
    backgroundColor: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(theme.palette[ownerState.color].main, theme.palette.action.hoverOpacity)
  },
  [`&.${chipClasses$1.focusVisible}`]: {
    backgroundColor: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / ${theme.vars.palette.action.focusOpacity})` : alpha(theme.palette[ownerState.color].main, theme.palette.action.focusOpacity)
  },
  [`& .${chipClasses$1.deleteIcon}`]: {
    color: theme.vars ? `rgba(${theme.vars.palette[ownerState.color].mainChannel} / 0.7)` : alpha(theme.palette[ownerState.color].main, 0.7),
    "&:hover, &:active": {
      color: (theme.vars || theme).palette[ownerState.color].main
    }
  }
}));
const ChipLabel = styled$1("span", {
  name: "MuiChip",
  slot: "Label",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    const {
      size
    } = ownerState;
    return [styles2.label, styles2[`label${capitalize(size)}`]];
  }
})(({
  ownerState
}) => _extends$1({
  overflow: "hidden",
  textOverflow: "ellipsis",
  paddingLeft: 12,
  paddingRight: 12,
  whiteSpace: "nowrap"
}, ownerState.size === "small" && {
  paddingLeft: 8,
  paddingRight: 8
}));
function isDeleteKeyboardEvent(keyboardEvent) {
  return keyboardEvent.key === "Backspace" || keyboardEvent.key === "Delete";
}
const Chip = /* @__PURE__ */ reactExports.forwardRef(function Chip2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiChip"
  });
  const {
    avatar: avatarProp,
    className,
    clickable: clickableProp,
    color = "default",
    component: ComponentProp,
    deleteIcon: deleteIconProp,
    disabled = false,
    icon: iconProp,
    label,
    onClick,
    onDelete,
    onKeyDown,
    onKeyUp,
    size = "medium",
    variant = "filled",
    tabIndex,
    skipFocusWhenDisabled = false
    // TODO v6: Rename to `focusableWhenDisabled`.
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$r);
  const chipRef = reactExports.useRef(null);
  const handleRef = useForkRef$1(chipRef, ref);
  const handleDeleteIconClick = (event) => {
    event.stopPropagation();
    if (onDelete) {
      onDelete(event);
    }
  };
  const handleKeyDown = (event) => {
    if (event.currentTarget === event.target && isDeleteKeyboardEvent(event)) {
      event.preventDefault();
    }
    if (onKeyDown) {
      onKeyDown(event);
    }
  };
  const handleKeyUp = (event) => {
    if (event.currentTarget === event.target) {
      if (onDelete && isDeleteKeyboardEvent(event)) {
        onDelete(event);
      } else if (event.key === "Escape" && chipRef.current) {
        chipRef.current.blur();
      }
    }
    if (onKeyUp) {
      onKeyUp(event);
    }
  };
  const clickable = clickableProp !== false && onClick ? true : clickableProp;
  const component = clickable || onDelete ? ButtonBase : ComponentProp || "div";
  const ownerState = _extends$1({}, props, {
    component,
    disabled,
    size,
    color,
    iconColor: /* @__PURE__ */ reactExports.isValidElement(iconProp) ? iconProp.props.color || color : color,
    onDelete: !!onDelete,
    clickable,
    variant
  });
  const classes2 = useUtilityClasses$i(ownerState);
  const moreProps = component === ButtonBase ? _extends$1({
    component: ComponentProp || "div",
    focusVisibleClassName: classes2.focusVisible
  }, onDelete && {
    disableRipple: true
  }) : {};
  let deleteIcon = null;
  if (onDelete) {
    deleteIcon = deleteIconProp && /* @__PURE__ */ reactExports.isValidElement(deleteIconProp) ? /* @__PURE__ */ reactExports.cloneElement(deleteIconProp, {
      className: clsx$1(deleteIconProp.props.className, classes2.deleteIcon),
      onClick: handleDeleteIconClick
    }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CancelIcon, {
      className: clsx$1(classes2.deleteIcon),
      onClick: handleDeleteIconClick
    });
  }
  let avatar = null;
  if (avatarProp && /* @__PURE__ */ reactExports.isValidElement(avatarProp)) {
    avatar = /* @__PURE__ */ reactExports.cloneElement(avatarProp, {
      className: clsx$1(classes2.avatar, avatarProp.props.className)
    });
  }
  let icon = null;
  if (iconProp && /* @__PURE__ */ reactExports.isValidElement(iconProp)) {
    icon = /* @__PURE__ */ reactExports.cloneElement(iconProp, {
      className: clsx$1(classes2.icon, iconProp.props.className)
    });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(ChipRoot, _extends$1({
    as: component,
    className: clsx$1(classes2.root, className),
    disabled: clickable && disabled ? true : void 0,
    onClick,
    onKeyDown: handleKeyDown,
    onKeyUp: handleKeyUp,
    ref: handleRef,
    tabIndex: skipFocusWhenDisabled && disabled ? -1 : tabIndex,
    ownerState
  }, moreProps, other, {
    children: [avatar || icon, /* @__PURE__ */ jsxRuntimeExports.jsx(ChipLabel, {
      className: clsx$1(classes2.label),
      ownerState,
      children: label
    }), deleteIcon]
  }));
});
const MUIChip = Chip;
const CloseIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
}), "Close");
function getAutocompleteUtilityClass(slot) {
  return generateUtilityClass("MuiAutocomplete", slot);
}
const autocompleteClasses = generateUtilityClasses("MuiAutocomplete", ["root", "expanded", "fullWidth", "focused", "focusVisible", "tag", "tagSizeSmall", "tagSizeMedium", "hasPopupIcon", "hasClearIcon", "inputRoot", "input", "inputFocused", "endAdornment", "clearIndicator", "popupIndicator", "popupIndicatorOpen", "popper", "popperDisablePortal", "paper", "listbox", "loading", "noOptions", "option", "groupLabel", "groupUl"]);
const autocompleteClasses$1 = autocompleteClasses;
var _ClearIcon, _ArrowDropDownIcon;
const _excluded$q = ["autoComplete", "autoHighlight", "autoSelect", "blurOnSelect", "ChipProps", "className", "clearIcon", "clearOnBlur", "clearOnEscape", "clearText", "closeText", "componentsProps", "defaultValue", "disableClearable", "disableCloseOnSelect", "disabled", "disabledItemsFocusable", "disableListWrap", "disablePortal", "filterOptions", "filterSelectedOptions", "forcePopupIcon", "freeSolo", "fullWidth", "getLimitTagsText", "getOptionDisabled", "getOptionLabel", "isOptionEqualToValue", "groupBy", "handleHomeEndKeys", "id", "includeInputInList", "inputValue", "limitTags", "ListboxComponent", "ListboxProps", "loading", "loadingText", "multiple", "noOptionsText", "onChange", "onClose", "onHighlightChange", "onInputChange", "onOpen", "open", "openOnFocus", "openText", "options", "PaperComponent", "PopperComponent", "popupIcon", "readOnly", "renderGroup", "renderInput", "renderOption", "renderTags", "selectOnFocus", "size", "slotProps", "value"], _excluded2$4 = ["ref"];
const useUtilityClasses$h = (ownerState) => {
  const {
    classes: classes2,
    disablePortal,
    expanded,
    focused,
    fullWidth,
    hasClearIcon,
    hasPopupIcon,
    inputFocused,
    popupOpen,
    size
  } = ownerState;
  const slots = {
    root: ["root", expanded && "expanded", focused && "focused", fullWidth && "fullWidth", hasClearIcon && "hasClearIcon", hasPopupIcon && "hasPopupIcon"],
    inputRoot: ["inputRoot"],
    input: ["input", inputFocused && "inputFocused"],
    tag: ["tag", `tagSize${capitalize(size)}`],
    endAdornment: ["endAdornment"],
    clearIndicator: ["clearIndicator"],
    popupIndicator: ["popupIndicator", popupOpen && "popupIndicatorOpen"],
    popper: ["popper", disablePortal && "popperDisablePortal"],
    paper: ["paper"],
    listbox: ["listbox"],
    loading: ["loading"],
    noOptions: ["noOptions"],
    option: ["option"],
    groupLabel: ["groupLabel"],
    groupUl: ["groupUl"]
  };
  return composeClasses(slots, getAutocompleteUtilityClass, classes2);
};
const AutocompleteRoot = styled$1("div", {
  name: "MuiAutocomplete",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    const {
      fullWidth,
      hasClearIcon,
      hasPopupIcon,
      inputFocused,
      size
    } = ownerState;
    return [{
      [`& .${autocompleteClasses$1.tag}`]: styles2.tag
    }, {
      [`& .${autocompleteClasses$1.tag}`]: styles2[`tagSize${capitalize(size)}`]
    }, {
      [`& .${autocompleteClasses$1.inputRoot}`]: styles2.inputRoot
    }, {
      [`& .${autocompleteClasses$1.input}`]: styles2.input
    }, {
      [`& .${autocompleteClasses$1.input}`]: inputFocused && styles2.inputFocused
    }, styles2.root, fullWidth && styles2.fullWidth, hasPopupIcon && styles2.hasPopupIcon, hasClearIcon && styles2.hasClearIcon];
  }
})(({
  ownerState
}) => _extends$1({
  [`&.${autocompleteClasses$1.focused} .${autocompleteClasses$1.clearIndicator}`]: {
    visibility: "visible"
  },
  /* Avoid double tap issue on iOS */
  "@media (pointer: fine)": {
    [`&:hover .${autocompleteClasses$1.clearIndicator}`]: {
      visibility: "visible"
    }
  }
}, ownerState.fullWidth && {
  width: "100%"
}, {
  [`& .${autocompleteClasses$1.tag}`]: _extends$1({
    margin: 3,
    maxWidth: "calc(100% - 6px)"
  }, ownerState.size === "small" && {
    margin: 2,
    maxWidth: "calc(100% - 4px)"
  }),
  [`& .${autocompleteClasses$1.inputRoot}`]: {
    flexWrap: "wrap",
    [`.${autocompleteClasses$1.hasPopupIcon}&, .${autocompleteClasses$1.hasClearIcon}&`]: {
      paddingRight: 26 + 4
    },
    [`.${autocompleteClasses$1.hasPopupIcon}.${autocompleteClasses$1.hasClearIcon}&`]: {
      paddingRight: 52 + 4
    },
    [`& .${autocompleteClasses$1.input}`]: {
      width: 0,
      minWidth: 30
    }
  },
  [`& .${inputClasses.root}`]: {
    paddingBottom: 1,
    "& .MuiInput-input": {
      padding: "4px 4px 4px 0px"
    }
  },
  [`& .${inputClasses.root}.${inputBaseClasses.sizeSmall}`]: {
    [`& .${inputClasses.input}`]: {
      padding: "2px 4px 3px 0"
    }
  },
  [`& .${outlinedInputClasses.root}`]: {
    padding: 9,
    [`.${autocompleteClasses$1.hasPopupIcon}&, .${autocompleteClasses$1.hasClearIcon}&`]: {
      paddingRight: 26 + 4 + 9
    },
    [`.${autocompleteClasses$1.hasPopupIcon}.${autocompleteClasses$1.hasClearIcon}&`]: {
      paddingRight: 52 + 4 + 9
    },
    [`& .${autocompleteClasses$1.input}`]: {
      padding: "7.5px 4px 7.5px 5px"
    },
    [`& .${autocompleteClasses$1.endAdornment}`]: {
      right: 9
    }
  },
  [`& .${outlinedInputClasses.root}.${inputBaseClasses.sizeSmall}`]: {
    // Don't specify paddingRight, as it overrides the default value set when there is only
    // one of the popup or clear icon as the specificity is equal so the latter one wins
    paddingTop: 6,
    paddingBottom: 6,
    paddingLeft: 6,
    [`& .${autocompleteClasses$1.input}`]: {
      padding: "2.5px 4px 2.5px 8px"
    }
  },
  [`& .${filledInputClasses.root}`]: {
    paddingTop: 19,
    paddingLeft: 8,
    [`.${autocompleteClasses$1.hasPopupIcon}&, .${autocompleteClasses$1.hasClearIcon}&`]: {
      paddingRight: 26 + 4 + 9
    },
    [`.${autocompleteClasses$1.hasPopupIcon}.${autocompleteClasses$1.hasClearIcon}&`]: {
      paddingRight: 52 + 4 + 9
    },
    [`& .${filledInputClasses.input}`]: {
      padding: "7px 4px"
    },
    [`& .${autocompleteClasses$1.endAdornment}`]: {
      right: 9
    }
  },
  [`& .${filledInputClasses.root}.${inputBaseClasses.sizeSmall}`]: {
    paddingBottom: 1,
    [`& .${filledInputClasses.input}`]: {
      padding: "2.5px 4px"
    }
  },
  [`& .${inputBaseClasses.hiddenLabel}`]: {
    paddingTop: 8
  },
  [`& .${filledInputClasses.root}.${inputBaseClasses.hiddenLabel}`]: {
    paddingTop: 0,
    paddingBottom: 0,
    [`& .${autocompleteClasses$1.input}`]: {
      paddingTop: 16,
      paddingBottom: 17
    }
  },
  [`& .${filledInputClasses.root}.${inputBaseClasses.hiddenLabel}.${inputBaseClasses.sizeSmall}`]: {
    [`& .${autocompleteClasses$1.input}`]: {
      paddingTop: 8,
      paddingBottom: 9
    }
  },
  [`& .${autocompleteClasses$1.input}`]: _extends$1({
    flexGrow: 1,
    textOverflow: "ellipsis",
    opacity: 0
  }, ownerState.inputFocused && {
    opacity: 1
  })
}));
const AutocompleteEndAdornment = styled$1("div", {
  name: "MuiAutocomplete",
  slot: "EndAdornment",
  overridesResolver: (props, styles2) => styles2.endAdornment
})({
  // We use a position absolute to support wrapping tags.
  position: "absolute",
  right: 0,
  top: "calc(50% - 14px)"
  // Center vertically
});
const AutocompleteClearIndicator = styled$1(IconButton$1, {
  name: "MuiAutocomplete",
  slot: "ClearIndicator",
  overridesResolver: (props, styles2) => styles2.clearIndicator
})({
  marginRight: -2,
  padding: 4,
  visibility: "hidden"
});
const AutocompletePopupIndicator = styled$1(IconButton$1, {
  name: "MuiAutocomplete",
  slot: "PopupIndicator",
  overridesResolver: ({
    ownerState
  }, styles2) => _extends$1({}, styles2.popupIndicator, ownerState.popupOpen && styles2.popupIndicatorOpen)
})(({
  ownerState
}) => _extends$1({
  padding: 2,
  marginRight: -2
}, ownerState.popupOpen && {
  transform: "rotate(180deg)"
}));
const AutocompletePopper = styled$1(MUIPopper, {
  name: "MuiAutocomplete",
  slot: "Popper",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [{
      [`& .${autocompleteClasses$1.option}`]: styles2.option
    }, styles2.popper, ownerState.disablePortal && styles2.popperDisablePortal];
  }
})(({
  theme,
  ownerState
}) => _extends$1({
  zIndex: (theme.vars || theme).zIndex.modal
}, ownerState.disablePortal && {
  position: "absolute"
}));
const AutocompletePaper = styled$1(Paper, {
  name: "MuiAutocomplete",
  slot: "Paper",
  overridesResolver: (props, styles2) => styles2.paper
})(({
  theme
}) => _extends$1({}, theme.typography.body1, {
  overflow: "auto"
}));
const AutocompleteLoading = styled$1("div", {
  name: "MuiAutocomplete",
  slot: "Loading",
  overridesResolver: (props, styles2) => styles2.loading
})(({
  theme
}) => ({
  color: (theme.vars || theme).palette.text.secondary,
  padding: "14px 16px"
}));
const AutocompleteNoOptions = styled$1("div", {
  name: "MuiAutocomplete",
  slot: "NoOptions",
  overridesResolver: (props, styles2) => styles2.noOptions
})(({
  theme
}) => ({
  color: (theme.vars || theme).palette.text.secondary,
  padding: "14px 16px"
}));
const AutocompleteListbox = styled$1("div", {
  name: "MuiAutocomplete",
  slot: "Listbox",
  overridesResolver: (props, styles2) => styles2.listbox
})(({
  theme
}) => ({
  listStyle: "none",
  margin: 0,
  padding: "8px 0",
  maxHeight: "40vh",
  overflow: "auto",
  position: "relative",
  [`& .${autocompleteClasses$1.option}`]: {
    minHeight: 48,
    display: "flex",
    overflow: "hidden",
    justifyContent: "flex-start",
    alignItems: "center",
    cursor: "pointer",
    paddingTop: 6,
    boxSizing: "border-box",
    outline: "0",
    WebkitTapHighlightColor: "transparent",
    paddingBottom: 6,
    paddingLeft: 16,
    paddingRight: 16,
    [theme.breakpoints.up("sm")]: {
      minHeight: "auto"
    },
    [`&.${autocompleteClasses$1.focused}`]: {
      backgroundColor: (theme.vars || theme).palette.action.hover,
      // Reset on touch devices, it doesn't add specificity
      "@media (hover: none)": {
        backgroundColor: "transparent"
      }
    },
    '&[aria-disabled="true"]': {
      opacity: (theme.vars || theme).palette.action.disabledOpacity,
      pointerEvents: "none"
    },
    [`&.${autocompleteClasses$1.focusVisible}`]: {
      backgroundColor: (theme.vars || theme).palette.action.focus
    },
    '&[aria-selected="true"]': {
      backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.selectedOpacity})` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity),
      [`&.${autocompleteClasses$1.focused}`]: {
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.hoverOpacity}))` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.hoverOpacity),
        // Reset on touch devices, it doesn't add specificity
        "@media (hover: none)": {
          backgroundColor: (theme.vars || theme).palette.action.selected
        }
      },
      [`&.${autocompleteClasses$1.focusVisible}`]: {
        backgroundColor: theme.vars ? `rgba(${theme.vars.palette.primary.mainChannel} / calc(${theme.vars.palette.action.selectedOpacity} + ${theme.vars.palette.action.focusOpacity}))` : alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity + theme.palette.action.focusOpacity)
      }
    }
  }
}));
const AutocompleteGroupLabel = styled$1(ListSubheader$1, {
  name: "MuiAutocomplete",
  slot: "GroupLabel",
  overridesResolver: (props, styles2) => styles2.groupLabel
})(({
  theme
}) => ({
  backgroundColor: (theme.vars || theme).palette.background.paper,
  top: -8
}));
const AutocompleteGroupUl = styled$1("ul", {
  name: "MuiAutocomplete",
  slot: "GroupUl",
  overridesResolver: (props, styles2) => styles2.groupUl
})({
  padding: 0,
  [`& .${autocompleteClasses$1.option}`]: {
    paddingLeft: 24
  }
});
const Autocomplete = /* @__PURE__ */ reactExports.forwardRef(function Autocomplete2(inProps, ref) {
  var _slotProps$clearIndic, _slotProps$paper, _slotProps$popper, _slotProps$popupIndic;
  const props = useThemeProps({
    props: inProps,
    name: "MuiAutocomplete"
  });
  const {
    autoComplete = false,
    autoHighlight = false,
    autoSelect = false,
    blurOnSelect = false,
    ChipProps,
    className,
    clearIcon = _ClearIcon || (_ClearIcon = /* @__PURE__ */ jsxRuntimeExports.jsx(CloseIcon, {
      fontSize: "small"
    })),
    clearOnBlur = !props.freeSolo,
    clearOnEscape = false,
    clearText = "Clear",
    closeText = "Close",
    componentsProps = {},
    defaultValue = props.multiple ? [] : null,
    disableClearable = false,
    disableCloseOnSelect = false,
    disabled = false,
    disabledItemsFocusable = false,
    disableListWrap = false,
    disablePortal = false,
    filterSelectedOptions = false,
    forcePopupIcon = "auto",
    freeSolo = false,
    fullWidth = false,
    getLimitTagsText = (more) => `+${more}`,
    getOptionLabel: getOptionLabelProp,
    groupBy,
    handleHomeEndKeys = !props.freeSolo,
    includeInputInList = false,
    limitTags = -1,
    ListboxComponent = "ul",
    ListboxProps,
    loading = false,
    loadingText = "Loading…",
    multiple = false,
    noOptionsText = "No options",
    openOnFocus = false,
    openText = "Open",
    PaperComponent = Paper,
    PopperComponent = MUIPopper,
    popupIcon = _ArrowDropDownIcon || (_ArrowDropDownIcon = /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowDropDownIcon, {})),
    readOnly = false,
    renderGroup: renderGroupProp,
    renderInput,
    renderOption: renderOptionProp,
    renderTags,
    selectOnFocus = !props.freeSolo,
    size = "medium",
    slotProps = {}
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$q);
  const {
    getRootProps,
    getInputProps,
    getInputLabelProps,
    getPopupIndicatorProps,
    getClearProps,
    getTagProps,
    getListboxProps,
    getOptionProps,
    value,
    dirty,
    expanded,
    id,
    popupOpen,
    focused,
    focusedTag,
    anchorEl,
    setAnchorEl,
    inputValue,
    groupedOptions
  } = useAutocomplete(_extends$1({}, props, {
    componentName: "Autocomplete"
  }));
  const hasClearIcon = !disableClearable && !disabled && dirty && !readOnly;
  const hasPopupIcon = (!freeSolo || forcePopupIcon === true) && forcePopupIcon !== false;
  const {
    onMouseDown: handleInputMouseDown
  } = getInputProps();
  const {
    ref: externalListboxRef
  } = ListboxProps != null ? ListboxProps : {};
  const _getListboxProps = getListboxProps(), {
    ref: listboxRef
  } = _getListboxProps, otherListboxProps = _objectWithoutPropertiesLoose$1(_getListboxProps, _excluded2$4);
  const combinedListboxRef = useForkRef$1(listboxRef, externalListboxRef);
  const defaultGetOptionLabel2 = (option) => {
    var _option$label;
    return (_option$label = option.label) != null ? _option$label : option;
  };
  const getOptionLabel = getOptionLabelProp || defaultGetOptionLabel2;
  const ownerState = _extends$1({}, props, {
    disablePortal,
    expanded,
    focused,
    fullWidth,
    getOptionLabel,
    hasClearIcon,
    hasPopupIcon,
    inputFocused: focusedTag === -1,
    popupOpen,
    size
  });
  const classes2 = useUtilityClasses$h(ownerState);
  let startAdornment;
  if (multiple && value.length > 0) {
    const getCustomizedTagProps = (params) => _extends$1({
      className: classes2.tag,
      disabled
    }, getTagProps(params));
    if (renderTags) {
      startAdornment = renderTags(value, getCustomizedTagProps, ownerState);
    } else {
      startAdornment = value.map((option, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(MUIChip, _extends$1({
        label: getOptionLabel(option),
        size
      }, getCustomizedTagProps({
        index
      }), ChipProps)));
    }
  }
  if (limitTags > -1 && Array.isArray(startAdornment)) {
    const more = startAdornment.length - limitTags;
    if (!focused && more > 0) {
      startAdornment = startAdornment.splice(0, limitTags);
      startAdornment.push(/* @__PURE__ */ jsxRuntimeExports.jsx("span", {
        className: classes2.tag,
        children: getLimitTagsText(more)
      }, startAdornment.length));
    }
  }
  const defaultRenderGroup = (params) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(AutocompleteGroupLabel, {
      className: classes2.groupLabel,
      ownerState,
      component: "div",
      children: params.group
    }), /* @__PURE__ */ jsxRuntimeExports.jsx(AutocompleteGroupUl, {
      className: classes2.groupUl,
      ownerState,
      children: params.children
    })]
  }, params.key);
  const renderGroup = renderGroupProp || defaultRenderGroup;
  const defaultRenderOption = (props2, option) => /* @__PURE__ */ jsxRuntimeExports.jsx("li", _extends$1({}, props2, {
    children: getOptionLabel(option)
  }));
  const renderOption = renderOptionProp || defaultRenderOption;
  const renderListOption = (option, index) => {
    const optionProps = getOptionProps({
      option,
      index
    });
    return renderOption(_extends$1({}, optionProps, {
      className: classes2.option
    }), option, {
      selected: optionProps["aria-selected"],
      index,
      inputValue
    }, ownerState);
  };
  const clearIndicatorSlotProps = (_slotProps$clearIndic = slotProps.clearIndicator) != null ? _slotProps$clearIndic : componentsProps.clearIndicator;
  const paperSlotProps = (_slotProps$paper = slotProps.paper) != null ? _slotProps$paper : componentsProps.paper;
  const popperSlotProps = (_slotProps$popper = slotProps.popper) != null ? _slotProps$popper : componentsProps.popper;
  const popupIndicatorSlotProps = (_slotProps$popupIndic = slotProps.popupIndicator) != null ? _slotProps$popupIndic : componentsProps.popupIndicator;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(AutocompleteRoot, _extends$1({
      ref,
      className: clsx$1(classes2.root, className),
      ownerState
    }, getRootProps(other), {
      children: renderInput({
        id,
        disabled,
        fullWidth: true,
        size: size === "small" ? "small" : void 0,
        InputLabelProps: getInputLabelProps(),
        InputProps: _extends$1({
          ref: setAnchorEl,
          className: classes2.inputRoot,
          startAdornment,
          onClick: (event) => {
            if (event.target === event.currentTarget) {
              handleInputMouseDown(event);
            }
          }
        }, (hasClearIcon || hasPopupIcon) && {
          endAdornment: /* @__PURE__ */ jsxRuntimeExports.jsxs(AutocompleteEndAdornment, {
            className: classes2.endAdornment,
            ownerState,
            children: [hasClearIcon ? /* @__PURE__ */ jsxRuntimeExports.jsx(AutocompleteClearIndicator, _extends$1({}, getClearProps(), {
              "aria-label": clearText,
              title: clearText,
              ownerState
            }, clearIndicatorSlotProps, {
              className: clsx$1(classes2.clearIndicator, clearIndicatorSlotProps == null ? void 0 : clearIndicatorSlotProps.className),
              children: clearIcon
            })) : null, hasPopupIcon ? /* @__PURE__ */ jsxRuntimeExports.jsx(AutocompletePopupIndicator, _extends$1({}, getPopupIndicatorProps(), {
              disabled,
              "aria-label": popupOpen ? closeText : openText,
              title: popupOpen ? closeText : openText,
              ownerState
            }, popupIndicatorSlotProps, {
              className: clsx$1(classes2.popupIndicator, popupIndicatorSlotProps == null ? void 0 : popupIndicatorSlotProps.className),
              children: popupIcon
            })) : null]
          })
        }),
        inputProps: _extends$1({
          className: classes2.input,
          disabled,
          readOnly
        }, getInputProps())
      })
    })), anchorEl ? /* @__PURE__ */ jsxRuntimeExports.jsx(AutocompletePopper, _extends$1({
      as: PopperComponent,
      disablePortal,
      style: {
        width: anchorEl ? anchorEl.clientWidth : null
      },
      ownerState,
      role: "presentation",
      anchorEl,
      open: popupOpen
    }, popperSlotProps, {
      className: clsx$1(classes2.popper, popperSlotProps == null ? void 0 : popperSlotProps.className),
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(AutocompletePaper, _extends$1({
        ownerState,
        as: PaperComponent
      }, paperSlotProps, {
        className: clsx$1(classes2.paper, paperSlotProps == null ? void 0 : paperSlotProps.className),
        children: [loading && groupedOptions.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(AutocompleteLoading, {
          className: classes2.loading,
          ownerState,
          children: loadingText
        }) : null, groupedOptions.length === 0 && !freeSolo && !loading ? /* @__PURE__ */ jsxRuntimeExports.jsx(AutocompleteNoOptions, {
          className: classes2.noOptions,
          ownerState,
          role: "presentation",
          onMouseDown: (event) => {
            event.preventDefault();
          },
          children: noOptionsText
        }) : null, groupedOptions.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(AutocompleteListbox, _extends$1({
          as: ListboxComponent,
          className: classes2.listbox,
          ownerState
        }, otherListboxProps, ListboxProps, {
          ref: combinedListboxRef,
          children: groupedOptions.map((option, index) => {
            if (groupBy) {
              return renderGroup({
                key: option.key,
                group: option.group,
                children: option.options.map((option2, index2) => renderListOption(option2, option.index + index2))
              });
            }
            return renderListOption(option, index);
          })
        })) : null]
      }))
    })) : null]
  });
});
const Autocomplete$1 = Autocomplete;
const _excluded$p = ["item", "applyValue", "type", "apiRef", "focusElementRef", "color", "error", "helperText", "size", "variant"];
function GridFilterInputMultipleValue(props) {
  const {
    item,
    applyValue,
    type,
    apiRef: apiRef2,
    focusElementRef,
    color,
    error,
    helperText,
    size,
    variant
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$p);
  const TextFieldProps = {
    color,
    error,
    helperText,
    size,
    variant
  };
  const [filterValueState, setFilterValueState] = reactExports.useState(item.value || []);
  const id = useId();
  const rootProps = useGridRootProps();
  reactExports.useEffect(() => {
    var _item$value;
    const itemValue = (_item$value = item.value) != null ? _item$value : [];
    setFilterValueState(itemValue.map(String));
  }, [item.value]);
  const handleChange = reactExports.useCallback((event, value) => {
    setFilterValueState(value.map(String));
    applyValue(_extends$1({}, item, {
      value: [...value]
    }));
  }, [applyValue, item]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Autocomplete$1, _extends$1({
    multiple: true,
    freeSolo: true,
    options: [],
    filterOptions: (options, params) => {
      const {
        inputValue
      } = params;
      return inputValue == null || inputValue === "" ? [] : [inputValue];
    },
    id,
    value: filterValueState,
    onChange: handleChange,
    renderTags: (value, getTagProps) => value.map((option, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseChip, _extends$1({
      variant: "outlined",
      size: "small",
      label: option
    }, getTagProps({
      index
    })))),
    renderInput: (params) => {
      var _rootProps$slotProps;
      return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseTextField, _extends$1({}, params, {
        label: apiRef2.current.getLocaleText("filterPanelInputLabel"),
        placeholder: apiRef2.current.getLocaleText("filterPanelInputPlaceholder"),
        InputLabelProps: _extends$1({}, params.InputLabelProps, {
          shrink: true
        }),
        inputRef: focusElementRef,
        type: type || "text"
      }, TextFieldProps, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseTextField));
    }
  }, other));
}
const _excluded$o = ["item", "applyValue", "type", "apiRef", "focusElementRef", "color", "error", "helperText", "size", "variant", "getOptionLabel", "getOptionValue"];
const filter = createFilterOptions();
function GridFilterInputMultipleSingleSelect(props) {
  var _resolvedColumn, _resolvedColumn2;
  const {
    item,
    applyValue,
    apiRef: apiRef2,
    focusElementRef,
    color,
    error,
    helperText,
    size,
    variant = "standard",
    getOptionLabel: getOptionLabelProp,
    getOptionValue: getOptionValueProp
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$o);
  const TextFieldProps = {
    color,
    error,
    helperText,
    size,
    variant
  };
  const id = useId();
  const rootProps = useGridRootProps();
  let resolvedColumn = null;
  if (item.field) {
    const column = apiRef2.current.getColumn(item.field);
    if (isSingleSelectColDef(column)) {
      resolvedColumn = column;
    }
  }
  const getOptionValue = getOptionValueProp || ((_resolvedColumn = resolvedColumn) == null ? void 0 : _resolvedColumn.getOptionValue);
  const getOptionLabel = getOptionLabelProp || ((_resolvedColumn2 = resolvedColumn) == null ? void 0 : _resolvedColumn2.getOptionLabel);
  const isOptionEqualToValue = reactExports.useCallback((option, value) => getOptionValue(option) === getOptionValue(value), [getOptionValue]);
  const resolvedValueOptions = reactExports.useMemo(() => {
    var _resolvedColumn3;
    if (!((_resolvedColumn3 = resolvedColumn) != null && _resolvedColumn3.valueOptions)) {
      return [];
    }
    if (typeof resolvedColumn.valueOptions === "function") {
      return resolvedColumn.valueOptions({
        field: resolvedColumn.field
      });
    }
    return resolvedColumn.valueOptions;
  }, [resolvedColumn]);
  const resolvedFormattedValueOptions = reactExports.useMemo(() => {
    return resolvedValueOptions == null ? void 0 : resolvedValueOptions.map(getOptionValue);
  }, [resolvedValueOptions, getOptionValue]);
  const filteredValues = reactExports.useMemo(() => {
    if (!Array.isArray(item.value)) {
      return [];
    }
    if (resolvedValueOptions !== void 0) {
      const itemValueIndexes = item.value.map((element) => {
        return resolvedFormattedValueOptions == null ? void 0 : resolvedFormattedValueOptions.findIndex((formattedOption) => formattedOption === element);
      });
      return itemValueIndexes.filter((index) => index >= 0).map((index) => resolvedValueOptions[index]);
    }
    return item.value;
  }, [item.value, resolvedValueOptions, resolvedFormattedValueOptions]);
  reactExports.useEffect(() => {
    if (!Array.isArray(item.value) || filteredValues.length !== item.value.length) {
      applyValue(_extends$1({}, item, {
        value: filteredValues.map(getOptionValue)
      }));
    }
  }, [item, filteredValues, applyValue, getOptionValue]);
  const handleChange = reactExports.useCallback((event, value) => {
    applyValue(_extends$1({}, item, {
      value: value.map(getOptionValue)
    }));
  }, [applyValue, item, getOptionValue]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Autocomplete$1, _extends$1({
    multiple: true,
    options: resolvedValueOptions,
    isOptionEqualToValue,
    filterOptions: filter,
    id,
    value: filteredValues,
    onChange: handleChange,
    getOptionLabel,
    renderTags: (value, getTagProps) => value.map((option, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseChip, _extends$1({
      variant: "outlined",
      size: "small",
      label: getOptionLabel(option)
    }, getTagProps({
      index
    })))),
    renderInput: (params) => {
      var _rootProps$slotProps;
      return /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.baseTextField, _extends$1({}, params, {
        label: apiRef2.current.getLocaleText("filterPanelInputLabel"),
        placeholder: apiRef2.current.getLocaleText("filterPanelInputPlaceholder"),
        InputLabelProps: _extends$1({}, params.InputLabelProps, {
          shrink: true
        }),
        inputRef: focusElementRef,
        type: "singleSelect"
      }, TextFieldProps, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.baseTextField));
    }
  }, other));
}
const _excluded$n = ["hideMenu", "options"], _excluded2$3 = ["hideMenu", "options"];
function GridCsvExportMenuItem(props) {
  const apiRef2 = useGridApiContext();
  const {
    hideMenu,
    options
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$n);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(MUIMenuItem, _extends$1({
    onClick: () => {
      apiRef2.current.exportDataAsCsv(options);
      hideMenu == null || hideMenu();
    }
  }, other, {
    children: apiRef2.current.getLocaleText("toolbarExportCSV")
  }));
}
function GridPrintExportMenuItem(props) {
  const apiRef2 = useGridApiContext();
  const {
    hideMenu,
    options
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded2$3);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(MUIMenuItem, _extends$1({
    onClick: () => {
      apiRef2.current.exportDataAsPrint(options);
      hideMenu == null || hideMenu();
    }
  }, other, {
    children: apiRef2.current.getLocaleText("toolbarExportPrint")
  }));
}
const _excluded$m = ["className", "selectedRowCount"];
const useUtilityClasses$g = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["selectedRowCount"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridSelectedRowCountRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "SelectedRowCount",
  overridesResolver: (props, styles2) => styles2.selectedRowCount
})(({
  theme
}) => ({
  alignItems: "center",
  display: "flex",
  margin: theme.spacing(0, 2),
  visibility: "hidden",
  width: 0,
  height: 0,
  [theme.breakpoints.up("sm")]: {
    visibility: "visible",
    width: "auto",
    height: "auto"
  }
}));
const GridSelectedRowCount = /* @__PURE__ */ reactExports.forwardRef(function GridSelectedRowCount2(props, ref) {
  const {
    className,
    selectedRowCount
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$m);
  const apiRef2 = useGridApiContext();
  const ownerState = useGridRootProps();
  const classes2 = useUtilityClasses$g(ownerState);
  const rowSelectedText = apiRef2.current.getLocaleText("footerRowSelected")(selectedRowCount);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridSelectedRowCountRoot, _extends$1({
    ref,
    className: clsx$1(classes2.root, className),
    ownerState
  }, other, {
    children: rowSelectedText
  }));
});
const GridFooter = /* @__PURE__ */ reactExports.forwardRef(function GridFooter2(props, ref) {
  var _rootProps$slotProps, _rootProps$slotProps2;
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const totalTopLevelRowCount = useGridSelector(apiRef2, gridTopLevelRowCountSelector);
  const selectedRowCount = useGridSelector(apiRef2, selectedGridRowsCountSelector);
  const visibleTopLevelRowCount = useGridSelector(apiRef2, gridFilteredTopLevelRowCountSelector);
  const selectedRowCountElement = !rootProps.hideFooterSelectedRowCount && selectedRowCount > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(GridSelectedRowCount, {
    selectedRowCount
  }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", {});
  const rowCountElement = !rootProps.hideFooterRowCount && !rootProps.pagination ? /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.footerRowCount, _extends$1({}, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.footerRowCount, {
    rowCount: totalTopLevelRowCount,
    visibleRowCount: visibleTopLevelRowCount
  })) : null;
  const paginationElement = rootProps.pagination && !rootProps.hideFooterPagination && rootProps.slots.pagination && /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.pagination, _extends$1({}, (_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.pagination));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(GridFooterContainer, _extends$1({
    ref
  }, props, {
    children: [selectedRowCountElement, rowCountElement, paginationElement]
  }));
});
function GridHeader() {
  var _rootProps$slotProps, _rootProps$slotProps2;
  const rootProps = useGridRootProps();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.preferencesPanel, _extends$1({}, (_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.preferencesPanel)), rootProps.slots.toolbar && /* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.toolbar, _extends$1({}, (_rootProps$slotProps2 = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps2.toolbar))]
  });
}
const GridLoadingOverlay = /* @__PURE__ */ reactExports.forwardRef(function GridLoadingOverlay2(props, ref) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridOverlay, _extends$1({
    ref
  }, props, {
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircularProgress, {})
  }));
});
const GridNoRowsOverlay = /* @__PURE__ */ reactExports.forwardRef(function GridNoRowsOverlay2(props, ref) {
  const apiRef2 = useGridApiContext();
  const noRowsLabel = apiRef2.current.getLocaleText("noRowsLabel");
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridOverlay, _extends$1({
    ref
  }, props, {
    children: noRowsLabel
  }));
});
const TableContext = /* @__PURE__ */ reactExports.createContext();
const TableContext$1 = TableContext;
const Tablelvl2Context = /* @__PURE__ */ reactExports.createContext();
const Tablelvl2Context$1 = Tablelvl2Context;
function getTableCellUtilityClass(slot) {
  return generateUtilityClass("MuiTableCell", slot);
}
const tableCellClasses = generateUtilityClasses("MuiTableCell", ["root", "head", "body", "footer", "sizeSmall", "sizeMedium", "paddingCheckbox", "paddingNone", "alignLeft", "alignCenter", "alignRight", "alignJustify", "stickyHeader"]);
const tableCellClasses$1 = tableCellClasses;
const _excluded$l = ["align", "className", "component", "padding", "scope", "size", "sortDirection", "variant"];
const useUtilityClasses$f = (ownerState) => {
  const {
    classes: classes2,
    variant,
    align,
    padding,
    size,
    stickyHeader
  } = ownerState;
  const slots = {
    root: ["root", variant, stickyHeader && "stickyHeader", align !== "inherit" && `align${capitalize(align)}`, padding !== "normal" && `padding${capitalize(padding)}`, `size${capitalize(size)}`]
  };
  return composeClasses(slots, getTableCellUtilityClass, classes2);
};
const TableCellRoot = styled$1("td", {
  name: "MuiTableCell",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, styles2[ownerState.variant], styles2[`size${capitalize(ownerState.size)}`], ownerState.padding !== "normal" && styles2[`padding${capitalize(ownerState.padding)}`], ownerState.align !== "inherit" && styles2[`align${capitalize(ownerState.align)}`], ownerState.stickyHeader && styles2.stickyHeader];
  }
})(({
  theme,
  ownerState
}) => _extends$1({}, theme.typography.body2, {
  display: "table-cell",
  verticalAlign: "inherit",
  // Workaround for a rendering bug with spanned columns in Chrome 62.0.
  // Removes the alpha (sets it to 1), and lightens or darkens the theme color.
  borderBottom: theme.vars ? `1px solid ${theme.vars.palette.TableCell.border}` : `1px solid
    ${theme.palette.mode === "light" ? lighten(alpha(theme.palette.divider, 1), 0.88) : darken(alpha(theme.palette.divider, 1), 0.68)}`,
  textAlign: "left",
  padding: 16
}, ownerState.variant === "head" && {
  color: (theme.vars || theme).palette.text.primary,
  lineHeight: theme.typography.pxToRem(24),
  fontWeight: theme.typography.fontWeightMedium
}, ownerState.variant === "body" && {
  color: (theme.vars || theme).palette.text.primary
}, ownerState.variant === "footer" && {
  color: (theme.vars || theme).palette.text.secondary,
  lineHeight: theme.typography.pxToRem(21),
  fontSize: theme.typography.pxToRem(12)
}, ownerState.size === "small" && {
  padding: "6px 16px",
  [`&.${tableCellClasses$1.paddingCheckbox}`]: {
    width: 24,
    // prevent the checkbox column from growing
    padding: "0 12px 0 16px",
    "& > *": {
      padding: 0
    }
  }
}, ownerState.padding === "checkbox" && {
  width: 48,
  // prevent the checkbox column from growing
  padding: "0 0 0 4px"
}, ownerState.padding === "none" && {
  padding: 0
}, ownerState.align === "left" && {
  textAlign: "left"
}, ownerState.align === "center" && {
  textAlign: "center"
}, ownerState.align === "right" && {
  textAlign: "right",
  flexDirection: "row-reverse"
}, ownerState.align === "justify" && {
  textAlign: "justify"
}, ownerState.stickyHeader && {
  position: "sticky",
  top: 0,
  zIndex: 2,
  backgroundColor: (theme.vars || theme).palette.background.default
}));
const TableCell = /* @__PURE__ */ reactExports.forwardRef(function TableCell2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiTableCell"
  });
  const {
    align = "inherit",
    className,
    component: componentProp,
    padding: paddingProp,
    scope: scopeProp,
    size: sizeProp,
    sortDirection,
    variant: variantProp
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$l);
  const table = reactExports.useContext(TableContext$1);
  const tablelvl2 = reactExports.useContext(Tablelvl2Context$1);
  const isHeadCell = tablelvl2 && tablelvl2.variant === "head";
  let component;
  if (componentProp) {
    component = componentProp;
  } else {
    component = isHeadCell ? "th" : "td";
  }
  let scope = scopeProp;
  if (component === "td") {
    scope = void 0;
  } else if (!scope && isHeadCell) {
    scope = "col";
  }
  const variant = variantProp || tablelvl2 && tablelvl2.variant;
  const ownerState = _extends$1({}, props, {
    align,
    component,
    padding: paddingProp || (table && table.padding ? table.padding : "normal"),
    size: sizeProp || (table && table.size ? table.size : "medium"),
    sortDirection,
    stickyHeader: variant === "head" && table && table.stickyHeader,
    variant
  });
  const classes2 = useUtilityClasses$f(ownerState);
  let ariaSort = null;
  if (sortDirection) {
    ariaSort = sortDirection === "asc" ? "ascending" : "descending";
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(TableCellRoot, _extends$1({
    as: component,
    ref,
    className: clsx$1(classes2.root, className),
    "aria-sort": ariaSort,
    scope,
    ownerState
  }, other));
});
const TableCell$1 = TableCell;
function getToolbarUtilityClass(slot) {
  return generateUtilityClass("MuiToolbar", slot);
}
generateUtilityClasses("MuiToolbar", ["root", "gutters", "regular", "dense"]);
const _excluded$k = ["className", "component", "disableGutters", "variant"];
const useUtilityClasses$e = (ownerState) => {
  const {
    classes: classes2,
    disableGutters,
    variant
  } = ownerState;
  const slots = {
    root: ["root", !disableGutters && "gutters", variant]
  };
  return composeClasses(slots, getToolbarUtilityClass, classes2);
};
const ToolbarRoot = styled$1("div", {
  name: "MuiToolbar",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, !ownerState.disableGutters && styles2.gutters, styles2[ownerState.variant]];
  }
})(({
  theme,
  ownerState
}) => _extends$1({
  position: "relative",
  display: "flex",
  alignItems: "center"
}, !ownerState.disableGutters && {
  paddingLeft: theme.spacing(2),
  paddingRight: theme.spacing(2),
  [theme.breakpoints.up("sm")]: {
    paddingLeft: theme.spacing(3),
    paddingRight: theme.spacing(3)
  }
}, ownerState.variant === "dense" && {
  minHeight: 48
}), ({
  theme,
  ownerState
}) => ownerState.variant === "regular" && theme.mixins.toolbar);
const Toolbar = /* @__PURE__ */ reactExports.forwardRef(function Toolbar2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiToolbar"
  });
  const {
    className,
    component = "div",
    disableGutters = false,
    variant = "regular"
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$k);
  const ownerState = _extends$1({}, props, {
    component,
    disableGutters,
    variant
  });
  const classes2 = useUtilityClasses$e(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ToolbarRoot, _extends$1({
    as: component,
    className: clsx$1(classes2.root, className),
    ref,
    ownerState
  }, other));
});
const Toolbar$1 = Toolbar;
const KeyboardArrowLeft = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M15.41 16.09l-4.58-4.59 4.58-4.59L14 5.5l-6 6 6 6z"
}), "KeyboardArrowLeft");
const KeyboardArrowRight = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z"
}), "KeyboardArrowRight");
const LastPageIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M5.59 7.41L10.18 12l-4.59 4.59L7 18l6-6-6-6zM16 6h2v12h-2z"
}), "LastPage");
const FirstPageIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M18.41 16.59L13.82 12l4.59-4.59L17 6l-6 6 6 6zM6 6h2v12H6z"
}), "FirstPage");
var _LastPageIcon, _FirstPageIcon, _KeyboardArrowRight, _KeyboardArrowLeft, _KeyboardArrowLeft2, _KeyboardArrowRight2, _FirstPageIcon2, _LastPageIcon2;
const _excluded$j = ["backIconButtonProps", "count", "getItemAriaLabel", "nextIconButtonProps", "onPageChange", "page", "rowsPerPage", "showFirstButton", "showLastButton"];
const TablePaginationActions = /* @__PURE__ */ reactExports.forwardRef(function TablePaginationActions2(props, ref) {
  const {
    backIconButtonProps,
    count,
    getItemAriaLabel,
    nextIconButtonProps,
    onPageChange,
    page,
    rowsPerPage,
    showFirstButton,
    showLastButton
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$j);
  const theme = useTheme$1();
  const handleFirstPageButtonClick = (event) => {
    onPageChange(event, 0);
  };
  const handleBackButtonClick = (event) => {
    onPageChange(event, page - 1);
  };
  const handleNextButtonClick = (event) => {
    onPageChange(event, page + 1);
  };
  const handleLastPageButtonClick = (event) => {
    onPageChange(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", _extends$1({
    ref
  }, other, {
    children: [showFirstButton && /* @__PURE__ */ jsxRuntimeExports.jsx(IconButton$1, {
      onClick: handleFirstPageButtonClick,
      disabled: page === 0,
      "aria-label": getItemAriaLabel("first", page),
      title: getItemAriaLabel("first", page),
      children: theme.direction === "rtl" ? _LastPageIcon || (_LastPageIcon = /* @__PURE__ */ jsxRuntimeExports.jsx(LastPageIcon, {})) : _FirstPageIcon || (_FirstPageIcon = /* @__PURE__ */ jsxRuntimeExports.jsx(FirstPageIcon, {}))
    }), /* @__PURE__ */ jsxRuntimeExports.jsx(IconButton$1, _extends$1({
      onClick: handleBackButtonClick,
      disabled: page === 0,
      color: "inherit",
      "aria-label": getItemAriaLabel("previous", page),
      title: getItemAriaLabel("previous", page)
    }, backIconButtonProps, {
      children: theme.direction === "rtl" ? _KeyboardArrowRight || (_KeyboardArrowRight = /* @__PURE__ */ jsxRuntimeExports.jsx(KeyboardArrowRight, {})) : _KeyboardArrowLeft || (_KeyboardArrowLeft = /* @__PURE__ */ jsxRuntimeExports.jsx(KeyboardArrowLeft, {}))
    })), /* @__PURE__ */ jsxRuntimeExports.jsx(IconButton$1, _extends$1({
      onClick: handleNextButtonClick,
      disabled: count !== -1 ? page >= Math.ceil(count / rowsPerPage) - 1 : false,
      color: "inherit",
      "aria-label": getItemAriaLabel("next", page),
      title: getItemAriaLabel("next", page)
    }, nextIconButtonProps, {
      children: theme.direction === "rtl" ? _KeyboardArrowLeft2 || (_KeyboardArrowLeft2 = /* @__PURE__ */ jsxRuntimeExports.jsx(KeyboardArrowLeft, {})) : _KeyboardArrowRight2 || (_KeyboardArrowRight2 = /* @__PURE__ */ jsxRuntimeExports.jsx(KeyboardArrowRight, {}))
    })), showLastButton && /* @__PURE__ */ jsxRuntimeExports.jsx(IconButton$1, {
      onClick: handleLastPageButtonClick,
      disabled: page >= Math.ceil(count / rowsPerPage) - 1,
      "aria-label": getItemAriaLabel("last", page),
      title: getItemAriaLabel("last", page),
      children: theme.direction === "rtl" ? _FirstPageIcon2 || (_FirstPageIcon2 = /* @__PURE__ */ jsxRuntimeExports.jsx(FirstPageIcon, {})) : _LastPageIcon2 || (_LastPageIcon2 = /* @__PURE__ */ jsxRuntimeExports.jsx(LastPageIcon, {}))
    })]
  }));
});
const TablePaginationActions$1 = TablePaginationActions;
function getTablePaginationUtilityClass(slot) {
  return generateUtilityClass("MuiTablePagination", slot);
}
const tablePaginationClasses = generateUtilityClasses("MuiTablePagination", ["root", "toolbar", "spacer", "selectLabel", "selectRoot", "select", "selectIcon", "input", "menuItem", "displayedRows", "actions"]);
const tablePaginationClasses$1 = tablePaginationClasses;
var _InputBase;
const _excluded$i = ["ActionsComponent", "backIconButtonProps", "className", "colSpan", "component", "count", "getItemAriaLabel", "labelDisplayedRows", "labelRowsPerPage", "nextIconButtonProps", "onPageChange", "onRowsPerPageChange", "page", "rowsPerPage", "rowsPerPageOptions", "SelectProps", "showFirstButton", "showLastButton"];
const TablePaginationRoot = styled$1(TableCell$1, {
  name: "MuiTablePagination",
  slot: "Root",
  overridesResolver: (props, styles2) => styles2.root
})(({
  theme
}) => ({
  overflow: "auto",
  color: (theme.vars || theme).palette.text.primary,
  fontSize: theme.typography.pxToRem(14),
  // Increase the specificity to override TableCell.
  "&:last-child": {
    padding: 0
  }
}));
const TablePaginationToolbar = styled$1(Toolbar$1, {
  name: "MuiTablePagination",
  slot: "Toolbar",
  overridesResolver: (props, styles2) => _extends$1({
    [`& .${tablePaginationClasses$1.actions}`]: styles2.actions
  }, styles2.toolbar)
})(({
  theme
}) => ({
  minHeight: 52,
  paddingRight: 2,
  [`${theme.breakpoints.up("xs")} and (orientation: landscape)`]: {
    minHeight: 52
  },
  [theme.breakpoints.up("sm")]: {
    minHeight: 52,
    paddingRight: 2
  },
  [`& .${tablePaginationClasses$1.actions}`]: {
    flexShrink: 0,
    marginLeft: 20
  }
}));
const TablePaginationSpacer = styled$1("div", {
  name: "MuiTablePagination",
  slot: "Spacer",
  overridesResolver: (props, styles2) => styles2.spacer
})({
  flex: "1 1 100%"
});
const TablePaginationSelectLabel = styled$1("p", {
  name: "MuiTablePagination",
  slot: "SelectLabel",
  overridesResolver: (props, styles2) => styles2.selectLabel
})(({
  theme
}) => _extends$1({}, theme.typography.body2, {
  flexShrink: 0
}));
const TablePaginationSelect = styled$1(MUISelect, {
  name: "MuiTablePagination",
  slot: "Select",
  overridesResolver: (props, styles2) => _extends$1({
    [`& .${tablePaginationClasses$1.selectIcon}`]: styles2.selectIcon,
    [`& .${tablePaginationClasses$1.select}`]: styles2.select
  }, styles2.input, styles2.selectRoot)
})({
  color: "inherit",
  fontSize: "inherit",
  flexShrink: 0,
  marginRight: 32,
  marginLeft: 8,
  [`& .${tablePaginationClasses$1.select}`]: {
    paddingLeft: 8,
    paddingRight: 24,
    textAlign: "right",
    textAlignLast: "right"
    // Align <select> on Chrome.
  }
});
const TablePaginationMenuItem = styled$1(MUIMenuItem, {
  name: "MuiTablePagination",
  slot: "MenuItem",
  overridesResolver: (props, styles2) => styles2.menuItem
})({});
const TablePaginationDisplayedRows = styled$1("p", {
  name: "MuiTablePagination",
  slot: "DisplayedRows",
  overridesResolver: (props, styles2) => styles2.displayedRows
})(({
  theme
}) => _extends$1({}, theme.typography.body2, {
  flexShrink: 0
}));
function defaultLabelDisplayedRows({
  from,
  to,
  count
}) {
  return `${from}–${to} of ${count !== -1 ? count : `more than ${to}`}`;
}
function defaultGetAriaLabel(type) {
  return `Go to ${type} page`;
}
const useUtilityClasses$d = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["root"],
    toolbar: ["toolbar"],
    spacer: ["spacer"],
    selectLabel: ["selectLabel"],
    select: ["select"],
    input: ["input"],
    selectIcon: ["selectIcon"],
    menuItem: ["menuItem"],
    displayedRows: ["displayedRows"],
    actions: ["actions"]
  };
  return composeClasses(slots, getTablePaginationUtilityClass, classes2);
};
const TablePagination = /* @__PURE__ */ reactExports.forwardRef(function TablePagination2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiTablePagination"
  });
  const {
    ActionsComponent = TablePaginationActions$1,
    backIconButtonProps,
    className,
    colSpan: colSpanProp,
    component = TableCell$1,
    count,
    getItemAriaLabel = defaultGetAriaLabel,
    labelDisplayedRows = defaultLabelDisplayedRows,
    labelRowsPerPage = "Rows per page:",
    nextIconButtonProps,
    onPageChange,
    onRowsPerPageChange,
    page,
    rowsPerPage,
    rowsPerPageOptions = [10, 25, 50, 100],
    SelectProps = {},
    showFirstButton = false,
    showLastButton = false
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$i);
  const ownerState = props;
  const classes2 = useUtilityClasses$d(ownerState);
  const MenuItemComponent = SelectProps.native ? "option" : TablePaginationMenuItem;
  let colSpan;
  if (component === TableCell$1 || component === "td") {
    colSpan = colSpanProp || 1e3;
  }
  const selectId = useId(SelectProps.id);
  const labelId = useId(SelectProps.labelId);
  const getLabelDisplayedRowsTo = () => {
    if (count === -1) {
      return (page + 1) * rowsPerPage;
    }
    return rowsPerPage === -1 ? count : Math.min(count, (page + 1) * rowsPerPage);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(TablePaginationRoot, _extends$1({
    colSpan,
    ref,
    as: component,
    ownerState,
    className: clsx$1(classes2.root, className)
  }, other, {
    children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TablePaginationToolbar, {
      className: classes2.toolbar,
      children: [/* @__PURE__ */ jsxRuntimeExports.jsx(TablePaginationSpacer, {
        className: classes2.spacer
      }), rowsPerPageOptions.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx(TablePaginationSelectLabel, {
        className: classes2.selectLabel,
        id: labelId,
        children: labelRowsPerPage
      }), rowsPerPageOptions.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx(TablePaginationSelect, _extends$1({
        variant: "standard"
      }, !SelectProps.variant && {
        input: _InputBase || (_InputBase = /* @__PURE__ */ jsxRuntimeExports.jsx(InputBase, {}))
      }, {
        value: rowsPerPage,
        onChange: onRowsPerPageChange,
        id: selectId,
        labelId
      }, SelectProps, {
        classes: _extends$1({}, SelectProps.classes, {
          // TODO v5 remove `classes.input`
          root: clsx$1(classes2.input, classes2.selectRoot, (SelectProps.classes || {}).root),
          select: clsx$1(classes2.select, (SelectProps.classes || {}).select),
          // TODO v5 remove `selectIcon`
          icon: clsx$1(classes2.selectIcon, (SelectProps.classes || {}).icon)
        }),
        children: rowsPerPageOptions.map((rowsPerPageOption) => /* @__PURE__ */ reactExports.createElement(MenuItemComponent, _extends$1({}, !isHostComponent(MenuItemComponent) && {
          ownerState
        }, {
          className: classes2.menuItem,
          key: rowsPerPageOption.label ? rowsPerPageOption.label : rowsPerPageOption,
          value: rowsPerPageOption.value ? rowsPerPageOption.value : rowsPerPageOption
        }), rowsPerPageOption.label ? rowsPerPageOption.label : rowsPerPageOption))
      })), /* @__PURE__ */ jsxRuntimeExports.jsx(TablePaginationDisplayedRows, {
        className: classes2.displayedRows,
        children: labelDisplayedRows({
          from: count === 0 ? 0 : page * rowsPerPage + 1,
          to: getLabelDisplayedRowsTo(),
          count: count === -1 ? -1 : count,
          page
        })
      }), /* @__PURE__ */ jsxRuntimeExports.jsx(ActionsComponent, {
        className: classes2.actions,
        backIconButtonProps,
        count,
        nextIconButtonProps,
        onPageChange,
        page,
        rowsPerPage,
        showFirstButton,
        showLastButton,
        getItemAriaLabel
      })]
    })
  }));
});
const TablePagination$1 = TablePagination;
const GridPaginationRoot = styled$1(TablePagination$1)(({
  theme
}) => ({
  [`& .${tablePaginationClasses$1.selectLabel}`]: {
    display: "none",
    [theme.breakpoints.up("sm")]: {
      display: "block"
    }
  },
  [`& .${tablePaginationClasses$1.input}`]: {
    display: "none",
    [theme.breakpoints.up("sm")]: {
      display: "inline-flex"
    }
  }
}));
const GridPagination = /* @__PURE__ */ reactExports.forwardRef(function GridPagination2(props, ref) {
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const paginationModel = useGridSelector(apiRef2, gridPaginationModelSelector);
  const visibleTopLevelRowCount = useGridSelector(apiRef2, gridFilteredTopLevelRowCountSelector);
  const rowCount = reactExports.useMemo(() => {
    var _ref, _rootProps$rowCount;
    return (_ref = (_rootProps$rowCount = rootProps.rowCount) != null ? _rootProps$rowCount : visibleTopLevelRowCount) != null ? _ref : 0;
  }, [rootProps.rowCount, visibleTopLevelRowCount]);
  const lastPage = reactExports.useMemo(() => Math.floor(rowCount / (paginationModel.pageSize || 1)), [rowCount, paginationModel.pageSize]);
  const handlePageSizeChange = reactExports.useCallback((event) => {
    const pageSize2 = Number(event.target.value);
    apiRef2.current.setPageSize(pageSize2);
  }, [apiRef2]);
  const handlePageChange = reactExports.useCallback((_2, page) => {
    apiRef2.current.setPage(page);
  }, [apiRef2]);
  const isPageSizeIncludedInPageSizeOptions = (pageSize2) => {
    for (let i2 = 0; i2 < rootProps.pageSizeOptions.length; i2 += 1) {
      const option = rootProps.pageSizeOptions[i2];
      if (typeof option === "number") {
        if (option === pageSize2) {
          return true;
        }
      } else if (option.value === pageSize2) {
        return true;
      }
    }
    return false;
  };
  const pageSizeOptions = isPageSizeIncludedInPageSizeOptions(paginationModel.pageSize) ? rootProps.pageSizeOptions : [];
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridPaginationRoot, _extends$1({
    ref,
    component: "div",
    count: rowCount,
    page: paginationModel.page <= lastPage ? paginationModel.page : lastPage,
    rowsPerPageOptions: pageSizeOptions,
    rowsPerPage: paginationModel.pageSize,
    onPageChange: handlePageChange,
    onRowsPerPageChange: handlePageSizeChange
  }, apiRef2.current.getLocaleText("MuiTablePagination"), props));
});
const _excluded$h = ["className", "rowCount", "visibleRowCount"];
const useUtilityClasses$c = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["rowCount"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridRowCountRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "RowCount",
  overridesResolver: (props, styles2) => styles2.rowCount
})(({
  theme
}) => ({
  alignItems: "center",
  display: "flex",
  margin: theme.spacing(0, 2)
}));
const GridRowCount = /* @__PURE__ */ reactExports.forwardRef(function GridRowCount2(props, ref) {
  const {
    className,
    rowCount,
    visibleRowCount
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$h);
  const apiRef2 = useGridApiContext();
  const ownerState = useGridRootProps();
  const classes2 = useUtilityClasses$c(ownerState);
  if (rowCount === 0) {
    return null;
  }
  const text = visibleRowCount < rowCount ? apiRef2.current.getLocaleText("footerTotalVisibleRows")(visibleRowCount, rowCount) : rowCount.toLocaleString();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(GridRowCountRoot, _extends$1({
    ref,
    className: clsx$1(classes2.root, className),
    ownerState
  }, other, {
    children: [apiRef2.current.getLocaleText("footerTotalRows"), " ", text]
  }));
});
const getVisibleRows = (apiRef2, props) => {
  let rows;
  let range;
  if (props.pagination && props.paginationMode === "client") {
    range = gridPaginationRowRangeSelector(apiRef2);
    rows = gridPaginatedVisibleSortedGridRowEntriesSelector(apiRef2);
  } else {
    rows = gridExpandedSortedRowEntriesSelector(apiRef2);
    if (rows.length === 0) {
      range = null;
    } else {
      range = {
        firstRowIndex: 0,
        lastRowIndex: rows.length - 1
      };
    }
  }
  return {
    rows,
    range
  };
};
const useGridVisibleRows = (apiRef2, props) => {
  const response = getVisibleRows(apiRef2, props);
  return reactExports.useMemo(() => ({
    rows: response.rows,
    range: response.range
  }), [response.rows, response.range]);
};
const GLOBAL_API_REF = {
  current: null
};
function tagInternalFilter(fn2) {
  fn2.isInternal = true;
  return fn2;
}
function isInternalFilter(fn2) {
  return fn2 !== void 0 && fn2.isInternal === true;
}
function convertFilterV7ToLegacy(fn2) {
  return tagInternalFilter((filterItem2, column) => {
    const filterFn = fn2(filterItem2, column);
    if (!filterFn) {
      return filterFn;
    }
    return (cellParams) => {
      return filterFn(cellParams.value, cellParams.row, column, GLOBAL_API_REF.current);
    };
  });
}
function convertLegacyOperators(ops) {
  return ops.map((op) => {
    return _extends$1({}, op, {
      getApplyFilterFn: convertFilterV7ToLegacy(op.getApplyFilterFnV7),
      getApplyFilterFnV7: tagInternalFilter(op.getApplyFilterFnV7)
    });
  });
}
function convertQuickFilterV7ToLegacy(fn2) {
  return tagInternalFilter((filterItem2, column, apiRef2) => {
    const filterFn = fn2(filterItem2, column, apiRef2);
    if (!filterFn) {
      return filterFn;
    }
    return (cellParams) => {
      return filterFn(cellParams.value, cellParams.row, column, apiRef2);
    };
  });
}
const getGridStringQuickFilterFn = tagInternalFilter((value) => {
  if (!value) {
    return null;
  }
  const filterRegex = new RegExp(escapeRegExp(value), "i");
  return (_2, row, column, apiRef2) => {
    const columnValue = apiRef2.current.getRowFormattedValue(row, column);
    return columnValue != null ? filterRegex.test(columnValue.toString()) : false;
  };
});
const getGridStringOperators = (disableTrim = false) => convertLegacyOperators([{
  value: "contains",
  getApplyFilterFnV7: (filterItem2) => {
    if (!filterItem2.value) {
      return null;
    }
    const filterItemValue = disableTrim ? filterItem2.value : filterItem2.value.trim();
    const filterRegex = new RegExp(escapeRegExp(filterItemValue), "i");
    return (value) => {
      return value != null ? filterRegex.test(String(value)) : false;
    };
  },
  InputComponent: GridFilterInputValue
}, {
  value: "equals",
  getApplyFilterFnV7: (filterItem2) => {
    if (!filterItem2.value) {
      return null;
    }
    const filterItemValue = disableTrim ? filterItem2.value : filterItem2.value.trim();
    const collator2 = new Intl.Collator(void 0, {
      sensitivity: "base",
      usage: "search"
    });
    return (value) => {
      return value != null ? collator2.compare(filterItemValue, value.toString()) === 0 : false;
    };
  },
  InputComponent: GridFilterInputValue
}, {
  value: "startsWith",
  getApplyFilterFnV7: (filterItem2) => {
    if (!filterItem2.value) {
      return null;
    }
    const filterItemValue = disableTrim ? filterItem2.value : filterItem2.value.trim();
    const filterRegex = new RegExp(`^${escapeRegExp(filterItemValue)}.*$`, "i");
    return (value) => {
      return value != null ? filterRegex.test(value.toString()) : false;
    };
  },
  InputComponent: GridFilterInputValue
}, {
  value: "endsWith",
  getApplyFilterFnV7: (filterItem2) => {
    if (!filterItem2.value) {
      return null;
    }
    const filterItemValue = disableTrim ? filterItem2.value : filterItem2.value.trim();
    const filterRegex = new RegExp(`.*${escapeRegExp(filterItemValue)}$`, "i");
    return (value) => {
      return value != null ? filterRegex.test(value.toString()) : false;
    };
  },
  InputComponent: GridFilterInputValue
}, {
  value: "isEmpty",
  getApplyFilterFnV7: () => {
    return (value) => {
      return value === "" || value == null;
    };
  },
  requiresFilterValue: false
}, {
  value: "isNotEmpty",
  getApplyFilterFnV7: () => {
    return (value) => {
      return value !== "" && value != null;
    };
  },
  requiresFilterValue: false
}, {
  value: "isAnyOf",
  getApplyFilterFnV7: (filterItem2) => {
    if (!Array.isArray(filterItem2.value) || filterItem2.value.length === 0) {
      return null;
    }
    const filterItemValue = disableTrim ? filterItem2.value : filterItem2.value.map((val) => val.trim());
    const collator2 = new Intl.Collator(void 0, {
      sensitivity: "base",
      usage: "search"
    });
    return (value) => value != null ? filterItemValue.some((filterValue) => {
      return collator2.compare(filterValue, value.toString() || "") === 0;
    }) : false;
  },
  InputComponent: GridFilterInputMultipleValue
}]);
const GRID_STRING_COL_DEF = {
  width: 100,
  minWidth: 50,
  maxWidth: Infinity,
  hideable: true,
  sortable: true,
  resizable: true,
  filterable: true,
  groupable: true,
  pinnable: true,
  // @ts-ignore
  aggregable: true,
  editable: false,
  sortComparator: gridStringOrNumberComparator,
  type: "string",
  align: "left",
  filterOperators: getGridStringOperators(),
  renderEditCell: renderEditInputCell,
  getApplyQuickFilterFn: convertQuickFilterV7ToLegacy(getGridStringQuickFilterFn),
  getApplyQuickFilterFnV7: getGridStringQuickFilterFn
};
const getGridBooleanOperators = () => convertLegacyOperators([{
  value: "is",
  getApplyFilterFnV7: (filterItem2) => {
    if (!filterItem2.value) {
      return null;
    }
    const valueAsBoolean = filterItem2.value === "true";
    return (value) => {
      return Boolean(value) === valueAsBoolean;
    };
  },
  InputComponent: GridFilterInputBoolean
}]);
function gridBooleanFormatter({
  value,
  api
}) {
  return value ? api.getLocaleText("booleanCellTrueLabel") : api.getLocaleText("booleanCellFalseLabel");
}
const stringToBoolean = (value) => {
  switch (value.toLowerCase().trim()) {
    case "true":
    case "yes":
    case "1":
      return true;
    case "false":
    case "no":
    case "0":
    case "null":
    case "undefined":
      return false;
    default:
      return void 0;
  }
};
const GRID_BOOLEAN_COL_DEF = _extends$1({}, GRID_STRING_COL_DEF, {
  type: "boolean",
  align: "center",
  headerAlign: "center",
  renderCell: renderBooleanCell,
  renderEditCell: renderEditBooleanCell,
  sortComparator: gridNumberComparator,
  valueFormatter: gridBooleanFormatter,
  filterOperators: getGridBooleanOperators(),
  getApplyQuickFilterFn: void 0,
  getApplyQuickFilterFnV7: void 0,
  // @ts-ignore
  aggregable: false,
  // @ts-ignore
  pastedValueParser: (value) => stringToBoolean(value)
});
const GRID_CHECKBOX_SELECTION_FIELD = "__check__";
const GRID_CHECKBOX_SELECTION_COL_DEF = _extends$1({}, GRID_BOOLEAN_COL_DEF, {
  field: GRID_CHECKBOX_SELECTION_FIELD,
  type: "checkboxSelection",
  width: 50,
  resizable: false,
  sortable: false,
  filterable: false,
  // @ts-ignore
  aggregable: false,
  disableColumnMenu: true,
  disableReorder: true,
  disableExport: true,
  getApplyQuickFilterFn: void 0,
  getApplyQuickFilterFnV7: void 0,
  valueGetter: (params) => {
    const selectionLookup = selectedIdsLookupSelector(params.api.state, params.api.instanceId);
    return selectionLookup[params.id] !== void 0;
  },
  renderHeader: (params) => /* @__PURE__ */ jsxRuntimeExports.jsx(GridHeaderCheckbox, _extends$1({}, params)),
  renderCell: (params) => /* @__PURE__ */ jsxRuntimeExports.jsx(GridCellCheckboxRenderer, _extends$1({}, params))
});
const GRID_ACTIONS_COLUMN_TYPE = "actions";
const GRID_ACTIONS_COL_DEF = _extends$1({}, GRID_STRING_COL_DEF, {
  sortable: false,
  filterable: false,
  // @ts-ignore
  aggregable: false,
  width: 100,
  align: "center",
  headerAlign: "center",
  headerName: "",
  disableColumnMenu: true,
  disableExport: true,
  renderCell: renderActionsCell,
  getApplyQuickFilterFn: void 0,
  getApplyQuickFilterFnV7: void 0
});
const GRID_DETAIL_PANEL_TOGGLE_FIELD = "__detail_panel_toggle__";
const gridEditRowsStateSelector = (state) => state.editRows;
const _excluded$g = ["selected", "rowId", "row", "index", "style", "position", "rowHeight", "className", "visibleColumns", "renderedColumns", "containerWidth", "firstColumnToRender", "lastColumnToRender", "isLastVisible", "focusedCellColumnIndexNotInRange", "isNotVisible", "focusedCell", "tabbableCell", "onClick", "onDoubleClick", "onMouseEnter", "onMouseLeave"];
const useUtilityClasses$b = (ownerState) => {
  const {
    editable,
    editing,
    selected,
    isLastVisible,
    rowHeight,
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["row", selected && "selected", editable && "row--editable", editing && "row--editing", isLastVisible && "row--lastVisible", rowHeight === "auto" && "row--dynamicHeight"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
function EmptyCell({
  width
}) {
  if (!width) {
    return null;
  }
  const style = {
    width
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", {
    className: `${gridClasses.cell} ${gridClasses.withBorderColor}`,
    style
  });
}
const GridRow = /* @__PURE__ */ reactExports.forwardRef(function GridRow2(props, refProp) {
  const {
    selected,
    rowId,
    row,
    index,
    style: styleProp,
    position,
    rowHeight,
    className,
    visibleColumns,
    renderedColumns,
    containerWidth,
    firstColumnToRender,
    isLastVisible = false,
    focusedCellColumnIndexNotInRange,
    isNotVisible,
    focusedCell,
    onClick,
    onDoubleClick,
    onMouseEnter,
    onMouseLeave
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$g);
  const apiRef2 = useGridApiContext();
  const ref = reactExports.useRef(null);
  const rootProps = useGridRootProps();
  const currentPage = useGridVisibleRows(apiRef2, rootProps);
  const columnsTotalWidth = useGridSelector(apiRef2, gridColumnsTotalWidthSelector);
  const sortModel = useGridSelector(apiRef2, gridSortModelSelector);
  const treeDepth = useGridSelector(apiRef2, gridRowMaximumTreeDepthSelector);
  const headerGroupingMaxDepth = useGridSelector(apiRef2, gridColumnGroupsHeaderMaxDepthSelector);
  const editRowsState = useGridSelector(apiRef2, gridEditRowsStateSelector);
  const handleRef = useForkRef$1(ref, refProp);
  const ariaRowIndex = index + headerGroupingMaxDepth + 2;
  const ownerState = {
    selected,
    isLastVisible,
    classes: rootProps.classes,
    editing: apiRef2.current.getRowMode(rowId) === GridRowModes.Edit,
    editable: rootProps.editMode === GridEditModes.Row,
    rowHeight
  };
  const classes2 = useUtilityClasses$b(ownerState);
  reactExports.useLayoutEffect(() => {
    if (rowHeight === "auto" && ref.current && typeof ResizeObserver === "undefined") {
      apiRef2.current.unstable_storeRowHeightMeasurement(rowId, ref.current.clientHeight, position);
    }
  }, [apiRef2, rowHeight, rowId, position]);
  reactExports.useLayoutEffect(() => {
    if (currentPage.range) {
      const rowIndex = apiRef2.current.getRowIndexRelativeToVisibleRows(rowId);
      if (rowIndex != null) {
        apiRef2.current.unstable_setLastMeasuredRowIndex(rowIndex);
      }
    }
    const rootElement = ref.current;
    const hasFixedHeight = rowHeight !== "auto";
    if (!rootElement || hasFixedHeight || typeof ResizeObserver === "undefined") {
      return void 0;
    }
    const resizeObserver = new ResizeObserver((entries) => {
      const [entry] = entries;
      const height = entry.borderBoxSize && entry.borderBoxSize.length > 0 ? entry.borderBoxSize[0].blockSize : entry.contentRect.height;
      apiRef2.current.unstable_storeRowHeightMeasurement(rowId, height, position);
    });
    resizeObserver.observe(rootElement);
    return () => resizeObserver.disconnect();
  }, [apiRef2, currentPage.range, index, rowHeight, rowId, position]);
  const publish = reactExports.useCallback((eventName, propHandler) => (event) => {
    if (event.target.nodeType === 1 && !event.currentTarget.contains(event.target)) {
      return;
    }
    if (!apiRef2.current.getRow(rowId)) {
      return;
    }
    apiRef2.current.publishEvent(eventName, apiRef2.current.getRowParams(rowId), event);
    if (propHandler) {
      propHandler(event);
    }
  }, [apiRef2, rowId]);
  const publishClick = reactExports.useCallback((event) => {
    const cell = findParentElementFromClassName(event.target, gridClasses.cell);
    const field = cell == null ? void 0 : cell.getAttribute("data-field");
    if (field) {
      if (field === GRID_CHECKBOX_SELECTION_COL_DEF.field) {
        return;
      }
      if (field === GRID_DETAIL_PANEL_TOGGLE_FIELD) {
        return;
      }
      if (field === "__reorder__") {
        return;
      }
      if (apiRef2.current.getCellMode(rowId, field) === GridCellModes.Edit) {
        return;
      }
      const column = apiRef2.current.getColumn(field);
      if ((column == null ? void 0 : column.type) === GRID_ACTIONS_COLUMN_TYPE) {
        return;
      }
    }
    publish("rowClick", onClick)(event);
  }, [apiRef2, onClick, publish, rowId]);
  const {
    slots,
    slotProps,
    disableColumnReorder
  } = rootProps;
  const CellComponent = slots.cell === MemoizedGridCellV7 ? MemoizedGridCellV7 : MemoizedCellWrapper;
  const rowReordering = rootProps.rowReordering;
  const getCell = (column, cellProps) => {
    var _editRowsState$rowId$, _editRowsState$rowId;
    const disableDragEvents = disableColumnReorder && column.disableReorder || !rowReordering && !!sortModel.length && treeDepth > 1 && Object.keys(editRowsState).length > 0;
    const editCellState = (_editRowsState$rowId$ = (_editRowsState$rowId = editRowsState[rowId]) == null ? void 0 : _editRowsState$rowId[column.field]) != null ? _editRowsState$rowId$ : null;
    let cellIsNotVisible = false;
    if (focusedCellColumnIndexNotInRange !== void 0 && visibleColumns[focusedCellColumnIndexNotInRange].field === column.field) {
      cellIsNotVisible = true;
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(CellComponent, _extends$1({
      column,
      width: cellProps.width,
      rowId,
      height: rowHeight,
      showRightBorder: cellProps.showRightBorder,
      align: column.align || "left",
      colIndex: cellProps.indexRelativeToAllColumns,
      colSpan: cellProps.colSpan,
      disableDragEvents,
      editCellState,
      isNotVisible: cellIsNotVisible
    }, slotProps == null ? void 0 : slotProps.cell), column.field);
  };
  const sizes = useGridSelector(apiRef2, () => _extends$1({}, apiRef2.current.unstable_getRowInternalSizes(rowId)), objectShallowCompare);
  let minHeight = rowHeight;
  if (minHeight === "auto" && sizes) {
    let numberOfBaseSizes = 0;
    const maximumSize = Object.entries(sizes).reduce((acc, [key, size]) => {
      const isBaseHeight = /^base[A-Z]/.test(key);
      if (!isBaseHeight) {
        return acc;
      }
      numberOfBaseSizes += 1;
      if (size > acc) {
        return size;
      }
      return acc;
    }, 0);
    if (maximumSize > 0 && numberOfBaseSizes > 1) {
      minHeight = maximumSize;
    }
  }
  const style = reactExports.useMemo(() => {
    if (isNotVisible) {
      return {
        opacity: 0,
        width: 0,
        height: 0
      };
    }
    const rowStyle = _extends$1({}, styleProp, {
      maxHeight: rowHeight === "auto" ? "none" : rowHeight,
      // max-height doesn't support "auto"
      minHeight
    });
    if (sizes != null && sizes.spacingTop) {
      const property = rootProps.rowSpacingType === "border" ? "borderTopWidth" : "marginTop";
      rowStyle[property] = sizes.spacingTop;
    }
    if (sizes != null && sizes.spacingBottom) {
      const property = rootProps.rowSpacingType === "border" ? "borderBottomWidth" : "marginBottom";
      let propertyValue = rowStyle[property];
      if (typeof propertyValue !== "number") {
        propertyValue = parseInt(propertyValue || "0", 10);
      }
      propertyValue += sizes.spacingBottom;
      rowStyle[property] = propertyValue;
    }
    return rowStyle;
  }, [isNotVisible, rowHeight, styleProp, minHeight, sizes, rootProps.rowSpacingType]);
  const rowClassNames = apiRef2.current.unstable_applyPipeProcessors("rowClassName", [], rowId);
  if (typeof rootProps.getRowClassName === "function") {
    var _currentPage$range;
    const indexRelativeToCurrentPage = index - (((_currentPage$range = currentPage.range) == null ? void 0 : _currentPage$range.firstRowIndex) || 0);
    const rowParams = _extends$1({}, apiRef2.current.getRowParams(rowId), {
      isFirstVisible: indexRelativeToCurrentPage === 0,
      isLastVisible: indexRelativeToCurrentPage === currentPage.rows.length - 1,
      indexRelativeToCurrentPage
    });
    rowClassNames.push(rootProps.getRowClassName(rowParams));
  }
  const randomNumber = randomNumberBetween(1e4, 20, 80);
  const rowNode = apiRef2.current.getRowNode(rowId);
  if (!rowNode) {
    return null;
  }
  const rowType = rowNode.type;
  const cells = [];
  for (let i2 = 0; i2 < renderedColumns.length; i2 += 1) {
    const column = renderedColumns[i2];
    let indexRelativeToAllColumns = firstColumnToRender + i2;
    if (focusedCellColumnIndexNotInRange !== void 0 && focusedCell) {
      if (visibleColumns[focusedCellColumnIndexNotInRange].field === column.field) {
        indexRelativeToAllColumns = focusedCellColumnIndexNotInRange;
      } else {
        indexRelativeToAllColumns -= 1;
      }
    }
    const cellColSpanInfo = apiRef2.current.unstable_getCellColSpanInfo(rowId, indexRelativeToAllColumns);
    if (cellColSpanInfo && !cellColSpanInfo.spannedByColSpan) {
      if (rowType !== "skeletonRow") {
        const {
          colSpan,
          width
        } = cellColSpanInfo.cellProps;
        const cellProps = {
          width,
          colSpan,
          showRightBorder: rootProps.showCellVerticalBorder,
          indexRelativeToAllColumns
        };
        cells.push(getCell(column, cellProps));
      } else {
        const {
          width
        } = cellColSpanInfo.cellProps;
        const contentWidth = Math.round(randomNumber());
        cells.push(/* @__PURE__ */ jsxRuntimeExports.jsx(slots.skeletonCell, {
          width,
          contentWidth,
          field: column.field,
          align: column.align
        }, column.field));
      }
    }
  }
  const emptyCellWidth = containerWidth - columnsTotalWidth;
  const eventHandlers = row ? {
    onClick: publishClick,
    onDoubleClick: publish("rowDoubleClick", onDoubleClick),
    onMouseEnter: publish("rowMouseEnter", onMouseEnter),
    onMouseLeave: publish("rowMouseLeave", onMouseLeave)
  } : null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", _extends$1({
    ref: handleRef,
    "data-id": rowId,
    "data-rowindex": index,
    role: "row",
    className: clsx$1(...rowClassNames, classes2.root, className),
    "aria-rowindex": ariaRowIndex,
    "aria-selected": selected,
    style
  }, eventHandlers, other, {
    children: [cells, emptyCellWidth > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyCell, {
      width: emptyCellWidth
    })]
  }));
});
const MemoizedGridRow = fastMemo(GridRow);
function GridContextProvider({
  privateApiRef,
  props,
  children
}) {
  const apiRef2 = reactExports.useRef(privateApiRef.current.getPublicApi());
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridRootPropsContext.Provider, {
    value: props,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(GridPrivateApiContext.Provider, {
      value: privateApiRef,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(GridApiContext.Provider, {
        value: apiRef2,
        children
      })
    })
  });
}
const forceDebug = localStorageAvailable() && window.localStorage.getItem("DEBUG") != null;
const noop = () => {
};
const noopLogger = {
  debug: noop,
  info: noop,
  warn: noop,
  error: noop
};
const LOG_LEVELS = ["debug", "info", "warn", "error"];
function getAppender(name, logLevel, appender = console) {
  const minLogLevelIdx = LOG_LEVELS.indexOf(logLevel);
  if (minLogLevelIdx === -1) {
    throw new Error(`MUI: Log level ${logLevel} not recognized.`);
  }
  const logger = LOG_LEVELS.reduce((loggerObj, method, idx) => {
    if (idx >= minLogLevelIdx) {
      loggerObj[method] = (...args) => {
        const [message, ...other] = args;
        appender[method](`MUI: ${name} - ${message}`, ...other);
      };
    } else {
      loggerObj[method] = noop;
    }
    return loggerObj;
  }, {});
  return logger;
}
const useGridLoggerFactory = (apiRef2, props) => {
  const getLogger = reactExports.useCallback((name) => {
    if (forceDebug) {
      return getAppender(name, "debug", props.logger);
    }
    if (!props.logLevel) {
      return noopLogger;
    }
    return getAppender(name, props.logLevel.toString(), props.logger);
  }, [props.logLevel, props.logger]);
  useGridApiMethod(apiRef2, {
    getLogger
  }, "private");
};
class Store {
  static create(value) {
    return new Store(value);
  }
  constructor(_value) {
    this.value = void 0;
    this.listeners = void 0;
    this.subscribe = (fn2) => {
      this.listeners.add(fn2);
      return () => {
        this.listeners.delete(fn2);
      };
    };
    this.getSnapshot = () => {
      return this.value;
    };
    this.update = (value) => {
      this.value = value;
      this.listeners.forEach((l2) => l2(value));
    };
    this.value = _value;
    this.listeners = /* @__PURE__ */ new Set();
  }
}
class EventManager {
  constructor() {
    this.maxListeners = 20;
    this.warnOnce = false;
    this.events = {};
  }
  on(eventName, listener, options = {}) {
    let collection = this.events[eventName];
    if (!collection) {
      collection = {
        highPriority: /* @__PURE__ */ new Map(),
        regular: /* @__PURE__ */ new Map()
      };
      this.events[eventName] = collection;
    }
    if (options.isFirst) {
      collection.highPriority.set(listener, true);
    } else {
      collection.regular.set(listener, true);
    }
  }
  removeListener(eventName, listener) {
    if (this.events[eventName]) {
      this.events[eventName].regular.delete(listener);
      this.events[eventName].highPriority.delete(listener);
    }
  }
  removeAllListeners() {
    this.events = {};
  }
  emit(eventName, ...args) {
    const collection = this.events[eventName];
    if (!collection) {
      return;
    }
    const highPriorityListeners = Array.from(collection.highPriority.keys());
    const regularListeners = Array.from(collection.regular.keys());
    for (let i2 = highPriorityListeners.length - 1; i2 >= 0; i2 -= 1) {
      const listener = highPriorityListeners[i2];
      if (collection.highPriority.has(listener)) {
        listener.apply(this, args);
      }
    }
    for (let i2 = 0; i2 < regularListeners.length; i2 += 1) {
      const listener = regularListeners[i2];
      if (collection.regular.has(listener)) {
        listener.apply(this, args);
      }
    }
  }
  once(eventName, listener) {
    const that = this;
    this.on(eventName, function oneTimeListener(...args) {
      that.removeListener(eventName, oneTimeListener);
      listener.apply(that, args);
    });
  }
}
const SYMBOL_API_PRIVATE = Symbol("mui.api_private");
const isSyntheticEvent = (event) => {
  return event.isPropagationStopped !== void 0;
};
let globalId = 0;
function createPrivateAPI(publicApiRef) {
  var _publicApiRef$current;
  const existingPrivateApi = (_publicApiRef$current = publicApiRef.current) == null ? void 0 : _publicApiRef$current[SYMBOL_API_PRIVATE];
  if (existingPrivateApi) {
    return existingPrivateApi;
  }
  const state = {};
  const privateApi = {
    state,
    store: Store.create(state),
    instanceId: {
      id: globalId
    }
  };
  globalId += 1;
  privateApi.getPublicApi = () => publicApiRef.current;
  privateApi.register = (visibility, methods) => {
    Object.keys(methods).forEach((methodName) => {
      const method = methods[methodName];
      const currentPrivateMethod = privateApi[methodName];
      if ((currentPrivateMethod == null ? void 0 : currentPrivateMethod.spying) === true) {
        currentPrivateMethod.target = method;
      } else {
        privateApi[methodName] = method;
      }
      if (visibility === "public") {
        const publicApi = publicApiRef.current;
        const currentPublicMethod = publicApi[methodName];
        if ((currentPublicMethod == null ? void 0 : currentPublicMethod.spying) === true) {
          currentPublicMethod.target = method;
        } else {
          publicApi[methodName] = method;
        }
      }
    });
  };
  privateApi.register("private", {
    caches: {},
    eventManager: new EventManager()
  });
  return privateApi;
}
function createPublicAPI(privateApiRef) {
  const publicApi = {
    get state() {
      return privateApiRef.current.state;
    },
    get store() {
      return privateApiRef.current.store;
    },
    get instanceId() {
      return privateApiRef.current.instanceId;
    },
    [SYMBOL_API_PRIVATE]: privateApiRef.current
  };
  return publicApi;
}
function useGridApiInitialization(inputApiRef, props) {
  const publicApiRef = reactExports.useRef();
  const privateApiRef = reactExports.useRef();
  if (!privateApiRef.current) {
    privateApiRef.current = createPrivateAPI(publicApiRef);
  }
  if (!publicApiRef.current) {
    publicApiRef.current = createPublicAPI(privateApiRef);
  }
  const publishEvent = reactExports.useCallback((...args) => {
    const [name, params, event = {}] = args;
    event.defaultMuiPrevented = false;
    if (isSyntheticEvent(event) && event.isPropagationStopped()) {
      return;
    }
    const details = props.signature === GridSignature.DataGridPro ? {
      api: privateApiRef.current.getPublicApi()
    } : {};
    privateApiRef.current.eventManager.emit(name, params, event, details);
  }, [privateApiRef, props.signature]);
  const subscribeEvent = reactExports.useCallback((event, handler, options) => {
    privateApiRef.current.eventManager.on(event, handler, options);
    const api = privateApiRef.current;
    return () => {
      api.eventManager.removeListener(event, handler);
    };
  }, [privateApiRef]);
  useGridApiMethod(privateApiRef, {
    subscribeEvent,
    publishEvent
  }, "public");
  reactExports.useImperativeHandle(inputApiRef, () => publicApiRef.current, [publicApiRef]);
  reactExports.useEffect(() => {
    const api = privateApiRef.current;
    return () => {
      api.publishEvent("unmount");
    };
  }, [privateApiRef]);
  return privateApiRef;
}
const useGridLocaleText = (apiRef2, props) => {
  const getLocaleText = reactExports.useCallback((key) => {
    if (props.localeText[key] == null) {
      throw new Error(`Missing translation for key ${key}.`);
    }
    return props.localeText[key];
  }, [props.localeText]);
  apiRef2.current.register("public", {
    getLocaleText
  });
};
function _typeof(o2) {
  "@babel/helpers - typeof";
  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o3) {
    return typeof o3;
  } : function(o3) {
    return o3 && "function" == typeof Symbol && o3.constructor === Symbol && o3 !== Symbol.prototype ? "symbol" : typeof o3;
  }, _typeof(o2);
}
function _toPrimitive(input, hint) {
  if (_typeof(input) !== "object" || input === null)
    return input;
  var prim = input[Symbol.toPrimitive];
  if (prim !== void 0) {
    var res = prim.call(input, hint || "default");
    if (_typeof(res) !== "object")
      return res;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (hint === "string" ? String : Number)(input);
}
function _toPropertyKey(arg) {
  var key = _toPrimitive(arg, "string");
  return _typeof(key) === "symbol" ? key : String(key);
}
const useGridPipeProcessing = (apiRef2) => {
  const processorsCache = reactExports.useRef({});
  const isRunning = reactExports.useRef(false);
  const runAppliers = reactExports.useCallback((groupCache) => {
    if (isRunning.current || !groupCache) {
      return;
    }
    isRunning.current = true;
    Object.values(groupCache.appliers).forEach((callback) => {
      callback();
    });
    isRunning.current = false;
  }, []);
  const registerPipeProcessor = reactExports.useCallback((group, id, processor) => {
    if (!processorsCache.current[group]) {
      processorsCache.current[group] = {
        processors: /* @__PURE__ */ new Map(),
        appliers: {}
      };
    }
    const groupCache = processorsCache.current[group];
    const oldProcessor = groupCache.processors.get(id);
    if (oldProcessor !== processor) {
      groupCache.processors.set(id, processor);
      runAppliers(groupCache);
    }
    return () => {
      processorsCache.current[group].processors.set(id, null);
    };
  }, [runAppliers]);
  const registerPipeApplier = reactExports.useCallback((group, id, applier) => {
    if (!processorsCache.current[group]) {
      processorsCache.current[group] = {
        processors: /* @__PURE__ */ new Map(),
        appliers: {}
      };
    }
    processorsCache.current[group].appliers[id] = applier;
    return () => {
      const _appliers = processorsCache.current[group].appliers, otherAppliers = _objectWithoutPropertiesLoose$1(_appliers, [id].map(_toPropertyKey));
      processorsCache.current[group].appliers = otherAppliers;
    };
  }, []);
  const requestPipeProcessorsApplication = reactExports.useCallback((group) => {
    const groupCache = processorsCache.current[group];
    runAppliers(groupCache);
  }, [runAppliers]);
  const applyPipeProcessors = reactExports.useCallback((...args) => {
    const [group, value, context] = args;
    if (!processorsCache.current[group]) {
      return value;
    }
    const preProcessors = Array.from(processorsCache.current[group].processors.values());
    return preProcessors.reduce((acc, preProcessor) => {
      if (!preProcessor) {
        return acc;
      }
      return preProcessor(acc, context);
    }, value);
  }, []);
  const preProcessingPrivateApi = {
    registerPipeProcessor,
    registerPipeApplier,
    requestPipeProcessorsApplication
  };
  const preProcessingPublicApi = {
    unstable_applyPipeProcessors: applyPipeProcessors
  };
  useGridApiMethod(apiRef2, preProcessingPrivateApi, "private");
  useGridApiMethod(apiRef2, preProcessingPublicApi, "public");
};
const useGridRegisterPipeProcessor = (apiRef2, group, callback) => {
  const cleanup = reactExports.useRef();
  const id = reactExports.useRef(`mui-${Math.round(Math.random() * 1e9)}`);
  const registerPreProcessor = reactExports.useCallback(() => {
    cleanup.current = apiRef2.current.registerPipeProcessor(group, id.current, callback);
  }, [apiRef2, callback, group]);
  useFirstRender(() => {
    registerPreProcessor();
  });
  const isFirstRender = reactExports.useRef(true);
  reactExports.useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
    } else {
      registerPreProcessor();
    }
    return () => {
      if (cleanup.current) {
        cleanup.current();
        cleanup.current = null;
      }
    };
  }, [registerPreProcessor]);
};
const useGridRegisterPipeApplier = (apiRef2, group, callback) => {
  const cleanup = reactExports.useRef();
  const id = reactExports.useRef(`mui-${Math.round(Math.random() * 1e9)}`);
  const registerPreProcessor = reactExports.useCallback(() => {
    cleanup.current = apiRef2.current.registerPipeApplier(group, id.current, callback);
  }, [apiRef2, callback, group]);
  useFirstRender(() => {
    registerPreProcessor();
  });
  const isFirstRender = reactExports.useRef(true);
  reactExports.useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
    } else {
      registerPreProcessor();
    }
    return () => {
      if (cleanup.current) {
        cleanup.current();
        cleanup.current = null;
      }
    };
  }, [registerPreProcessor]);
};
const useGridRegisterStrategyProcessor = (apiRef2, strategyName, group, processor) => {
  const registerPreProcessor = reactExports.useCallback(() => {
    apiRef2.current.registerStrategyProcessor(strategyName, group, processor);
  }, [apiRef2, processor, group, strategyName]);
  useFirstRender(() => {
    registerPreProcessor();
  });
  const isFirstRender = reactExports.useRef(true);
  reactExports.useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
    } else {
      registerPreProcessor();
    }
  }, [registerPreProcessor]);
};
const GRID_DEFAULT_STRATEGY = "none";
const GRID_STRATEGIES_PROCESSORS = {
  rowTreeCreation: "rowTree",
  filtering: "rowTree",
  sorting: "rowTree",
  visibleRowsLookupCreation: "rowTree"
};
const useGridStrategyProcessing = (apiRef2) => {
  const availableStrategies = reactExports.useRef(/* @__PURE__ */ new Map());
  const strategiesCache = reactExports.useRef({});
  const registerStrategyProcessor = reactExports.useCallback((strategyName, processorName, processor) => {
    const cleanup = () => {
      const _ref = strategiesCache.current[processorName], otherProcessors = _objectWithoutPropertiesLoose$1(_ref, [strategyName].map(_toPropertyKey));
      strategiesCache.current[processorName] = otherProcessors;
    };
    if (!strategiesCache.current[processorName]) {
      strategiesCache.current[processorName] = {};
    }
    const groupPreProcessors = strategiesCache.current[processorName];
    const previousProcessor = groupPreProcessors[strategyName];
    groupPreProcessors[strategyName] = processor;
    if (!previousProcessor || previousProcessor === processor) {
      return cleanup;
    }
    if (strategyName === apiRef2.current.getActiveStrategy(GRID_STRATEGIES_PROCESSORS[processorName])) {
      apiRef2.current.publishEvent("activeStrategyProcessorChange", processorName);
    }
    return cleanup;
  }, [apiRef2]);
  const applyStrategyProcessor = reactExports.useCallback((processorName, params) => {
    const activeStrategy = apiRef2.current.getActiveStrategy(GRID_STRATEGIES_PROCESSORS[processorName]);
    if (activeStrategy == null) {
      throw new Error("Can't apply a strategy processor before defining an active strategy");
    }
    const groupCache = strategiesCache.current[processorName];
    if (!groupCache || !groupCache[activeStrategy]) {
      throw new Error(`No processor found for processor "${processorName}" on strategy "${activeStrategy}"`);
    }
    const processor = groupCache[activeStrategy];
    return processor(params);
  }, [apiRef2]);
  const getActiveStrategy = reactExports.useCallback((strategyGroup) => {
    var _availableStrategyEnt;
    const strategyEntries = Array.from(availableStrategies.current.entries());
    const availableStrategyEntry = strategyEntries.find(([, strategy]) => {
      if (strategy.group !== strategyGroup) {
        return false;
      }
      return strategy.isAvailable();
    });
    return (_availableStrategyEnt = availableStrategyEntry == null ? void 0 : availableStrategyEntry[0]) != null ? _availableStrategyEnt : GRID_DEFAULT_STRATEGY;
  }, []);
  const setStrategyAvailability = reactExports.useCallback((strategyGroup, strategyName, isAvailable) => {
    availableStrategies.current.set(strategyName, {
      group: strategyGroup,
      isAvailable
    });
    apiRef2.current.publishEvent("strategyAvailabilityChange");
  }, [apiRef2]);
  const strategyProcessingApi = {
    registerStrategyProcessor,
    applyStrategyProcessor,
    getActiveStrategy,
    setStrategyAvailability
  };
  useGridApiMethod(apiRef2, strategyProcessingApi, "private");
};
const useGridStateInitialization = (apiRef2, props) => {
  const controlStateMapRef = reactExports.useRef({});
  const [, rawForceUpdate] = reactExports.useState();
  const registerControlState = reactExports.useCallback((controlStateItem) => {
    controlStateMapRef.current[controlStateItem.stateId] = controlStateItem;
  }, []);
  const setState = reactExports.useCallback((state, reason) => {
    let newState;
    if (isFunction(state)) {
      newState = state(apiRef2.current.state);
    } else {
      newState = state;
    }
    if (apiRef2.current.state === newState) {
      return false;
    }
    let ignoreSetState = false;
    const updatedControlStateIds = [];
    Object.keys(controlStateMapRef.current).forEach((stateId) => {
      const controlState = controlStateMapRef.current[stateId];
      const oldSubState = controlState.stateSelector(apiRef2.current.state, apiRef2.current.instanceId);
      const newSubState = controlState.stateSelector(newState, apiRef2.current.instanceId);
      if (newSubState === oldSubState) {
        return;
      }
      updatedControlStateIds.push({
        stateId: controlState.stateId,
        hasPropChanged: newSubState !== controlState.propModel
      });
      if (controlState.propModel !== void 0 && newSubState !== controlState.propModel) {
        ignoreSetState = true;
      }
    });
    if (updatedControlStateIds.length > 1) {
      throw new Error(`You're not allowed to update several sub-state in one transaction. You already updated ${updatedControlStateIds[0].stateId}, therefore, you're not allowed to update ${updatedControlStateIds.map((el) => el.stateId).join(", ")} in the same transaction.`);
    }
    if (!ignoreSetState) {
      apiRef2.current.state = newState;
      if (apiRef2.current.publishEvent) {
        apiRef2.current.publishEvent("stateChange", newState);
      }
      apiRef2.current.store.update(newState);
    }
    if (updatedControlStateIds.length === 1) {
      const {
        stateId,
        hasPropChanged
      } = updatedControlStateIds[0];
      const controlState = controlStateMapRef.current[stateId];
      const model = controlState.stateSelector(newState, apiRef2.current.instanceId);
      if (controlState.propOnChange && hasPropChanged) {
        const details = props.signature === GridSignature.DataGridPro ? {
          api: apiRef2.current,
          reason
        } : {
          reason
        };
        controlState.propOnChange(model, details);
      }
      if (!ignoreSetState) {
        apiRef2.current.publishEvent(controlState.changeEvent, model, {
          reason
        });
      }
    }
    return !ignoreSetState;
  }, [apiRef2, props.signature]);
  const updateControlState = reactExports.useCallback((key, state, reason) => {
    return apiRef2.current.setState((previousState) => {
      return _extends$1({}, previousState, {
        [key]: state(previousState[key])
      });
    }, reason);
  }, [apiRef2]);
  const forceUpdate = reactExports.useCallback(() => rawForceUpdate(() => apiRef2.current.state), [apiRef2]);
  const publicStateApi = {
    setState,
    forceUpdate
  };
  const privateStateApi = {
    updateControlState,
    registerControlState
  };
  useGridApiMethod(apiRef2, publicStateApi, "public");
  useGridApiMethod(apiRef2, privateStateApi, "private");
};
const useGridInitialization = (inputApiRef, props) => {
  const privateApiRef = useGridApiInitialization(inputApiRef, props);
  useGridLoggerFactory(privateApiRef, props);
  useGridStateInitialization(privateApiRef, props);
  useGridPipeProcessing(privateApiRef);
  useGridStrategyProcessing(privateApiRef);
  useGridLocaleText(privateApiRef, props);
  return privateApiRef;
};
const useGridInitializeState = (initializer, privateApiRef, props) => {
  const isInitialized = reactExports.useRef(false);
  if (!isInitialized.current) {
    privateApiRef.current.state = initializer(privateApiRef.current.state, props, privateApiRef);
    isInitialized.current = true;
  }
};
const dateRegex = /(\d+)-(\d+)-(\d+)/;
const dateTimeRegex = /(\d+)-(\d+)-(\d+)T(\d+):(\d+)/;
function buildApplyFilterFn(filterItem2, compareFn, showTime, keepHours) {
  if (!filterItem2.value) {
    return null;
  }
  const [year, month, day, hour, minute] = filterItem2.value.match(showTime ? dateTimeRegex : dateRegex).slice(1).map(Number);
  const time = new Date(year, month - 1, day, hour || 0, minute || 0).getTime();
  return (value) => {
    if (!value) {
      return false;
    }
    if (keepHours) {
      return compareFn(value.getTime(), time);
    }
    const dateCopy = new Date(value);
    const timeToCompare = dateCopy.setHours(showTime ? value.getHours() : 0, showTime ? value.getMinutes() : 0, 0, 0);
    return compareFn(timeToCompare, time);
  };
}
const getGridDateOperators = (showTime) => convertLegacyOperators([{
  value: "is",
  getApplyFilterFnV7: (filterItem2) => {
    return buildApplyFilterFn(filterItem2, (value1, value2) => value1 === value2, showTime);
  },
  InputComponent: GridFilterInputDate,
  InputComponentProps: {
    type: showTime ? "datetime-local" : "date"
  }
}, {
  value: "not",
  getApplyFilterFnV7: (filterItem2) => {
    return buildApplyFilterFn(filterItem2, (value1, value2) => value1 !== value2, showTime);
  },
  InputComponent: GridFilterInputDate,
  InputComponentProps: {
    type: showTime ? "datetime-local" : "date"
  }
}, {
  value: "after",
  getApplyFilterFnV7: (filterItem2) => {
    return buildApplyFilterFn(filterItem2, (value1, value2) => value1 > value2, showTime);
  },
  InputComponent: GridFilterInputDate,
  InputComponentProps: {
    type: showTime ? "datetime-local" : "date"
  }
}, {
  value: "onOrAfter",
  getApplyFilterFnV7: (filterItem2) => {
    return buildApplyFilterFn(filterItem2, (value1, value2) => value1 >= value2, showTime);
  },
  InputComponent: GridFilterInputDate,
  InputComponentProps: {
    type: showTime ? "datetime-local" : "date"
  }
}, {
  value: "before",
  getApplyFilterFnV7: (filterItem2) => {
    return buildApplyFilterFn(filterItem2, (value1, value2) => value1 < value2, showTime, !showTime);
  },
  InputComponent: GridFilterInputDate,
  InputComponentProps: {
    type: showTime ? "datetime-local" : "date"
  }
}, {
  value: "onOrBefore",
  getApplyFilterFnV7: (filterItem2) => {
    return buildApplyFilterFn(filterItem2, (value1, value2) => value1 <= value2, showTime);
  },
  InputComponent: GridFilterInputDate,
  InputComponentProps: {
    type: showTime ? "datetime-local" : "date"
  }
}, {
  value: "isEmpty",
  getApplyFilterFnV7: () => {
    return (value) => {
      return value == null;
    };
  },
  requiresFilterValue: false
}, {
  value: "isNotEmpty",
  getApplyFilterFnV7: () => {
    return (value) => {
      return value != null;
    };
  },
  requiresFilterValue: false
}]);
function throwIfNotDateObject({
  value,
  columnType,
  rowId,
  field
}) {
  if (!(value instanceof Date)) {
    throw new Error([`MUI: \`${columnType}\` column type only accepts \`Date\` objects as values.`, "Use `valueGetter` to transform the value into a `Date` object.", `Row ID: ${rowId}, field: "${field}".`].join("\n"));
  }
}
function gridDateFormatter({
  value,
  field,
  id
}) {
  if (!value) {
    return "";
  }
  throwIfNotDateObject({
    value,
    columnType: "date",
    rowId: id,
    field
  });
  return value.toLocaleDateString();
}
function gridDateTimeFormatter({
  value,
  field,
  id
}) {
  if (!value) {
    return "";
  }
  throwIfNotDateObject({
    value,
    columnType: "dateTime",
    rowId: id,
    field
  });
  return value.toLocaleString();
}
const GRID_DATE_COL_DEF = _extends$1({}, GRID_STRING_COL_DEF, {
  type: "date",
  sortComparator: gridDateComparator,
  valueFormatter: gridDateFormatter,
  filterOperators: getGridDateOperators(),
  renderEditCell: renderEditDateCell,
  getApplyQuickFilterFn: void 0,
  getApplyQuickFilterFnV7: void 0,
  // @ts-ignore
  pastedValueParser: (value) => new Date(value)
});
const GRID_DATETIME_COL_DEF = _extends$1({}, GRID_STRING_COL_DEF, {
  type: "dateTime",
  sortComparator: gridDateComparator,
  valueFormatter: gridDateTimeFormatter,
  filterOperators: getGridDateOperators(true),
  renderEditCell: renderEditDateCell,
  getApplyQuickFilterFn: void 0,
  getApplyQuickFilterFnV7: void 0,
  // @ts-ignore
  pastedValueParser: (value) => new Date(value)
});
const parseNumericValue = (value) => {
  if (value == null) {
    return null;
  }
  return Number(value);
};
const getGridNumericQuickFilterFn = tagInternalFilter((value) => {
  if (value == null || Number.isNaN(value) || value === "") {
    return null;
  }
  return (columnValue) => {
    return parseNumericValue(columnValue) === parseNumericValue(value);
  };
});
const getGridNumericOperators = () => convertLegacyOperators([{
  value: "=",
  getApplyFilterFnV7: (filterItem2) => {
    if (filterItem2.value == null || Number.isNaN(filterItem2.value)) {
      return null;
    }
    return (value) => {
      return parseNumericValue(value) === filterItem2.value;
    };
  },
  InputComponent: GridFilterInputValue,
  InputComponentProps: {
    type: "number"
  }
}, {
  value: "!=",
  getApplyFilterFnV7: (filterItem2) => {
    if (filterItem2.value == null || Number.isNaN(filterItem2.value)) {
      return null;
    }
    return (value) => {
      return parseNumericValue(value) !== filterItem2.value;
    };
  },
  InputComponent: GridFilterInputValue,
  InputComponentProps: {
    type: "number"
  }
}, {
  value: ">",
  getApplyFilterFnV7: (filterItem2) => {
    if (filterItem2.value == null || Number.isNaN(filterItem2.value)) {
      return null;
    }
    return (value) => {
      if (value == null) {
        return false;
      }
      return parseNumericValue(value) > filterItem2.value;
    };
  },
  InputComponent: GridFilterInputValue,
  InputComponentProps: {
    type: "number"
  }
}, {
  value: ">=",
  getApplyFilterFnV7: (filterItem2) => {
    if (filterItem2.value == null || Number.isNaN(filterItem2.value)) {
      return null;
    }
    return (value) => {
      if (value == null) {
        return false;
      }
      return parseNumericValue(value) >= filterItem2.value;
    };
  },
  InputComponent: GridFilterInputValue,
  InputComponentProps: {
    type: "number"
  }
}, {
  value: "<",
  getApplyFilterFnV7: (filterItem2) => {
    if (filterItem2.value == null || Number.isNaN(filterItem2.value)) {
      return null;
    }
    return (value) => {
      if (value == null) {
        return false;
      }
      return parseNumericValue(value) < filterItem2.value;
    };
  },
  InputComponent: GridFilterInputValue,
  InputComponentProps: {
    type: "number"
  }
}, {
  value: "<=",
  getApplyFilterFnV7: (filterItem2) => {
    if (filterItem2.value == null || Number.isNaN(filterItem2.value)) {
      return null;
    }
    return (value) => {
      if (value == null) {
        return false;
      }
      return parseNumericValue(value) <= filterItem2.value;
    };
  },
  InputComponent: GridFilterInputValue,
  InputComponentProps: {
    type: "number"
  }
}, {
  value: "isEmpty",
  getApplyFilterFnV7: () => {
    return (value) => {
      return value == null;
    };
  },
  requiresFilterValue: false
}, {
  value: "isNotEmpty",
  getApplyFilterFnV7: () => {
    return (value) => {
      return value != null;
    };
  },
  requiresFilterValue: false
}, {
  value: "isAnyOf",
  getApplyFilterFnV7: (filterItem2) => {
    if (!Array.isArray(filterItem2.value) || filterItem2.value.length === 0) {
      return null;
    }
    return (value) => {
      return value != null && filterItem2.value.includes(Number(value));
    };
  },
  InputComponent: GridFilterInputMultipleValue,
  InputComponentProps: {
    type: "number"
  }
}]);
const GRID_NUMERIC_COL_DEF = _extends$1({}, GRID_STRING_COL_DEF, {
  type: "number",
  align: "right",
  headerAlign: "right",
  sortComparator: gridNumberComparator,
  valueParser: (value) => value === "" ? null : Number(value),
  valueFormatter: ({
    value
  }) => isNumber(value) ? value.toLocaleString() : value || "",
  filterOperators: getGridNumericOperators(),
  getApplyQuickFilterFn: convertQuickFilterV7ToLegacy(getGridNumericQuickFilterFn),
  getApplyQuickFilterFnV7: getGridNumericQuickFilterFn
});
const parseObjectValue = (value) => {
  if (value == null || !isObject(value)) {
    return value;
  }
  return value.value;
};
const getGridSingleSelectOperators = () => convertLegacyOperators([{
  value: "is",
  getApplyFilterFnV7: (filterItem2) => {
    if (filterItem2.value == null || filterItem2.value === "") {
      return null;
    }
    return (value) => parseObjectValue(value) === parseObjectValue(filterItem2.value);
  },
  InputComponent: GridFilterInputSingleSelect
}, {
  value: "not",
  getApplyFilterFnV7: (filterItem2) => {
    if (filterItem2.value == null || filterItem2.value === "") {
      return null;
    }
    return (value) => parseObjectValue(value) !== parseObjectValue(filterItem2.value);
  },
  InputComponent: GridFilterInputSingleSelect
}, {
  value: "isAnyOf",
  getApplyFilterFnV7: (filterItem2) => {
    if (!Array.isArray(filterItem2.value) || filterItem2.value.length === 0) {
      return null;
    }
    const filterItemValues = filterItem2.value.map(parseObjectValue);
    return (value) => filterItemValues.includes(parseObjectValue(value));
  },
  InputComponent: GridFilterInputMultipleSingleSelect
}]);
const isArrayOfObjects = (options) => {
  return typeof options[0] === "object";
};
const defaultGetOptionValue = (value) => {
  return isObject(value) ? value.value : value;
};
const defaultGetOptionLabel = (value) => {
  return isObject(value) ? value.label : String(value);
};
const GRID_SINGLE_SELECT_COL_DEF = _extends$1({}, GRID_STRING_COL_DEF, {
  type: "singleSelect",
  getOptionLabel: defaultGetOptionLabel,
  getOptionValue: defaultGetOptionValue,
  valueFormatter(params) {
    const {
      id,
      field,
      value,
      api
    } = params;
    const colDef = params.api.getColumn(field);
    if (!isSingleSelectColDef(colDef)) {
      return "";
    }
    let valueOptions;
    if (typeof colDef.valueOptions === "function") {
      valueOptions = colDef.valueOptions({
        id,
        row: id ? api.getRow(id) : null,
        field
      });
    } else {
      valueOptions = colDef.valueOptions;
    }
    if (value == null) {
      return "";
    }
    if (!valueOptions) {
      return value;
    }
    if (!isArrayOfObjects(valueOptions)) {
      return colDef.getOptionLabel(value);
    }
    const valueOption = valueOptions.find((option) => colDef.getOptionValue(option) === value);
    return valueOption ? colDef.getOptionLabel(valueOption) : "";
  },
  renderEditCell: renderEditSingleSelectCell,
  filterOperators: getGridSingleSelectOperators(),
  // @ts-ignore
  pastedValueParser: (value, params) => {
    const colDef = params.colDef;
    const colDefValueOptions = colDef.valueOptions;
    const valueOptions = typeof colDefValueOptions === "function" ? colDefValueOptions({
      field: colDef.field
    }) : colDefValueOptions || [];
    const getOptionValue = colDef.getOptionValue;
    const valueOption = valueOptions.find((option) => {
      if (getOptionValue(option) === value) {
        return true;
      }
      return false;
    });
    if (valueOption) {
      return value;
    }
    return void 0;
  }
});
const DEFAULT_GRID_COL_TYPE_KEY = "__default__";
const getGridDefaultColumnTypes = () => {
  const nativeColumnTypes = {
    string: GRID_STRING_COL_DEF,
    number: GRID_NUMERIC_COL_DEF,
    date: GRID_DATE_COL_DEF,
    dateTime: GRID_DATETIME_COL_DEF,
    boolean: GRID_BOOLEAN_COL_DEF,
    singleSelect: GRID_SINGLE_SELECT_COL_DEF,
    [GRID_ACTIONS_COLUMN_TYPE]: GRID_ACTIONS_COL_DEF,
    [DEFAULT_GRID_COL_TYPE_KEY]: GRID_STRING_COL_DEF
  };
  return nativeColumnTypes;
};
function sanitizeCellValue(value, delimiterCharacter) {
  if (typeof value === "string") {
    if ([delimiterCharacter, "\n", "\r", '"'].some((delimiter) => value.includes(delimiter))) {
      return `"${value.replace(/"/g, '""')}"`;
    }
    return value;
  }
  return value;
}
const serializeCellValue = (cellParams, options) => {
  const {
    delimiterCharacter,
    ignoreValueFormatter
  } = options;
  let value;
  if (ignoreValueFormatter) {
    var _cellParams$value2;
    const columnType = cellParams.colDef.type;
    if (columnType === "number") {
      value = String(cellParams.value);
    } else if (columnType === "date" || columnType === "dateTime") {
      var _cellParams$value;
      value = (_cellParams$value = cellParams.value) == null ? void 0 : _cellParams$value.toISOString();
    } else if (typeof ((_cellParams$value2 = cellParams.value) == null ? void 0 : _cellParams$value2.toString) === "function") {
      value = cellParams.value.toString();
    } else {
      value = cellParams.value;
    }
  } else {
    value = cellParams.formattedValue;
  }
  return sanitizeCellValue(value, delimiterCharacter);
};
buildWarning(["MUI: When the value of a field is an object or a `renderCell` is provided, the CSV export might not display the value correctly.", "You can provide a `valueFormatter` with a string representation to be used."]);
class CSVRow {
  constructor(options) {
    this.options = void 0;
    this.rowString = "";
    this.isEmpty = true;
    this.options = options;
  }
  addValue(value) {
    if (!this.isEmpty) {
      this.rowString += this.options.delimiterCharacter;
    }
    if (value === null || value === void 0) {
      this.rowString += "";
    } else if (typeof this.options.sanitizeCellValue === "function") {
      this.rowString += this.options.sanitizeCellValue(value, this.options.delimiterCharacter);
    } else {
      this.rowString += value;
    }
    this.isEmpty = false;
  }
  getRowString() {
    return this.rowString;
  }
}
const serializeRow = ({
  id,
  columns,
  getCellParams,
  delimiterCharacter,
  ignoreValueFormatter
}) => {
  const row = new CSVRow({
    delimiterCharacter
  });
  columns.forEach((column) => {
    const cellParams = getCellParams(id, column.field);
    row.addValue(serializeCellValue(cellParams, {
      delimiterCharacter,
      ignoreValueFormatter
    }));
  });
  return row.getRowString();
};
function buildCSV(options) {
  const {
    columns,
    rowIds,
    delimiterCharacter,
    includeHeaders,
    includeColumnGroupsHeaders,
    ignoreValueFormatter,
    apiRef: apiRef2
  } = options;
  const CSVBody = rowIds.reduce((acc, id) => `${acc}${serializeRow({
    id,
    columns,
    getCellParams: apiRef2.current.getCellParams,
    delimiterCharacter,
    ignoreValueFormatter
  })}\r
`, "").trim();
  if (!includeHeaders) {
    return CSVBody;
  }
  const filteredColumns = columns.filter((column) => column.field !== GRID_CHECKBOX_SELECTION_COL_DEF.field);
  const headerRows = [];
  if (includeColumnGroupsHeaders) {
    const columnGroupLookup = apiRef2.current.unstable_getAllGroupDetails();
    let maxColumnGroupsDepth = 0;
    const columnGroupPathsLookup = filteredColumns.reduce((acc, column) => {
      const columnGroupPath = apiRef2.current.unstable_getColumnGroupPath(column.field);
      acc[column.field] = columnGroupPath;
      maxColumnGroupsDepth = Math.max(maxColumnGroupsDepth, columnGroupPath.length);
      return acc;
    }, {});
    for (let i2 = 0; i2 < maxColumnGroupsDepth; i2 += 1) {
      const headerGroupRow = new CSVRow({
        delimiterCharacter,
        sanitizeCellValue
      });
      headerRows.push(headerGroupRow);
      filteredColumns.forEach((column) => {
        const columnGroupId = (columnGroupPathsLookup[column.field] || [])[i2];
        const columnGroup = columnGroupLookup[columnGroupId];
        headerGroupRow.addValue(columnGroup ? columnGroup.headerName || columnGroup.groupId : "");
      });
    }
  }
  const mainHeaderRow = new CSVRow({
    delimiterCharacter,
    sanitizeCellValue
  });
  filteredColumns.forEach((column) => {
    mainHeaderRow.addValue(column.headerName || column.field);
  });
  headerRows.push(mainHeaderRow);
  const CSVHead = `${headerRows.map((row) => row.getRowString()).join("\r\n")}\r
`;
  return `${CSVHead}${CSVBody}`.trim();
}
function writeToClipboardPolyfill(data) {
  const span = document.createElement("span");
  span.style.whiteSpace = "pre";
  span.style.userSelect = "all";
  span.style.opacity = "0px";
  span.textContent = data;
  document.body.appendChild(span);
  const range = document.createRange();
  range.selectNode(span);
  const selection = window.getSelection();
  selection.removeAllRanges();
  selection.addRange(range);
  try {
    document.execCommand("copy");
  } finally {
    document.body.removeChild(span);
  }
}
function copyToClipboard(data) {
  if (navigator.clipboard) {
    navigator.clipboard.writeText(data).catch(() => {
      writeToClipboardPolyfill(data);
    });
  } else {
    writeToClipboardPolyfill(data);
  }
}
function hasNativeSelection(element) {
  var _window$getSelection;
  if ((_window$getSelection = window.getSelection()) != null && _window$getSelection.toString()) {
    return true;
  }
  if (element && (element.selectionEnd || 0) - (element.selectionStart || 0) > 0) {
    return true;
  }
  return false;
}
const useGridClipboard = (apiRef2, props) => {
  const ignoreValueFormatterProp = props.unstable_ignoreValueFormatterDuringExport;
  const ignoreValueFormatter = (typeof ignoreValueFormatterProp === "object" ? ignoreValueFormatterProp == null ? void 0 : ignoreValueFormatterProp.clipboardExport : ignoreValueFormatterProp) || false;
  const clipboardCopyCellDelimiter = props.clipboardCopyCellDelimiter;
  const handleCopy = reactExports.useCallback((event) => {
    if (!((event.ctrlKey || event.metaKey) && event.key === "c")) {
      return;
    }
    if (hasNativeSelection(event.target)) {
      return;
    }
    let textToCopy = "";
    const selectedRows = apiRef2.current.getSelectedRows();
    if (selectedRows.size > 0) {
      textToCopy = apiRef2.current.getDataAsCsv({
        includeHeaders: false,
        // TODO: make it configurable
        delimiter: clipboardCopyCellDelimiter
      });
    } else {
      const focusedCell = gridFocusCellSelector(apiRef2);
      if (focusedCell) {
        const cellParams = apiRef2.current.getCellParams(focusedCell.id, focusedCell.field);
        textToCopy = serializeCellValue(cellParams, {
          delimiterCharacter: clipboardCopyCellDelimiter,
          ignoreValueFormatter
        });
      }
    }
    textToCopy = apiRef2.current.unstable_applyPipeProcessors("clipboardCopy", textToCopy);
    if (textToCopy) {
      copyToClipboard(textToCopy);
      apiRef2.current.publishEvent("clipboardCopy", textToCopy);
    }
  }, [apiRef2, ignoreValueFormatter, clipboardCopyCellDelimiter]);
  useGridNativeEventListener(apiRef2, apiRef2.current.rootElementRef, "keydown", handleCopy);
  useGridApiOptionHandler(apiRef2, "clipboardCopy", props.onClipboardCopy);
};
const columnMenuStateInitializer = (state) => _extends$1({}, state, {
  columnMenu: {
    open: false
  }
});
const useGridColumnMenu = (apiRef2) => {
  const logger = useGridLogger(apiRef2, "useGridColumnMenu");
  const showColumnMenu = reactExports.useCallback((field) => {
    const shouldUpdate = apiRef2.current.setState((state) => {
      if (state.columnMenu.open && state.columnMenu.field === field) {
        return state;
      }
      logger.debug("Opening Column Menu");
      return _extends$1({}, state, {
        columnMenu: {
          open: true,
          field
        }
      });
    });
    if (shouldUpdate) {
      apiRef2.current.hidePreferences();
      apiRef2.current.forceUpdate();
    }
  }, [apiRef2, logger]);
  const hideColumnMenu = reactExports.useCallback(() => {
    const columnMenuState = gridColumnMenuSelector(apiRef2.current.state);
    if (columnMenuState.field) {
      const columnLookup = gridColumnLookupSelector(apiRef2);
      const columnVisibilityModel = gridColumnVisibilityModelSelector(apiRef2);
      const orderedFields = gridColumnFieldsSelector(apiRef2);
      let fieldToFocus = columnMenuState.field;
      if (!columnLookup[fieldToFocus]) {
        fieldToFocus = orderedFields[0];
      }
      if (columnVisibilityModel[fieldToFocus] === false) {
        const visibleOrderedFields = orderedFields.filter((field) => {
          if (field === fieldToFocus) {
            return true;
          }
          return columnVisibilityModel[field] !== false;
        });
        const fieldIndex = visibleOrderedFields.indexOf(fieldToFocus);
        fieldToFocus = visibleOrderedFields[fieldIndex + 1] || visibleOrderedFields[fieldIndex - 1];
      }
      apiRef2.current.setColumnHeaderFocus(fieldToFocus);
    }
    const shouldUpdate = apiRef2.current.setState((state) => {
      if (!state.columnMenu.open && state.columnMenu.field === void 0) {
        return state;
      }
      logger.debug("Hiding Column Menu");
      return _extends$1({}, state, {
        columnMenu: _extends$1({}, state.columnMenu, {
          open: false,
          field: void 0
        })
      });
    });
    if (shouldUpdate) {
      apiRef2.current.forceUpdate();
    }
  }, [apiRef2, logger]);
  const toggleColumnMenu = reactExports.useCallback((field) => {
    logger.debug("Toggle Column Menu");
    const columnMenu = gridColumnMenuSelector(apiRef2.current.state);
    if (!columnMenu.open || columnMenu.field !== field) {
      showColumnMenu(field);
    } else {
      hideColumnMenu();
    }
  }, [apiRef2, logger, showColumnMenu, hideColumnMenu]);
  const columnMenuApi = {
    showColumnMenu,
    hideColumnMenu,
    toggleColumnMenu
  };
  useGridApiMethod(apiRef2, columnMenuApi, "public");
  useGridApiEventHandler(apiRef2, "columnResizeStart", hideColumnMenu);
  useGridApiEventHandler(apiRef2, "virtualScrollerWheel", apiRef2.current.hideColumnMenu);
  useGridApiEventHandler(apiRef2, "virtualScrollerTouchMove", apiRef2.current.hideColumnMenu);
};
const COLUMNS_DIMENSION_PROPERTIES = ["maxWidth", "minWidth", "width", "flex"];
function computeFlexColumnsWidth({
  initialFreeSpace,
  totalFlexUnits,
  flexColumns
}) {
  const uniqueFlexColumns = new Set(flexColumns.map((col) => col.field));
  const flexColumnsLookup = {
    all: {},
    frozenFields: [],
    freeze: (field) => {
      const value = flexColumnsLookup.all[field];
      if (value && value.frozen !== true) {
        flexColumnsLookup.all[field].frozen = true;
        flexColumnsLookup.frozenFields.push(field);
      }
    }
  };
  function loopOverFlexItems() {
    if (flexColumnsLookup.frozenFields.length === uniqueFlexColumns.size) {
      return;
    }
    const violationsLookup = {
      min: {},
      max: {}
    };
    let remainingFreeSpace = initialFreeSpace;
    let flexUnits = totalFlexUnits;
    let totalViolation = 0;
    flexColumnsLookup.frozenFields.forEach((field) => {
      remainingFreeSpace -= flexColumnsLookup.all[field].computedWidth;
      flexUnits -= flexColumnsLookup.all[field].flex;
    });
    for (let i2 = 0; i2 < flexColumns.length; i2 += 1) {
      const column = flexColumns[i2];
      if (flexColumnsLookup.all[column.field] && flexColumnsLookup.all[column.field].frozen === true) {
        continue;
      }
      const widthPerFlexUnit = remainingFreeSpace / flexUnits;
      let computedWidth = widthPerFlexUnit * column.flex;
      if (computedWidth < column.minWidth) {
        totalViolation += column.minWidth - computedWidth;
        computedWidth = column.minWidth;
        violationsLookup.min[column.field] = true;
      } else if (computedWidth > column.maxWidth) {
        totalViolation += column.maxWidth - computedWidth;
        computedWidth = column.maxWidth;
        violationsLookup.max[column.field] = true;
      }
      flexColumnsLookup.all[column.field] = {
        frozen: false,
        computedWidth,
        flex: column.flex
      };
    }
    if (totalViolation < 0) {
      Object.keys(violationsLookup.max).forEach((field) => {
        flexColumnsLookup.freeze(field);
      });
    } else if (totalViolation > 0) {
      Object.keys(violationsLookup.min).forEach((field) => {
        flexColumnsLookup.freeze(field);
      });
    } else {
      flexColumns.forEach(({
        field
      }) => {
        flexColumnsLookup.freeze(field);
      });
    }
    loopOverFlexItems();
  }
  loopOverFlexItems();
  return flexColumnsLookup.all;
}
const hydrateColumnsWidth = (rawState, viewportInnerWidth) => {
  const columnsLookup = {};
  let totalFlexUnits = 0;
  let widthAllocatedBeforeFlex = 0;
  const flexColumns = [];
  rawState.orderedFields.forEach((columnField) => {
    const newColumn = _extends$1({}, rawState.lookup[columnField]);
    if (rawState.columnVisibilityModel[columnField] === false) {
      newColumn.computedWidth = 0;
    } else {
      let computedWidth;
      if (newColumn.flex && newColumn.flex > 0) {
        totalFlexUnits += newColumn.flex;
        computedWidth = 0;
        flexColumns.push(newColumn);
      } else {
        computedWidth = clamp(newColumn.width || GRID_STRING_COL_DEF.width, newColumn.minWidth || GRID_STRING_COL_DEF.minWidth, newColumn.maxWidth || GRID_STRING_COL_DEF.maxWidth);
      }
      widthAllocatedBeforeFlex += computedWidth;
      newColumn.computedWidth = computedWidth;
    }
    columnsLookup[columnField] = newColumn;
  });
  const initialFreeSpace = Math.max(viewportInnerWidth - widthAllocatedBeforeFlex, 0);
  if (totalFlexUnits > 0 && viewportInnerWidth > 0) {
    const computedColumnWidths = computeFlexColumnsWidth({
      initialFreeSpace,
      totalFlexUnits,
      flexColumns
    });
    Object.keys(computedColumnWidths).forEach((field) => {
      columnsLookup[field].computedWidth = computedColumnWidths[field].computedWidth;
    });
  }
  return _extends$1({}, rawState, {
    lookup: columnsLookup
  });
};
const applyInitialState = (columnsState, initialState) => {
  if (!initialState) {
    return columnsState;
  }
  const {
    orderedFields = [],
    dimensions = {}
  } = initialState;
  const columnsWithUpdatedDimensions = Object.keys(dimensions);
  if (columnsWithUpdatedDimensions.length === 0 && orderedFields.length === 0) {
    return columnsState;
  }
  const orderedFieldsLookup = {};
  const cleanOrderedFields = [];
  for (let i2 = 0; i2 < orderedFields.length; i2 += 1) {
    const field = orderedFields[i2];
    if (columnsState.lookup[field]) {
      orderedFieldsLookup[field] = true;
      cleanOrderedFields.push(field);
    }
  }
  const newOrderedFields = cleanOrderedFields.length === 0 ? columnsState.orderedFields : [...cleanOrderedFields, ...columnsState.orderedFields.filter((field) => !orderedFieldsLookup[field])];
  const newColumnLookup = _extends$1({}, columnsState.lookup);
  for (let i2 = 0; i2 < columnsWithUpdatedDimensions.length; i2 += 1) {
    const field = columnsWithUpdatedDimensions[i2];
    const newColDef = _extends$1({}, newColumnLookup[field], {
      hasBeenResized: true
    });
    Object.entries(dimensions[field]).forEach(([key, value]) => {
      newColDef[key] = value === -1 ? Infinity : value;
    });
    newColumnLookup[field] = newColDef;
  }
  const newColumnsState = _extends$1({}, columnsState, {
    orderedFields: newOrderedFields,
    lookup: newColumnLookup
  });
  return newColumnsState;
};
function getDefaultColTypeDef(columnTypes, type) {
  let colDef = columnTypes[DEFAULT_GRID_COL_TYPE_KEY];
  if (type && columnTypes[type]) {
    colDef = columnTypes[type];
  }
  return colDef;
}
const createColumnsState = ({
  apiRef: apiRef2,
  columnsToUpsert,
  initialState,
  columnTypes,
  columnVisibilityModel = gridColumnVisibilityModelSelector(apiRef2),
  keepOnlyColumnsToUpsert = false
}) => {
  var _apiRef$current$getRo, _apiRef$current$getRo2, _apiRef$current;
  const isInsideStateInitializer = !apiRef2.current.state.columns;
  let columnsState;
  if (isInsideStateInitializer) {
    columnsState = {
      orderedFields: [],
      lookup: {},
      columnVisibilityModel
    };
  } else {
    const currentState = gridColumnsStateSelector(apiRef2.current.state);
    columnsState = {
      orderedFields: keepOnlyColumnsToUpsert ? [] : [...currentState.orderedFields],
      lookup: _extends$1({}, currentState.lookup),
      // Will be cleaned later if keepOnlyColumnsToUpsert=true
      columnVisibilityModel
    };
  }
  let columnsToKeep = {};
  if (keepOnlyColumnsToUpsert && !isInsideStateInitializer) {
    columnsToKeep = Object.keys(columnsState.lookup).reduce((acc, key) => _extends$1({}, acc, {
      [key]: false
    }), {});
  }
  columnsToUpsert.forEach((newColumn) => {
    const {
      field
    } = newColumn;
    columnsToKeep[field] = true;
    let existingState = columnsState.lookup[field];
    if (existingState == null) {
      existingState = _extends$1({}, getDefaultColTypeDef(columnTypes, newColumn.type), {
        field,
        hasBeenResized: false
      });
      columnsState.orderedFields.push(field);
    } else if (keepOnlyColumnsToUpsert) {
      columnsState.orderedFields.push(field);
    }
    if (existingState && existingState.type !== newColumn.type) {
      existingState = _extends$1({}, getDefaultColTypeDef(columnTypes, newColumn.type), {
        field
      });
    }
    let hasBeenResized = existingState.hasBeenResized;
    COLUMNS_DIMENSION_PROPERTIES.forEach((key) => {
      if (newColumn[key] !== void 0) {
        hasBeenResized = true;
        if (newColumn[key] === -1) {
          newColumn[key] = Infinity;
        }
      }
    });
    columnsState.lookup[field] = _extends$1({}, existingState, newColumn, {
      hasBeenResized
    });
  });
  if (keepOnlyColumnsToUpsert && !isInsideStateInitializer) {
    Object.keys(columnsState.lookup).forEach((field) => {
      if (!columnsToKeep[field]) {
        delete columnsState.lookup[field];
      }
    });
  }
  const columnsStateWithPreProcessing = apiRef2.current.unstable_applyPipeProcessors("hydrateColumns", columnsState);
  const columnsStateWithPortableColumns = applyInitialState(columnsStateWithPreProcessing, initialState);
  return hydrateColumnsWidth(columnsStateWithPortableColumns, (_apiRef$current$getRo = (_apiRef$current$getRo2 = (_apiRef$current = apiRef2.current).getRootDimensions) == null || (_apiRef$current$getRo2 = _apiRef$current$getRo2.call(_apiRef$current)) == null ? void 0 : _apiRef$current$getRo2.viewportInnerSize.width) != null ? _apiRef$current$getRo : 0);
};
const mergeColumnsState = (columnsState) => (state) => _extends$1({}, state, {
  columns: columnsState
});
function getFirstNonSpannedColumnToRender({
  firstColumnToRender,
  apiRef: apiRef2,
  firstRowToRender,
  lastRowToRender,
  visibleRows
}) {
  let firstNonSpannedColumnToRender = firstColumnToRender;
  for (let i2 = firstRowToRender; i2 < lastRowToRender; i2 += 1) {
    const row = visibleRows[i2];
    if (row) {
      const rowId = visibleRows[i2].id;
      const cellColSpanInfo = apiRef2.current.unstable_getCellColSpanInfo(rowId, firstColumnToRender);
      if (cellColSpanInfo && cellColSpanInfo.spannedByColSpan) {
        firstNonSpannedColumnToRender = cellColSpanInfo.leftVisibleCellIndex;
      }
    }
  }
  return firstNonSpannedColumnToRender;
}
function getFirstColumnIndexToRender({
  firstColumnIndex,
  minColumnIndex,
  columnBuffer,
  firstRowToRender,
  lastRowToRender,
  apiRef: apiRef2,
  visibleRows
}) {
  const initialFirstColumnToRender = Math.max(firstColumnIndex - columnBuffer, minColumnIndex);
  const firstColumnToRender = getFirstNonSpannedColumnToRender({
    firstColumnToRender: initialFirstColumnToRender,
    apiRef: apiRef2,
    firstRowToRender,
    lastRowToRender,
    visibleRows
  });
  return firstColumnToRender;
}
function getTotalHeaderHeight(apiRef2, headerHeight) {
  const densityFactor = gridDensityFactorSelector(apiRef2);
  const maxDepth = gridColumnGroupsHeaderMaxDepthSelector(apiRef2);
  return Math.floor(headerHeight * densityFactor) * ((maxDepth != null ? maxDepth : 0) + 1);
}
const defaultColumnTypes = getGridDefaultColumnTypes();
const columnsStateInitializer = (state, props, apiRef2) => {
  var _props$initialState, _ref, _props$columnVisibili, _props$initialState2;
  const columnsState = createColumnsState({
    apiRef: apiRef2,
    columnTypes: defaultColumnTypes,
    columnsToUpsert: props.columns,
    initialState: (_props$initialState = props.initialState) == null ? void 0 : _props$initialState.columns,
    columnVisibilityModel: (_ref = (_props$columnVisibili = props.columnVisibilityModel) != null ? _props$columnVisibili : (_props$initialState2 = props.initialState) == null || (_props$initialState2 = _props$initialState2.columns) == null ? void 0 : _props$initialState2.columnVisibilityModel) != null ? _ref : {},
    keepOnlyColumnsToUpsert: true
  });
  return _extends$1({}, state, {
    columns: columnsState
  });
};
function useGridColumns(apiRef2, props) {
  var _props$initialState4, _props$slotProps2;
  const logger = useGridLogger(apiRef2, "useGridColumns");
  const columnTypes = defaultColumnTypes;
  const previousColumnsProp = reactExports.useRef(props.columns);
  const previousColumnTypesProp = reactExports.useRef(columnTypes);
  apiRef2.current.registerControlState({
    stateId: "visibleColumns",
    propModel: props.columnVisibilityModel,
    propOnChange: props.onColumnVisibilityModelChange,
    stateSelector: gridColumnVisibilityModelSelector,
    changeEvent: "columnVisibilityModelChange"
  });
  const setGridColumnsState = reactExports.useCallback((columnsState) => {
    logger.debug("Updating columns state.");
    apiRef2.current.setState(mergeColumnsState(columnsState));
    apiRef2.current.forceUpdate();
    apiRef2.current.publishEvent("columnsChange", columnsState.orderedFields);
  }, [logger, apiRef2]);
  const getColumn = reactExports.useCallback((field) => gridColumnLookupSelector(apiRef2)[field], [apiRef2]);
  const getAllColumns = reactExports.useCallback(() => gridColumnDefinitionsSelector(apiRef2), [apiRef2]);
  const getVisibleColumns = reactExports.useCallback(() => gridVisibleColumnDefinitionsSelector(apiRef2), [apiRef2]);
  const getColumnIndex = reactExports.useCallback((field, useVisibleColumns = true) => {
    const columns = useVisibleColumns ? gridVisibleColumnDefinitionsSelector(apiRef2) : gridColumnDefinitionsSelector(apiRef2);
    return columns.findIndex((col) => col.field === field);
  }, [apiRef2]);
  const getColumnPosition = reactExports.useCallback((field) => {
    const index = getColumnIndex(field);
    return gridColumnPositionsSelector(apiRef2)[index];
  }, [apiRef2, getColumnIndex]);
  const setColumnVisibilityModel = reactExports.useCallback((model) => {
    const currentModel = gridColumnVisibilityModelSelector(apiRef2);
    if (currentModel !== model) {
      apiRef2.current.setState((state) => _extends$1({}, state, {
        columns: createColumnsState({
          apiRef: apiRef2,
          columnTypes,
          columnsToUpsert: [],
          initialState: void 0,
          columnVisibilityModel: model,
          keepOnlyColumnsToUpsert: false
        })
      }));
      apiRef2.current.forceUpdate();
    }
  }, [apiRef2, columnTypes]);
  const updateColumns = reactExports.useCallback((columns) => {
    const columnsState = createColumnsState({
      apiRef: apiRef2,
      columnTypes,
      columnsToUpsert: columns,
      initialState: void 0,
      keepOnlyColumnsToUpsert: false
    });
    setGridColumnsState(columnsState);
  }, [apiRef2, setGridColumnsState, columnTypes]);
  const setColumnVisibility = reactExports.useCallback((field, isVisible) => {
    var _columnVisibilityMode;
    const columnVisibilityModel = gridColumnVisibilityModelSelector(apiRef2);
    const isCurrentlyVisible = (_columnVisibilityMode = columnVisibilityModel[field]) != null ? _columnVisibilityMode : true;
    if (isVisible !== isCurrentlyVisible) {
      const newModel = _extends$1({}, columnVisibilityModel, {
        [field]: isVisible
      });
      apiRef2.current.setColumnVisibilityModel(newModel);
    }
  }, [apiRef2]);
  const getColumnIndexRelativeToVisibleColumns = reactExports.useCallback((field) => {
    const allColumns = gridColumnFieldsSelector(apiRef2);
    return allColumns.findIndex((col) => col === field);
  }, [apiRef2]);
  const setColumnIndex = reactExports.useCallback((field, targetIndexPosition) => {
    const allColumns = gridColumnFieldsSelector(apiRef2);
    const oldIndexPosition = getColumnIndexRelativeToVisibleColumns(field);
    if (oldIndexPosition === targetIndexPosition) {
      return;
    }
    logger.debug(`Moving column ${field} to index ${targetIndexPosition}`);
    const updatedColumns = [...allColumns];
    const fieldRemoved = updatedColumns.splice(oldIndexPosition, 1)[0];
    updatedColumns.splice(targetIndexPosition, 0, fieldRemoved);
    setGridColumnsState(_extends$1({}, gridColumnsStateSelector(apiRef2.current.state), {
      orderedFields: updatedColumns
    }));
    const params = {
      column: apiRef2.current.getColumn(field),
      targetIndex: apiRef2.current.getColumnIndexRelativeToVisibleColumns(field),
      oldIndex: oldIndexPosition
    };
    apiRef2.current.publishEvent("columnIndexChange", params);
  }, [apiRef2, logger, setGridColumnsState, getColumnIndexRelativeToVisibleColumns]);
  const setColumnWidth = reactExports.useCallback((field, width) => {
    var _apiRef$current$getRo, _apiRef$current$getRo2;
    logger.debug(`Updating column ${field} width to ${width}`);
    const columnsState = gridColumnsStateSelector(apiRef2.current.state);
    const column = columnsState.lookup[field];
    const newColumn = _extends$1({}, column, {
      width,
      hasBeenResized: true
    });
    setGridColumnsState(hydrateColumnsWidth(_extends$1({}, columnsState, {
      lookup: _extends$1({}, columnsState.lookup, {
        [field]: newColumn
      })
    }), (_apiRef$current$getRo = (_apiRef$current$getRo2 = apiRef2.current.getRootDimensions()) == null ? void 0 : _apiRef$current$getRo2.viewportInnerSize.width) != null ? _apiRef$current$getRo : 0));
    apiRef2.current.publishEvent("columnWidthChange", {
      element: apiRef2.current.getColumnHeaderElement(field),
      colDef: newColumn,
      width
    });
  }, [apiRef2, logger, setGridColumnsState]);
  const columnApi = {
    getColumn,
    getAllColumns,
    getColumnIndex,
    getColumnPosition,
    getVisibleColumns,
    getColumnIndexRelativeToVisibleColumns,
    updateColumns,
    setColumnVisibilityModel,
    setColumnVisibility,
    setColumnWidth
  };
  const columnReorderApi = {
    setColumnIndex
  };
  useGridApiMethod(apiRef2, columnApi, "public");
  useGridApiMethod(apiRef2, columnReorderApi, props.signature === GridSignature.DataGrid ? "private" : "public");
  const stateExportPreProcessing = reactExports.useCallback((prevState, context) => {
    var _props$initialState$c, _props$initialState3;
    const columnsStateToExport = {};
    const columnVisibilityModelToExport = gridColumnVisibilityModelSelector(apiRef2);
    const shouldExportColumnVisibilityModel = (
      // Always export if the `exportOnlyDirtyModels` property is not activated
      !context.exportOnlyDirtyModels || // Always export if the model is controlled
      props.columnVisibilityModel != null || // Always export if the model has been initialized
      // TODO v6 Do a nullish check instead to export even if the initial model equals "{}"
      Object.keys((_props$initialState$c = (_props$initialState3 = props.initialState) == null || (_props$initialState3 = _props$initialState3.columns) == null ? void 0 : _props$initialState3.columnVisibilityModel) != null ? _props$initialState$c : {}).length > 0 || // Always export if the model is not empty
      Object.keys(columnVisibilityModelToExport).length > 0
    );
    if (shouldExportColumnVisibilityModel) {
      columnsStateToExport.columnVisibilityModel = columnVisibilityModelToExport;
    }
    columnsStateToExport.orderedFields = gridColumnFieldsSelector(apiRef2);
    const columns = gridColumnDefinitionsSelector(apiRef2);
    const dimensions = {};
    columns.forEach((colDef) => {
      if (colDef.hasBeenResized) {
        const colDefDimensions = {};
        COLUMNS_DIMENSION_PROPERTIES.forEach((propertyName) => {
          let propertyValue = colDef[propertyName];
          if (propertyValue === Infinity) {
            propertyValue = -1;
          }
          colDefDimensions[propertyName] = propertyValue;
        });
        dimensions[colDef.field] = colDefDimensions;
      }
    });
    if (Object.keys(dimensions).length > 0) {
      columnsStateToExport.dimensions = dimensions;
    }
    return _extends$1({}, prevState, {
      columns: columnsStateToExport
    });
  }, [apiRef2, props.columnVisibilityModel, (_props$initialState4 = props.initialState) == null ? void 0 : _props$initialState4.columns]);
  const stateRestorePreProcessing = reactExports.useCallback((params, context) => {
    var _context$stateToResto;
    const columnVisibilityModelToImport = (_context$stateToResto = context.stateToRestore.columns) == null ? void 0 : _context$stateToResto.columnVisibilityModel;
    const initialState = context.stateToRestore.columns;
    if (columnVisibilityModelToImport == null && initialState == null) {
      return params;
    }
    const columnsState = createColumnsState({
      apiRef: apiRef2,
      columnTypes,
      columnsToUpsert: [],
      initialState,
      columnVisibilityModel: columnVisibilityModelToImport,
      keepOnlyColumnsToUpsert: false
    });
    apiRef2.current.setState(mergeColumnsState(columnsState));
    if (initialState != null) {
      apiRef2.current.publishEvent("columnsChange", columnsState.orderedFields);
    }
    return params;
  }, [apiRef2, columnTypes]);
  const preferencePanelPreProcessing = reactExports.useCallback((initialValue, value) => {
    if (value === GridPreferencePanelsValue.columns) {
      var _props$slotProps;
      const ColumnsPanel = props.slots.columnsPanel;
      return /* @__PURE__ */ jsxRuntimeExports.jsx(ColumnsPanel, _extends$1({}, (_props$slotProps = props.slotProps) == null ? void 0 : _props$slotProps.columnsPanel));
    }
    return initialValue;
  }, [props.slots.columnsPanel, (_props$slotProps2 = props.slotProps) == null ? void 0 : _props$slotProps2.columnsPanel]);
  const addColumnMenuItems = reactExports.useCallback((columnMenuItems) => {
    if (props.disableColumnSelector) {
      return columnMenuItems;
    }
    return [...columnMenuItems, "columnMenuColumnsItem"];
  }, [props.disableColumnSelector]);
  useGridRegisterPipeProcessor(apiRef2, "columnMenu", addColumnMenuItems);
  useGridRegisterPipeProcessor(apiRef2, "exportState", stateExportPreProcessing);
  useGridRegisterPipeProcessor(apiRef2, "restoreState", stateRestorePreProcessing);
  useGridRegisterPipeProcessor(apiRef2, "preferencePanel", preferencePanelPreProcessing);
  const prevInnerWidth = reactExports.useRef(null);
  const handleGridSizeChange = (viewportInnerSize) => {
    if (prevInnerWidth.current !== viewportInnerSize.width) {
      prevInnerWidth.current = viewportInnerSize.width;
      setGridColumnsState(hydrateColumnsWidth(gridColumnsStateSelector(apiRef2.current.state), viewportInnerSize.width));
    }
  };
  useGridApiEventHandler(apiRef2, "viewportInnerSizeChange", handleGridSizeChange);
  const hydrateColumns = reactExports.useCallback(() => {
    logger.info(`Columns pipe processing have changed, regenerating the columns`);
    const columnsState = createColumnsState({
      apiRef: apiRef2,
      columnTypes,
      columnsToUpsert: [],
      initialState: void 0,
      keepOnlyColumnsToUpsert: false
    });
    setGridColumnsState(columnsState);
  }, [apiRef2, logger, setGridColumnsState, columnTypes]);
  useGridRegisterPipeApplier(apiRef2, "hydrateColumns", hydrateColumns);
  const isFirstRender = reactExports.useRef(true);
  reactExports.useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    logger.info(`GridColumns have changed, new length ${props.columns.length}`);
    if (previousColumnsProp.current === props.columns && previousColumnTypesProp.current === columnTypes) {
      return;
    }
    const columnsState = createColumnsState({
      apiRef: apiRef2,
      columnTypes,
      initialState: void 0,
      // If the user provides a model, we don't want to set it in the state here because it has it's dedicated `useEffect` which calls `setColumnVisibilityModel`
      columnsToUpsert: props.columns,
      keepOnlyColumnsToUpsert: true
    });
    previousColumnsProp.current = props.columns;
    previousColumnTypesProp.current = columnTypes;
    setGridColumnsState(columnsState);
  }, [logger, apiRef2, setGridColumnsState, props.columns, columnTypes]);
  reactExports.useEffect(() => {
    if (props.columnVisibilityModel !== void 0) {
      apiRef2.current.setColumnVisibilityModel(props.columnVisibilityModel);
    }
  }, [apiRef2, logger, props.columnVisibilityModel]);
}
const COMPACT_DENSITY_FACTOR = 0.7;
const COMFORTABLE_DENSITY_FACTOR = 1.3;
const DENSITY_FACTORS = {
  compact: COMPACT_DENSITY_FACTOR,
  comfortable: COMFORTABLE_DENSITY_FACTOR,
  standard: 1
};
const densityStateInitializer = (state, props) => _extends$1({}, state, {
  density: {
    value: props.density,
    factor: DENSITY_FACTORS[props.density]
  }
});
const useGridDensity = (apiRef2, props) => {
  const logger = useGridLogger(apiRef2, "useDensity");
  const setDensity = reactExports.useCallback((newDensity) => {
    logger.debug(`Set grid density to ${newDensity}`);
    apiRef2.current.setState((state) => {
      const currentDensityState = gridDensitySelector(state);
      const newDensityState = {
        value: newDensity,
        factor: DENSITY_FACTORS[newDensity]
      };
      if (isDeepEqual(currentDensityState, newDensityState)) {
        return state;
      }
      return _extends$1({}, state, {
        density: newDensityState
      });
    });
    apiRef2.current.forceUpdate();
  }, [logger, apiRef2]);
  reactExports.useEffect(() => {
    apiRef2.current.setDensity(props.density);
  }, [apiRef2, props.density]);
  const densityApi = {
    setDensity
  };
  useGridApiMethod(apiRef2, densityApi, "public");
};
function exportAs(blob, extension = "csv", filename = document.title || "untitled") {
  const fullName = `${filename}.${extension}`;
  if ("download" in HTMLAnchorElement.prototype) {
    const url = URL.createObjectURL(blob);
    const a2 = document.createElement("a");
    a2.href = url;
    a2.download = fullName;
    a2.click();
    setTimeout(() => {
      URL.revokeObjectURL(url);
    });
    return;
  }
  throw new Error("MUI: exportAs not supported");
}
const getColumnsToExport = ({
  apiRef: apiRef2,
  options
}) => {
  const columns = gridColumnDefinitionsSelector(apiRef2);
  if (options.fields) {
    return options.fields.reduce((currentColumns, field) => {
      const column = columns.find((col) => col.field === field);
      if (column) {
        currentColumns.push(column);
      }
      return currentColumns;
    }, []);
  }
  const validColumns = options.allColumns ? columns : gridVisibleColumnDefinitionsSelector(apiRef2);
  return validColumns.filter((column) => !column.disableExport);
};
const defaultGetRowsToExport = ({
  apiRef: apiRef2
}) => {
  var _pinnedRows$top, _pinnedRows$bottom;
  const filteredSortedRowIds = gridFilteredSortedRowIdsSelector(apiRef2);
  const rowTree = gridRowTreeSelector(apiRef2);
  const selectedRows = apiRef2.current.getSelectedRows();
  const bodyRows = filteredSortedRowIds.filter((id) => rowTree[id].type !== "footer");
  const pinnedRows = gridPinnedRowsSelector(apiRef2);
  const topPinnedRowsIds = (pinnedRows == null || (_pinnedRows$top = pinnedRows.top) == null ? void 0 : _pinnedRows$top.map((row) => row.id)) || [];
  const bottomPinnedRowsIds = (pinnedRows == null || (_pinnedRows$bottom = pinnedRows.bottom) == null ? void 0 : _pinnedRows$bottom.map((row) => row.id)) || [];
  bodyRows.unshift(...topPinnedRowsIds);
  bodyRows.push(...bottomPinnedRowsIds);
  if (selectedRows.size > 0) {
    return bodyRows.filter((id) => selectedRows.has(id));
  }
  return bodyRows;
};
const useGridCsvExport = (apiRef2, props) => {
  const logger = useGridLogger(apiRef2, "useGridCsvExport");
  const ignoreValueFormatterProp = props.unstable_ignoreValueFormatterDuringExport;
  const ignoreValueFormatter = (typeof ignoreValueFormatterProp === "object" ? ignoreValueFormatterProp == null ? void 0 : ignoreValueFormatterProp.csvExport : ignoreValueFormatterProp) || false;
  const getDataAsCsv = reactExports.useCallback((options = {}) => {
    var _options$getRowsToExp, _options$includeHeade, _options$includeColum;
    logger.debug(`Get data as CSV`);
    const exportedColumns = getColumnsToExport({
      apiRef: apiRef2,
      options
    });
    const getRowsToExport = (_options$getRowsToExp = options.getRowsToExport) != null ? _options$getRowsToExp : defaultGetRowsToExport;
    const exportedRowIds = getRowsToExport({
      apiRef: apiRef2
    });
    return buildCSV({
      columns: exportedColumns,
      rowIds: exportedRowIds,
      delimiterCharacter: options.delimiter || ",",
      includeHeaders: (_options$includeHeade = options.includeHeaders) != null ? _options$includeHeade : true,
      includeColumnGroupsHeaders: (_options$includeColum = options.includeColumnGroupsHeaders) != null ? _options$includeColum : true,
      ignoreValueFormatter,
      apiRef: apiRef2
    });
  }, [logger, apiRef2, ignoreValueFormatter]);
  const exportDataAsCsv = reactExports.useCallback((options) => {
    logger.debug(`Export data as CSV`);
    const csv = getDataAsCsv(options);
    const blob = new Blob([options != null && options.utf8WithBom ? new Uint8Array([239, 187, 191]) : "", csv], {
      type: "text/csv"
    });
    exportAs(blob, "csv", options == null ? void 0 : options.fileName);
  }, [logger, getDataAsCsv]);
  const csvExportApi = {
    getDataAsCsv,
    exportDataAsCsv
  };
  useGridApiMethod(apiRef2, csvExportApi, "public");
  const addExportMenuButtons = reactExports.useCallback((initialValue, options) => {
    var _options$csvOptions;
    if ((_options$csvOptions = options.csvOptions) != null && _options$csvOptions.disableToolbarButton) {
      return initialValue;
    }
    return [...initialValue, {
      component: /* @__PURE__ */ jsxRuntimeExports.jsx(GridCsvExportMenuItem, {
        options: options.csvOptions
      }),
      componentName: "csvExport"
    }];
  }, []);
  useGridRegisterPipeProcessor(apiRef2, "exportMenu", addExportMenuButtons);
};
const paginationStateInitializer = (state, props) => {
  var _props$paginationMode, _props$initialState;
  const paginationModel = _extends$1({}, getDefaultGridPaginationModel(props.autoPageSize), (_props$paginationMode = props.paginationModel) != null ? _props$paginationMode : (_props$initialState = props.initialState) == null || (_props$initialState = _props$initialState.pagination) == null ? void 0 : _props$initialState.paginationModel);
  throwIfPageSizeExceedsTheLimit(paginationModel.pageSize, props.signature);
  return _extends$1({}, state, {
    pagination: {
      paginationModel
    }
  });
};
const mergeStateWithPaginationModel = (rowCount, signature, paginationModelProp) => (paginationState) => {
  var _paginationModelProp$;
  let paginationModel = paginationState.paginationModel;
  const pageSize2 = (_paginationModelProp$ = paginationModelProp == null ? void 0 : paginationModelProp.pageSize) != null ? _paginationModelProp$ : paginationModel.pageSize;
  const pageCount = getPageCount(rowCount, pageSize2);
  if (paginationModelProp && ((paginationModelProp == null ? void 0 : paginationModelProp.page) !== paginationModel.page || (paginationModelProp == null ? void 0 : paginationModelProp.pageSize) !== paginationModel.pageSize)) {
    paginationModel = paginationModelProp;
  }
  const validPage = getValidPage(paginationModel.page, pageCount);
  if (validPage !== paginationModel.page) {
    paginationModel = _extends$1({}, paginationModel, {
      page: validPage
    });
  }
  throwIfPageSizeExceedsTheLimit(paginationModel.pageSize, signature);
  return {
    paginationModel
  };
};
const useGridPagination = (apiRef2, props) => {
  var _props$initialState3;
  const logger = useGridLogger(apiRef2, "useGridPagination");
  const visibleTopLevelRowCount = useGridSelector(apiRef2, gridFilteredTopLevelRowCountSelector);
  const densityFactor = useGridSelector(apiRef2, gridDensityFactorSelector);
  const rowHeight = Math.floor(props.rowHeight * densityFactor);
  apiRef2.current.registerControlState({
    stateId: "pagination",
    propModel: props.paginationModel,
    propOnChange: props.onPaginationModelChange,
    stateSelector: gridPaginationModelSelector,
    changeEvent: "paginationModelChange"
  });
  const setPage = reactExports.useCallback((page) => {
    const currentModel = gridPaginationModelSelector(apiRef2);
    if (page === currentModel.page) {
      return;
    }
    logger.debug(`Setting page to ${page}`);
    apiRef2.current.setPaginationModel({
      page,
      pageSize: currentModel.pageSize
    });
  }, [apiRef2, logger]);
  const setPageSize = reactExports.useCallback((pageSize2) => {
    const currentModel = gridPaginationModelSelector(apiRef2);
    if (pageSize2 === currentModel.pageSize) {
      return;
    }
    logger.debug(`Setting page size to ${pageSize2}`);
    apiRef2.current.setPaginationModel({
      pageSize: pageSize2,
      page: currentModel.page
    });
  }, [apiRef2, logger]);
  const setPaginationModel = reactExports.useCallback((paginationModel) => {
    var _props$rowCount;
    const currentModel = gridPaginationModelSelector(apiRef2);
    if (paginationModel === currentModel) {
      return;
    }
    logger.debug("Setting 'paginationModel' to", paginationModel);
    apiRef2.current.updateControlState("pagination", mergeStateWithPaginationModel((_props$rowCount = props.rowCount) != null ? _props$rowCount : visibleTopLevelRowCount, props.signature, paginationModel), "setPaginationModel");
    apiRef2.current.forceUpdate();
  }, [apiRef2, logger, props.rowCount, props.signature, visibleTopLevelRowCount]);
  const pageApi = {
    setPage,
    setPageSize,
    setPaginationModel
  };
  useGridApiMethod(apiRef2, pageApi, "public");
  const stateExportPreProcessing = reactExports.useCallback((prevState, context) => {
    var _props$initialState2;
    const paginationModel = gridPaginationModelSelector(apiRef2);
    const shouldExportPaginationModel = (
      // Always export if the `exportOnlyDirtyModels` property is not activated
      !context.exportOnlyDirtyModels || // Always export if the `paginationModel` is controlled
      props.paginationModel != null || // Always export if the `paginationModel` has been initialized
      ((_props$initialState2 = props.initialState) == null || (_props$initialState2 = _props$initialState2.pagination) == null ? void 0 : _props$initialState2.paginationModel) != null || // Export if `page` or `pageSize` is not equal to the default value
      paginationModel.page !== 0 && paginationModel.pageSize !== defaultPageSize(props.autoPageSize)
    );
    if (!shouldExportPaginationModel) {
      return prevState;
    }
    return _extends$1({}, prevState, {
      pagination: _extends$1({}, prevState.pagination, {
        paginationModel
      })
    });
  }, [apiRef2, props.paginationModel, (_props$initialState3 = props.initialState) == null || (_props$initialState3 = _props$initialState3.pagination) == null ? void 0 : _props$initialState3.paginationModel, props.autoPageSize]);
  const stateRestorePreProcessing = reactExports.useCallback((params, context) => {
    var _context$stateToResto, _context$stateToResto2, _props$rowCount2;
    const paginationModel = (_context$stateToResto = context.stateToRestore.pagination) != null && _context$stateToResto.paginationModel ? _extends$1({}, getDefaultGridPaginationModel(props.autoPageSize), (_context$stateToResto2 = context.stateToRestore.pagination) == null ? void 0 : _context$stateToResto2.paginationModel) : gridPaginationModelSelector(apiRef2);
    apiRef2.current.updateControlState("pagination", mergeStateWithPaginationModel((_props$rowCount2 = props.rowCount) != null ? _props$rowCount2 : visibleTopLevelRowCount, props.signature, paginationModel), "stateRestorePreProcessing");
    return params;
  }, [apiRef2, props.autoPageSize, props.rowCount, props.signature, visibleTopLevelRowCount]);
  useGridRegisterPipeProcessor(apiRef2, "exportState", stateExportPreProcessing);
  useGridRegisterPipeProcessor(apiRef2, "restoreState", stateRestorePreProcessing);
  const handlePaginationModelChange = () => {
    var _apiRef$current$virtu;
    const paginationModel = gridPaginationModelSelector(apiRef2);
    if ((_apiRef$current$virtu = apiRef2.current.virtualScrollerRef) != null && _apiRef$current$virtu.current) {
      apiRef2.current.scrollToIndexes({
        rowIndex: paginationModel.page * paginationModel.pageSize
      });
    }
    apiRef2.current.forceUpdate();
  };
  const handleUpdateAutoPageSize = reactExports.useCallback(() => {
    const dimensions = apiRef2.current.getRootDimensions();
    if (!props.autoPageSize || !dimensions) {
      return;
    }
    const pinnedRowsHeight = calculatePinnedRowsHeight(apiRef2);
    const maximumPageSizeWithoutScrollBar = Math.floor((dimensions.viewportInnerSize.height - pinnedRowsHeight.top - pinnedRowsHeight.bottom) / rowHeight);
    apiRef2.current.setPageSize(maximumPageSizeWithoutScrollBar);
  }, [apiRef2, props.autoPageSize, rowHeight]);
  useGridApiEventHandler(apiRef2, "viewportInnerSizeChange", handleUpdateAutoPageSize);
  useGridApiEventHandler(apiRef2, "paginationModelChange", handlePaginationModelChange);
  reactExports.useEffect(() => {
  }, [props.rowCount, props.paginationMode]);
  reactExports.useEffect(() => {
    var _props$rowCount3;
    apiRef2.current.updateControlState("pagination", mergeStateWithPaginationModel((_props$rowCount3 = props.rowCount) != null ? _props$rowCount3 : visibleTopLevelRowCount, props.signature, props.paginationModel));
  }, [apiRef2, props.paginationModel, props.rowCount, props.paginationMode, visibleTopLevelRowCount, props.signature]);
  reactExports.useEffect(() => {
    handleUpdateAutoPageSize();
  }, [handleUpdateAutoPageSize]);
};
function raf() {
  return new Promise((resolve) => {
    requestAnimationFrame(() => {
      resolve();
    });
  });
}
function buildPrintWindow(title) {
  const iframeEl = document.createElement("iframe");
  iframeEl.style.position = "absolute";
  iframeEl.style.width = "0px";
  iframeEl.style.height = "0px";
  iframeEl.title = title || document.title;
  return iframeEl;
}
const useGridPrintExport = (apiRef2, props) => {
  const logger = useGridLogger(apiRef2, "useGridPrintExport");
  const doc = reactExports.useRef(null);
  const previousGridState = reactExports.useRef(null);
  const previousColumnVisibility = reactExports.useRef({});
  reactExports.useEffect(() => {
    doc.current = ownerDocument$1(apiRef2.current.rootElementRef.current);
  }, [apiRef2]);
  const updateGridColumnsForPrint = reactExports.useCallback((fields, allColumns) => new Promise((resolve) => {
    const exportedColumnFields = getColumnsToExport({
      apiRef: apiRef2,
      options: {
        fields,
        allColumns
      }
    }).map((column) => column.field);
    const columns = gridColumnDefinitionsSelector(apiRef2);
    const newColumnVisibilityModel = {};
    columns.forEach((column) => {
      newColumnVisibilityModel[column.field] = exportedColumnFields.includes(column.field);
    });
    apiRef2.current.setColumnVisibilityModel(newColumnVisibilityModel);
    resolve();
  }), [apiRef2]);
  const handlePrintWindowLoad = reactExports.useCallback((printWindow, options) => {
    var _querySelector, _querySelector2;
    const normalizeOptions = _extends$1({
      copyStyles: true,
      hideToolbar: false,
      hideFooter: false
    }, options);
    const printDoc = printWindow.contentDocument;
    if (!printDoc) {
      return;
    }
    const rowsMeta = gridRowsMetaSelector(apiRef2.current.state);
    const gridRootElement = apiRef2.current.rootElementRef.current;
    const gridClone = gridRootElement.cloneNode(true);
    const gridMain = gridClone.querySelector(`.${gridClasses.main}`);
    gridMain.style.overflow = "visible";
    gridClone.style.contain = "size";
    const columnHeaders = gridClone.querySelector(`.${gridClasses.columnHeaders}`);
    const columnHeadersInner = columnHeaders.querySelector(`.${gridClasses.columnHeadersInner}`);
    columnHeadersInner.style.width = "100%";
    let gridToolbarElementHeight = ((_querySelector = gridRootElement.querySelector(`.${gridClasses.toolbarContainer}`)) == null ? void 0 : _querySelector.offsetHeight) || 0;
    let gridFooterElementHeight = ((_querySelector2 = gridRootElement.querySelector(`.${gridClasses.footerContainer}`)) == null ? void 0 : _querySelector2.offsetHeight) || 0;
    if (normalizeOptions.hideToolbar) {
      var _gridClone$querySelec;
      (_gridClone$querySelec = gridClone.querySelector(`.${gridClasses.toolbarContainer}`)) == null || _gridClone$querySelec.remove();
      gridToolbarElementHeight = 0;
    }
    if (normalizeOptions.hideFooter) {
      var _gridClone$querySelec2;
      (_gridClone$querySelec2 = gridClone.querySelector(`.${gridClasses.footerContainer}`)) == null || _gridClone$querySelec2.remove();
      gridFooterElementHeight = 0;
    }
    gridClone.style.height = `${rowsMeta.currentPageTotalHeight + getTotalHeaderHeight(apiRef2, props.columnHeaderHeight) + gridToolbarElementHeight + gridFooterElementHeight}px`;
    gridClone.style.boxSizing = "content-box";
    const container = document.createElement("div");
    container.appendChild(gridClone);
    printDoc.body.innerHTML = container.innerHTML;
    const defaultPageStyle = typeof normalizeOptions.pageStyle === "function" ? normalizeOptions.pageStyle() : normalizeOptions.pageStyle;
    if (typeof defaultPageStyle === "string") {
      const styleElement = printDoc.createElement("style");
      styleElement.appendChild(printDoc.createTextNode(defaultPageStyle));
      printDoc.head.appendChild(styleElement);
    }
    if (normalizeOptions.bodyClassName) {
      printDoc.body.classList.add(...normalizeOptions.bodyClassName.split(" "));
    }
    const stylesheetLoadPromises = [];
    if (normalizeOptions.copyStyles) {
      const rootCandidate = gridRootElement.getRootNode();
      const root = rootCandidate.constructor.name === "ShadowRoot" ? rootCandidate : doc.current;
      const headStyleElements = root.querySelectorAll("style, link[rel='stylesheet']");
      for (let i2 = 0; i2 < headStyleElements.length; i2 += 1) {
        const node = headStyleElements[i2];
        if (node.tagName === "STYLE") {
          const newHeadStyleElements = printDoc.createElement(node.tagName);
          const sheet = node.sheet;
          if (sheet) {
            let styleCSS = "";
            for (let j = 0; j < sheet.cssRules.length; j += 1) {
              if (typeof sheet.cssRules[j].cssText === "string") {
                styleCSS += `${sheet.cssRules[j].cssText}\r
`;
              }
            }
            newHeadStyleElements.appendChild(printDoc.createTextNode(styleCSS));
            printDoc.head.appendChild(newHeadStyleElements);
          }
        } else if (node.getAttribute("href")) {
          const newHeadStyleElements = printDoc.createElement(node.tagName);
          for (let j = 0; j < node.attributes.length; j += 1) {
            const attr = node.attributes[j];
            if (attr) {
              newHeadStyleElements.setAttribute(attr.nodeName, attr.nodeValue || "");
            }
          }
          stylesheetLoadPromises.push(new Promise((resolve) => {
            newHeadStyleElements.addEventListener("load", () => resolve());
          }));
          printDoc.head.appendChild(newHeadStyleElements);
        }
      }
    }
    {
      Promise.all(stylesheetLoadPromises).then(() => {
        printWindow.contentWindow.print();
      });
    }
  }, [apiRef2, doc, props.columnHeaderHeight]);
  const handlePrintWindowAfterPrint = reactExports.useCallback((printWindow) => {
    var _previousGridState$cu;
    doc.current.body.removeChild(printWindow);
    apiRef2.current.restoreState(previousGridState.current || {});
    if (!((_previousGridState$cu = previousGridState.current) != null && (_previousGridState$cu = _previousGridState$cu.columns) != null && _previousGridState$cu.columnVisibilityModel)) {
      apiRef2.current.setColumnVisibilityModel(previousColumnVisibility.current);
    }
    apiRef2.current.unstable_enableVirtualization();
    previousGridState.current = null;
    previousColumnVisibility.current = {};
  }, [apiRef2]);
  const exportDataAsPrint = reactExports.useCallback(async (options) => {
    logger.debug(`Export data as Print`);
    if (!apiRef2.current.rootElementRef.current) {
      throw new Error("MUI: No grid root element available.");
    }
    previousGridState.current = apiRef2.current.exportState();
    previousColumnVisibility.current = gridColumnVisibilityModelSelector(apiRef2);
    if (props.pagination) {
      const visibleRowCount = gridExpandedRowCountSelector(apiRef2);
      const paginationModel = {
        page: 0,
        pageSize: visibleRowCount
      };
      apiRef2.current.updateControlState(
        "pagination",
        // Using signature `DataGridPro` to allow more than 100 rows in the print export
        mergeStateWithPaginationModel(visibleRowCount, "DataGridPro", paginationModel)
      );
      apiRef2.current.forceUpdate();
    }
    await updateGridColumnsForPrint(options == null ? void 0 : options.fields, options == null ? void 0 : options.allColumns);
    apiRef2.current.unstable_disableVirtualization();
    await raf();
    const printWindow = buildPrintWindow(options == null ? void 0 : options.fileName);
    {
      printWindow.onload = () => {
        handlePrintWindowLoad(printWindow, options);
        const mediaQueryList = printWindow.contentWindow.matchMedia("print");
        mediaQueryList.addEventListener("change", (mql) => {
          const isAfterPrint = mql.matches === false;
          if (isAfterPrint) {
            handlePrintWindowAfterPrint(printWindow);
          }
        });
      };
      doc.current.body.appendChild(printWindow);
    }
  }, [props, logger, apiRef2, handlePrintWindowLoad, handlePrintWindowAfterPrint, updateGridColumnsForPrint]);
  const printExportApi = {
    exportDataAsPrint
  };
  useGridApiMethod(apiRef2, printExportApi, "public");
  const addExportMenuButtons = reactExports.useCallback((initialValue, options) => {
    var _options$printOptions;
    if ((_options$printOptions = options.printOptions) != null && _options$printOptions.disableToolbarButton) {
      return initialValue;
    }
    return [...initialValue, {
      component: /* @__PURE__ */ jsxRuntimeExports.jsx(GridPrintExportMenuItem, {
        options: options.printOptions
      }),
      componentName: "printExport"
    }];
  }, []);
  useGridRegisterPipeProcessor(apiRef2, "exportMenu", addExportMenuButtons);
};
let hasEval;
try {
  hasEval = eval("true");
} catch (_2) {
  hasEval = false;
}
const cleanFilterItem = (item, apiRef2) => {
  const cleanItem = _extends$1({}, item);
  if (cleanItem.id == null) {
    cleanItem.id = Math.round(Math.random() * 1e5);
  }
  if (cleanItem.operator == null) {
    const column = gridColumnLookupSelector(apiRef2)[cleanItem.field];
    cleanItem.operator = column && column.filterOperators[0].value;
  }
  return cleanItem;
};
const filterModelDisableMultiColumnsFilteringWarning = buildWarning(["MUI: The `filterModel` can only contain a single item when the `disableMultipleColumnsFiltering` prop is set to `true`.", "If you are using the community version of the `DataGrid`, this prop is always `true`."], "error");
const filterModelMissingItemIdWarning = buildWarning("MUI: The `id` field is required on `filterModel.items` when you use multiple filters.", "error");
const filterModelMissingItemOperatorWarning = buildWarning("MUI: The `operator` field is required on `filterModel.items`, one or more of your filtering item has no `operator` provided.", "error");
const sanitizeFilterModel = (model, disableMultipleColumnsFiltering, apiRef2) => {
  const hasSeveralItems = model.items.length > 1;
  let items2;
  if (hasSeveralItems && disableMultipleColumnsFiltering) {
    filterModelDisableMultiColumnsFilteringWarning();
    items2 = [model.items[0]];
  } else {
    items2 = model.items;
  }
  const hasItemsWithoutIds = hasSeveralItems && items2.some((item) => item.id == null);
  const hasItemWithoutOperator = items2.some((item) => item.operator == null);
  if (hasItemsWithoutIds) {
    filterModelMissingItemIdWarning();
  }
  if (hasItemWithoutOperator) {
    filterModelMissingItemOperatorWarning();
  }
  if (hasItemWithoutOperator || hasItemsWithoutIds) {
    return _extends$1({}, model, {
      items: items2.map((item) => cleanFilterItem(item, apiRef2))
    });
  }
  if (model.items !== items2) {
    return _extends$1({}, model, {
      items: items2
    });
  }
  return model;
};
const mergeStateWithFilterModel = (filterModel2, disableMultipleColumnsFiltering, apiRef2) => (filteringState) => _extends$1({}, filteringState, {
  filterModel: sanitizeFilterModel(filterModel2, disableMultipleColumnsFiltering, apiRef2)
});
const getFilterCallbackFromItem = (filterItem2, apiRef2) => {
  if (!filterItem2.field || !filterItem2.operator) {
    return null;
  }
  const column = apiRef2.current.getColumn(filterItem2.field);
  if (!column) {
    return null;
  }
  let parsedValue;
  if (column.valueParser) {
    var _filterItem$value;
    const parser = column.valueParser;
    parsedValue = Array.isArray(filterItem2.value) ? (_filterItem$value = filterItem2.value) == null ? void 0 : _filterItem$value.map((x) => parser(x)) : parser(filterItem2.value);
  } else {
    parsedValue = filterItem2.value;
  }
  const newFilterItem = _extends$1({}, filterItem2, {
    value: parsedValue
  });
  const filterOperators = column.filterOperators;
  if (!(filterOperators != null && filterOperators.length)) {
    throw new Error(`MUI: No filter operators found for column '${column.field}'.`);
  }
  const filterOperator = filterOperators.find((operator) => operator.value === newFilterItem.operator);
  if (!filterOperator) {
    throw new Error(`MUI: No filter operator found for column '${column.field}' and operator value '${newFilterItem.operator}'.`);
  }
  const hasUserFunctionLegacy = !isInternalFilter(filterOperator.getApplyFilterFn);
  const hasUserFunctionV7 = !isInternalFilter(filterOperator.getApplyFilterFnV7);
  if (filterOperator.getApplyFilterFnV7 && !(hasUserFunctionLegacy && !hasUserFunctionV7)) {
    const applyFilterOnRow2 = filterOperator.getApplyFilterFnV7(newFilterItem, column);
    if (typeof applyFilterOnRow2 !== "function") {
      return null;
    }
    return {
      v7: true,
      item: newFilterItem,
      fn: (row) => {
        const value = apiRef2.current.getRowValue(row, column);
        return applyFilterOnRow2(value, row, column, apiRef2);
      }
    };
  }
  const applyFilterOnRow = filterOperator.getApplyFilterFn(newFilterItem, column);
  if (typeof applyFilterOnRow !== "function") {
    return null;
  }
  return {
    v7: false,
    item: newFilterItem,
    fn: (rowId) => {
      const params = apiRef2.current.getCellParams(rowId, newFilterItem.field);
      GLOBAL_API_REF.current = apiRef2;
      const result = applyFilterOnRow(params);
      GLOBAL_API_REF.current = null;
      return result;
    }
  };
};
let filterItemsApplierId = 1;
const buildAggregatedFilterItemsApplier = (getRowId, filterModel, apiRef, disableEval) => {
  const {
    items
  } = filterModel;
  const appliers = items.map((item) => getFilterCallbackFromItem(item, apiRef)).filter((callback) => !!callback);
  if (appliers.length === 0) {
    return null;
  }
  if (!hasEval || disableEval) {
    return (row, shouldApplyFilter) => {
      const resultPerItemId = {};
      for (let i2 = 0; i2 < appliers.length; i2 += 1) {
        const applier = appliers[i2];
        if (!shouldApplyFilter || shouldApplyFilter(applier.item.field)) {
          resultPerItemId[applier.item.id] = applier.v7 ? applier.fn(row) : applier.fn(getRowId ? getRowId(row) : row.id);
        }
      }
      return resultPerItemId;
    };
  }
  const filterItemTemplate = `(function filterItem$$(row, shouldApplyFilter) {
      ${appliers.map((applier, i2) => `const shouldApply${i2} = !shouldApplyFilter || shouldApplyFilter(${JSON.stringify(applier.item.field)});`).join("\n")}

      const result$$ = {
      ${appliers.map((applier, i2) => `${JSON.stringify(String(applier.item.id))}:
          !shouldApply${i2} ?
            false :
            ${applier.v7 ? `appliers[${i2}].fn(row)` : `appliers[${i2}].fn(${getRowId ? "getRowId(row)" : "row.id"})`},
      `).join("\n")}};

      return result$$;
    })`;
  const filterItem = eval(filterItemTemplate.replaceAll("$$", String(filterItemsApplierId)));
  filterItemsApplierId += 1;
  return filterItem;
};
const buildAggregatedQuickFilterApplier = (getRowId2, filterModel2, apiRef2) => {
  var _filterModel$quickFil, _filterModel$quickFil2, _filterModel$quickFil3;
  const quickFilterValues = (_filterModel$quickFil = (_filterModel$quickFil2 = filterModel2.quickFilterValues) == null ? void 0 : _filterModel$quickFil2.filter(Boolean)) != null ? _filterModel$quickFil : [];
  if (quickFilterValues.length === 0) {
    return null;
  }
  const quickFilterExcludeHiddenColumns = (_filterModel$quickFil3 = filterModel2.quickFilterExcludeHiddenColumns) != null ? _filterModel$quickFil3 : false;
  const columnFields = quickFilterExcludeHiddenColumns ? gridVisibleColumnFieldsSelector(apiRef2) : gridColumnFieldsSelector(apiRef2);
  const appliersPerField = [];
  columnFields.forEach((field) => {
    const column = apiRef2.current.getColumn(field);
    const getApplyQuickFilterFn = column == null ? void 0 : column.getApplyQuickFilterFn;
    const getApplyQuickFilterFnV7 = column == null ? void 0 : column.getApplyQuickFilterFnV7;
    const hasUserFunctionLegacy = !isInternalFilter(getApplyQuickFilterFn);
    const hasUserFunctionV7 = !isInternalFilter(getApplyQuickFilterFnV7);
    if (getApplyQuickFilterFnV7 && !(hasUserFunctionLegacy && !hasUserFunctionV7)) {
      appliersPerField.push({
        column,
        appliers: quickFilterValues.map((value) => ({
          v7: true,
          fn: getApplyQuickFilterFnV7(value, column, apiRef2)
        }))
      });
    } else if (getApplyQuickFilterFn) {
      appliersPerField.push({
        column,
        appliers: quickFilterValues.map((value) => ({
          v7: false,
          fn: getApplyQuickFilterFn(value, column, apiRef2)
        }))
      });
    }
  });
  return function isRowMatchingQuickFilter(row, shouldApplyFilter) {
    const result = {};
    const usedCellParams = {};
    outer:
      for (let v = 0; v < quickFilterValues.length; v += 1) {
        const filterValue = quickFilterValues[v];
        for (let i2 = 0; i2 < appliersPerField.length; i2 += 1) {
          const {
            column,
            appliers: appliers2
          } = appliersPerField[i2];
          const {
            field
          } = column;
          if (shouldApplyFilter && !shouldApplyFilter(field)) {
            continue;
          }
          const applier = appliers2[v];
          const value = apiRef2.current.getRowValue(row, column);
          if (applier.fn === null) {
            continue;
          }
          if (applier.v7) {
            const isMatching = applier.fn(value, row, column, apiRef2);
            if (isMatching) {
              result[filterValue] = true;
              continue outer;
            }
          } else {
            var _usedCellParams$field;
            const cellParams = (_usedCellParams$field = usedCellParams[field]) != null ? _usedCellParams$field : apiRef2.current.getCellParams(getRowId2 ? getRowId2(row) : row.id, field);
            usedCellParams[field] = cellParams;
            const isMatching = applier.fn(cellParams);
            if (isMatching) {
              result[filterValue] = true;
              continue outer;
            }
          }
        }
        result[filterValue] = false;
      }
    return result;
  };
};
const buildAggregatedFilterApplier = (getRowId2, filterModel2, apiRef2, disableEval2) => {
  const isRowMatchingFilterItems = buildAggregatedFilterItemsApplier(getRowId2, filterModel2, apiRef2, disableEval2);
  const isRowMatchingQuickFilter = buildAggregatedQuickFilterApplier(getRowId2, filterModel2, apiRef2);
  return function isRowMatchingFilters(row, shouldApplyFilter, result) {
    var _isRowMatchingFilterI, _isRowMatchingQuickFi;
    result.passingFilterItems = (_isRowMatchingFilterI = isRowMatchingFilterItems == null ? void 0 : isRowMatchingFilterItems(row, shouldApplyFilter)) != null ? _isRowMatchingFilterI : null;
    result.passingQuickFilterValues = (_isRowMatchingQuickFi = isRowMatchingQuickFilter == null ? void 0 : isRowMatchingQuickFilter(row, shouldApplyFilter)) != null ? _isRowMatchingQuickFi : null;
  };
};
const isNotNull = (result) => result != null;
const filterModelItems = (cache, apiRef2, items2) => {
  if (!cache.cleanedFilterItems) {
    cache.cleanedFilterItems = items2.filter((item) => getFilterCallbackFromItem(item, apiRef2) !== null);
  }
  return cache.cleanedFilterItems;
};
const passFilterLogic = (allFilterItemResults, allQuickFilterResults, filterModel2, apiRef2, cache) => {
  const cleanedFilterItems = filterModelItems(cache, apiRef2, filterModel2.items);
  const cleanedFilterItemResults = allFilterItemResults.filter(isNotNull);
  const cleanedQuickFilterResults = allQuickFilterResults.filter(isNotNull);
  if (cleanedFilterItemResults.length > 0) {
    var _filterModel$logicOpe;
    const filterItemPredicate = (item) => {
      return cleanedFilterItemResults.some((filterItemResult) => filterItemResult[item.id]);
    };
    const logicOperator = (_filterModel$logicOpe = filterModel2.logicOperator) != null ? _filterModel$logicOpe : getDefaultGridFilterModel().logicOperator;
    if (logicOperator === GridLogicOperator.And) {
      const passesAllFilters = cleanedFilterItems.every(filterItemPredicate);
      if (!passesAllFilters) {
        return false;
      }
    } else {
      const passesSomeFilters = cleanedFilterItems.some(filterItemPredicate);
      if (!passesSomeFilters) {
        return false;
      }
    }
  }
  if (cleanedQuickFilterResults.length > 0 && filterModel2.quickFilterValues != null) {
    var _filterModel$quickFil4;
    const quickFilterValuePredicate = (value) => {
      return cleanedQuickFilterResults.some((quickFilterValueResult) => quickFilterValueResult[value]);
    };
    const quickFilterLogicOperator = (_filterModel$quickFil4 = filterModel2.quickFilterLogicOperator) != null ? _filterModel$quickFil4 : getDefaultGridFilterModel().quickFilterLogicOperator;
    if (quickFilterLogicOperator === GridLogicOperator.And) {
      const passesAllQuickFilterValues = filterModel2.quickFilterValues.every(quickFilterValuePredicate);
      if (!passesAllQuickFilterValues) {
        return false;
      }
    } else {
      const passesSomeQuickFilterValues = filterModel2.quickFilterValues.some(quickFilterValuePredicate);
      if (!passesSomeQuickFilterValues) {
        return false;
      }
    }
  }
  return true;
};
const filterStateInitializer = (state, props, apiRef2) => {
  var _ref, _props$filterModel, _props$initialState;
  const filterModel2 = (_ref = (_props$filterModel = props.filterModel) != null ? _props$filterModel : (_props$initialState = props.initialState) == null || (_props$initialState = _props$initialState.filter) == null ? void 0 : _props$initialState.filterModel) != null ? _ref : getDefaultGridFilterModel();
  return _extends$1({}, state, {
    filter: {
      filterModel: sanitizeFilterModel(filterModel2, props.disableMultipleColumnsFiltering, apiRef2),
      filteredRowsLookup: {},
      filteredDescendantCountLookup: {}
    },
    visibleRowsLookup: {}
  });
};
const getVisibleRowsLookup = (params) => {
  return params.filteredRowsLookup;
};
function getVisibleRowsLookupState(apiRef2, state) {
  return apiRef2.current.applyStrategyProcessor("visibleRowsLookupCreation", {
    tree: state.rows.tree,
    filteredRowsLookup: state.filter.filteredRowsLookup
  });
}
function createMemoizedValues() {
  return defaultMemoize(Object.values);
}
const useGridFilter = (apiRef2, props) => {
  var _props$initialState3, _props$slotProps2;
  const logger = useGridLogger(apiRef2, "useGridFilter");
  apiRef2.current.registerControlState({
    stateId: "filter",
    propModel: props.filterModel,
    propOnChange: props.onFilterModelChange,
    stateSelector: gridFilterModelSelector,
    changeEvent: "filterModelChange"
  });
  const updateFilteredRows = reactExports.useCallback(() => {
    apiRef2.current.setState((state) => {
      const filterModel2 = gridFilterModelSelector(state, apiRef2.current.instanceId);
      const isRowMatchingFilters = props.filterMode === "client" ? buildAggregatedFilterApplier(props.getRowId, filterModel2, apiRef2, props.disableEval) : null;
      const filteringResult = apiRef2.current.applyStrategyProcessor("filtering", {
        isRowMatchingFilters,
        filterModel: filterModel2 != null ? filterModel2 : getDefaultGridFilterModel()
      });
      const newState = _extends$1({}, state, {
        filter: _extends$1({}, state.filter, filteringResult)
      });
      const visibleRowsLookupState = getVisibleRowsLookupState(apiRef2, newState);
      return _extends$1({}, newState, {
        visibleRowsLookup: visibleRowsLookupState
      });
    });
    apiRef2.current.publishEvent("filteredRowsSet");
  }, [apiRef2, props.filterMode, props.getRowId, props.disableEval]);
  const addColumnMenuItem = reactExports.useCallback((columnMenuItems, colDef) => {
    if (colDef == null || colDef.filterable === false || props.disableColumnFilter) {
      return columnMenuItems;
    }
    return [...columnMenuItems, "columnMenuFilterItem"];
  }, [props.disableColumnFilter]);
  const applyFilters = reactExports.useCallback(() => {
    updateFilteredRows();
    apiRef2.current.forceUpdate();
  }, [apiRef2, updateFilteredRows]);
  const upsertFilterItem = reactExports.useCallback((item) => {
    const filterModel2 = gridFilterModelSelector(apiRef2);
    const items2 = [...filterModel2.items];
    const itemIndex = items2.findIndex((filterItem2) => filterItem2.id === item.id);
    if (itemIndex === -1) {
      items2.push(item);
    } else {
      items2[itemIndex] = item;
    }
    apiRef2.current.setFilterModel(_extends$1({}, filterModel2, {
      items: items2
    }), "upsertFilterItem");
  }, [apiRef2]);
  const upsertFilterItems = reactExports.useCallback((items2) => {
    const filterModel2 = gridFilterModelSelector(apiRef2);
    const existingItems = [...filterModel2.items];
    items2.forEach((item) => {
      const itemIndex = items2.findIndex((filterItem2) => filterItem2.id === item.id);
      if (itemIndex === -1) {
        existingItems.push(item);
      } else {
        existingItems[itemIndex] = item;
      }
    });
    apiRef2.current.setFilterModel(_extends$1({}, filterModel2, {
      items: items2
    }), "upsertFilterItems");
  }, [apiRef2]);
  const deleteFilterItem = reactExports.useCallback((itemToDelete) => {
    const filterModel2 = gridFilterModelSelector(apiRef2);
    const items2 = filterModel2.items.filter((item) => item.id !== itemToDelete.id);
    if (items2.length === filterModel2.items.length) {
      return;
    }
    apiRef2.current.setFilterModel(_extends$1({}, filterModel2, {
      items: items2
    }), "deleteFilterItem");
  }, [apiRef2]);
  const showFilterPanel = reactExports.useCallback((targetColumnField, panelId, labelId) => {
    logger.debug("Displaying filter panel");
    if (targetColumnField) {
      const filterModel2 = gridFilterModelSelector(apiRef2);
      const filterItemsWithValue = filterModel2.items.filter((item) => {
        var _column$filterOperato;
        if (item.value !== void 0) {
          if (Array.isArray(item.value) && item.value.length === 0) {
            return false;
          }
          return true;
        }
        const column = apiRef2.current.getColumn(item.field);
        const filterOperator = (_column$filterOperato = column.filterOperators) == null ? void 0 : _column$filterOperato.find((operator) => operator.value === item.operator);
        const requiresFilterValue = typeof (filterOperator == null ? void 0 : filterOperator.requiresFilterValue) === "undefined" ? true : filterOperator == null ? void 0 : filterOperator.requiresFilterValue;
        if (requiresFilterValue) {
          return false;
        }
        return true;
      });
      let newFilterItems;
      const filterItemOnTarget = filterItemsWithValue.find((item) => item.field === targetColumnField);
      const targetColumn = apiRef2.current.getColumn(targetColumnField);
      if (filterItemOnTarget) {
        newFilterItems = filterItemsWithValue;
      } else if (props.disableMultipleColumnsFiltering) {
        newFilterItems = [cleanFilterItem({
          field: targetColumnField,
          operator: targetColumn.filterOperators[0].value
        }, apiRef2)];
      } else {
        newFilterItems = [...filterItemsWithValue, cleanFilterItem({
          field: targetColumnField,
          operator: targetColumn.filterOperators[0].value
        }, apiRef2)];
      }
      apiRef2.current.setFilterModel(_extends$1({}, filterModel2, {
        items: newFilterItems
      }));
    }
    apiRef2.current.showPreferences(GridPreferencePanelsValue.filters, panelId, labelId);
  }, [apiRef2, logger, props.disableMultipleColumnsFiltering]);
  const hideFilterPanel = reactExports.useCallback(() => {
    logger.debug("Hiding filter panel");
    apiRef2.current.hidePreferences();
  }, [apiRef2, logger]);
  const setFilterLogicOperator = reactExports.useCallback((logicOperator) => {
    const filterModel2 = gridFilterModelSelector(apiRef2);
    if (filterModel2.logicOperator === logicOperator) {
      return;
    }
    apiRef2.current.setFilterModel(_extends$1({}, filterModel2, {
      logicOperator
    }), "changeLogicOperator");
  }, [apiRef2]);
  const setQuickFilterValues = reactExports.useCallback((values) => {
    const filterModel2 = gridFilterModelSelector(apiRef2);
    if (isDeepEqual(filterModel2.quickFilterValues, values)) {
      return;
    }
    apiRef2.current.setFilterModel(_extends$1({}, filterModel2, {
      quickFilterValues: [...values]
    }));
  }, [apiRef2]);
  const setFilterModel = reactExports.useCallback((model, reason) => {
    const currentModel = gridFilterModelSelector(apiRef2);
    if (currentModel !== model) {
      logger.debug("Setting filter model");
      apiRef2.current.updateControlState("filter", mergeStateWithFilterModel(model, props.disableMultipleColumnsFiltering, apiRef2), reason);
      apiRef2.current.unstable_applyFilters();
    }
  }, [apiRef2, logger, props.disableMultipleColumnsFiltering]);
  const filterApi = {
    setFilterLogicOperator,
    unstable_applyFilters: applyFilters,
    deleteFilterItem,
    upsertFilterItem,
    upsertFilterItems,
    setFilterModel,
    showFilterPanel,
    hideFilterPanel,
    setQuickFilterValues
  };
  useGridApiMethod(apiRef2, filterApi, "public");
  const stateExportPreProcessing = reactExports.useCallback((prevState, context) => {
    var _props$initialState2;
    const filterModelToExport = gridFilterModelSelector(apiRef2);
    const shouldExportFilterModel = (
      // Always export if the `exportOnlyDirtyModels` property is not activated
      !context.exportOnlyDirtyModels || // Always export if the model is controlled
      props.filterModel != null || // Always export if the model has been initialized
      ((_props$initialState2 = props.initialState) == null || (_props$initialState2 = _props$initialState2.filter) == null ? void 0 : _props$initialState2.filterModel) != null || // Export if the model is not equal to the default value
      !isDeepEqual(filterModelToExport, getDefaultGridFilterModel())
    );
    if (!shouldExportFilterModel) {
      return prevState;
    }
    return _extends$1({}, prevState, {
      filter: {
        filterModel: filterModelToExport
      }
    });
  }, [apiRef2, props.filterModel, (_props$initialState3 = props.initialState) == null || (_props$initialState3 = _props$initialState3.filter) == null ? void 0 : _props$initialState3.filterModel]);
  const stateRestorePreProcessing = reactExports.useCallback((params, context) => {
    var _context$stateToResto;
    const filterModel2 = (_context$stateToResto = context.stateToRestore.filter) == null ? void 0 : _context$stateToResto.filterModel;
    if (filterModel2 == null) {
      return params;
    }
    apiRef2.current.updateControlState("filter", mergeStateWithFilterModel(filterModel2, props.disableMultipleColumnsFiltering, apiRef2), "restoreState");
    return _extends$1({}, params, {
      callbacks: [...params.callbacks, apiRef2.current.unstable_applyFilters]
    });
  }, [apiRef2, props.disableMultipleColumnsFiltering]);
  const preferencePanelPreProcessing = reactExports.useCallback((initialValue, value) => {
    if (value === GridPreferencePanelsValue.filters) {
      var _props$slotProps;
      const FilterPanel = props.slots.filterPanel;
      return /* @__PURE__ */ jsxRuntimeExports.jsx(FilterPanel, _extends$1({}, (_props$slotProps = props.slotProps) == null ? void 0 : _props$slotProps.filterPanel));
    }
    return initialValue;
  }, [props.slots.filterPanel, (_props$slotProps2 = props.slotProps) == null ? void 0 : _props$slotProps2.filterPanel]);
  const {
    getRowId: getRowId2
  } = props;
  const getRowsRef = useLazyRef(createMemoizedValues);
  const flatFilteringMethod = reactExports.useCallback((params) => {
    if (props.filterMode !== "client" || !params.isRowMatchingFilters) {
      return {
        filteredRowsLookup: {},
        filteredDescendantCountLookup: {}
      };
    }
    const dataRowIdToModelLookup = gridRowsLookupSelector(apiRef2);
    const filteredRowsLookup = {};
    const {
      isRowMatchingFilters
    } = params;
    const filterCache = {};
    const result = {
      passingFilterItems: null,
      passingQuickFilterValues: null
    };
    const rows = getRowsRef.current(apiRef2.current.state.rows.dataRowIdToModelLookup);
    for (let i2 = 0; i2 < rows.length; i2 += 1) {
      const row = rows[i2];
      const id = getRowId2 ? getRowId2(row) : row.id;
      isRowMatchingFilters(row, void 0, result);
      const isRowPassing = passFilterLogic([result.passingFilterItems], [result.passingQuickFilterValues], params.filterModel, apiRef2, filterCache);
      filteredRowsLookup[id] = isRowPassing;
    }
    const footerId = "auto-generated-group-footer-root";
    const footer = dataRowIdToModelLookup[footerId];
    if (footer) {
      filteredRowsLookup[footerId] = true;
    }
    return {
      filteredRowsLookup,
      filteredDescendantCountLookup: {}
    };
  }, [apiRef2, props.filterMode, getRowId2, getRowsRef]);
  useGridRegisterPipeProcessor(apiRef2, "columnMenu", addColumnMenuItem);
  useGridRegisterPipeProcessor(apiRef2, "exportState", stateExportPreProcessing);
  useGridRegisterPipeProcessor(apiRef2, "restoreState", stateRestorePreProcessing);
  useGridRegisterPipeProcessor(apiRef2, "preferencePanel", preferencePanelPreProcessing);
  useGridRegisterStrategyProcessor(apiRef2, GRID_DEFAULT_STRATEGY, "filtering", flatFilteringMethod);
  useGridRegisterStrategyProcessor(apiRef2, GRID_DEFAULT_STRATEGY, "visibleRowsLookupCreation", getVisibleRowsLookup);
  const handleColumnsChange = reactExports.useCallback(() => {
    logger.debug("onColUpdated - GridColumns changed, applying filters");
    const filterModel2 = gridFilterModelSelector(apiRef2);
    const filterableColumnsLookup = gridFilterableColumnLookupSelector(apiRef2);
    const newFilterItems = filterModel2.items.filter((item) => item.field && filterableColumnsLookup[item.field]);
    if (newFilterItems.length < filterModel2.items.length) {
      apiRef2.current.setFilterModel(_extends$1({}, filterModel2, {
        items: newFilterItems
      }));
    }
  }, [apiRef2, logger]);
  const handleStrategyProcessorChange = reactExports.useCallback((methodName) => {
    if (methodName === "filtering") {
      apiRef2.current.unstable_applyFilters();
    }
  }, [apiRef2]);
  const updateVisibleRowsLookupState = reactExports.useCallback(() => {
    apiRef2.current.setState((state) => {
      return _extends$1({}, state, {
        visibleRowsLookup: getVisibleRowsLookupState(apiRef2, state)
      });
    });
    apiRef2.current.forceUpdate();
  }, [apiRef2]);
  useGridApiEventHandler(apiRef2, "rowsSet", updateFilteredRows);
  useGridApiEventHandler(apiRef2, "columnsChange", handleColumnsChange);
  useGridApiEventHandler(apiRef2, "activeStrategyProcessorChange", handleStrategyProcessorChange);
  useGridApiEventHandler(apiRef2, "rowExpansionChange", updateVisibleRowsLookupState);
  useGridApiEventHandler(apiRef2, "columnVisibilityModelChange", () => {
    const filterModel2 = gridFilterModelSelector(apiRef2);
    if (filterModel2.quickFilterValues && filterModel2.quickFilterExcludeHiddenColumns) {
      apiRef2.current.unstable_applyFilters();
    }
  });
  useFirstRender(() => {
    apiRef2.current.unstable_applyFilters();
  });
  useEnhancedEffect$1(() => {
    if (props.filterModel !== void 0) {
      apiRef2.current.setFilterModel(props.filterModel);
    }
  }, [apiRef2, logger, props.filterModel]);
};
const focusStateInitializer = (state) => _extends$1({}, state, {
  focus: {
    cell: null,
    columnHeader: null,
    columnHeaderFilter: null,
    columnGroupHeader: null
  },
  tabIndex: {
    cell: null,
    columnHeader: null,
    columnHeaderFilter: null,
    columnGroupHeader: null
  }
});
const useGridFocus = (apiRef2, props) => {
  const logger = useGridLogger(apiRef2, "useGridFocus");
  const lastClickedCell = reactExports.useRef(null);
  const publishCellFocusOut = reactExports.useCallback((cell, event) => {
    if (cell) {
      if (apiRef2.current.getRow(cell.id)) {
        apiRef2.current.publishEvent("cellFocusOut", apiRef2.current.getCellParams(cell.id, cell.field), event);
      }
    }
  }, [apiRef2]);
  const setCellFocus = reactExports.useCallback((id, field) => {
    const focusedCell = gridFocusCellSelector(apiRef2);
    if ((focusedCell == null ? void 0 : focusedCell.id) === id && (focusedCell == null ? void 0 : focusedCell.field) === field) {
      return;
    }
    apiRef2.current.setState((state) => {
      logger.debug(`Focusing on cell with id=${id} and field=${field}`);
      return _extends$1({}, state, {
        tabIndex: {
          cell: {
            id,
            field
          },
          columnHeader: null,
          columnHeaderFilter: null,
          columnGroupHeader: null
        },
        focus: {
          cell: {
            id,
            field
          },
          columnHeader: null,
          columnHeaderFilter: null,
          columnGroupHeader: null
        }
      });
    });
    apiRef2.current.forceUpdate();
    if (!apiRef2.current.getRow(id)) {
      return;
    }
    if (focusedCell) {
      publishCellFocusOut(focusedCell, {});
    }
    apiRef2.current.publishEvent("cellFocusIn", apiRef2.current.getCellParams(id, field));
  }, [apiRef2, logger, publishCellFocusOut]);
  const setColumnHeaderFocus = reactExports.useCallback((field, event = {}) => {
    const cell = gridFocusCellSelector(apiRef2);
    publishCellFocusOut(cell, event);
    apiRef2.current.setState((state) => {
      logger.debug(`Focusing on column header with colIndex=${field}`);
      return _extends$1({}, state, {
        tabIndex: {
          columnHeader: {
            field
          },
          columnHeaderFilter: null,
          cell: null,
          columnGroupHeader: null
        },
        focus: {
          columnHeader: {
            field
          },
          columnHeaderFilter: null,
          cell: null,
          columnGroupHeader: null
        }
      });
    });
    apiRef2.current.forceUpdate();
  }, [apiRef2, logger, publishCellFocusOut]);
  const setColumnHeaderFilterFocus = reactExports.useCallback((field, event = {}) => {
    const cell = gridFocusCellSelector(apiRef2);
    publishCellFocusOut(cell, event);
    apiRef2.current.setState((state) => {
      logger.debug(`Focusing on column header filter with colIndex=${field}`);
      return _extends$1({}, state, {
        tabIndex: {
          columnHeader: null,
          columnHeaderFilter: {
            field
          },
          cell: null,
          columnGroupHeader: null
        },
        focus: {
          columnHeader: null,
          columnHeaderFilter: {
            field
          },
          cell: null,
          columnGroupHeader: null
        }
      });
    });
    apiRef2.current.forceUpdate();
  }, [apiRef2, logger, publishCellFocusOut]);
  const setColumnGroupHeaderFocus = reactExports.useCallback((field, depth, event = {}) => {
    const cell = gridFocusCellSelector(apiRef2);
    if (cell) {
      apiRef2.current.publishEvent("cellFocusOut", apiRef2.current.getCellParams(cell.id, cell.field), event);
    }
    apiRef2.current.setState((state) => {
      return _extends$1({}, state, {
        tabIndex: {
          columnGroupHeader: {
            field,
            depth
          },
          columnHeader: null,
          columnHeaderFilter: null,
          cell: null
        },
        focus: {
          columnGroupHeader: {
            field,
            depth
          },
          columnHeader: null,
          columnHeaderFilter: null,
          cell: null
        }
      });
    });
    apiRef2.current.forceUpdate();
  }, [apiRef2]);
  const getColumnGroupHeaderFocus = reactExports.useCallback(() => unstable_gridFocusColumnGroupHeaderSelector(apiRef2), [apiRef2]);
  const moveFocusToRelativeCell = reactExports.useCallback((id, field, direction2) => {
    let columnIndexToFocus = apiRef2.current.getColumnIndex(field);
    const visibleColumns = gridVisibleColumnDefinitionsSelector(apiRef2);
    const currentPage = getVisibleRows(apiRef2, {
      pagination: props.pagination,
      paginationMode: props.paginationMode
    });
    const pinnedRows = gridPinnedRowsSelector(apiRef2);
    const currentPageRows = [].concat(pinnedRows.top || [], currentPage.rows, pinnedRows.bottom || []);
    let rowIndexToFocus = currentPageRows.findIndex((row) => row.id === id);
    if (direction2 === "right") {
      columnIndexToFocus += 1;
    } else if (direction2 === "left") {
      columnIndexToFocus -= 1;
    } else {
      rowIndexToFocus += 1;
    }
    if (columnIndexToFocus >= visibleColumns.length) {
      rowIndexToFocus += 1;
      if (rowIndexToFocus < currentPageRows.length) {
        columnIndexToFocus = 0;
      }
    } else if (columnIndexToFocus < 0) {
      rowIndexToFocus -= 1;
      if (rowIndexToFocus >= 0) {
        columnIndexToFocus = visibleColumns.length - 1;
      }
    }
    rowIndexToFocus = clamp(rowIndexToFocus, 0, currentPageRows.length - 1);
    const rowToFocus = currentPageRows[rowIndexToFocus];
    if (!rowToFocus) {
      return;
    }
    const colSpanInfo = apiRef2.current.unstable_getCellColSpanInfo(rowToFocus.id, columnIndexToFocus);
    if (colSpanInfo && colSpanInfo.spannedByColSpan) {
      if (direction2 === "left" || direction2 === "below") {
        columnIndexToFocus = colSpanInfo.leftVisibleCellIndex;
      } else if (direction2 === "right") {
        columnIndexToFocus = colSpanInfo.rightVisibleCellIndex;
      }
    }
    columnIndexToFocus = clamp(columnIndexToFocus, 0, visibleColumns.length - 1);
    const columnToFocus = visibleColumns[columnIndexToFocus];
    apiRef2.current.setCellFocus(rowToFocus.id, columnToFocus.field);
  }, [apiRef2, props.pagination, props.paginationMode]);
  const handleCellDoubleClick = reactExports.useCallback(({
    id,
    field
  }) => {
    apiRef2.current.setCellFocus(id, field);
  }, [apiRef2]);
  const handleCellKeyDown = reactExports.useCallback((params, event) => {
    if (event.key === "Enter" || event.key === "Tab" || event.key === "Shift" || isNavigationKey(event.key)) {
      return;
    }
    apiRef2.current.setCellFocus(params.id, params.field);
  }, [apiRef2]);
  const handleColumnHeaderFocus = reactExports.useCallback(({
    field
  }, event) => {
    if (event.target !== event.currentTarget) {
      return;
    }
    apiRef2.current.setColumnHeaderFocus(field, event);
  }, [apiRef2]);
  const handleColumnGroupHeaderFocus = reactExports.useCallback(({
    fields,
    depth
  }, event) => {
    if (event.target !== event.currentTarget) {
      return;
    }
    const focusedColumnGroup = unstable_gridFocusColumnGroupHeaderSelector(apiRef2);
    if (focusedColumnGroup !== null && focusedColumnGroup.depth === depth && fields.includes(focusedColumnGroup.field)) {
      return;
    }
    apiRef2.current.setColumnGroupHeaderFocus(fields[0], depth, event);
  }, [apiRef2]);
  const handleBlur = reactExports.useCallback((_2, event) => {
    var _event$relatedTarget;
    if ((_event$relatedTarget = event.relatedTarget) != null && _event$relatedTarget.className.includes(gridClasses.columnHeader)) {
      return;
    }
    logger.debug(`Clearing focus`);
    apiRef2.current.setState((state) => _extends$1({}, state, {
      focus: {
        cell: null,
        columnHeader: null,
        columnHeaderFilter: null,
        columnGroupHeader: null
      }
    }));
  }, [logger, apiRef2]);
  const handleCellMouseDown = reactExports.useCallback((params) => {
    lastClickedCell.current = params;
  }, []);
  const handleDocumentClick = reactExports.useCallback((event) => {
    const cellParams = lastClickedCell.current;
    lastClickedCell.current = null;
    const focusedCell = gridFocusCellSelector(apiRef2);
    const canUpdateFocus = apiRef2.current.unstable_applyPipeProcessors("canUpdateFocus", true, {
      event,
      cell: cellParams
    });
    if (!canUpdateFocus) {
      return;
    }
    if (!focusedCell) {
      if (cellParams) {
        apiRef2.current.setCellFocus(cellParams.id, cellParams.field);
      }
      return;
    }
    if ((cellParams == null ? void 0 : cellParams.id) === focusedCell.id && (cellParams == null ? void 0 : cellParams.field) === focusedCell.field) {
      return;
    }
    const cellElement = apiRef2.current.getCellElement(focusedCell.id, focusedCell.field);
    if (cellElement != null && cellElement.contains(event.target)) {
      return;
    }
    if (cellParams) {
      apiRef2.current.setCellFocus(cellParams.id, cellParams.field);
    } else {
      apiRef2.current.setState((state) => _extends$1({}, state, {
        focus: {
          cell: null,
          columnHeader: null,
          columnHeaderFilter: null,
          columnGroupHeader: null
        }
      }));
      apiRef2.current.forceUpdate();
      publishCellFocusOut(focusedCell, event);
    }
  }, [apiRef2, publishCellFocusOut]);
  const handleCellModeChange = reactExports.useCallback((params) => {
    if (params.cellMode === "view") {
      return;
    }
    const cell = gridFocusCellSelector(apiRef2);
    if ((cell == null ? void 0 : cell.id) !== params.id || (cell == null ? void 0 : cell.field) !== params.field) {
      apiRef2.current.setCellFocus(params.id, params.field);
    }
  }, [apiRef2]);
  const handleRowSet = reactExports.useCallback(() => {
    const cell = gridFocusCellSelector(apiRef2);
    if (cell && !apiRef2.current.getRow(cell.id)) {
      apiRef2.current.setState((state) => _extends$1({}, state, {
        focus: {
          cell: null,
          columnHeader: null,
          columnHeaderFilter: null,
          columnGroupHeader: null
        }
      }));
    }
  }, [apiRef2]);
  const handlePaginationModelChange = useEventCallback$1(() => {
    const currentFocusedCell = gridFocusCellSelector(apiRef2);
    if (!currentFocusedCell) {
      return;
    }
    const currentPage = getVisibleRows(apiRef2, {
      pagination: props.pagination,
      paginationMode: props.paginationMode
    });
    const rowIsInCurrentPage = currentPage.rows.find((row) => row.id === currentFocusedCell.id);
    if (rowIsInCurrentPage) {
      return;
    }
    const visibleColumns = gridVisibleColumnDefinitionsSelector(apiRef2);
    apiRef2.current.setState((state) => {
      return _extends$1({}, state, {
        tabIndex: {
          cell: {
            id: currentPage.rows[0].id,
            field: visibleColumns[0].field
          },
          columnGroupHeader: null,
          columnHeader: null,
          columnHeaderFilter: null
        }
      });
    });
  });
  const focusApi = {
    setCellFocus,
    setColumnHeaderFocus,
    setColumnHeaderFilterFocus
  };
  const focusPrivateApi = {
    moveFocusToRelativeCell,
    setColumnGroupHeaderFocus,
    getColumnGroupHeaderFocus
  };
  useGridApiMethod(apiRef2, focusApi, "public");
  useGridApiMethod(apiRef2, focusPrivateApi, "private");
  reactExports.useEffect(() => {
    const doc = ownerDocument$1(apiRef2.current.rootElementRef.current);
    doc.addEventListener("mouseup", handleDocumentClick);
    return () => {
      doc.removeEventListener("mouseup", handleDocumentClick);
    };
  }, [apiRef2, handleDocumentClick]);
  useGridApiEventHandler(apiRef2, "columnHeaderBlur", handleBlur);
  useGridApiEventHandler(apiRef2, "headerFilterBlur", handleBlur);
  useGridApiEventHandler(apiRef2, "cellDoubleClick", handleCellDoubleClick);
  useGridApiEventHandler(apiRef2, "cellMouseDown", handleCellMouseDown);
  useGridApiEventHandler(apiRef2, "cellKeyDown", handleCellKeyDown);
  useGridApiEventHandler(apiRef2, "cellModeChange", handleCellModeChange);
  useGridApiEventHandler(apiRef2, "columnHeaderFocus", handleColumnHeaderFocus);
  useGridApiEventHandler(apiRef2, "columnGroupHeaderFocus", handleColumnGroupHeaderFocus);
  useGridApiEventHandler(apiRef2, "rowsSet", handleRowSet);
  useGridApiEventHandler(apiRef2, "paginationModelChange", handlePaginationModelChange);
};
function enrichPageRowsWithPinnedRows(apiRef2, rows) {
  const pinnedRows = gridPinnedRowsSelector(apiRef2) || {};
  return [...pinnedRows.top || [], ...rows, ...pinnedRows.bottom || []];
}
const getLeftColumnIndex = ({
  currentColIndex,
  firstColIndex,
  lastColIndex,
  direction: direction2
}) => {
  if (direction2 === "rtl") {
    if (currentColIndex < lastColIndex) {
      return currentColIndex + 1;
    }
  } else if (direction2 === "ltr") {
    if (currentColIndex > firstColIndex) {
      return currentColIndex - 1;
    }
  }
  return null;
};
const getRightColumnIndex = ({
  currentColIndex,
  firstColIndex,
  lastColIndex,
  direction: direction2
}) => {
  if (direction2 === "rtl") {
    if (currentColIndex > firstColIndex) {
      return currentColIndex - 1;
    }
  } else if (direction2 === "ltr") {
    if (currentColIndex < lastColIndex) {
      return currentColIndex + 1;
    }
  }
  return null;
};
const useGridKeyboardNavigation = (apiRef2, props) => {
  const logger = useGridLogger(apiRef2, "useGridKeyboardNavigation");
  const initialCurrentPageRows = useGridVisibleRows(apiRef2, props).rows;
  const theme = useTheme$1();
  const currentPageRows = reactExports.useMemo(() => enrichPageRowsWithPinnedRows(apiRef2, initialCurrentPageRows), [apiRef2, initialCurrentPageRows]);
  const headerFilteringEnabled = (
    // @ts-expect-error // TODO move relevant code to the `DataGridPro`
    props.signature !== "DataGrid" && props.unstable_headerFilters
  );
  const goToCell = reactExports.useCallback((colIndex, rowId, closestColumnToUse = "left") => {
    const visibleSortedRows = gridExpandedSortedRowEntriesSelector(apiRef2);
    const nextCellColSpanInfo = apiRef2.current.unstable_getCellColSpanInfo(rowId, colIndex);
    if (nextCellColSpanInfo && nextCellColSpanInfo.spannedByColSpan) {
      if (closestColumnToUse === "left") {
        colIndex = nextCellColSpanInfo.leftVisibleCellIndex;
      } else if (closestColumnToUse === "right") {
        colIndex = nextCellColSpanInfo.rightVisibleCellIndex;
      }
    }
    const rowIndexRelativeToAllRows = visibleSortedRows.findIndex((row) => row.id === rowId);
    logger.debug(`Navigating to cell row ${rowIndexRelativeToAllRows}, col ${colIndex}`);
    apiRef2.current.scrollToIndexes({
      colIndex,
      rowIndex: rowIndexRelativeToAllRows
    });
    const field = apiRef2.current.getVisibleColumns()[colIndex].field;
    apiRef2.current.setCellFocus(rowId, field);
  }, [apiRef2, logger]);
  const goToHeader = reactExports.useCallback((colIndex, event) => {
    logger.debug(`Navigating to header col ${colIndex}`);
    apiRef2.current.scrollToIndexes({
      colIndex
    });
    const field = apiRef2.current.getVisibleColumns()[colIndex].field;
    apiRef2.current.setColumnHeaderFocus(field, event);
  }, [apiRef2, logger]);
  const goToHeaderFilter = reactExports.useCallback((colIndex, event) => {
    logger.debug(`Navigating to header filter col ${colIndex}`);
    apiRef2.current.scrollToIndexes({
      colIndex
    });
    const field = apiRef2.current.getVisibleColumns()[colIndex].field;
    apiRef2.current.setColumnHeaderFilterFocus(field, event);
  }, [apiRef2, logger]);
  const goToGroupHeader = reactExports.useCallback((colIndex, depth, event) => {
    logger.debug(`Navigating to header col ${colIndex}`);
    apiRef2.current.scrollToIndexes({
      colIndex
    });
    const {
      field
    } = apiRef2.current.getVisibleColumns()[colIndex];
    apiRef2.current.setColumnGroupHeaderFocus(field, depth, event);
  }, [apiRef2, logger]);
  const getRowIdFromIndex = reactExports.useCallback((rowIndex) => {
    var _currentPageRows$rowI;
    return (_currentPageRows$rowI = currentPageRows[rowIndex]) == null ? void 0 : _currentPageRows$rowI.id;
  }, [currentPageRows]);
  const handleColumnHeaderKeyDown = reactExports.useCallback((params, event) => {
    const headerTitleNode = event.currentTarget.querySelector(`.${gridClasses.columnHeaderTitleContainerContent}`);
    const isFromInsideContent = !!headerTitleNode && headerTitleNode.contains(event.target);
    if (isFromInsideContent && params.field !== GRID_CHECKBOX_SELECTION_COL_DEF.field) {
      return;
    }
    const dimensions = apiRef2.current.getRootDimensions();
    if (!dimensions) {
      return;
    }
    const viewportPageSize = apiRef2.current.getViewportPageSize();
    const colIndexBefore = params.field ? apiRef2.current.getColumnIndex(params.field) : 0;
    const firstRowIndexInPage = currentPageRows.length > 0 ? 0 : null;
    const lastRowIndexInPage = currentPageRows.length - 1;
    const firstColIndex = 0;
    const lastColIndex = gridVisibleColumnDefinitionsSelector(apiRef2).length - 1;
    const columnGroupMaxDepth = gridColumnGroupsHeaderMaxDepthSelector(apiRef2);
    let shouldPreventDefault = true;
    switch (event.key) {
      case "ArrowDown": {
        if (firstRowIndexInPage !== null) {
          if (headerFilteringEnabled) {
            goToHeaderFilter(colIndexBefore, event);
          } else {
            goToCell(colIndexBefore, getRowIdFromIndex(firstRowIndexInPage));
          }
        }
        break;
      }
      case "ArrowRight": {
        const rightColIndex = getRightColumnIndex({
          currentColIndex: colIndexBefore,
          firstColIndex,
          lastColIndex,
          direction: theme.direction
        });
        if (rightColIndex !== null) {
          goToHeader(rightColIndex, event);
        }
        break;
      }
      case "ArrowLeft": {
        const leftColIndex = getLeftColumnIndex({
          currentColIndex: colIndexBefore,
          firstColIndex,
          lastColIndex,
          direction: theme.direction
        });
        if (leftColIndex !== null) {
          goToHeader(leftColIndex, event);
        }
        break;
      }
      case "ArrowUp": {
        if (columnGroupMaxDepth > 0) {
          goToGroupHeader(colIndexBefore, columnGroupMaxDepth - 1, event);
        }
        break;
      }
      case "PageDown": {
        if (firstRowIndexInPage !== null && lastRowIndexInPage !== null) {
          goToCell(colIndexBefore, getRowIdFromIndex(Math.min(firstRowIndexInPage + viewportPageSize, lastRowIndexInPage)));
        }
        break;
      }
      case "Home": {
        goToHeader(firstColIndex, event);
        break;
      }
      case "End": {
        goToHeader(lastColIndex, event);
        break;
      }
      case "Enter": {
        if (event.ctrlKey || event.metaKey) {
          apiRef2.current.toggleColumnMenu(params.field);
        }
        break;
      }
      case " ": {
        break;
      }
      default: {
        shouldPreventDefault = false;
      }
    }
    if (shouldPreventDefault) {
      event.preventDefault();
    }
  }, [apiRef2, currentPageRows.length, headerFilteringEnabled, goToHeaderFilter, goToCell, getRowIdFromIndex, theme.direction, goToHeader, goToGroupHeader]);
  const handleHeaderFilterKeyDown = reactExports.useCallback((params, event) => {
    const dimensions = apiRef2.current.getRootDimensions();
    if (!dimensions) {
      return;
    }
    const isEditing = unstable_gridHeaderFilteringEditFieldSelector(apiRef2) === params.field;
    const isHeaderMenuOpen = unstable_gridHeaderFilteringMenuSelector(apiRef2) === params.field;
    if (isEditing || isHeaderMenuOpen || !isNavigationKey(event.key)) {
      return;
    }
    const viewportPageSize = apiRef2.current.getViewportPageSize();
    const colIndexBefore = params.field ? apiRef2.current.getColumnIndex(params.field) : 0;
    const firstRowIndexInPage = 0;
    const lastRowIndexInPage = currentPageRows.length - 1;
    const firstColIndex = 0;
    const lastColIndex = gridVisibleColumnDefinitionsSelector(apiRef2).length - 1;
    let shouldPreventDefault = true;
    switch (event.key) {
      case "ArrowDown": {
        const rowId = getRowIdFromIndex(firstRowIndexInPage);
        if (rowId != null) {
          goToCell(colIndexBefore, rowId);
        }
        break;
      }
      case "ArrowRight": {
        const rightColIndex = getRightColumnIndex({
          currentColIndex: colIndexBefore,
          firstColIndex,
          lastColIndex,
          direction: theme.direction
        });
        if (rightColIndex !== null) {
          goToHeaderFilter(rightColIndex, event);
        }
        break;
      }
      case "ArrowLeft": {
        const leftColIndex = getLeftColumnIndex({
          currentColIndex: colIndexBefore,
          firstColIndex,
          lastColIndex,
          direction: theme.direction
        });
        if (leftColIndex !== null) {
          goToHeaderFilter(leftColIndex, event);
        } else {
          apiRef2.current.setColumnHeaderFilterFocus(params.field, event);
        }
        break;
      }
      case "ArrowUp": {
        goToHeader(colIndexBefore, event);
        break;
      }
      case "PageDown": {
        if (lastRowIndexInPage !== null) {
          goToCell(colIndexBefore, getRowIdFromIndex(Math.min(firstRowIndexInPage + viewportPageSize, lastRowIndexInPage)));
        }
        break;
      }
      case "Home": {
        goToHeaderFilter(firstColIndex, event);
        break;
      }
      case "End": {
        goToHeaderFilter(lastColIndex, event);
        break;
      }
      case " ": {
        break;
      }
      default: {
        shouldPreventDefault = false;
      }
    }
    if (shouldPreventDefault) {
      event.preventDefault();
    }
  }, [apiRef2, currentPageRows.length, goToHeaderFilter, theme.direction, goToHeader, goToCell, getRowIdFromIndex]);
  const handleColumnGroupHeaderKeyDown = reactExports.useCallback((params, event) => {
    const dimensions = apiRef2.current.getRootDimensions();
    if (!dimensions) {
      return;
    }
    const focusedColumnGroup = unstable_gridFocusColumnGroupHeaderSelector(apiRef2);
    if (focusedColumnGroup === null) {
      return;
    }
    const {
      field: currentField,
      depth: currentDepth
    } = focusedColumnGroup;
    const {
      fields,
      depth,
      maxDepth
    } = params;
    const viewportPageSize = apiRef2.current.getViewportPageSize();
    const currentColIndex = apiRef2.current.getColumnIndex(currentField);
    const colIndexBefore = currentField ? apiRef2.current.getColumnIndex(currentField) : 0;
    const firstRowIndexInPage = 0;
    const lastRowIndexInPage = currentPageRows.length - 1;
    const firstColIndex = 0;
    const lastColIndex = gridVisibleColumnDefinitionsSelector(apiRef2).length - 1;
    let shouldPreventDefault = true;
    switch (event.key) {
      case "ArrowDown": {
        if (depth === maxDepth - 1) {
          goToHeader(currentColIndex, event);
        } else {
          goToGroupHeader(currentColIndex, currentDepth + 1, event);
        }
        break;
      }
      case "ArrowUp": {
        if (depth > 0) {
          goToGroupHeader(currentColIndex, currentDepth - 1, event);
        }
        break;
      }
      case "ArrowRight": {
        const remainingRightColumns = fields.length - fields.indexOf(currentField) - 1;
        if (currentColIndex + remainingRightColumns + 1 <= lastColIndex) {
          goToGroupHeader(currentColIndex + remainingRightColumns + 1, currentDepth, event);
        }
        break;
      }
      case "ArrowLeft": {
        const remainingLeftColumns = fields.indexOf(currentField);
        if (currentColIndex - remainingLeftColumns - 1 >= firstColIndex) {
          goToGroupHeader(currentColIndex - remainingLeftColumns - 1, currentDepth, event);
        }
        break;
      }
      case "PageDown": {
        if (lastRowIndexInPage !== null) {
          goToCell(colIndexBefore, getRowIdFromIndex(Math.min(firstRowIndexInPage + viewportPageSize, lastRowIndexInPage)));
        }
        break;
      }
      case "Home": {
        goToGroupHeader(firstColIndex, currentDepth, event);
        break;
      }
      case "End": {
        goToGroupHeader(lastColIndex, currentDepth, event);
        break;
      }
      case " ": {
        break;
      }
      default: {
        shouldPreventDefault = false;
      }
    }
    if (shouldPreventDefault) {
      event.preventDefault();
    }
  }, [apiRef2, currentPageRows.length, goToHeader, goToGroupHeader, goToCell, getRowIdFromIndex]);
  const handleCellKeyDown = reactExports.useCallback((params, event) => {
    if (!event.currentTarget.contains(event.target)) {
      return;
    }
    const cellParams = apiRef2.current.getCellParams(params.id, params.field);
    if (cellParams.cellMode === GridCellModes.Edit || !isNavigationKey(event.key)) {
      return;
    }
    const canUpdateFocus = apiRef2.current.unstable_applyPipeProcessors("canUpdateFocus", true, {
      event,
      cell: cellParams
    });
    if (!canUpdateFocus) {
      return;
    }
    const dimensions = apiRef2.current.getRootDimensions();
    if (currentPageRows.length === 0 || !dimensions) {
      return;
    }
    const direction2 = theme.direction;
    const viewportPageSize = apiRef2.current.getViewportPageSize();
    const colIndexBefore = params.field ? apiRef2.current.getColumnIndex(params.field) : 0;
    const rowIndexBefore = currentPageRows.findIndex((row) => row.id === params.id);
    const firstRowIndexInPage = 0;
    const lastRowIndexInPage = currentPageRows.length - 1;
    const firstColIndex = 0;
    const lastColIndex = gridVisibleColumnDefinitionsSelector(apiRef2).length - 1;
    let shouldPreventDefault = true;
    switch (event.key) {
      case "ArrowDown": {
        if (rowIndexBefore < lastRowIndexInPage) {
          goToCell(colIndexBefore, getRowIdFromIndex(rowIndexBefore + 1));
        }
        break;
      }
      case "ArrowUp": {
        if (rowIndexBefore > firstRowIndexInPage) {
          goToCell(colIndexBefore, getRowIdFromIndex(rowIndexBefore - 1));
        } else if (headerFilteringEnabled) {
          goToHeaderFilter(colIndexBefore, event);
        } else {
          goToHeader(colIndexBefore, event);
        }
        break;
      }
      case "ArrowRight": {
        const rightColIndex = getRightColumnIndex({
          currentColIndex: colIndexBefore,
          firstColIndex,
          lastColIndex,
          direction: direction2
        });
        if (rightColIndex !== null) {
          goToCell(rightColIndex, getRowIdFromIndex(rowIndexBefore), direction2 === "rtl" ? "left" : "right");
        }
        break;
      }
      case "ArrowLeft": {
        const leftColIndex = getLeftColumnIndex({
          currentColIndex: colIndexBefore,
          firstColIndex,
          lastColIndex,
          direction: direction2
        });
        if (leftColIndex !== null) {
          goToCell(leftColIndex, getRowIdFromIndex(rowIndexBefore), direction2 === "rtl" ? "right" : "left");
        }
        break;
      }
      case "Tab": {
        if (event.shiftKey && colIndexBefore > firstColIndex) {
          goToCell(colIndexBefore - 1, getRowIdFromIndex(rowIndexBefore), "left");
        } else if (!event.shiftKey && colIndexBefore < lastColIndex) {
          goToCell(colIndexBefore + 1, getRowIdFromIndex(rowIndexBefore), "right");
        }
        break;
      }
      case " ": {
        const field = params.field;
        if (field === GRID_DETAIL_PANEL_TOGGLE_FIELD) {
          break;
        }
        const colDef = params.colDef;
        if (colDef && colDef.type === "treeDataGroup") {
          break;
        }
        if (!event.shiftKey && rowIndexBefore < lastRowIndexInPage) {
          goToCell(colIndexBefore, getRowIdFromIndex(Math.min(rowIndexBefore + viewportPageSize, lastRowIndexInPage)));
        }
        break;
      }
      case "PageDown": {
        if (rowIndexBefore < lastRowIndexInPage) {
          goToCell(colIndexBefore, getRowIdFromIndex(Math.min(rowIndexBefore + viewportPageSize, lastRowIndexInPage)));
        }
        break;
      }
      case "PageUp": {
        const nextRowIndex = Math.max(rowIndexBefore - viewportPageSize, firstRowIndexInPage);
        if (nextRowIndex !== rowIndexBefore && nextRowIndex >= firstRowIndexInPage) {
          goToCell(colIndexBefore, getRowIdFromIndex(nextRowIndex));
        } else {
          goToHeader(colIndexBefore, event);
        }
        break;
      }
      case "Home": {
        if (event.ctrlKey || event.metaKey || event.shiftKey) {
          goToCell(firstColIndex, getRowIdFromIndex(firstRowIndexInPage));
        } else {
          goToCell(firstColIndex, getRowIdFromIndex(rowIndexBefore));
        }
        break;
      }
      case "End": {
        if (event.ctrlKey || event.metaKey || event.shiftKey) {
          goToCell(lastColIndex, getRowIdFromIndex(lastRowIndexInPage));
        } else {
          goToCell(lastColIndex, getRowIdFromIndex(rowIndexBefore));
        }
        break;
      }
      default: {
        shouldPreventDefault = false;
      }
    }
    if (shouldPreventDefault) {
      event.preventDefault();
    }
  }, [apiRef2, currentPageRows, theme.direction, goToCell, getRowIdFromIndex, headerFilteringEnabled, goToHeaderFilter, goToHeader]);
  const checkIfCanStartEditing = reactExports.useCallback((initialValue, {
    event
  }) => {
    if (event.key === " ") {
      return false;
    }
    return initialValue;
  }, []);
  useGridRegisterPipeProcessor(apiRef2, "canStartEditing", checkIfCanStartEditing);
  useGridApiEventHandler(apiRef2, "columnHeaderKeyDown", handleColumnHeaderKeyDown);
  useGridApiEventHandler(apiRef2, "headerFilterKeyDown", handleHeaderFilterKeyDown);
  useGridApiEventHandler(apiRef2, "columnGroupHeaderKeyDown", handleColumnGroupHeaderKeyDown);
  useGridApiEventHandler(apiRef2, "cellKeyDown", handleCellKeyDown);
};
const preferencePanelStateInitializer = (state, props) => {
  var _props$initialState$p, _props$initialState;
  return _extends$1({}, state, {
    preferencePanel: (_props$initialState$p = (_props$initialState = props.initialState) == null ? void 0 : _props$initialState.preferencePanel) != null ? _props$initialState$p : {
      open: false
    }
  });
};
const useGridPreferencesPanel = (apiRef2, props) => {
  var _props$initialState3;
  const logger = useGridLogger(apiRef2, "useGridPreferencesPanel");
  const hideTimeout = reactExports.useRef();
  const immediateTimeout = reactExports.useRef();
  const hidePreferences = reactExports.useCallback(() => {
    logger.debug("Hiding Preferences Panel");
    const preferencePanelState = gridPreferencePanelStateSelector(apiRef2.current.state);
    if (preferencePanelState.openedPanelValue) {
      apiRef2.current.publishEvent("preferencePanelClose", {
        openedPanelValue: preferencePanelState.openedPanelValue
      });
    }
    apiRef2.current.setState((state) => _extends$1({}, state, {
      preferencePanel: {
        open: false
      }
    }));
    apiRef2.current.forceUpdate();
  }, [apiRef2, logger]);
  const doNotHidePanel = reactExports.useCallback(() => {
    immediateTimeout.current = setTimeout(() => clearTimeout(hideTimeout.current), 0);
  }, []);
  const hidePreferencesDelayed = reactExports.useCallback(() => {
    hideTimeout.current = setTimeout(hidePreferences, 100);
  }, [hidePreferences]);
  const showPreferences = reactExports.useCallback((newValue, panelId, labelId) => {
    logger.debug("Opening Preferences Panel");
    doNotHidePanel();
    apiRef2.current.setState((state) => _extends$1({}, state, {
      preferencePanel: _extends$1({}, state.preferencePanel, {
        open: true,
        openedPanelValue: newValue,
        panelId,
        labelId
      })
    }));
    apiRef2.current.publishEvent("preferencePanelOpen", {
      openedPanelValue: newValue
    });
    apiRef2.current.forceUpdate();
  }, [logger, doNotHidePanel, apiRef2]);
  useGridApiMethod(apiRef2, {
    showPreferences,
    hidePreferences: hidePreferencesDelayed
  }, "public");
  const stateExportPreProcessing = reactExports.useCallback((prevState, context) => {
    var _props$initialState2;
    const preferencePanelToExport = gridPreferencePanelStateSelector(apiRef2.current.state);
    const shouldExportPreferencePanel = (
      // Always export if the `exportOnlyDirtyModels` property is not activated
      !context.exportOnlyDirtyModels || // Always export if the panel was initialized
      ((_props$initialState2 = props.initialState) == null ? void 0 : _props$initialState2.preferencePanel) != null || // Always export if the panel is opened
      preferencePanelToExport.open
    );
    if (!shouldExportPreferencePanel) {
      return prevState;
    }
    return _extends$1({}, prevState, {
      preferencePanel: preferencePanelToExport
    });
  }, [apiRef2, (_props$initialState3 = props.initialState) == null ? void 0 : _props$initialState3.preferencePanel]);
  const stateRestorePreProcessing = reactExports.useCallback((params, context) => {
    const preferencePanel = context.stateToRestore.preferencePanel;
    if (preferencePanel != null) {
      apiRef2.current.setState((state) => _extends$1({}, state, {
        preferencePanel
      }));
    }
    return params;
  }, [apiRef2]);
  useGridRegisterPipeProcessor(apiRef2, "exportState", stateExportPreProcessing);
  useGridRegisterPipeProcessor(apiRef2, "restoreState", stateRestorePreProcessing);
  reactExports.useEffect(() => {
    return () => {
      clearTimeout(hideTimeout.current);
      clearTimeout(immediateTimeout.current);
    };
  }, []);
};
const _excluded$f = ["id", "field"], _excluded2$2 = ["id", "field"];
const missingOnProcessRowUpdateErrorWarning$1 = buildWarning(["MUI: A call to `processRowUpdate` threw an error which was not handled because `onProcessRowUpdateError` is missing.", "To handle the error pass a callback to the `onProcessRowUpdateError` prop, e.g. `<DataGrid onProcessRowUpdateError={(error) => ...} />`.", "For more detail, see http://mui.com/components/data-grid/editing/#server-side-persistence."], "error");
const useGridCellEditing = (apiRef2, props) => {
  const [cellModesModel, setCellModesModel] = reactExports.useState({});
  const cellModesModelRef = reactExports.useRef(cellModesModel);
  const prevCellModesModel = reactExports.useRef({});
  const {
    processRowUpdate,
    onProcessRowUpdateError,
    cellModesModel: cellModesModelProp,
    onCellModesModelChange
  } = props;
  const runIfEditModeIsCell = (callback) => (...args) => {
    if (props.editMode === GridEditModes.Cell) {
      callback(...args);
    }
  };
  const throwIfNotEditable = reactExports.useCallback((id, field) => {
    const params = apiRef2.current.getCellParams(id, field);
    if (!apiRef2.current.isCellEditable(params)) {
      throw new Error(`MUI: The cell with id=${id} and field=${field} is not editable.`);
    }
  }, [apiRef2]);
  const throwIfNotInMode = reactExports.useCallback((id, field, mode) => {
    if (apiRef2.current.getCellMode(id, field) !== mode) {
      throw new Error(`MUI: The cell with id=${id} and field=${field} is not in ${mode} mode.`);
    }
  }, [apiRef2]);
  const handleCellDoubleClick = reactExports.useCallback((params, event) => {
    if (!params.isEditable) {
      return;
    }
    if (params.cellMode === GridCellModes.Edit) {
      return;
    }
    const newParams = _extends$1({}, params, {
      reason: GridCellEditStartReasons.cellDoubleClick
    });
    apiRef2.current.publishEvent("cellEditStart", newParams, event);
  }, [apiRef2]);
  const handleCellFocusOut = reactExports.useCallback((params, event) => {
    if (params.cellMode === GridCellModes.View) {
      return;
    }
    if (apiRef2.current.getCellMode(params.id, params.field) === GridCellModes.View) {
      return;
    }
    const newParams = _extends$1({}, params, {
      reason: GridCellEditStopReasons.cellFocusOut
    });
    apiRef2.current.publishEvent("cellEditStop", newParams, event);
  }, [apiRef2]);
  const handleCellKeyDown = reactExports.useCallback((params, event) => {
    if (params.cellMode === GridCellModes.Edit) {
      if (event.which === 229) {
        return;
      }
      let reason;
      if (event.key === "Escape") {
        reason = GridCellEditStopReasons.escapeKeyDown;
      } else if (event.key === "Enter") {
        reason = GridCellEditStopReasons.enterKeyDown;
      } else if (event.key === "Tab") {
        reason = event.shiftKey ? GridCellEditStopReasons.shiftTabKeyDown : GridCellEditStopReasons.tabKeyDown;
        event.preventDefault();
      }
      if (reason) {
        const newParams = _extends$1({}, params, {
          reason
        });
        apiRef2.current.publishEvent("cellEditStop", newParams, event);
      }
    } else if (params.isEditable) {
      let reason;
      const canStartEditing = apiRef2.current.unstable_applyPipeProcessors("canStartEditing", true, {
        event,
        cellParams: params,
        editMode: "cell"
      });
      if (!canStartEditing) {
        return;
      }
      if (isPrintableKey(event)) {
        reason = GridCellEditStartReasons.printableKeyDown;
      } else if ((event.ctrlKey || event.metaKey) && event.key === "v") {
        reason = GridCellEditStartReasons.printableKeyDown;
      } else if (event.key === "Enter") {
        reason = GridCellEditStartReasons.enterKeyDown;
      } else if (event.key === "Delete" || event.key === "Backspace") {
        reason = GridCellEditStartReasons.deleteKeyDown;
      }
      if (reason) {
        const newParams = _extends$1({}, params, {
          reason,
          key: event.key
        });
        apiRef2.current.publishEvent("cellEditStart", newParams, event);
      }
    }
  }, [apiRef2]);
  const handleCellEditStart = reactExports.useCallback((params) => {
    const {
      id,
      field,
      reason,
      key,
      colDef
    } = params;
    const startCellEditModeParams = {
      id,
      field
    };
    if (reason === GridCellEditStartReasons.printableKeyDown) {
      if (reactExports.version.startsWith("17")) {
        startCellEditModeParams.deleteValue = true;
      } else {
        const initialValue = colDef.valueParser ? colDef.valueParser(key) : key;
        startCellEditModeParams.initialValue = initialValue;
      }
    } else if (reason === GridCellEditStartReasons.deleteKeyDown) {
      startCellEditModeParams.deleteValue = true;
    }
    apiRef2.current.startCellEditMode(startCellEditModeParams);
  }, [apiRef2]);
  const handleCellEditStop = reactExports.useCallback((params) => {
    const {
      id,
      field,
      reason
    } = params;
    apiRef2.current.runPendingEditCellValueMutation(id, field);
    let cellToFocusAfter;
    if (reason === GridCellEditStopReasons.enterKeyDown) {
      cellToFocusAfter = "below";
    } else if (reason === GridCellEditStopReasons.tabKeyDown) {
      cellToFocusAfter = "right";
    } else if (reason === GridCellEditStopReasons.shiftTabKeyDown) {
      cellToFocusAfter = "left";
    }
    const ignoreModifications = reason === "escapeKeyDown";
    apiRef2.current.stopCellEditMode({
      id,
      field,
      ignoreModifications,
      cellToFocusAfter
    });
  }, [apiRef2]);
  useGridApiEventHandler(apiRef2, "cellDoubleClick", runIfEditModeIsCell(handleCellDoubleClick));
  useGridApiEventHandler(apiRef2, "cellFocusOut", runIfEditModeIsCell(handleCellFocusOut));
  useGridApiEventHandler(apiRef2, "cellKeyDown", runIfEditModeIsCell(handleCellKeyDown));
  useGridApiEventHandler(apiRef2, "cellEditStart", runIfEditModeIsCell(handleCellEditStart));
  useGridApiEventHandler(apiRef2, "cellEditStop", runIfEditModeIsCell(handleCellEditStop));
  useGridApiOptionHandler(apiRef2, "cellEditStart", props.onCellEditStart);
  useGridApiOptionHandler(apiRef2, "cellEditStop", props.onCellEditStop);
  const getCellMode = reactExports.useCallback((id, field) => {
    const editingState = gridEditRowsStateSelector(apiRef2.current.state);
    const isEditing = editingState[id] && editingState[id][field];
    return isEditing ? GridCellModes.Edit : GridCellModes.View;
  }, [apiRef2]);
  const updateCellModesModel = useEventCallback$1((newModel) => {
    const isNewModelDifferentFromProp = newModel !== props.cellModesModel;
    if (onCellModesModelChange && isNewModelDifferentFromProp) {
      onCellModesModelChange(newModel, {});
    }
    if (props.cellModesModel && isNewModelDifferentFromProp) {
      return;
    }
    setCellModesModel(newModel);
    cellModesModelRef.current = newModel;
    apiRef2.current.publishEvent("cellModesModelChange", newModel);
  });
  const updateFieldInCellModesModel = reactExports.useCallback((id, field, newProps) => {
    const newModel = _extends$1({}, cellModesModelRef.current);
    if (newProps !== null) {
      newModel[id] = _extends$1({}, newModel[id], {
        [field]: _extends$1({}, newProps)
      });
    } else {
      const _newModel$id = newModel[id], otherFields = _objectWithoutPropertiesLoose$1(_newModel$id, [field].map(_toPropertyKey));
      newModel[id] = otherFields;
      if (Object.keys(newModel[id]).length === 0) {
        delete newModel[id];
      }
    }
    updateCellModesModel(newModel);
  }, [updateCellModesModel]);
  const updateOrDeleteFieldState = reactExports.useCallback((id, field, newProps) => {
    apiRef2.current.setState((state) => {
      const newEditingState = _extends$1({}, state.editRows);
      if (newProps !== null) {
        newEditingState[id] = _extends$1({}, newEditingState[id], {
          [field]: _extends$1({}, newProps)
        });
      } else {
        delete newEditingState[id][field];
        if (Object.keys(newEditingState[id]).length === 0) {
          delete newEditingState[id];
        }
      }
      return _extends$1({}, state, {
        editRows: newEditingState
      });
    });
    apiRef2.current.forceUpdate();
  }, [apiRef2]);
  const startCellEditMode = reactExports.useCallback((params) => {
    const {
      id,
      field
    } = params, other = _objectWithoutPropertiesLoose$1(params, _excluded$f);
    throwIfNotEditable(id, field);
    throwIfNotInMode(id, field, GridCellModes.View);
    updateFieldInCellModesModel(id, field, _extends$1({
      mode: GridCellModes.Edit
    }, other));
  }, [throwIfNotEditable, throwIfNotInMode, updateFieldInCellModesModel]);
  const updateStateToStartCellEditMode = useEventCallback$1((params) => {
    const {
      id,
      field,
      deleteValue,
      initialValue
    } = params;
    let newValue = apiRef2.current.getCellValue(id, field);
    let unstable_updateValueOnRender = false;
    if (deleteValue || initialValue) {
      newValue = deleteValue ? "" : initialValue;
      unstable_updateValueOnRender = true;
    }
    const newProps = {
      value: newValue,
      error: false,
      isProcessingProps: false,
      unstable_updateValueOnRender
    };
    updateOrDeleteFieldState(id, field, newProps);
    apiRef2.current.setCellFocus(id, field);
  });
  const stopCellEditMode = reactExports.useCallback((params) => {
    const {
      id,
      field
    } = params, other = _objectWithoutPropertiesLoose$1(params, _excluded2$2);
    throwIfNotInMode(id, field, GridCellModes.Edit);
    updateFieldInCellModesModel(id, field, _extends$1({
      mode: GridCellModes.View
    }, other));
  }, [throwIfNotInMode, updateFieldInCellModesModel]);
  const updateStateToStopCellEditMode = useEventCallback$1(async (params) => {
    const {
      id,
      field,
      ignoreModifications,
      cellToFocusAfter = "none"
    } = params;
    throwIfNotInMode(id, field, GridCellModes.Edit);
    apiRef2.current.runPendingEditCellValueMutation(id, field);
    const finishCellEditMode = () => {
      updateOrDeleteFieldState(id, field, null);
      updateFieldInCellModesModel(id, field, null);
      if (cellToFocusAfter !== "none") {
        apiRef2.current.moveFocusToRelativeCell(id, field, cellToFocusAfter);
      }
    };
    if (ignoreModifications) {
      finishCellEditMode();
      return;
    }
    const editingState = gridEditRowsStateSelector(apiRef2.current.state);
    const {
      error,
      isProcessingProps
    } = editingState[id][field];
    if (error || isProcessingProps) {
      prevCellModesModel.current[id][field].mode = GridCellModes.Edit;
      updateFieldInCellModesModel(id, field, {
        mode: GridCellModes.Edit
      });
      return;
    }
    const rowUpdate = apiRef2.current.getRowWithUpdatedValuesFromCellEditing(id, field);
    if (processRowUpdate) {
      const handleError = (errorThrown) => {
        prevCellModesModel.current[id][field].mode = GridCellModes.Edit;
        updateFieldInCellModesModel(id, field, {
          mode: GridCellModes.Edit
        });
        if (onProcessRowUpdateError) {
          onProcessRowUpdateError(errorThrown);
        } else {
          missingOnProcessRowUpdateErrorWarning$1();
        }
      };
      try {
        const row = apiRef2.current.getRow(id);
        Promise.resolve(processRowUpdate(rowUpdate, row)).then((finalRowUpdate) => {
          apiRef2.current.updateRows([finalRowUpdate]);
          finishCellEditMode();
        }).catch(handleError);
      } catch (errorThrown) {
        handleError(errorThrown);
      }
    } else {
      apiRef2.current.updateRows([rowUpdate]);
      finishCellEditMode();
    }
  });
  const setCellEditingEditCellValue = reactExports.useCallback(async (params) => {
    var _editingState$id;
    const {
      id,
      field,
      value,
      debounceMs,
      unstable_skipValueParser: skipValueParser
    } = params;
    throwIfNotEditable(id, field);
    throwIfNotInMode(id, field, GridCellModes.Edit);
    const column = apiRef2.current.getColumn(field);
    const row = apiRef2.current.getRow(id);
    let parsedValue = value;
    if (column.valueParser && !skipValueParser) {
      parsedValue = column.valueParser(value, apiRef2.current.getCellParams(id, field));
    }
    let editingState = gridEditRowsStateSelector(apiRef2.current.state);
    let newProps = _extends$1({}, editingState[id][field], {
      value: parsedValue,
      changeReason: debounceMs ? "debouncedSetEditCellValue" : "setEditCellValue"
    });
    if (column.preProcessEditCellProps) {
      const hasChanged = value !== editingState[id][field].value;
      newProps = _extends$1({}, newProps, {
        isProcessingProps: true
      });
      updateOrDeleteFieldState(id, field, newProps);
      newProps = await Promise.resolve(column.preProcessEditCellProps({
        id,
        row,
        props: newProps,
        hasChanged
      }));
    }
    if (apiRef2.current.getCellMode(id, field) === GridCellModes.View) {
      return false;
    }
    editingState = gridEditRowsStateSelector(apiRef2.current.state);
    newProps = _extends$1({}, newProps, {
      isProcessingProps: false
    });
    newProps.value = column.preProcessEditCellProps ? editingState[id][field].value : parsedValue;
    updateOrDeleteFieldState(id, field, newProps);
    editingState = gridEditRowsStateSelector(apiRef2.current.state);
    return !((_editingState$id = editingState[id]) != null && (_editingState$id = _editingState$id[field]) != null && _editingState$id.error);
  }, [apiRef2, throwIfNotEditable, throwIfNotInMode, updateOrDeleteFieldState]);
  const getRowWithUpdatedValuesFromCellEditing = reactExports.useCallback((id, field) => {
    const column = apiRef2.current.getColumn(field);
    const editingState = gridEditRowsStateSelector(apiRef2.current.state);
    const row = apiRef2.current.getRow(id);
    if (!editingState[id] || !editingState[id][field]) {
      return apiRef2.current.getRow(id);
    }
    const {
      value
    } = editingState[id][field];
    return column.valueSetter ? column.valueSetter({
      value,
      row
    }) : _extends$1({}, row, {
      [field]: value
    });
  }, [apiRef2]);
  const editingApi = {
    getCellMode,
    startCellEditMode,
    stopCellEditMode
  };
  const editingPrivateApi = {
    setCellEditingEditCellValue,
    getRowWithUpdatedValuesFromCellEditing
  };
  useGridApiMethod(apiRef2, editingApi, "public");
  useGridApiMethod(apiRef2, editingPrivateApi, "private");
  reactExports.useEffect(() => {
    if (cellModesModelProp) {
      updateCellModesModel(cellModesModelProp);
    }
  }, [cellModesModelProp, updateCellModesModel]);
  reactExports.useEffect(() => {
    const idToIdLookup = gridRowsDataRowIdToIdLookupSelector(apiRef2);
    const copyOfPrevCellModes = prevCellModesModel.current;
    prevCellModesModel.current = deepClone(cellModesModel);
    Object.entries(cellModesModel).forEach(([id, fields]) => {
      Object.entries(fields).forEach(([field, params]) => {
        var _copyOfPrevCellModes$, _idToIdLookup$id;
        const prevMode = ((_copyOfPrevCellModes$ = copyOfPrevCellModes[id]) == null || (_copyOfPrevCellModes$ = _copyOfPrevCellModes$[field]) == null ? void 0 : _copyOfPrevCellModes$.mode) || GridCellModes.View;
        const originalId = (_idToIdLookup$id = idToIdLookup[id]) != null ? _idToIdLookup$id : id;
        if (params.mode === GridCellModes.Edit && prevMode === GridCellModes.View) {
          updateStateToStartCellEditMode(_extends$1({
            id: originalId,
            field
          }, params));
        } else if (params.mode === GridCellModes.View && prevMode === GridCellModes.Edit) {
          updateStateToStopCellEditMode(_extends$1({
            id: originalId,
            field
          }, params));
        }
      });
    });
  }, [apiRef2, cellModesModel, updateStateToStartCellEditMode, updateStateToStopCellEditMode]);
};
const _excluded$e = ["id"], _excluded2$1 = ["id"];
const missingOnProcessRowUpdateErrorWarning = buildWarning(["MUI: A call to `processRowUpdate` threw an error which was not handled because `onProcessRowUpdateError` is missing.", "To handle the error pass a callback to the `onProcessRowUpdateError` prop, e.g. `<DataGrid onProcessRowUpdateError={(error) => ...} />`.", "For more detail, see http://mui.com/components/data-grid/editing/#server-side-persistence."], "error");
const useGridRowEditing = (apiRef2, props) => {
  const [rowModesModel, setRowModesModel] = reactExports.useState({});
  const rowModesModelRef = reactExports.useRef(rowModesModel);
  const prevRowModesModel = reactExports.useRef({});
  const focusTimeout = reactExports.useRef(null);
  const nextFocusedCell = reactExports.useRef(null);
  const {
    processRowUpdate,
    onProcessRowUpdateError,
    rowModesModel: rowModesModelProp,
    onRowModesModelChange
  } = props;
  const runIfEditModeIsRow = (callback) => (...args) => {
    if (props.editMode === GridEditModes.Row) {
      callback(...args);
    }
  };
  const throwIfNotEditable = reactExports.useCallback((id, field) => {
    const params = apiRef2.current.getCellParams(id, field);
    if (!apiRef2.current.isCellEditable(params)) {
      throw new Error(`MUI: The cell with id=${id} and field=${field} is not editable.`);
    }
  }, [apiRef2]);
  const throwIfNotInMode = reactExports.useCallback((id, mode) => {
    if (apiRef2.current.getRowMode(id) !== mode) {
      throw new Error(`MUI: The row with id=${id} is not in ${mode} mode.`);
    }
  }, [apiRef2]);
  const handleCellDoubleClick = reactExports.useCallback((params, event) => {
    if (!params.isEditable) {
      return;
    }
    if (apiRef2.current.getRowMode(params.id) === GridRowModes.Edit) {
      return;
    }
    const rowParams = apiRef2.current.getRowParams(params.id);
    const newParams = _extends$1({}, rowParams, {
      field: params.field,
      reason: GridRowEditStartReasons.cellDoubleClick
    });
    apiRef2.current.publishEvent("rowEditStart", newParams, event);
  }, [apiRef2]);
  const handleCellFocusIn = reactExports.useCallback((params) => {
    nextFocusedCell.current = params;
  }, []);
  const handleCellFocusOut = reactExports.useCallback((params, event) => {
    if (!params.isEditable) {
      return;
    }
    if (apiRef2.current.getRowMode(params.id) === GridRowModes.View) {
      return;
    }
    nextFocusedCell.current = null;
    focusTimeout.current = setTimeout(() => {
      var _nextFocusedCell$curr;
      focusTimeout.current = null;
      if (((_nextFocusedCell$curr = nextFocusedCell.current) == null ? void 0 : _nextFocusedCell$curr.id) !== params.id) {
        if (!apiRef2.current.getRow(params.id)) {
          return;
        }
        if (apiRef2.current.getRowMode(params.id) === GridRowModes.View) {
          return;
        }
        const rowParams = apiRef2.current.getRowParams(params.id);
        const newParams = _extends$1({}, rowParams, {
          field: params.field,
          reason: GridRowEditStopReasons.rowFocusOut
        });
        apiRef2.current.publishEvent("rowEditStop", newParams, event);
      }
    });
  }, [apiRef2]);
  reactExports.useEffect(() => {
    return () => {
      clearTimeout(focusTimeout.current);
    };
  }, []);
  const handleCellKeyDown = reactExports.useCallback((params, event) => {
    if (params.cellMode === GridRowModes.Edit) {
      if (event.which === 229) {
        return;
      }
      let reason;
      if (event.key === "Escape") {
        reason = GridRowEditStopReasons.escapeKeyDown;
      } else if (event.key === "Enter") {
        reason = GridRowEditStopReasons.enterKeyDown;
      } else if (event.key === "Tab") {
        const columnFields = gridVisibleColumnFieldsSelector(apiRef2).filter((field) => {
          const column = apiRef2.current.getColumn(field);
          if (column.type === GRID_ACTIONS_COLUMN_TYPE) {
            return true;
          }
          return apiRef2.current.isCellEditable(apiRef2.current.getCellParams(params.id, field));
        });
        if (event.shiftKey) {
          if (params.field === columnFields[0]) {
            reason = GridRowEditStopReasons.shiftTabKeyDown;
          }
        } else if (params.field === columnFields[columnFields.length - 1]) {
          reason = GridRowEditStopReasons.tabKeyDown;
        }
        event.preventDefault();
        if (!reason) {
          const index = columnFields.findIndex((field) => field === params.field);
          const nextFieldToFocus = columnFields[event.shiftKey ? index - 1 : index + 1];
          apiRef2.current.setCellFocus(params.id, nextFieldToFocus);
        }
      }
      if (reason) {
        const newParams = _extends$1({}, apiRef2.current.getRowParams(params.id), {
          reason,
          field: params.field
        });
        apiRef2.current.publishEvent("rowEditStop", newParams, event);
      }
    } else if (params.isEditable) {
      let reason;
      const canStartEditing = apiRef2.current.unstable_applyPipeProcessors("canStartEditing", true, {
        event,
        cellParams: params,
        editMode: "row"
      });
      if (!canStartEditing) {
        return;
      }
      if (isPrintableKey(event)) {
        reason = GridRowEditStartReasons.printableKeyDown;
      } else if ((event.ctrlKey || event.metaKey) && event.key === "v") {
        reason = GridRowEditStartReasons.printableKeyDown;
      } else if (event.key === "Enter") {
        reason = GridRowEditStartReasons.enterKeyDown;
      } else if (event.key === "Delete" || event.key === "Backspace") {
        reason = GridRowEditStartReasons.deleteKeyDown;
      }
      if (reason) {
        const rowParams = apiRef2.current.getRowParams(params.id);
        const newParams = _extends$1({}, rowParams, {
          field: params.field,
          key: event.key,
          reason
        });
        apiRef2.current.publishEvent("rowEditStart", newParams, event);
      }
    }
  }, [apiRef2]);
  const handleRowEditStart = reactExports.useCallback((params) => {
    const {
      id,
      field,
      reason,
      key,
      columns
    } = params;
    const startRowEditModeParams = {
      id,
      fieldToFocus: field
    };
    if (reason === GridRowEditStartReasons.printableKeyDown) {
      if (reactExports.version.startsWith("17")) {
        startRowEditModeParams.deleteValue = !!field;
      } else {
        const colDef = columns.find((col) => col.field === field);
        startRowEditModeParams.initialValue = colDef.valueParser ? colDef.valueParser(key) : key;
      }
    } else if (reason === GridRowEditStartReasons.deleteKeyDown) {
      startRowEditModeParams.deleteValue = !!field;
    }
    apiRef2.current.startRowEditMode(startRowEditModeParams);
  }, [apiRef2]);
  const handleRowEditStop = reactExports.useCallback((params) => {
    const {
      id,
      reason,
      field
    } = params;
    apiRef2.current.runPendingEditCellValueMutation(id);
    let cellToFocusAfter;
    if (reason === GridRowEditStopReasons.enterKeyDown) {
      cellToFocusAfter = "below";
    } else if (reason === GridRowEditStopReasons.tabKeyDown) {
      cellToFocusAfter = "right";
    } else if (reason === GridRowEditStopReasons.shiftTabKeyDown) {
      cellToFocusAfter = "left";
    }
    const ignoreModifications = reason === "escapeKeyDown";
    apiRef2.current.stopRowEditMode({
      id,
      ignoreModifications,
      field,
      cellToFocusAfter
    });
  }, [apiRef2]);
  useGridApiEventHandler(apiRef2, "cellDoubleClick", runIfEditModeIsRow(handleCellDoubleClick));
  useGridApiEventHandler(apiRef2, "cellFocusIn", runIfEditModeIsRow(handleCellFocusIn));
  useGridApiEventHandler(apiRef2, "cellFocusOut", runIfEditModeIsRow(handleCellFocusOut));
  useGridApiEventHandler(apiRef2, "cellKeyDown", runIfEditModeIsRow(handleCellKeyDown));
  useGridApiEventHandler(apiRef2, "rowEditStart", runIfEditModeIsRow(handleRowEditStart));
  useGridApiEventHandler(apiRef2, "rowEditStop", runIfEditModeIsRow(handleRowEditStop));
  useGridApiOptionHandler(apiRef2, "rowEditStart", props.onRowEditStart);
  useGridApiOptionHandler(apiRef2, "rowEditStop", props.onRowEditStop);
  const getRowMode = reactExports.useCallback((id) => {
    if (props.editMode === GridEditModes.Cell) {
      return GridRowModes.View;
    }
    const editingState = gridEditRowsStateSelector(apiRef2.current.state);
    const isEditing = editingState[id] && Object.keys(editingState[id]).length > 0;
    return isEditing ? GridRowModes.Edit : GridRowModes.View;
  }, [apiRef2, props.editMode]);
  const updateRowModesModel = useEventCallback$1((newModel) => {
    const isNewModelDifferentFromProp = newModel !== props.rowModesModel;
    if (onRowModesModelChange && isNewModelDifferentFromProp) {
      onRowModesModelChange(newModel, {});
    }
    if (props.rowModesModel && isNewModelDifferentFromProp) {
      return;
    }
    setRowModesModel(newModel);
    rowModesModelRef.current = newModel;
    apiRef2.current.publishEvent("rowModesModelChange", newModel);
  });
  const updateRowInRowModesModel = reactExports.useCallback((id, newProps) => {
    const newModel = _extends$1({}, rowModesModelRef.current);
    if (newProps !== null) {
      newModel[id] = _extends$1({}, newProps);
    } else {
      delete newModel[id];
    }
    updateRowModesModel(newModel);
  }, [updateRowModesModel]);
  const updateOrDeleteRowState = reactExports.useCallback((id, newProps) => {
    apiRef2.current.setState((state) => {
      const newEditingState = _extends$1({}, state.editRows);
      if (newProps !== null) {
        newEditingState[id] = newProps;
      } else {
        delete newEditingState[id];
      }
      return _extends$1({}, state, {
        editRows: newEditingState
      });
    });
    apiRef2.current.forceUpdate();
  }, [apiRef2]);
  const updateOrDeleteFieldState = reactExports.useCallback((id, field, newProps) => {
    apiRef2.current.setState((state) => {
      const newEditingState = _extends$1({}, state.editRows);
      if (newProps !== null) {
        newEditingState[id] = _extends$1({}, newEditingState[id], {
          [field]: _extends$1({}, newProps)
        });
      } else {
        delete newEditingState[id][field];
        if (Object.keys(newEditingState[id]).length === 0) {
          delete newEditingState[id];
        }
      }
      return _extends$1({}, state, {
        editRows: newEditingState
      });
    });
    apiRef2.current.forceUpdate();
  }, [apiRef2]);
  const startRowEditMode = reactExports.useCallback((params) => {
    const {
      id
    } = params, other = _objectWithoutPropertiesLoose$1(params, _excluded$e);
    throwIfNotInMode(id, GridRowModes.View);
    updateRowInRowModesModel(id, _extends$1({
      mode: GridRowModes.Edit
    }, other));
  }, [throwIfNotInMode, updateRowInRowModesModel]);
  const updateStateToStartRowEditMode = useEventCallback$1((params) => {
    const {
      id,
      fieldToFocus,
      deleteValue,
      initialValue
    } = params;
    const columnFields = gridColumnFieldsSelector(apiRef2);
    const newProps = columnFields.reduce((acc, field) => {
      const cellParams = apiRef2.current.getCellParams(id, field);
      if (!cellParams.isEditable) {
        return acc;
      }
      let newValue = apiRef2.current.getCellValue(id, field);
      let unstable_updateValueOnRender = false;
      if (fieldToFocus === field && (deleteValue || initialValue)) {
        newValue = deleteValue ? "" : initialValue;
        unstable_updateValueOnRender = true;
      }
      acc[field] = {
        value: newValue,
        error: false,
        isProcessingProps: false,
        unstable_updateValueOnRender
      };
      return acc;
    }, {});
    updateOrDeleteRowState(id, newProps);
    if (fieldToFocus) {
      apiRef2.current.setCellFocus(id, fieldToFocus);
    }
  });
  const stopRowEditMode = reactExports.useCallback((params) => {
    const {
      id
    } = params, other = _objectWithoutPropertiesLoose$1(params, _excluded2$1);
    throwIfNotInMode(id, GridRowModes.Edit);
    updateRowInRowModesModel(id, _extends$1({
      mode: GridRowModes.View
    }, other));
  }, [throwIfNotInMode, updateRowInRowModesModel]);
  const updateStateToStopRowEditMode = useEventCallback$1((params) => {
    const {
      id,
      ignoreModifications,
      field: focusedField,
      cellToFocusAfter = "none"
    } = params;
    apiRef2.current.runPendingEditCellValueMutation(id);
    const finishRowEditMode = () => {
      if (cellToFocusAfter !== "none" && focusedField) {
        apiRef2.current.moveFocusToRelativeCell(id, focusedField, cellToFocusAfter);
      }
      updateOrDeleteRowState(id, null);
      updateRowInRowModesModel(id, null);
    };
    if (ignoreModifications) {
      finishRowEditMode();
      return;
    }
    const editingState = gridEditRowsStateSelector(apiRef2.current.state);
    const row = apiRef2.current.getRow(id);
    const isSomeFieldProcessingProps = Object.values(editingState[id]).some((fieldProps) => fieldProps.isProcessingProps);
    if (isSomeFieldProcessingProps) {
      prevRowModesModel.current[id].mode = GridRowModes.Edit;
      return;
    }
    const hasSomeFieldWithError = Object.values(editingState[id]).some((fieldProps) => fieldProps.error);
    if (hasSomeFieldWithError) {
      prevRowModesModel.current[id].mode = GridRowModes.Edit;
      updateRowInRowModesModel(id, {
        mode: GridRowModes.Edit
      });
      return;
    }
    const rowUpdate = apiRef2.current.getRowWithUpdatedValuesFromRowEditing(id);
    if (processRowUpdate) {
      const handleError = (errorThrown) => {
        prevRowModesModel.current[id].mode = GridRowModes.Edit;
        updateRowInRowModesModel(id, {
          mode: GridRowModes.Edit
        });
        if (onProcessRowUpdateError) {
          onProcessRowUpdateError(errorThrown);
        } else {
          missingOnProcessRowUpdateErrorWarning();
        }
      };
      try {
        Promise.resolve(processRowUpdate(rowUpdate, row)).then((finalRowUpdate) => {
          apiRef2.current.updateRows([finalRowUpdate]);
          finishRowEditMode();
        }).catch(handleError);
      } catch (errorThrown) {
        handleError(errorThrown);
      }
    } else {
      apiRef2.current.updateRows([rowUpdate]);
      finishRowEditMode();
    }
  });
  const setRowEditingEditCellValue = reactExports.useCallback((params) => {
    const {
      id,
      field,
      value,
      debounceMs,
      unstable_skipValueParser: skipValueParser
    } = params;
    throwIfNotEditable(id, field);
    const column = apiRef2.current.getColumn(field);
    const row = apiRef2.current.getRow(id);
    let parsedValue = value;
    if (column.valueParser && !skipValueParser) {
      parsedValue = column.valueParser(value, apiRef2.current.getCellParams(id, field));
    }
    let editingState = gridEditRowsStateSelector(apiRef2.current.state);
    let newProps = _extends$1({}, editingState[id][field], {
      value: parsedValue,
      changeReason: debounceMs ? "debouncedSetEditCellValue" : "setEditCellValue"
    });
    if (!column.preProcessEditCellProps) {
      updateOrDeleteFieldState(id, field, newProps);
    }
    return new Promise((resolve) => {
      const promises = [];
      if (column.preProcessEditCellProps) {
        const hasChanged = newProps.value !== editingState[id][field].value;
        newProps = _extends$1({}, newProps, {
          isProcessingProps: true
        });
        updateOrDeleteFieldState(id, field, newProps);
        const _editingState$id = editingState[id], otherFieldsProps = _objectWithoutPropertiesLoose$1(_editingState$id, [field].map(_toPropertyKey));
        const promise = Promise.resolve(column.preProcessEditCellProps({
          id,
          row,
          props: newProps,
          hasChanged,
          otherFieldsProps
        })).then((processedProps) => {
          if (apiRef2.current.getRowMode(id) === GridRowModes.View) {
            resolve(false);
            return;
          }
          editingState = gridEditRowsStateSelector(apiRef2.current.state);
          processedProps = _extends$1({}, processedProps, {
            isProcessingProps: false
          });
          processedProps.value = column.preProcessEditCellProps ? editingState[id][field].value : parsedValue;
          updateOrDeleteFieldState(id, field, processedProps);
        });
        promises.push(promise);
      }
      Object.entries(editingState[id]).forEach(([thisField, fieldProps]) => {
        if (thisField === field) {
          return;
        }
        const fieldColumn = apiRef2.current.getColumn(thisField);
        if (!fieldColumn.preProcessEditCellProps) {
          return;
        }
        fieldProps = _extends$1({}, fieldProps, {
          isProcessingProps: true
        });
        updateOrDeleteFieldState(id, thisField, fieldProps);
        editingState = gridEditRowsStateSelector(apiRef2.current.state);
        const _editingState$id2 = editingState[id], otherFieldsProps = _objectWithoutPropertiesLoose$1(_editingState$id2, [thisField].map(_toPropertyKey));
        const promise = Promise.resolve(fieldColumn.preProcessEditCellProps({
          id,
          row,
          props: fieldProps,
          hasChanged: false,
          otherFieldsProps
        })).then((processedProps) => {
          if (apiRef2.current.getRowMode(id) === GridRowModes.View) {
            resolve(false);
            return;
          }
          processedProps = _extends$1({}, processedProps, {
            isProcessingProps: false
          });
          updateOrDeleteFieldState(id, thisField, processedProps);
        });
        promises.push(promise);
      });
      Promise.all(promises).then(() => {
        if (apiRef2.current.getRowMode(id) === GridRowModes.Edit) {
          editingState = gridEditRowsStateSelector(apiRef2.current.state);
          resolve(!editingState[id][field].error);
        } else {
          resolve(false);
        }
      });
    });
  }, [apiRef2, throwIfNotEditable, updateOrDeleteFieldState]);
  const getRowWithUpdatedValuesFromRowEditing = reactExports.useCallback((id) => {
    const editingState = gridEditRowsStateSelector(apiRef2.current.state);
    const row = apiRef2.current.getRow(id);
    if (!editingState[id]) {
      return apiRef2.current.getRow(id);
    }
    let rowUpdate = _extends$1({}, row);
    Object.entries(editingState[id]).forEach(([field, fieldProps]) => {
      const column = apiRef2.current.getColumn(field);
      if (column.valueSetter) {
        rowUpdate = column.valueSetter({
          value: fieldProps.value,
          row: rowUpdate
        });
      } else {
        rowUpdate[field] = fieldProps.value;
      }
    });
    return rowUpdate;
  }, [apiRef2]);
  const editingApi = {
    getRowMode,
    startRowEditMode,
    stopRowEditMode
  };
  const editingPrivateApi = {
    setRowEditingEditCellValue,
    getRowWithUpdatedValuesFromRowEditing
  };
  useGridApiMethod(apiRef2, editingApi, "public");
  useGridApiMethod(apiRef2, editingPrivateApi, "private");
  reactExports.useEffect(() => {
    if (rowModesModelProp) {
      updateRowModesModel(rowModesModelProp);
    }
  }, [rowModesModelProp, updateRowModesModel]);
  reactExports.useEffect(() => {
    const idToIdLookup = gridRowsDataRowIdToIdLookupSelector(apiRef2);
    const copyOfPrevRowModesModel = prevRowModesModel.current;
    prevRowModesModel.current = deepClone(rowModesModel);
    Object.entries(rowModesModel).forEach(([id, params]) => {
      var _copyOfPrevRowModesMo, _idToIdLookup$id;
      const prevMode = ((_copyOfPrevRowModesMo = copyOfPrevRowModesModel[id]) == null ? void 0 : _copyOfPrevRowModesMo.mode) || GridRowModes.View;
      const originalId = (_idToIdLookup$id = idToIdLookup[id]) != null ? _idToIdLookup$id : id;
      if (params.mode === GridRowModes.Edit && prevMode === GridRowModes.View) {
        updateStateToStartRowEditMode(_extends$1({
          id: originalId
        }, params));
      } else if (params.mode === GridRowModes.View && prevMode === GridRowModes.Edit) {
        updateStateToStopRowEditMode(_extends$1({
          id: originalId
        }, params));
      }
    });
  }, [apiRef2, rowModesModel, updateStateToStartRowEditMode, updateStateToStopRowEditMode]);
};
const editingStateInitializer = (state) => _extends$1({}, state, {
  editRows: {}
});
const useGridEditing = (apiRef2, props) => {
  useGridCellEditing(apiRef2, props);
  useGridRowEditing(apiRef2, props);
  const debounceMap = reactExports.useRef({});
  const {
    isCellEditable: isCellEditableProp
  } = props;
  const isCellEditable = reactExports.useCallback((params) => {
    if (isAutoGeneratedRow(params.rowNode)) {
      return false;
    }
    if (!params.colDef.editable) {
      return false;
    }
    if (!params.colDef.renderEditCell) {
      return false;
    }
    if (isCellEditableProp) {
      return isCellEditableProp(params);
    }
    return true;
  }, [isCellEditableProp]);
  const maybeDebounce = (id, field, debounceMs, callback) => {
    if (!debounceMs) {
      callback();
      return;
    }
    if (!debounceMap.current[id]) {
      debounceMap.current[id] = {};
    }
    if (debounceMap.current[id][field]) {
      const [timeout3] = debounceMap.current[id][field];
      clearTimeout(timeout3);
    }
    const runImmediately = () => {
      const [timeout3] = debounceMap.current[id][field];
      clearTimeout(timeout3);
      callback();
      delete debounceMap.current[id][field];
    };
    const timeout2 = setTimeout(() => {
      callback();
      delete debounceMap.current[id][field];
    }, debounceMs);
    debounceMap.current[id][field] = [timeout2, runImmediately];
  };
  reactExports.useEffect(() => {
    const debounces = debounceMap.current;
    return () => {
      Object.entries(debounces).forEach(([id, fields]) => {
        Object.keys(fields).forEach((field) => {
          const [timeout2] = debounces[id][field];
          clearTimeout(timeout2);
          delete debounces[id][field];
        });
      });
    };
  }, []);
  const runPendingEditCellValueMutation = reactExports.useCallback((id, field) => {
    if (!debounceMap.current[id]) {
      return;
    }
    if (!field) {
      Object.keys(debounceMap.current[id]).forEach((debouncedField) => {
        const [, runCallback] = debounceMap.current[id][debouncedField];
        runCallback();
      });
    } else if (debounceMap.current[id][field]) {
      const [, runCallback] = debounceMap.current[id][field];
      runCallback();
    }
  }, []);
  const setEditCellValue = reactExports.useCallback((params) => {
    const {
      id,
      field,
      debounceMs
    } = params;
    return new Promise((resolve) => {
      maybeDebounce(id, field, debounceMs, async () => {
        const setEditCellValueToCall = props.editMode === GridEditModes.Row ? apiRef2.current.setRowEditingEditCellValue : apiRef2.current.setCellEditingEditCellValue;
        if (apiRef2.current.getCellMode(id, field) === GridCellModes.Edit) {
          const result = await setEditCellValueToCall(params);
          resolve(result);
        }
      });
    });
  }, [apiRef2, props.editMode]);
  const getRowWithUpdatedValues = reactExports.useCallback((id, field) => {
    return props.editMode === GridEditModes.Cell ? apiRef2.current.getRowWithUpdatedValuesFromCellEditing(id, field) : apiRef2.current.getRowWithUpdatedValuesFromRowEditing(id);
  }, [apiRef2, props.editMode]);
  const getEditCellMeta = reactExports.useCallback((id, field) => {
    var _editingState$id$fiel, _editingState$id;
    const editingState = gridEditRowsStateSelector(apiRef2.current.state);
    return (_editingState$id$fiel = (_editingState$id = editingState[id]) == null ? void 0 : _editingState$id[field]) != null ? _editingState$id$fiel : null;
  }, [apiRef2]);
  const editingSharedApi = {
    isCellEditable,
    setEditCellValue,
    getRowWithUpdatedValues,
    unstable_getEditCellMeta: getEditCellMeta
  };
  const editingSharedPrivateApi = {
    runPendingEditCellValueMutation
  };
  useGridApiMethod(apiRef2, editingSharedApi, "public");
  useGridApiMethod(apiRef2, editingSharedPrivateApi, "private");
};
const rowsStateInitializer = (state, props, apiRef2) => {
  apiRef2.current.caches.rows = createRowsInternalCache({
    rows: props.rows,
    getRowId: props.getRowId,
    loading: props.loading,
    rowCount: props.rowCount
  });
  return _extends$1({}, state, {
    rows: getRowsStateFromCache({
      apiRef: apiRef2,
      rowCountProp: props.rowCount,
      loadingProp: props.loading,
      previousTree: null,
      previousTreeDepths: null
    })
  });
};
const useGridRows = (apiRef2, props) => {
  const logger = useGridLogger(apiRef2, "useGridRows");
  const currentPage = useGridVisibleRows(apiRef2, props);
  const lastUpdateMs = reactExports.useRef(Date.now());
  const timeout2 = useTimeout();
  const getRow = reactExports.useCallback((id) => {
    const model = gridRowsLookupSelector(apiRef2)[id];
    if (model) {
      return model;
    }
    const node = apiRef2.current.getRowNode(id);
    if (node && isAutoGeneratedRow(node)) {
      return {
        [GRID_ID_AUTOGENERATED]: id
      };
    }
    return null;
  }, [apiRef2]);
  const getRowIdProp = props.getRowId;
  const getRowId2 = reactExports.useCallback((row) => {
    if (GRID_ID_AUTOGENERATED in row) {
      return row[GRID_ID_AUTOGENERATED];
    }
    if (getRowIdProp) {
      return getRowIdProp(row);
    }
    return row.id;
  }, [getRowIdProp]);
  const lookup = reactExports.useMemo(() => currentPage.rows.reduce((acc, {
    id
  }, index) => {
    acc[id] = index;
    return acc;
  }, {}), [currentPage.rows]);
  const throttledRowsChange = reactExports.useCallback(({
    cache,
    throttle
  }) => {
    const run = () => {
      lastUpdateMs.current = Date.now();
      apiRef2.current.setState((state) => _extends$1({}, state, {
        rows: getRowsStateFromCache({
          apiRef: apiRef2,
          rowCountProp: props.rowCount,
          loadingProp: props.loading,
          previousTree: gridRowTreeSelector(apiRef2),
          previousTreeDepths: gridRowTreeDepthsSelector(apiRef2)
        })
      }));
      apiRef2.current.publishEvent("rowsSet");
      apiRef2.current.forceUpdate();
    };
    timeout2.clear();
    apiRef2.current.caches.rows = cache;
    if (!throttle) {
      run();
      return;
    }
    const throttleRemainingTimeMs = props.throttleRowsMs - (Date.now() - lastUpdateMs.current);
    if (throttleRemainingTimeMs > 0) {
      timeout2.start(throttleRemainingTimeMs, run);
      return;
    }
    run();
  }, [props.throttleRowsMs, props.rowCount, props.loading, apiRef2, timeout2]);
  const setRows = reactExports.useCallback((rows) => {
    logger.debug(`Updating all rows, new length ${rows.length}`);
    const cache = createRowsInternalCache({
      rows,
      getRowId: props.getRowId,
      loading: props.loading,
      rowCount: props.rowCount
    });
    const prevCache = apiRef2.current.caches.rows;
    cache.rowsBeforePartialUpdates = prevCache.rowsBeforePartialUpdates;
    throttledRowsChange({
      cache,
      throttle: true
    });
  }, [logger, props.getRowId, props.loading, props.rowCount, throttledRowsChange, apiRef2]);
  const updateRows = reactExports.useCallback((updates) => {
    if (props.signature === GridSignature.DataGrid && updates.length > 1) {
      throw new Error(["MUI: You can't update several rows at once in `apiRef.current.updateRows` on the DataGrid.", "You need to upgrade to DataGridPro or DataGridPremium component to unlock this feature."].join("\n"));
    }
    const nonPinnedRowsUpdates = [];
    updates.forEach((update) => {
      const id = getRowIdFromRowModel(update, props.getRowId, "A row was provided without id when calling updateRows():");
      const rowNode = apiRef2.current.getRowNode(id);
      if ((rowNode == null ? void 0 : rowNode.type) === "pinnedRow") {
        const pinnedRowsCache = apiRef2.current.caches.pinnedRows;
        const prevModel = pinnedRowsCache.idLookup[id];
        if (prevModel) {
          pinnedRowsCache.idLookup[id] = _extends$1({}, prevModel, update);
        }
      } else {
        nonPinnedRowsUpdates.push(update);
      }
    });
    const cache = updateCacheWithNewRows({
      updates: nonPinnedRowsUpdates,
      getRowId: props.getRowId,
      previousCache: apiRef2.current.caches.rows
    });
    throttledRowsChange({
      cache,
      throttle: true
    });
  }, [props.signature, props.getRowId, throttledRowsChange, apiRef2]);
  const getRowModels = reactExports.useCallback(() => {
    const dataRows = gridDataRowIdsSelector(apiRef2);
    const idRowsLookup = gridRowsLookupSelector(apiRef2);
    return new Map(dataRows.map((id) => {
      var _idRowsLookup$id;
      return [id, (_idRowsLookup$id = idRowsLookup[id]) != null ? _idRowsLookup$id : {}];
    }));
  }, [apiRef2]);
  const getRowsCount = reactExports.useCallback(() => gridRowCountSelector(apiRef2), [apiRef2]);
  const getAllRowIds = reactExports.useCallback(() => gridDataRowIdsSelector(apiRef2), [apiRef2]);
  const getRowIndexRelativeToVisibleRows = reactExports.useCallback((id) => lookup[id], [lookup]);
  const setRowChildrenExpansion = reactExports.useCallback((id, isExpanded) => {
    const currentNode = apiRef2.current.getRowNode(id);
    if (!currentNode) {
      throw new Error(`MUI: No row with id #${id} found`);
    }
    if (currentNode.type !== "group") {
      throw new Error("MUI: Only group nodes can be expanded or collapsed");
    }
    const newNode = _extends$1({}, currentNode, {
      childrenExpanded: isExpanded
    });
    apiRef2.current.setState((state) => {
      return _extends$1({}, state, {
        rows: _extends$1({}, state.rows, {
          tree: _extends$1({}, state.rows.tree, {
            [id]: newNode
          })
        })
      });
    });
    apiRef2.current.forceUpdate();
    apiRef2.current.publishEvent("rowExpansionChange", newNode);
  }, [apiRef2]);
  const getRowNode = reactExports.useCallback((id) => {
    var _ref;
    return (_ref = gridRowTreeSelector(apiRef2)[id]) != null ? _ref : null;
  }, [apiRef2]);
  const getRowGroupChildren = reactExports.useCallback(({
    skipAutoGeneratedRows = true,
    groupId,
    applySorting,
    applyFiltering
  }) => {
    const tree = gridRowTreeSelector(apiRef2);
    let children;
    if (applySorting) {
      const groupNode = tree[groupId];
      if (!groupNode) {
        return [];
      }
      const sortedRowIds = gridSortedRowIdsSelector(apiRef2);
      children = [];
      const startIndex = sortedRowIds.findIndex((id) => id === groupId) + 1;
      for (let index = startIndex; index < sortedRowIds.length && tree[sortedRowIds[index]].depth > groupNode.depth; index += 1) {
        const id = sortedRowIds[index];
        if (!skipAutoGeneratedRows || !isAutoGeneratedRow(tree[id])) {
          children.push(id);
        }
      }
    } else {
      children = getTreeNodeDescendants(tree, groupId, skipAutoGeneratedRows);
    }
    if (applyFiltering) {
      const filteredRowsLookup = gridFilteredRowsLookupSelector(apiRef2);
      children = children.filter((childId) => filteredRowsLookup[childId] !== false);
    }
    return children;
  }, [apiRef2]);
  const setRowIndex = reactExports.useCallback((rowId, targetIndex) => {
    const node = apiRef2.current.getRowNode(rowId);
    if (!node) {
      throw new Error(`MUI: No row with id #${rowId} found`);
    }
    if (node.parent !== GRID_ROOT_GROUP_ID) {
      throw new Error(`MUI: The row reordering do not support reordering of grouped rows yet`);
    }
    if (node.type !== "leaf") {
      throw new Error(`MUI: The row reordering do not support reordering of footer or grouping rows`);
    }
    apiRef2.current.setState((state) => {
      const group = gridRowTreeSelector(state, apiRef2.current.instanceId)[GRID_ROOT_GROUP_ID];
      const allRows = group.children;
      const oldIndex = allRows.findIndex((row) => row === rowId);
      if (oldIndex === -1 || oldIndex === targetIndex) {
        return state;
      }
      logger.debug(`Moving row ${rowId} to index ${targetIndex}`);
      const updatedRows = [...allRows];
      updatedRows.splice(targetIndex, 0, updatedRows.splice(oldIndex, 1)[0]);
      return _extends$1({}, state, {
        rows: _extends$1({}, state.rows, {
          tree: _extends$1({}, state.rows.tree, {
            [GRID_ROOT_GROUP_ID]: _extends$1({}, group, {
              children: updatedRows
            })
          })
        })
      });
    });
    apiRef2.current.publishEvent("rowsSet");
  }, [apiRef2, logger]);
  const replaceRows = reactExports.useCallback((firstRowToRender, newRows) => {
    if (props.signature === GridSignature.DataGrid && newRows.length > 1) {
      throw new Error(["MUI: You can't replace rows using `apiRef.current.unstable_replaceRows` on the DataGrid.", "You need to upgrade to DataGridPro or DataGridPremium component to unlock this feature."].join("\n"));
    }
    if (newRows.length === 0) {
      return;
    }
    const treeDepth = gridRowMaximumTreeDepthSelector(apiRef2);
    if (treeDepth > 1) {
      throw new Error("`apiRef.current.unstable_replaceRows` is not compatible with tree data and row grouping");
    }
    const tree = _extends$1({}, gridRowTreeSelector(apiRef2));
    const dataRowIdToModelLookup = _extends$1({}, gridRowsLookupSelector(apiRef2));
    const dataRowIdToIdLookup = _extends$1({}, gridRowsDataRowIdToIdLookupSelector(apiRef2));
    const rootGroup = tree[GRID_ROOT_GROUP_ID];
    const rootGroupChildren = [...rootGroup.children];
    for (let i2 = 0; i2 < newRows.length; i2 += 1) {
      const rowModel = newRows[i2];
      const rowId = getRowIdFromRowModel(rowModel, props.getRowId, "A row was provided without id when calling replaceRows().");
      const [replacedRowId] = rootGroupChildren.splice(firstRowToRender + i2, 1, rowId);
      delete dataRowIdToModelLookup[replacedRowId];
      delete dataRowIdToIdLookup[replacedRowId];
      delete tree[replacedRowId];
      const rowTreeNodeConfig = {
        id: rowId,
        depth: 0,
        parent: GRID_ROOT_GROUP_ID,
        type: "leaf",
        groupingKey: null
      };
      dataRowIdToModelLookup[rowId] = rowModel;
      dataRowIdToIdLookup[rowId] = rowId;
      tree[rowId] = rowTreeNodeConfig;
    }
    tree[GRID_ROOT_GROUP_ID] = _extends$1({}, rootGroup, {
      children: rootGroupChildren
    });
    const dataRowIds = rootGroupChildren.filter((childId) => tree[childId].type === "leaf");
    apiRef2.current.caches.rows.dataRowIdToModelLookup = dataRowIdToModelLookup;
    apiRef2.current.caches.rows.dataRowIdToIdLookup = dataRowIdToIdLookup;
    apiRef2.current.setState((state) => _extends$1({}, state, {
      rows: _extends$1({}, state.rows, {
        dataRowIdToModelLookup,
        dataRowIdToIdLookup,
        dataRowIds,
        tree
      })
    }));
    apiRef2.current.publishEvent("rowsSet");
  }, [apiRef2, props.signature, props.getRowId]);
  const rowApi = {
    getRow,
    getRowId: getRowId2,
    getRowModels,
    getRowsCount,
    getAllRowIds,
    setRows,
    updateRows,
    getRowNode,
    getRowIndexRelativeToVisibleRows,
    unstable_replaceRows: replaceRows
  };
  const rowProApi = {
    setRowIndex,
    setRowChildrenExpansion,
    getRowGroupChildren
  };
  const groupRows = reactExports.useCallback(() => {
    logger.info(`Row grouping pre-processing have changed, regenerating the row tree`);
    let cache;
    if (apiRef2.current.caches.rows.rowsBeforePartialUpdates === props.rows) {
      cache = _extends$1({}, apiRef2.current.caches.rows, {
        updates: {
          type: "full",
          rows: gridDataRowIdsSelector(apiRef2)
        }
      });
    } else {
      cache = createRowsInternalCache({
        rows: props.rows,
        getRowId: props.getRowId,
        loading: props.loading,
        rowCount: props.rowCount
      });
    }
    throttledRowsChange({
      cache,
      throttle: false
    });
  }, [logger, apiRef2, props.rows, props.getRowId, props.loading, props.rowCount, throttledRowsChange]);
  const handleStrategyProcessorChange = reactExports.useCallback((methodName) => {
    if (methodName === "rowTreeCreation") {
      groupRows();
    }
  }, [groupRows]);
  const handleStrategyActivityChange = reactExports.useCallback(() => {
    if (apiRef2.current.getActiveStrategy("rowTree") !== gridRowGroupingNameSelector(apiRef2)) {
      groupRows();
    }
  }, [apiRef2, groupRows]);
  useGridApiEventHandler(apiRef2, "activeStrategyProcessorChange", handleStrategyProcessorChange);
  useGridApiEventHandler(apiRef2, "strategyAvailabilityChange", handleStrategyActivityChange);
  const applyHydrateRowsProcessor = reactExports.useCallback(() => {
    apiRef2.current.setState((state) => {
      const response = apiRef2.current.unstable_applyPipeProcessors("hydrateRows", {
        tree: gridRowTreeSelector(state, apiRef2.current.instanceId),
        treeDepths: gridRowTreeDepthsSelector(state, apiRef2.current.instanceId),
        dataRowIds: gridDataRowIdsSelector(state, apiRef2.current.instanceId),
        dataRowIdToModelLookup: gridRowsLookupSelector(state, apiRef2.current.instanceId),
        dataRowIdToIdLookup: gridRowsDataRowIdToIdLookupSelector(state, apiRef2.current.instanceId)
      });
      return _extends$1({}, state, {
        rows: _extends$1({}, state.rows, response, {
          totalTopLevelRowCount: getTopLevelRowCount({
            tree: response.tree,
            rowCountProp: props.rowCount
          })
        })
      });
    });
    apiRef2.current.publishEvent("rowsSet");
    apiRef2.current.forceUpdate();
  }, [apiRef2, props.rowCount]);
  useGridRegisterPipeApplier(apiRef2, "hydrateRows", applyHydrateRowsProcessor);
  useGridApiMethod(apiRef2, rowApi, "public");
  useGridApiMethod(apiRef2, rowProApi, props.signature === GridSignature.DataGrid ? "private" : "public");
  const isFirstRender = reactExports.useRef(true);
  reactExports.useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    const areNewRowsAlreadyInState = apiRef2.current.caches.rows.rowsBeforePartialUpdates === props.rows;
    const isNewLoadingAlreadyInState = apiRef2.current.caches.rows.loadingPropBeforePartialUpdates === props.loading;
    const isNewRowCountAlreadyInState = apiRef2.current.caches.rows.rowCountPropBeforePartialUpdates === props.rowCount;
    if (areNewRowsAlreadyInState) {
      if (!isNewLoadingAlreadyInState) {
        apiRef2.current.setState((state) => _extends$1({}, state, {
          rows: _extends$1({}, state.rows, {
            loading: props.loading
          })
        }));
        apiRef2.current.caches.rows.loadingPropBeforePartialUpdates = props.loading;
        apiRef2.current.forceUpdate();
      }
      if (!isNewRowCountAlreadyInState) {
        apiRef2.current.setState((state) => _extends$1({}, state, {
          rows: _extends$1({}, state.rows, {
            totalRowCount: Math.max(props.rowCount || 0, state.rows.totalRowCount),
            totalTopLevelRowCount: Math.max(props.rowCount || 0, state.rows.totalTopLevelRowCount)
          })
        }));
        apiRef2.current.caches.rows.rowCountPropBeforePartialUpdates = props.rowCount;
        apiRef2.current.forceUpdate();
      }
      return;
    }
    logger.debug(`Updating all rows, new length ${props.rows.length}`);
    throttledRowsChange({
      cache: createRowsInternalCache({
        rows: props.rows,
        getRowId: props.getRowId,
        loading: props.loading,
        rowCount: props.rowCount
      }),
      throttle: false
    });
  }, [props.rows, props.rowCount, props.getRowId, props.loading, logger, throttledRowsChange, apiRef2]);
};
const createFlatRowTree = (rows) => {
  const tree = {
    [GRID_ROOT_GROUP_ID]: _extends$1({}, buildRootGroup(), {
      children: rows
    })
  };
  for (let i2 = 0; i2 < rows.length; i2 += 1) {
    const rowId = rows[i2];
    tree[rowId] = {
      id: rowId,
      depth: 0,
      parent: GRID_ROOT_GROUP_ID,
      type: "leaf",
      groupingKey: null
    };
  }
  return {
    groupingName: GRID_DEFAULT_STRATEGY,
    tree,
    treeDepths: {
      0: rows.length
    },
    dataRowIds: rows
  };
};
const updateFlatRowTree = ({
  previousTree,
  actions
}) => {
  const tree = _extends$1({}, previousTree);
  const idsToRemoveFromRootGroup = {};
  for (let i2 = 0; i2 < actions.remove.length; i2 += 1) {
    const idToDelete = actions.remove[i2];
    idsToRemoveFromRootGroup[idToDelete] = true;
    delete tree[idToDelete];
  }
  for (let i2 = 0; i2 < actions.insert.length; i2 += 1) {
    const idToInsert = actions.insert[i2];
    tree[idToInsert] = {
      id: idToInsert,
      depth: 0,
      parent: GRID_ROOT_GROUP_ID,
      type: "leaf",
      groupingKey: null
    };
  }
  const rootGroup = tree[GRID_ROOT_GROUP_ID];
  let rootGroupChildren = [...rootGroup.children, ...actions.insert];
  if (Object.values(idsToRemoveFromRootGroup).length) {
    rootGroupChildren = rootGroupChildren.filter((id) => !idsToRemoveFromRootGroup[id]);
  }
  tree[GRID_ROOT_GROUP_ID] = _extends$1({}, rootGroup, {
    children: rootGroupChildren
  });
  return {
    groupingName: GRID_DEFAULT_STRATEGY,
    tree,
    treeDepths: {
      0: rootGroupChildren.length
    },
    dataRowIds: rootGroupChildren
  };
};
const flatRowTreeCreationMethod = (params) => {
  if (params.updates.type === "full") {
    return createFlatRowTree(params.updates.rows);
  }
  return updateFlatRowTree({
    previousTree: params.previousTree,
    actions: params.updates.actions
  });
};
const useGridRowsPreProcessors = (apiRef2) => {
  useGridRegisterStrategyProcessor(apiRef2, GRID_DEFAULT_STRATEGY, "rowTreeCreation", flatRowTreeCreationMethod);
};
const getSelectionModelPropValue = (selectionModelProp, prevSelectionModel) => {
  if (selectionModelProp == null) {
    return selectionModelProp;
  }
  if (Array.isArray(selectionModelProp)) {
    return selectionModelProp;
  }
  if (prevSelectionModel && prevSelectionModel[0] === selectionModelProp) {
    return prevSelectionModel;
  }
  return [selectionModelProp];
};
const rowSelectionStateInitializer = (state, props) => {
  var _getSelectionModelPro;
  return _extends$1({}, state, {
    rowSelection: props.rowSelection ? (_getSelectionModelPro = getSelectionModelPropValue(props.rowSelectionModel)) != null ? _getSelectionModelPro : [] : []
  });
};
const useGridRowSelection = (apiRef2, props) => {
  const logger = useGridLogger(apiRef2, "useGridSelection");
  const runIfRowSelectionIsEnabled = (callback) => (...args) => {
    if (props.rowSelection) {
      callback(...args);
    }
  };
  const propRowSelectionModel = reactExports.useMemo(() => {
    return getSelectionModelPropValue(props.rowSelectionModel, gridRowSelectionStateSelector(apiRef2.current.state));
  }, [apiRef2, props.rowSelectionModel]);
  const lastRowToggled = reactExports.useRef(null);
  apiRef2.current.registerControlState({
    stateId: "rowSelection",
    propModel: propRowSelectionModel,
    propOnChange: props.onRowSelectionModelChange,
    stateSelector: gridRowSelectionStateSelector,
    changeEvent: "rowSelectionChange"
  });
  const {
    checkboxSelection,
    disableMultipleRowSelection,
    disableRowSelectionOnClick,
    isRowSelectable: propIsRowSelectable
  } = props;
  const canHaveMultipleSelection = !disableMultipleRowSelection || checkboxSelection;
  const visibleRows = useGridVisibleRows(apiRef2, props);
  const expandMouseRowRangeSelection = reactExports.useCallback((id) => {
    var _lastRowToggled$curre;
    let endId = id;
    const startId = (_lastRowToggled$curre = lastRowToggled.current) != null ? _lastRowToggled$curre : id;
    const isSelected = apiRef2.current.isRowSelected(id);
    if (isSelected) {
      const visibleRowIds = gridExpandedSortedRowIdsSelector(apiRef2);
      const startIndex = visibleRowIds.findIndex((rowId) => rowId === startId);
      const endIndex = visibleRowIds.findIndex((rowId) => rowId === endId);
      if (startIndex === endIndex) {
        return;
      }
      if (startIndex > endIndex) {
        endId = visibleRowIds[endIndex + 1];
      } else {
        endId = visibleRowIds[endIndex - 1];
      }
    }
    lastRowToggled.current = id;
    apiRef2.current.selectRowRange({
      startId,
      endId
    }, !isSelected);
  }, [apiRef2]);
  const setRowSelectionModel = reactExports.useCallback((model) => {
    if (props.signature === GridSignature.DataGrid && !props.checkboxSelection && Array.isArray(model) && model.length > 1) {
      throw new Error(["MUI: `rowSelectionModel` can only contain 1 item in DataGrid.", "You need to upgrade to DataGridPro or DataGridPremium component to unlock multiple selection."].join("\n"));
    }
    const currentModel = gridRowSelectionStateSelector(apiRef2.current.state);
    if (currentModel !== model) {
      logger.debug(`Setting selection model`);
      apiRef2.current.setState((state) => _extends$1({}, state, {
        rowSelection: props.rowSelection ? model : []
      }));
      apiRef2.current.forceUpdate();
    }
  }, [apiRef2, logger, props.rowSelection, props.signature, props.checkboxSelection]);
  const isRowSelected = reactExports.useCallback((id) => gridRowSelectionStateSelector(apiRef2.current.state).includes(id), [apiRef2]);
  const isRowSelectable = reactExports.useCallback((id) => {
    if (propIsRowSelectable && !propIsRowSelectable(apiRef2.current.getRowParams(id))) {
      return false;
    }
    const rowNode = apiRef2.current.getRowNode(id);
    if ((rowNode == null ? void 0 : rowNode.type) === "footer" || (rowNode == null ? void 0 : rowNode.type) === "pinnedRow") {
      return false;
    }
    return true;
  }, [apiRef2, propIsRowSelectable]);
  const getSelectedRows = reactExports.useCallback(() => selectedGridRowsSelector(apiRef2), [apiRef2]);
  const selectRow = reactExports.useCallback((id, isSelected = true, resetSelection = false) => {
    if (!apiRef2.current.isRowSelectable(id)) {
      return;
    }
    lastRowToggled.current = id;
    if (resetSelection) {
      logger.debug(`Setting selection for row ${id}`);
      apiRef2.current.setRowSelectionModel(isSelected ? [id] : []);
    } else {
      logger.debug(`Toggling selection for row ${id}`);
      const selection = gridRowSelectionStateSelector(apiRef2.current.state);
      const newSelection = selection.filter((el) => el !== id);
      if (isSelected) {
        newSelection.push(id);
      }
      const isSelectionValid = newSelection.length < 2 || canHaveMultipleSelection;
      if (isSelectionValid) {
        apiRef2.current.setRowSelectionModel(newSelection);
      }
    }
  }, [apiRef2, logger, canHaveMultipleSelection]);
  const selectRows = reactExports.useCallback((ids, isSelected = true, resetSelection = false) => {
    logger.debug(`Setting selection for several rows`);
    const selectableIds = ids.filter((id) => apiRef2.current.isRowSelectable(id));
    let newSelection;
    if (resetSelection) {
      newSelection = isSelected ? selectableIds : [];
    } else {
      const selectionLookup = _extends$1({}, selectedIdsLookupSelector(apiRef2));
      selectableIds.forEach((id) => {
        if (isSelected) {
          selectionLookup[id] = id;
        } else {
          delete selectionLookup[id];
        }
      });
      newSelection = Object.values(selectionLookup);
    }
    const isSelectionValid = newSelection.length < 2 || canHaveMultipleSelection;
    if (isSelectionValid) {
      apiRef2.current.setRowSelectionModel(newSelection);
    }
  }, [apiRef2, logger, canHaveMultipleSelection]);
  const selectRowRange = reactExports.useCallback(({
    startId,
    endId
  }, isSelected = true, resetSelection = false) => {
    if (!apiRef2.current.getRow(startId) || !apiRef2.current.getRow(endId)) {
      return;
    }
    logger.debug(`Expanding selection from row ${startId} to row ${endId}`);
    const allPagesRowIds = gridExpandedSortedRowIdsSelector(apiRef2);
    const startIndex = allPagesRowIds.indexOf(startId);
    const endIndex = allPagesRowIds.indexOf(endId);
    const [start2, end2] = startIndex > endIndex ? [endIndex, startIndex] : [startIndex, endIndex];
    const rowsBetweenStartAndEnd = allPagesRowIds.slice(start2, end2 + 1);
    apiRef2.current.selectRows(rowsBetweenStartAndEnd, isSelected, resetSelection);
  }, [apiRef2, logger]);
  const selectionPublicApi = {
    selectRow,
    setRowSelectionModel,
    getSelectedRows,
    isRowSelected,
    isRowSelectable
  };
  const selectionPrivateApi = {
    selectRows,
    selectRowRange
  };
  useGridApiMethod(apiRef2, selectionPublicApi, "public");
  useGridApiMethod(apiRef2, selectionPrivateApi, props.signature === GridSignature.DataGrid ? "private" : "public");
  const removeOutdatedSelection = reactExports.useCallback(() => {
    if (props.keepNonExistentRowsSelected) {
      return;
    }
    const currentSelection = gridRowSelectionStateSelector(apiRef2.current.state);
    const rowsLookup = gridRowsLookupSelector(apiRef2);
    const selectionLookup = _extends$1({}, selectedIdsLookupSelector(apiRef2));
    let hasChanged = false;
    currentSelection.forEach((id) => {
      if (!rowsLookup[id]) {
        delete selectionLookup[id];
        hasChanged = true;
      }
    });
    if (hasChanged) {
      apiRef2.current.setRowSelectionModel(Object.values(selectionLookup));
    }
  }, [apiRef2, props.keepNonExistentRowsSelected]);
  const handleSingleRowSelection = reactExports.useCallback((id, event) => {
    const hasCtrlKey = event.metaKey || event.ctrlKey;
    const isMultipleSelectionDisabled = !checkboxSelection && !hasCtrlKey && !isKeyboardEvent$1(event);
    const resetSelection = !canHaveMultipleSelection || isMultipleSelectionDisabled;
    const isSelected = apiRef2.current.isRowSelected(id);
    if (resetSelection) {
      apiRef2.current.selectRow(id, !isMultipleSelectionDisabled ? !isSelected : true, true);
    } else {
      apiRef2.current.selectRow(id, !isSelected, false);
    }
  }, [apiRef2, canHaveMultipleSelection, checkboxSelection]);
  const handleRowClick = reactExports.useCallback((params, event) => {
    var _closest;
    if (disableRowSelectionOnClick) {
      return;
    }
    const field = (_closest = event.target.closest(`.${gridClasses.cell}`)) == null ? void 0 : _closest.getAttribute("data-field");
    if (field === GRID_CHECKBOX_SELECTION_COL_DEF.field) {
      return;
    }
    if (field === GRID_DETAIL_PANEL_TOGGLE_FIELD) {
      return;
    }
    if (field) {
      const column = apiRef2.current.getColumn(field);
      if ((column == null ? void 0 : column.type) === GRID_ACTIONS_COLUMN_TYPE) {
        return;
      }
    }
    const rowNode = apiRef2.current.getRowNode(params.id);
    if (rowNode.type === "pinnedRow") {
      return;
    }
    if (event.shiftKey && (canHaveMultipleSelection || checkboxSelection)) {
      expandMouseRowRangeSelection(params.id);
    } else {
      handleSingleRowSelection(params.id, event);
    }
  }, [disableRowSelectionOnClick, canHaveMultipleSelection, checkboxSelection, apiRef2, expandMouseRowRangeSelection, handleSingleRowSelection]);
  const preventSelectionOnShift = reactExports.useCallback((params, event) => {
    if (canHaveMultipleSelection && event.shiftKey) {
      var _window$getSelection;
      (_window$getSelection = window.getSelection()) == null || _window$getSelection.removeAllRanges();
    }
  }, [canHaveMultipleSelection]);
  const handleRowSelectionCheckboxChange = reactExports.useCallback((params, event) => {
    if (event.nativeEvent.shiftKey) {
      expandMouseRowRangeSelection(params.id);
    } else {
      apiRef2.current.selectRow(params.id, params.value);
    }
  }, [apiRef2, expandMouseRowRangeSelection]);
  const handleHeaderSelectionCheckboxChange = reactExports.useCallback((params) => {
    const shouldLimitSelectionToCurrentPage = props.checkboxSelectionVisibleOnly && props.pagination;
    const rowsToBeSelected = shouldLimitSelectionToCurrentPage ? gridPaginatedVisibleSortedGridRowIdsSelector(apiRef2) : gridExpandedSortedRowIdsSelector(apiRef2);
    apiRef2.current.selectRows(rowsToBeSelected, params.value);
  }, [apiRef2, props.checkboxSelectionVisibleOnly, props.pagination]);
  const handleCellKeyDown = reactExports.useCallback((params, event) => {
    if (apiRef2.current.getCellMode(params.id, params.field) === GridCellModes.Edit) {
      return;
    }
    if (!event.currentTarget.contains(event.target)) {
      return;
    }
    if (isNavigationKey(event.key) && event.shiftKey) {
      const focusCell = gridFocusCellSelector(apiRef2);
      if (focusCell && focusCell.id !== params.id) {
        event.preventDefault();
        const isNextRowSelected = apiRef2.current.isRowSelected(focusCell.id);
        if (!canHaveMultipleSelection) {
          apiRef2.current.selectRow(focusCell.id, !isNextRowSelected, true);
          return;
        }
        const newRowIndex = apiRef2.current.getRowIndexRelativeToVisibleRows(focusCell.id);
        const previousRowIndex = apiRef2.current.getRowIndexRelativeToVisibleRows(params.id);
        let start2;
        let end2;
        if (newRowIndex > previousRowIndex) {
          if (isNextRowSelected) {
            start2 = previousRowIndex;
            end2 = newRowIndex - 1;
          } else {
            start2 = previousRowIndex;
            end2 = newRowIndex;
          }
        } else {
          if (isNextRowSelected) {
            start2 = newRowIndex + 1;
            end2 = previousRowIndex;
          } else {
            start2 = newRowIndex;
            end2 = previousRowIndex;
          }
        }
        const rowsBetweenStartAndEnd = visibleRows.rows.slice(start2, end2 + 1).map((row) => row.id);
        apiRef2.current.selectRows(rowsBetweenStartAndEnd, !isNextRowSelected);
        return;
      }
    }
    if (event.key === " " && event.shiftKey) {
      event.preventDefault();
      handleSingleRowSelection(params.id, event);
      return;
    }
    if (event.key === "a" && (event.ctrlKey || event.metaKey)) {
      event.preventDefault();
      selectRows(apiRef2.current.getAllRowIds(), true);
    }
  }, [apiRef2, handleSingleRowSelection, selectRows, visibleRows.rows, canHaveMultipleSelection]);
  useGridApiEventHandler(apiRef2, "sortedRowsSet", runIfRowSelectionIsEnabled(removeOutdatedSelection));
  useGridApiEventHandler(apiRef2, "rowClick", runIfRowSelectionIsEnabled(handleRowClick));
  useGridApiEventHandler(apiRef2, "rowSelectionCheckboxChange", runIfRowSelectionIsEnabled(handleRowSelectionCheckboxChange));
  useGridApiEventHandler(apiRef2, "headerSelectionCheckboxChange", handleHeaderSelectionCheckboxChange);
  useGridApiEventHandler(apiRef2, "cellMouseDown", runIfRowSelectionIsEnabled(preventSelectionOnShift));
  useGridApiEventHandler(apiRef2, "cellKeyDown", runIfRowSelectionIsEnabled(handleCellKeyDown));
  reactExports.useEffect(() => {
    if (propRowSelectionModel !== void 0) {
      apiRef2.current.setRowSelectionModel(propRowSelectionModel);
    }
  }, [apiRef2, propRowSelectionModel, props.rowSelection]);
  reactExports.useEffect(() => {
    if (!props.rowSelection) {
      apiRef2.current.setRowSelectionModel([]);
    }
  }, [apiRef2, props.rowSelection]);
  const isStateControlled = propRowSelectionModel != null;
  reactExports.useEffect(() => {
    if (isStateControlled || !props.rowSelection) {
      return;
    }
    const currentSelection = gridRowSelectionStateSelector(apiRef2.current.state);
    if (isRowSelectable) {
      const newSelection = currentSelection.filter((id) => isRowSelectable(id));
      if (newSelection.length < currentSelection.length) {
        apiRef2.current.setRowSelectionModel(newSelection);
      }
    }
  }, [apiRef2, isRowSelectable, isStateControlled, props.rowSelection]);
  reactExports.useEffect(() => {
    if (!props.rowSelection || isStateControlled) {
      return;
    }
    const currentSelection = gridRowSelectionStateSelector(apiRef2.current.state);
    if (!canHaveMultipleSelection && currentSelection.length > 1) {
      apiRef2.current.setRowSelectionModel([]);
    }
  }, [apiRef2, canHaveMultipleSelection, checkboxSelection, isStateControlled, props.rowSelection]);
};
const GRID_DEFAULT_LOCALE_TEXT = {
  // Root
  noRowsLabel: "No rows",
  noResultsOverlayLabel: "No results found.",
  // Density selector toolbar button text
  toolbarDensity: "Density",
  toolbarDensityLabel: "Density",
  toolbarDensityCompact: "Compact",
  toolbarDensityStandard: "Standard",
  toolbarDensityComfortable: "Comfortable",
  // Columns selector toolbar button text
  toolbarColumns: "Columns",
  toolbarColumnsLabel: "Select columns",
  // Filters toolbar button text
  toolbarFilters: "Filters",
  toolbarFiltersLabel: "Show filters",
  toolbarFiltersTooltipHide: "Hide filters",
  toolbarFiltersTooltipShow: "Show filters",
  toolbarFiltersTooltipActive: (count) => count !== 1 ? `${count} active filters` : `${count} active filter`,
  // Quick filter toolbar field
  toolbarQuickFilterPlaceholder: "Search…",
  toolbarQuickFilterLabel: "Search",
  toolbarQuickFilterDeleteIconLabel: "Clear",
  // Export selector toolbar button text
  toolbarExport: "Export",
  toolbarExportLabel: "Export",
  toolbarExportCSV: "Download as CSV",
  toolbarExportPrint: "Print",
  toolbarExportExcel: "Download as Excel",
  // Columns panel text
  columnsPanelTextFieldLabel: "Find column",
  columnsPanelTextFieldPlaceholder: "Column title",
  columnsPanelDragIconLabel: "Reorder column",
  columnsPanelShowAllButton: "Show all",
  columnsPanelHideAllButton: "Hide all",
  // Filter panel text
  filterPanelAddFilter: "Add filter",
  filterPanelRemoveAll: "Remove all",
  filterPanelDeleteIconLabel: "Delete",
  filterPanelLogicOperator: "Logic operator",
  filterPanelOperator: "Operator",
  filterPanelOperatorAnd: "And",
  filterPanelOperatorOr: "Or",
  filterPanelColumns: "Columns",
  filterPanelInputLabel: "Value",
  filterPanelInputPlaceholder: "Filter value",
  // Filter operators text
  filterOperatorContains: "contains",
  filterOperatorEquals: "equals",
  filterOperatorStartsWith: "starts with",
  filterOperatorEndsWith: "ends with",
  filterOperatorIs: "is",
  filterOperatorNot: "is not",
  filterOperatorAfter: "is after",
  filterOperatorOnOrAfter: "is on or after",
  filterOperatorBefore: "is before",
  filterOperatorOnOrBefore: "is on or before",
  filterOperatorIsEmpty: "is empty",
  filterOperatorIsNotEmpty: "is not empty",
  filterOperatorIsAnyOf: "is any of",
  "filterOperator=": "=",
  "filterOperator!=": "!=",
  "filterOperator>": ">",
  "filterOperator>=": ">=",
  "filterOperator<": "<",
  "filterOperator<=": "<=",
  // Header filter operators text
  headerFilterOperatorContains: "Contains",
  headerFilterOperatorEquals: "Equals",
  headerFilterOperatorStartsWith: "Starts with",
  headerFilterOperatorEndsWith: "Ends with",
  headerFilterOperatorIs: "Is",
  headerFilterOperatorNot: "Is not",
  headerFilterOperatorAfter: "Is after",
  headerFilterOperatorOnOrAfter: "Is on or after",
  headerFilterOperatorBefore: "Is before",
  headerFilterOperatorOnOrBefore: "Is on or before",
  headerFilterOperatorIsEmpty: "Is empty",
  headerFilterOperatorIsNotEmpty: "Is not empty",
  headerFilterOperatorIsAnyOf: "Is any of",
  "headerFilterOperator=": "Equals",
  "headerFilterOperator!=": "Not equals",
  "headerFilterOperator>": "Greater than",
  "headerFilterOperator>=": "Greater than or equal to",
  "headerFilterOperator<": "Less than",
  "headerFilterOperator<=": "Less than or equal to",
  // Filter values text
  filterValueAny: "any",
  filterValueTrue: "true",
  filterValueFalse: "false",
  // Column menu text
  columnMenuLabel: "Menu",
  columnMenuShowColumns: "Show columns",
  columnMenuManageColumns: "Manage columns",
  columnMenuFilter: "Filter",
  columnMenuHideColumn: "Hide column",
  columnMenuUnsort: "Unsort",
  columnMenuSortAsc: "Sort by ASC",
  columnMenuSortDesc: "Sort by DESC",
  // Column header text
  columnHeaderFiltersTooltipActive: (count) => count !== 1 ? `${count} active filters` : `${count} active filter`,
  columnHeaderFiltersLabel: "Show filters",
  columnHeaderSortIconLabel: "Sort",
  // Rows selected footer text
  footerRowSelected: (count) => count !== 1 ? `${count.toLocaleString()} rows selected` : `${count.toLocaleString()} row selected`,
  // Total row amount footer text
  footerTotalRows: "Total Rows:",
  // Total visible row amount footer text
  footerTotalVisibleRows: (visibleCount, totalCount) => `${visibleCount.toLocaleString()} of ${totalCount.toLocaleString()}`,
  // Checkbox selection text
  checkboxSelectionHeaderName: "Checkbox selection",
  checkboxSelectionSelectAllRows: "Select all rows",
  checkboxSelectionUnselectAllRows: "Unselect all rows",
  checkboxSelectionSelectRow: "Select row",
  checkboxSelectionUnselectRow: "Unselect row",
  // Boolean cell text
  booleanCellTrueLabel: "yes",
  booleanCellFalseLabel: "no",
  // Actions cell more text
  actionsCellMore: "more",
  // Column pinning text
  pinToLeft: "Pin to left",
  pinToRight: "Pin to right",
  unpin: "Unpin",
  // Tree Data
  treeDataGroupingHeaderName: "Group",
  treeDataExpand: "see children",
  treeDataCollapse: "hide children",
  // Grouping columns
  groupingColumnHeaderName: "Group",
  groupColumn: (name) => `Group by ${name}`,
  unGroupColumn: (name) => `Stop grouping by ${name}`,
  // Master/detail
  detailPanelToggle: "Detail panel toggle",
  expandDetailPanel: "Expand",
  collapseDetailPanel: "Collapse",
  // Used core components translation keys
  MuiTablePagination: {},
  // Row reordering text
  rowReorderingHeaderName: "Row reordering",
  // Aggregation
  aggregationMenuItemHeader: "Aggregation",
  aggregationFunctionLabelSum: "sum",
  aggregationFunctionLabelAvg: "avg",
  aggregationFunctionLabelMin: "min",
  aggregationFunctionLabelMax: "max",
  aggregationFunctionLabelSize: "size"
};
const useUtilityClasses$a = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  return reactExports.useMemo(() => {
    const slots = {
      cellCheckbox: ["cellCheckbox"],
      columnHeaderCheckbox: ["columnHeaderCheckbox"]
    };
    return composeClasses(slots, getDataGridUtilityClass, classes2);
  }, [classes2]);
};
const useGridRowSelectionPreProcessors = (apiRef2, props) => {
  const ownerState = {
    classes: props.classes
  };
  const classes2 = useUtilityClasses$a(ownerState);
  const updateSelectionColumn = reactExports.useCallback((columnsState) => {
    const selectionColumn = _extends$1({}, GRID_CHECKBOX_SELECTION_COL_DEF, {
      cellClassName: classes2.cellCheckbox,
      headerClassName: classes2.columnHeaderCheckbox,
      headerName: apiRef2.current.getLocaleText("checkboxSelectionHeaderName")
    });
    const shouldHaveSelectionColumn = props.checkboxSelection;
    const haveSelectionColumn = columnsState.lookup[GRID_CHECKBOX_SELECTION_FIELD] != null;
    if (shouldHaveSelectionColumn && !haveSelectionColumn) {
      columnsState.lookup[GRID_CHECKBOX_SELECTION_FIELD] = selectionColumn;
      columnsState.orderedFields = [GRID_CHECKBOX_SELECTION_FIELD, ...columnsState.orderedFields];
    } else if (!shouldHaveSelectionColumn && haveSelectionColumn) {
      delete columnsState.lookup[GRID_CHECKBOX_SELECTION_FIELD];
      columnsState.orderedFields = columnsState.orderedFields.filter((field) => field !== GRID_CHECKBOX_SELECTION_FIELD);
    } else if (shouldHaveSelectionColumn && haveSelectionColumn) {
      columnsState.lookup[GRID_CHECKBOX_SELECTION_FIELD] = _extends$1({}, selectionColumn, columnsState.lookup[GRID_CHECKBOX_SELECTION_FIELD]);
    }
    return columnsState;
  }, [apiRef2, classes2, props.checkboxSelection]);
  useGridRegisterPipeProcessor(apiRef2, "hydrateColumns", updateSelectionColumn);
};
const sortingStateInitializer = (state, props) => {
  var _ref, _props$sortModel, _props$initialState;
  const sortModel = (_ref = (_props$sortModel = props.sortModel) != null ? _props$sortModel : (_props$initialState = props.initialState) == null || (_props$initialState = _props$initialState.sorting) == null ? void 0 : _props$initialState.sortModel) != null ? _ref : [];
  return _extends$1({}, state, {
    sorting: {
      sortModel: sanitizeSortModel(sortModel, props.disableMultipleColumnsSorting),
      sortedRows: []
    }
  });
};
const useGridSorting = (apiRef2, props) => {
  var _props$initialState3;
  const logger = useGridLogger(apiRef2, "useGridSorting");
  apiRef2.current.registerControlState({
    stateId: "sortModel",
    propModel: props.sortModel,
    propOnChange: props.onSortModelChange,
    stateSelector: gridSortModelSelector,
    changeEvent: "sortModelChange"
  });
  const upsertSortModel = reactExports.useCallback((field, sortItem) => {
    const sortModel = gridSortModelSelector(apiRef2);
    const existingIdx = sortModel.findIndex((c2) => c2.field === field);
    let newSortModel = [...sortModel];
    if (existingIdx > -1) {
      if (!sortItem) {
        newSortModel.splice(existingIdx, 1);
      } else {
        newSortModel.splice(existingIdx, 1, sortItem);
      }
    } else {
      newSortModel = [...sortModel, sortItem];
    }
    return newSortModel;
  }, [apiRef2]);
  const createSortItem = reactExports.useCallback((col, directionOverride) => {
    var _col$sortingOrder2;
    const sortModel = gridSortModelSelector(apiRef2);
    const existing = sortModel.find((c2) => c2.field === col.field);
    if (existing) {
      var _col$sortingOrder;
      const nextSort = directionOverride === void 0 ? getNextGridSortDirection((_col$sortingOrder = col.sortingOrder) != null ? _col$sortingOrder : props.sortingOrder, existing.sort) : directionOverride;
      return nextSort == null ? void 0 : _extends$1({}, existing, {
        sort: nextSort
      });
    }
    return {
      field: col.field,
      sort: directionOverride === void 0 ? getNextGridSortDirection((_col$sortingOrder2 = col.sortingOrder) != null ? _col$sortingOrder2 : props.sortingOrder) : directionOverride
    };
  }, [apiRef2, props.sortingOrder]);
  const addColumnMenuItem = reactExports.useCallback((columnMenuItems, colDef) => {
    if (colDef == null || colDef.sortable === false) {
      return columnMenuItems;
    }
    const sortingOrder = colDef.sortingOrder || props.sortingOrder;
    if (sortingOrder.some((item) => !!item)) {
      return [...columnMenuItems, "columnMenuSortItem"];
    }
    return columnMenuItems;
  }, [props.sortingOrder]);
  const applySorting = reactExports.useCallback(() => {
    apiRef2.current.setState((state) => {
      if (props.sortingMode === "server") {
        logger.debug("Skipping sorting rows as sortingMode = server");
        return _extends$1({}, state, {
          sorting: _extends$1({}, state.sorting, {
            sortedRows: getTreeNodeDescendants(gridRowTreeSelector(apiRef2), GRID_ROOT_GROUP_ID, false)
          })
        });
      }
      const sortModel = gridSortModelSelector(state, apiRef2.current.instanceId);
      const sortRowList = buildAggregatedSortingApplier(sortModel, apiRef2);
      const sortedRows = apiRef2.current.applyStrategyProcessor("sorting", {
        sortRowList
      });
      return _extends$1({}, state, {
        sorting: _extends$1({}, state.sorting, {
          sortedRows
        })
      });
    });
    apiRef2.current.publishEvent("sortedRowsSet");
    apiRef2.current.forceUpdate();
  }, [apiRef2, logger, props.sortingMode]);
  const setSortModel = reactExports.useCallback((model) => {
    const currentModel = gridSortModelSelector(apiRef2);
    if (currentModel !== model) {
      logger.debug(`Setting sort model`);
      apiRef2.current.setState(mergeStateWithSortModel(model, props.disableMultipleColumnsSorting));
      apiRef2.current.forceUpdate();
      apiRef2.current.applySorting();
    }
  }, [apiRef2, logger, props.disableMultipleColumnsSorting]);
  const sortColumn = reactExports.useCallback((column, direction2, allowMultipleSorting) => {
    if (!column.sortable) {
      return;
    }
    const sortItem = createSortItem(column, direction2);
    let sortModel;
    if (!allowMultipleSorting || props.disableMultipleColumnsSorting) {
      sortModel = !sortItem ? [] : [sortItem];
    } else {
      sortModel = upsertSortModel(column.field, sortItem);
    }
    apiRef2.current.setSortModel(sortModel);
  }, [apiRef2, upsertSortModel, createSortItem, props.disableMultipleColumnsSorting]);
  const getSortModel = reactExports.useCallback(() => gridSortModelSelector(apiRef2), [apiRef2]);
  const getSortedRows = reactExports.useCallback(() => {
    const sortedRows = gridSortedRowEntriesSelector(apiRef2);
    return sortedRows.map((row) => row.model);
  }, [apiRef2]);
  const getSortedRowIds = reactExports.useCallback(() => gridSortedRowIdsSelector(apiRef2), [apiRef2]);
  const getRowIdFromRowIndex = reactExports.useCallback((index) => apiRef2.current.getSortedRowIds()[index], [apiRef2]);
  const sortApi = {
    getSortModel,
    getSortedRows,
    getSortedRowIds,
    getRowIdFromRowIndex,
    setSortModel,
    sortColumn,
    applySorting
  };
  useGridApiMethod(apiRef2, sortApi, "public");
  const stateExportPreProcessing = reactExports.useCallback((prevState, context) => {
    var _props$initialState2;
    const sortModelToExport = gridSortModelSelector(apiRef2);
    const shouldExportSortModel = (
      // Always export if the `exportOnlyDirtyModels` property is not activated
      !context.exportOnlyDirtyModels || // Always export if the model is controlled
      props.sortModel != null || // Always export if the model has been initialized
      ((_props$initialState2 = props.initialState) == null || (_props$initialState2 = _props$initialState2.sorting) == null ? void 0 : _props$initialState2.sortModel) != null || // Export if the model is not empty
      sortModelToExport.length > 0
    );
    if (!shouldExportSortModel) {
      return prevState;
    }
    return _extends$1({}, prevState, {
      sorting: {
        sortModel: sortModelToExport
      }
    });
  }, [apiRef2, props.sortModel, (_props$initialState3 = props.initialState) == null || (_props$initialState3 = _props$initialState3.sorting) == null ? void 0 : _props$initialState3.sortModel]);
  const stateRestorePreProcessing = reactExports.useCallback((params, context) => {
    var _context$stateToResto;
    const sortModel = (_context$stateToResto = context.stateToRestore.sorting) == null ? void 0 : _context$stateToResto.sortModel;
    if (sortModel == null) {
      return params;
    }
    apiRef2.current.setState(mergeStateWithSortModel(sortModel, props.disableMultipleColumnsSorting));
    return _extends$1({}, params, {
      callbacks: [...params.callbacks, apiRef2.current.applySorting]
    });
  }, [apiRef2, props.disableMultipleColumnsSorting]);
  const flatSortingMethod = reactExports.useCallback((params) => {
    const rowTree = gridRowTreeSelector(apiRef2);
    const rootGroupNode = rowTree[GRID_ROOT_GROUP_ID];
    const sortedChildren = params.sortRowList ? params.sortRowList(rootGroupNode.children.map((childId) => rowTree[childId])) : [...rootGroupNode.children];
    if (rootGroupNode.footerId != null) {
      sortedChildren.push(rootGroupNode.footerId);
    }
    return sortedChildren;
  }, [apiRef2]);
  useGridRegisterPipeProcessor(apiRef2, "exportState", stateExportPreProcessing);
  useGridRegisterPipeProcessor(apiRef2, "restoreState", stateRestorePreProcessing);
  useGridRegisterStrategyProcessor(apiRef2, GRID_DEFAULT_STRATEGY, "sorting", flatSortingMethod);
  const handleColumnHeaderClick = reactExports.useCallback(({
    colDef
  }, event) => {
    const allowMultipleSorting = event.shiftKey || event.metaKey || event.ctrlKey;
    sortColumn(colDef, void 0, allowMultipleSorting);
  }, [sortColumn]);
  const handleColumnHeaderKeyDown = reactExports.useCallback(({
    colDef
  }, event) => {
    if (isEnterKey(event.key) && !event.ctrlKey && !event.metaKey) {
      sortColumn(colDef, void 0, event.shiftKey);
    }
  }, [sortColumn]);
  const handleColumnsChange = reactExports.useCallback(() => {
    const sortModel = gridSortModelSelector(apiRef2);
    const latestColumns = gridColumnLookupSelector(apiRef2);
    if (sortModel.length > 0) {
      const newModel = sortModel.filter((sortItem) => latestColumns[sortItem.field]);
      if (newModel.length < sortModel.length) {
        apiRef2.current.setSortModel(newModel);
      }
    }
  }, [apiRef2]);
  const handleStrategyProcessorChange = reactExports.useCallback((methodName) => {
    if (methodName === "sorting") {
      apiRef2.current.applySorting();
    }
  }, [apiRef2]);
  useGridRegisterPipeProcessor(apiRef2, "columnMenu", addColumnMenuItem);
  useGridApiEventHandler(apiRef2, "columnHeaderClick", handleColumnHeaderClick);
  useGridApiEventHandler(apiRef2, "columnHeaderKeyDown", handleColumnHeaderKeyDown);
  useGridApiEventHandler(apiRef2, "rowsSet", apiRef2.current.applySorting);
  useGridApiEventHandler(apiRef2, "columnsChange", handleColumnsChange);
  useGridApiEventHandler(apiRef2, "activeStrategyProcessorChange", handleStrategyProcessorChange);
  useFirstRender(() => {
    apiRef2.current.applySorting();
  });
  useEnhancedEffect$1(() => {
    if (props.sortModel !== void 0) {
      apiRef2.current.setSortModel(props.sortModel);
    }
  }, [apiRef2, props.sortModel]);
};
function scrollIntoView(dimensions) {
  const {
    clientHeight,
    scrollTop,
    offsetHeight,
    offsetTop
  } = dimensions;
  const elementBottom = offsetTop + offsetHeight;
  if (offsetHeight > clientHeight) {
    return offsetTop;
  }
  if (elementBottom - clientHeight > scrollTop) {
    return elementBottom - clientHeight;
  }
  if (offsetTop < scrollTop) {
    return offsetTop;
  }
  return void 0;
}
const useGridScroll = (apiRef2, props) => {
  const theme = useTheme$1();
  const logger = useGridLogger(apiRef2, "useGridScroll");
  const colRef = apiRef2.current.columnHeadersElementRef;
  const virtualScrollerRef = apiRef2.current.virtualScrollerRef;
  const visibleSortedRows = useGridSelector(apiRef2, gridExpandedSortedRowEntriesSelector);
  const scrollToIndexes = reactExports.useCallback((params) => {
    const totalRowCount = gridRowCountSelector(apiRef2);
    const visibleColumns = gridVisibleColumnDefinitionsSelector(apiRef2);
    const scrollToHeader = params.rowIndex == null;
    if (!scrollToHeader && totalRowCount === 0 || visibleColumns.length === 0) {
      return false;
    }
    logger.debug(`Scrolling to cell at row ${params.rowIndex}, col: ${params.colIndex} `);
    let scrollCoordinates = {};
    if (params.colIndex != null) {
      const columnPositions = gridColumnPositionsSelector(apiRef2);
      let cellWidth;
      if (typeof params.rowIndex !== "undefined") {
        var _visibleSortedRows$pa;
        const rowId = (_visibleSortedRows$pa = visibleSortedRows[params.rowIndex]) == null ? void 0 : _visibleSortedRows$pa.id;
        const cellColSpanInfo = apiRef2.current.unstable_getCellColSpanInfo(rowId, params.colIndex);
        if (cellColSpanInfo && !cellColSpanInfo.spannedByColSpan) {
          cellWidth = cellColSpanInfo.cellProps.width;
        }
      }
      if (typeof cellWidth === "undefined") {
        cellWidth = visibleColumns[params.colIndex].computedWidth;
      }
      scrollCoordinates.left = scrollIntoView({
        clientHeight: virtualScrollerRef.current.clientWidth,
        scrollTop: Math.abs(virtualScrollerRef.current.scrollLeft),
        offsetHeight: cellWidth,
        offsetTop: columnPositions[params.colIndex]
      });
    }
    if (params.rowIndex != null) {
      var _querySelector, _querySelector2;
      const rowsMeta = gridRowsMetaSelector(apiRef2.current.state);
      const page = gridPageSelector(apiRef2);
      const pageSize2 = gridPageSizeSelector(apiRef2);
      const elementIndex = !props.pagination ? params.rowIndex : params.rowIndex - page * pageSize2;
      const targetOffsetHeight = rowsMeta.positions[elementIndex + 1] ? rowsMeta.positions[elementIndex + 1] - rowsMeta.positions[elementIndex] : rowsMeta.currentPageTotalHeight - rowsMeta.positions[elementIndex];
      const topPinnedRowsHeight = ((_querySelector = virtualScrollerRef.current.querySelector(`.${gridClasses["pinnedRows--top"]}`)) == null ? void 0 : _querySelector.clientHeight) || 0;
      const bottomPinnedRowsHeight = ((_querySelector2 = virtualScrollerRef.current.querySelector(`.${gridClasses["pinnedRows--bottom"]}`)) == null ? void 0 : _querySelector2.clientHeight) || 0;
      scrollCoordinates.top = scrollIntoView({
        clientHeight: virtualScrollerRef.current.clientHeight - topPinnedRowsHeight - bottomPinnedRowsHeight,
        scrollTop: virtualScrollerRef.current.scrollTop,
        offsetHeight: targetOffsetHeight,
        offsetTop: rowsMeta.positions[elementIndex]
      });
    }
    scrollCoordinates = apiRef2.current.unstable_applyPipeProcessors("scrollToIndexes", scrollCoordinates, params);
    if (typeof scrollCoordinates.left !== void 0 || typeof scrollCoordinates.top !== void 0) {
      apiRef2.current.scroll(scrollCoordinates);
      return true;
    }
    return false;
  }, [logger, apiRef2, virtualScrollerRef, props.pagination, visibleSortedRows]);
  const scroll = reactExports.useCallback((params) => {
    if (virtualScrollerRef.current && params.left != null && colRef.current) {
      const direction2 = theme.direction === "rtl" ? -1 : 1;
      colRef.current.scrollLeft = params.left;
      virtualScrollerRef.current.scrollLeft = direction2 * params.left;
      logger.debug(`Scrolling left: ${params.left}`);
    }
    if (virtualScrollerRef.current && params.top != null) {
      virtualScrollerRef.current.scrollTop = params.top;
      logger.debug(`Scrolling top: ${params.top}`);
    }
    logger.debug(`Scrolling, updating container, and viewport`);
  }, [virtualScrollerRef, theme.direction, colRef, logger]);
  const getScrollPosition = reactExports.useCallback(() => {
    if (!(virtualScrollerRef != null && virtualScrollerRef.current)) {
      return {
        top: 0,
        left: 0
      };
    }
    return {
      top: virtualScrollerRef.current.scrollTop,
      left: virtualScrollerRef.current.scrollLeft
    };
  }, [virtualScrollerRef]);
  const scrollApi = {
    scroll,
    scrollToIndexes,
    getScrollPosition
  };
  useGridApiMethod(apiRef2, scrollApi, "public");
};
function useGridEvents(apiRef2, props) {
  useGridApiOptionHandler(apiRef2, "columnHeaderClick", props.onColumnHeaderClick);
  useGridApiOptionHandler(apiRef2, "columnHeaderDoubleClick", props.onColumnHeaderDoubleClick);
  useGridApiOptionHandler(apiRef2, "columnHeaderOver", props.onColumnHeaderOver);
  useGridApiOptionHandler(apiRef2, "columnHeaderOut", props.onColumnHeaderOut);
  useGridApiOptionHandler(apiRef2, "columnHeaderEnter", props.onColumnHeaderEnter);
  useGridApiOptionHandler(apiRef2, "columnHeaderLeave", props.onColumnHeaderLeave);
  useGridApiOptionHandler(apiRef2, "cellClick", props.onCellClick);
  useGridApiOptionHandler(apiRef2, "cellDoubleClick", props.onCellDoubleClick);
  useGridApiOptionHandler(apiRef2, "cellKeyDown", props.onCellKeyDown);
  useGridApiOptionHandler(apiRef2, "preferencePanelClose", props.onPreferencePanelClose);
  useGridApiOptionHandler(apiRef2, "preferencePanelOpen", props.onPreferencePanelOpen);
  useGridApiOptionHandler(apiRef2, "menuOpen", props.onMenuOpen);
  useGridApiOptionHandler(apiRef2, "menuClose", props.onMenuClose);
  useGridApiOptionHandler(apiRef2, "rowDoubleClick", props.onRowDoubleClick);
  useGridApiOptionHandler(apiRef2, "rowClick", props.onRowClick);
  useGridApiOptionHandler(apiRef2, "stateChange", props.onStateChange);
}
const hasScroll = ({
  content,
  container,
  scrollBarSize
}) => {
  const hasScrollXIfNoYScrollBar = content.width > container.width;
  const hasScrollYIfNoXScrollBar = content.height > container.height;
  let hasScrollX = false;
  let hasScrollY = false;
  if (hasScrollXIfNoYScrollBar || hasScrollYIfNoXScrollBar) {
    hasScrollX = hasScrollXIfNoYScrollBar;
    hasScrollY = content.height + (hasScrollX ? scrollBarSize : 0) > container.height;
    if (hasScrollY) {
      hasScrollX = content.width + scrollBarSize > container.width;
    }
  }
  return {
    hasScrollX,
    hasScrollY
  };
};
function useGridDimensions(apiRef2, props) {
  const logger = useGridLogger(apiRef2, "useResizeContainer");
  const errorShown = reactExports.useRef(false);
  const rootDimensionsRef = reactExports.useRef(null);
  const fullDimensionsRef = reactExports.useRef(null);
  const rowsMeta = useGridSelector(apiRef2, gridRowsMetaSelector);
  const densityFactor = useGridSelector(apiRef2, gridDensityFactorSelector);
  const rowHeight = Math.floor(props.rowHeight * densityFactor);
  const totalHeaderHeight = getTotalHeaderHeight(apiRef2, props.columnHeaderHeight);
  const updateGridDimensionsRef = reactExports.useCallback(() => {
    var _apiRef$current$rootE;
    const rootElement = (_apiRef$current$rootE = apiRef2.current.rootElementRef) == null ? void 0 : _apiRef$current$rootE.current;
    const columnsTotalWidth = gridColumnsTotalWidthSelector(apiRef2);
    const pinnedRowsHeight = calculatePinnedRowsHeight(apiRef2);
    if (!rootDimensionsRef.current) {
      return;
    }
    let scrollBarSize;
    if (props.scrollbarSize != null) {
      scrollBarSize = props.scrollbarSize;
    } else if (!columnsTotalWidth || !rootElement) {
      scrollBarSize = 0;
    } else {
      const doc = ownerDocument$1(rootElement);
      const scrollDiv = doc.createElement("div");
      scrollDiv.style.width = "99px";
      scrollDiv.style.height = "99px";
      scrollDiv.style.position = "absolute";
      scrollDiv.style.overflow = "scroll";
      scrollDiv.className = "scrollDiv";
      rootElement.appendChild(scrollDiv);
      scrollBarSize = scrollDiv.offsetWidth - scrollDiv.clientWidth;
      rootElement.removeChild(scrollDiv);
    }
    let viewportOuterSize;
    let hasScrollX;
    let hasScrollY;
    if (props.autoHeight) {
      hasScrollY = false;
      hasScrollX = Math.round(columnsTotalWidth) > Math.round(rootDimensionsRef.current.width);
      viewportOuterSize = {
        width: rootDimensionsRef.current.width,
        height: rowsMeta.currentPageTotalHeight + (hasScrollX ? scrollBarSize : 0)
      };
    } else {
      viewportOuterSize = {
        width: rootDimensionsRef.current.width,
        height: Math.max(rootDimensionsRef.current.height - totalHeaderHeight, 0)
      };
      const scrollInformation = hasScroll({
        content: {
          width: Math.round(columnsTotalWidth),
          height: rowsMeta.currentPageTotalHeight
        },
        container: {
          width: Math.round(viewportOuterSize.width),
          height: viewportOuterSize.height - pinnedRowsHeight.top - pinnedRowsHeight.bottom
        },
        scrollBarSize
      });
      hasScrollY = scrollInformation.hasScrollY;
      hasScrollX = scrollInformation.hasScrollX;
    }
    const viewportInnerSize = {
      width: viewportOuterSize.width - (hasScrollY ? scrollBarSize : 0),
      height: viewportOuterSize.height - (hasScrollX ? scrollBarSize : 0)
    };
    const newFullDimensions = {
      viewportOuterSize,
      viewportInnerSize,
      hasScrollX,
      hasScrollY,
      scrollBarSize
    };
    const prevDimensions = fullDimensionsRef.current;
    fullDimensionsRef.current = newFullDimensions;
    if (newFullDimensions.viewportInnerSize.width !== (prevDimensions == null ? void 0 : prevDimensions.viewportInnerSize.width) || newFullDimensions.viewportInnerSize.height !== (prevDimensions == null ? void 0 : prevDimensions.viewportInnerSize.height)) {
      apiRef2.current.publishEvent("viewportInnerSizeChange", newFullDimensions.viewportInnerSize);
    }
  }, [apiRef2, props.scrollbarSize, props.autoHeight, rowsMeta.currentPageTotalHeight, totalHeaderHeight]);
  const [savedSize, setSavedSize] = reactExports.useState();
  const debouncedSetSavedSize = reactExports.useMemo(() => debounce$2(setSavedSize, 60), []);
  const previousSize = reactExports.useRef();
  useEnhancedEffect$1(() => {
    if (savedSize) {
      updateGridDimensionsRef();
      apiRef2.current.publishEvent("debouncedResize", rootDimensionsRef.current);
    }
  }, [apiRef2, savedSize, updateGridDimensionsRef]);
  const resize = reactExports.useCallback(() => {
    apiRef2.current.computeSizeAndPublishResizeEvent();
  }, [apiRef2]);
  const getRootDimensions = reactExports.useCallback(() => fullDimensionsRef.current, []);
  const getViewportPageSize = reactExports.useCallback(() => {
    const dimensions = apiRef2.current.getRootDimensions();
    if (!dimensions) {
      return 0;
    }
    const currentPage = getVisibleRows(apiRef2, {
      pagination: props.pagination,
      paginationMode: props.paginationMode
    });
    if (props.getRowHeight) {
      const renderContext = apiRef2.current.getRenderContext();
      const viewportPageSize = renderContext.lastRowIndex - renderContext.firstRowIndex;
      return Math.min(viewportPageSize - 1, currentPage.rows.length);
    }
    const maximumPageSizeWithoutScrollBar = Math.floor(dimensions.viewportInnerSize.height / rowHeight);
    return Math.min(maximumPageSizeWithoutScrollBar, currentPage.rows.length);
  }, [apiRef2, props.pagination, props.paginationMode, props.getRowHeight, rowHeight]);
  const computeSizeAndPublishResizeEvent = reactExports.useCallback(() => {
    var _apiRef$current$mainE, _previousSize$current, _previousSize$current2;
    const mainEl = (_apiRef$current$mainE = apiRef2.current.mainElementRef) == null ? void 0 : _apiRef$current$mainE.current;
    if (!mainEl) {
      return;
    }
    const win = ownerWindow$1(mainEl);
    const computedStyle = win.getComputedStyle(mainEl);
    const height = parseFloat(computedStyle.height) || 0;
    const width = parseFloat(computedStyle.width) || 0;
    const hasHeightChanged = height !== ((_previousSize$current = previousSize.current) == null ? void 0 : _previousSize$current.height);
    const hasWidthChanged = width !== ((_previousSize$current2 = previousSize.current) == null ? void 0 : _previousSize$current2.width);
    if (!previousSize.current || hasHeightChanged || hasWidthChanged) {
      const size = {
        width,
        height
      };
      apiRef2.current.publishEvent("resize", size);
      previousSize.current = size;
    }
  }, [apiRef2]);
  const dimensionsApi = {
    resize,
    getRootDimensions
  };
  const dimensionsPrivateApi = {
    getViewportPageSize,
    updateGridDimensionsRef,
    computeSizeAndPublishResizeEvent
  };
  useGridApiMethod(apiRef2, dimensionsApi, "public");
  useGridApiMethod(apiRef2, dimensionsPrivateApi, "private");
  const isFirstSizing = reactExports.useRef(true);
  const handleResize = reactExports.useCallback((size) => {
    rootDimensionsRef.current = size;
    const isJSDOM = /jsdom/.test(window.navigator.userAgent);
    if (size.height === 0 && !errorShown.current && !props.autoHeight && !isJSDOM) {
      logger.error(["The parent DOM element of the data grid has an empty height.", "Please make sure that this element has an intrinsic height.", "The grid displays with a height of 0px.", "", "More details: https://mui.com/r/x-data-grid-no-dimensions."].join("\n"));
      errorShown.current = true;
    }
    if (size.width === 0 && !errorShown.current && !isJSDOM) {
      logger.error(["The parent DOM element of the data grid has an empty width.", "Please make sure that this element has an intrinsic width.", "The grid displays with a width of 0px.", "", "More details: https://mui.com/r/x-data-grid-no-dimensions."].join("\n"));
      errorShown.current = true;
    }
    if (isFirstSizing.current) {
      setSavedSize(size);
      isFirstSizing.current = false;
      return;
    }
    debouncedSetSavedSize(size);
  }, [props.autoHeight, debouncedSetSavedSize, logger]);
  useEnhancedEffect$1(() => updateGridDimensionsRef(), [updateGridDimensionsRef]);
  useGridApiOptionHandler(apiRef2, "sortedRowsSet", updateGridDimensionsRef);
  useGridApiOptionHandler(apiRef2, "paginationModelChange", updateGridDimensionsRef);
  useGridApiOptionHandler(apiRef2, "columnsChange", updateGridDimensionsRef);
  useGridApiEventHandler(apiRef2, "resize", handleResize);
  useGridApiOptionHandler(apiRef2, "debouncedResize", props.onResize);
}
const _excluded$d = ["style"], _excluded2 = ["style"];
function binarySearch(offset2, positions, sliceStart = 0, sliceEnd = positions.length) {
  if (positions.length <= 0) {
    return -1;
  }
  if (sliceStart >= sliceEnd) {
    return sliceStart;
  }
  const pivot = sliceStart + Math.floor((sliceEnd - sliceStart) / 2);
  const itemOffset = positions[pivot];
  return offset2 <= itemOffset ? binarySearch(offset2, positions, sliceStart, pivot) : binarySearch(offset2, positions, pivot + 1, sliceEnd);
}
function exponentialSearch(offset2, positions, index) {
  let interval = 1;
  while (index < positions.length && Math.abs(positions[index]) < offset2) {
    index += interval;
    interval *= 2;
  }
  return binarySearch(offset2, positions, Math.floor(index / 2), Math.min(index, positions.length));
}
const getRenderableIndexes = ({
  firstIndex,
  lastIndex,
  buffer,
  minFirstIndex,
  maxLastIndex
}) => {
  return [clamp(firstIndex - buffer, minFirstIndex, maxLastIndex), clamp(lastIndex + buffer, minFirstIndex, maxLastIndex)];
};
const areRenderContextsEqual = (context1, context2) => {
  if (context1 === context2) {
    return true;
  }
  return context1.firstRowIndex === context2.firstRowIndex && context1.lastRowIndex === context2.lastRowIndex && context1.firstColumnIndex === context2.firstColumnIndex && context1.lastColumnIndex === context2.lastColumnIndex;
};
const MEMOIZE_OPTIONS = {
  maxSize: 3
};
const useGridVirtualScroller = (props) => {
  var _currentPage$range3, _currentPage$range4;
  const apiRef2 = useGridPrivateApiContext();
  const rootProps = useGridRootProps();
  const visibleColumns = useGridSelector(apiRef2, gridVisibleColumnDefinitionsSelector);
  const {
    ref,
    disableVirtualization,
    onRenderZonePositioning,
    renderZoneMinColumnIndex = 0,
    renderZoneMaxColumnIndex = visibleColumns.length,
    getRowProps
  } = props;
  const theme = useTheme$1();
  const columnPositions = useGridSelector(apiRef2, gridColumnPositionsSelector);
  const columnsTotalWidth = useGridSelector(apiRef2, gridColumnsTotalWidthSelector);
  const cellFocus = useGridSelector(apiRef2, gridFocusCellSelector);
  const cellTabIndex = useGridSelector(apiRef2, gridTabIndexCellSelector);
  const rowsMeta = useGridSelector(apiRef2, gridRowsMetaSelector);
  const selectedRowsLookup = useGridSelector(apiRef2, selectedIdsLookupSelector);
  const currentPage = useGridVisibleRows(apiRef2, rootProps);
  const renderZoneRef = reactExports.useRef(null);
  const rootRef = reactExports.useRef(null);
  const handleRef = useForkRef$1(ref, rootRef);
  const [renderContext, setRenderContext] = reactExports.useState(null);
  const prevRenderContext = reactExports.useRef(renderContext);
  const scrollPosition = reactExports.useRef({
    top: 0,
    left: 0
  });
  const [containerDimensions, setContainerDimensions] = reactExports.useState({
    width: null,
    height: null
  });
  const prevTotalWidth = reactExports.useRef(columnsTotalWidth);
  const rowStyleCache = reactExports.useRef(/* @__PURE__ */ Object.create(null));
  const prevGetRowProps = reactExports.useRef();
  const prevRootRowStyle = reactExports.useRef();
  const getRenderedColumnsRef = reactExports.useRef(defaultMemoize((columns, firstColumnToRender, lastColumnToRender, minFirstColumn, maxLastColumn, indexOfColumnWithFocusedCell2) => {
    let focusedCellColumnIndexNotInRange;
    const renderedColumns = columns.slice(firstColumnToRender, lastColumnToRender);
    if (indexOfColumnWithFocusedCell2 > -1) {
      if (firstColumnToRender > indexOfColumnWithFocusedCell2 && indexOfColumnWithFocusedCell2 >= minFirstColumn) {
        focusedCellColumnIndexNotInRange = indexOfColumnWithFocusedCell2;
      } else if (lastColumnToRender < indexOfColumnWithFocusedCell2 && indexOfColumnWithFocusedCell2 < maxLastColumn) {
        focusedCellColumnIndexNotInRange = indexOfColumnWithFocusedCell2;
      }
    }
    return {
      focusedCellColumnIndexNotInRange,
      renderedColumns
    };
  }, MEMOIZE_OPTIONS));
  const indexOfColumnWithFocusedCell = reactExports.useMemo(() => {
    if (cellFocus !== null) {
      return visibleColumns.findIndex((column) => column.field === cellFocus.field);
    }
    return -1;
  }, [cellFocus, visibleColumns]);
  const getNearestIndexToRender = reactExports.useCallback((offset2) => {
    var _currentPage$range, _currentPage$range2;
    const lastMeasuredIndexRelativeToAllRows = apiRef2.current.getLastMeasuredRowIndex();
    let allRowsMeasured = lastMeasuredIndexRelativeToAllRows === Infinity;
    if ((_currentPage$range = currentPage.range) != null && _currentPage$range.lastRowIndex && !allRowsMeasured) {
      allRowsMeasured = lastMeasuredIndexRelativeToAllRows >= currentPage.range.lastRowIndex;
    }
    const lastMeasuredIndexRelativeToCurrentPage = clamp(lastMeasuredIndexRelativeToAllRows - (((_currentPage$range2 = currentPage.range) == null ? void 0 : _currentPage$range2.firstRowIndex) || 0), 0, rowsMeta.positions.length);
    if (allRowsMeasured || rowsMeta.positions[lastMeasuredIndexRelativeToCurrentPage] >= offset2) {
      return binarySearch(offset2, rowsMeta.positions);
    }
    return exponentialSearch(offset2, rowsMeta.positions, lastMeasuredIndexRelativeToCurrentPage);
  }, [apiRef2, (_currentPage$range3 = currentPage.range) == null ? void 0 : _currentPage$range3.firstRowIndex, (_currentPage$range4 = currentPage.range) == null ? void 0 : _currentPage$range4.lastRowIndex, rowsMeta.positions]);
  const computeRenderContext = reactExports.useCallback(() => {
    if (disableVirtualization) {
      return {
        firstRowIndex: 0,
        lastRowIndex: currentPage.rows.length,
        firstColumnIndex: 0,
        lastColumnIndex: visibleColumns.length
      };
    }
    const {
      top: top2,
      left: left2
    } = scrollPosition.current;
    const firstRowIndex = Math.min(getNearestIndexToRender(top2), rowsMeta.positions.length - 1);
    const lastRowIndex = rootProps.autoHeight ? firstRowIndex + currentPage.rows.length : getNearestIndexToRender(top2 + containerDimensions.height);
    let hasRowWithAutoHeight = false;
    let firstColumnIndex = 0;
    let lastColumnIndex = columnPositions.length;
    const [firstRowToRender, lastRowToRender] = getRenderableIndexes({
      firstIndex: firstRowIndex,
      lastIndex: lastRowIndex,
      minFirstIndex: 0,
      maxLastIndex: currentPage.rows.length,
      buffer: rootProps.rowBuffer
    });
    for (let i2 = firstRowToRender; i2 < lastRowToRender && !hasRowWithAutoHeight; i2 += 1) {
      const row = currentPage.rows[i2];
      hasRowWithAutoHeight = apiRef2.current.rowHasAutoHeight(row.id);
    }
    if (!hasRowWithAutoHeight) {
      firstColumnIndex = binarySearch(Math.abs(left2), columnPositions);
      lastColumnIndex = binarySearch(Math.abs(left2) + containerDimensions.width, columnPositions);
    }
    return {
      firstRowIndex,
      lastRowIndex,
      firstColumnIndex,
      lastColumnIndex
    };
  }, [disableVirtualization, getNearestIndexToRender, rowsMeta.positions.length, rootProps.autoHeight, rootProps.rowBuffer, currentPage.rows, columnPositions, visibleColumns.length, apiRef2, containerDimensions]);
  useEnhancedEffect$1(() => {
    if (disableVirtualization) {
      renderZoneRef.current.style.transform = `translate3d(0px, 0px, 0px)`;
    } else {
      rootRef.current.scrollLeft = 0;
      rootRef.current.scrollTop = 0;
    }
  }, [disableVirtualization]);
  useEnhancedEffect$1(() => {
    setContainerDimensions({
      width: rootRef.current.clientWidth,
      height: rootRef.current.clientHeight
    });
  }, [rowsMeta.currentPageTotalHeight]);
  const handleResize = reactExports.useCallback(() => {
    if (rootRef.current) {
      setContainerDimensions({
        width: rootRef.current.clientWidth,
        height: rootRef.current.clientHeight
      });
    }
  }, []);
  useGridApiEventHandler(apiRef2, "debouncedResize", handleResize);
  const updateRenderZonePosition = reactExports.useCallback((nextRenderContext) => {
    const [firstRowToRender, lastRowToRender] = getRenderableIndexes({
      firstIndex: nextRenderContext.firstRowIndex,
      lastIndex: nextRenderContext.lastRowIndex,
      minFirstIndex: 0,
      maxLastIndex: currentPage.rows.length,
      buffer: rootProps.rowBuffer
    });
    const [initialFirstColumnToRender] = getRenderableIndexes({
      firstIndex: nextRenderContext.firstColumnIndex,
      lastIndex: nextRenderContext.lastColumnIndex,
      minFirstIndex: renderZoneMinColumnIndex,
      maxLastIndex: renderZoneMaxColumnIndex,
      buffer: rootProps.columnBuffer
    });
    const firstColumnToRender = getFirstNonSpannedColumnToRender({
      firstColumnToRender: initialFirstColumnToRender,
      apiRef: apiRef2,
      firstRowToRender,
      lastRowToRender,
      visibleRows: currentPage.rows
    });
    const direction2 = theme.direction === "ltr" ? 1 : -1;
    const top2 = gridRowsMetaSelector(apiRef2.current.state).positions[firstRowToRender];
    const left2 = direction2 * gridColumnPositionsSelector(apiRef2)[firstColumnToRender];
    renderZoneRef.current.style.transform = `translate3d(${left2}px, ${top2}px, 0px)`;
    if (typeof onRenderZonePositioning === "function") {
      onRenderZonePositioning({
        top: top2,
        left: left2
      });
    }
  }, [apiRef2, currentPage.rows, onRenderZonePositioning, renderZoneMinColumnIndex, renderZoneMaxColumnIndex, rootProps.columnBuffer, rootProps.rowBuffer, theme.direction]);
  const updateRenderContext = reactExports.useCallback((nextRenderContext) => {
    if (prevRenderContext.current && areRenderContextsEqual(nextRenderContext, prevRenderContext.current)) {
      updateRenderZonePosition(nextRenderContext);
      return;
    }
    setRenderContext(nextRenderContext);
    updateRenderZonePosition(nextRenderContext);
    const [firstRowToRender, lastRowToRender] = getRenderableIndexes({
      firstIndex: nextRenderContext.firstRowIndex,
      lastIndex: nextRenderContext.lastRowIndex,
      minFirstIndex: 0,
      maxLastIndex: currentPage.rows.length,
      buffer: rootProps.rowBuffer
    });
    apiRef2.current.publishEvent("renderedRowsIntervalChange", {
      firstRowToRender,
      lastRowToRender
    });
    prevRenderContext.current = nextRenderContext;
  }, [apiRef2, setRenderContext, prevRenderContext, currentPage.rows.length, rootProps.rowBuffer, updateRenderZonePosition]);
  useEnhancedEffect$1(() => {
    if (containerDimensions.width == null) {
      return;
    }
    const initialRenderContext = computeRenderContext();
    updateRenderContext(initialRenderContext);
    const {
      top: top2,
      left: left2
    } = scrollPosition.current;
    const params = {
      top: top2,
      left: left2,
      renderContext: initialRenderContext
    };
    apiRef2.current.publishEvent("scrollPositionChange", params);
  }, [apiRef2, computeRenderContext, containerDimensions.width, updateRenderContext]);
  const handleScroll = useEventCallback$1((event) => {
    const {
      scrollTop,
      scrollLeft
    } = event.currentTarget;
    scrollPosition.current.top = scrollTop;
    scrollPosition.current.left = scrollLeft;
    if (!prevRenderContext.current || scrollTop < 0) {
      return;
    }
    if (theme.direction === "ltr") {
      if (scrollLeft < 0) {
        return;
      }
    }
    if (theme.direction === "rtl") {
      if (scrollLeft > 0) {
        return;
      }
    }
    const nextRenderContext = disableVirtualization ? prevRenderContext.current : computeRenderContext();
    const topRowsScrolledSincePreviousRender = Math.abs(nextRenderContext.firstRowIndex - prevRenderContext.current.firstRowIndex);
    const bottomRowsScrolledSincePreviousRender = Math.abs(nextRenderContext.lastRowIndex - prevRenderContext.current.lastRowIndex);
    const topColumnsScrolledSincePreviousRender = Math.abs(nextRenderContext.firstColumnIndex - prevRenderContext.current.firstColumnIndex);
    const bottomColumnsScrolledSincePreviousRender = Math.abs(nextRenderContext.lastColumnIndex - prevRenderContext.current.lastColumnIndex);
    const shouldSetState = topRowsScrolledSincePreviousRender >= rootProps.rowThreshold || bottomRowsScrolledSincePreviousRender >= rootProps.rowThreshold || topColumnsScrolledSincePreviousRender >= rootProps.columnThreshold || bottomColumnsScrolledSincePreviousRender >= rootProps.columnThreshold || prevTotalWidth.current !== columnsTotalWidth;
    apiRef2.current.publishEvent("scrollPositionChange", {
      top: scrollTop,
      left: scrollLeft,
      renderContext: shouldSetState ? nextRenderContext : prevRenderContext.current
    }, event);
    if (shouldSetState) {
      reactDomExports.flushSync(() => {
        updateRenderContext(nextRenderContext);
      });
      prevTotalWidth.current = columnsTotalWidth;
    }
  });
  const handleWheel = useEventCallback$1((event) => {
    apiRef2.current.publishEvent("virtualScrollerWheel", {}, event);
  });
  const handleTouchMove = useEventCallback$1((event) => {
    apiRef2.current.publishEvent("virtualScrollerTouchMove", {}, event);
  });
  const indexOfRowWithFocusedCell = reactExports.useMemo(() => {
    if (cellFocus !== null) {
      return currentPage.rows.findIndex((row) => row.id === cellFocus.id);
    }
    return -1;
  }, [cellFocus, currentPage.rows]);
  const getRows = (params = {
    renderContext
  }) => {
    var _rootProps$slotProps;
    const {
      onRowRender,
      renderContext: nextRenderContext,
      minFirstColumn = renderZoneMinColumnIndex,
      maxLastColumn = renderZoneMaxColumnIndex,
      availableSpace = containerDimensions.width,
      rowIndexOffset = 0,
      position = "center"
    } = params;
    if (!nextRenderContext || availableSpace == null) {
      return null;
    }
    const rowBuffer = !disableVirtualization ? rootProps.rowBuffer : 0;
    const columnBuffer = !disableVirtualization ? rootProps.columnBuffer : 0;
    const [firstRowToRender, lastRowToRender] = getRenderableIndexes({
      firstIndex: nextRenderContext.firstRowIndex,
      lastIndex: nextRenderContext.lastRowIndex,
      minFirstIndex: 0,
      maxLastIndex: currentPage.rows.length,
      buffer: rowBuffer
    });
    const renderedRows = [];
    if (params.rows) {
      params.rows.forEach((row) => {
        renderedRows.push(row);
        apiRef2.current.calculateColSpan({
          rowId: row.id,
          minFirstColumn,
          maxLastColumn,
          columns: visibleColumns
        });
      });
    } else {
      if (!currentPage.range) {
        return null;
      }
      for (let i2 = firstRowToRender; i2 < lastRowToRender; i2 += 1) {
        const row = currentPage.rows[i2];
        renderedRows.push(row);
        apiRef2.current.calculateColSpan({
          rowId: row.id,
          minFirstColumn,
          maxLastColumn,
          columns: visibleColumns
        });
      }
    }
    let isRowWithFocusedCellNotInRange = false;
    if (indexOfRowWithFocusedCell > -1) {
      const rowWithFocusedCell = currentPage.rows[indexOfRowWithFocusedCell];
      if (firstRowToRender > indexOfRowWithFocusedCell || lastRowToRender < indexOfRowWithFocusedCell) {
        isRowWithFocusedCellNotInRange = true;
        if (indexOfRowWithFocusedCell > firstRowToRender) {
          renderedRows.push(rowWithFocusedCell);
        } else {
          renderedRows.unshift(rowWithFocusedCell);
        }
        apiRef2.current.calculateColSpan({
          rowId: rowWithFocusedCell.id,
          minFirstColumn,
          maxLastColumn,
          columns: visibleColumns
        });
      }
    }
    const [initialFirstColumnToRender, lastColumnToRender] = getRenderableIndexes({
      firstIndex: nextRenderContext.firstColumnIndex,
      lastIndex: nextRenderContext.lastColumnIndex,
      minFirstIndex: minFirstColumn,
      maxLastIndex: maxLastColumn,
      buffer: columnBuffer
    });
    const firstColumnToRender = getFirstNonSpannedColumnToRender({
      firstColumnToRender: initialFirstColumnToRender,
      apiRef: apiRef2,
      firstRowToRender,
      lastRowToRender,
      visibleRows: currentPage.rows
    });
    let isColumnWihFocusedCellNotInRange = false;
    if (firstColumnToRender > indexOfColumnWithFocusedCell || lastColumnToRender < indexOfColumnWithFocusedCell) {
      isColumnWihFocusedCellNotInRange = true;
    }
    const {
      focusedCellColumnIndexNotInRange,
      renderedColumns
    } = getRenderedColumnsRef.current(visibleColumns, firstColumnToRender, lastColumnToRender, minFirstColumn, maxLastColumn, isColumnWihFocusedCellNotInRange ? indexOfColumnWithFocusedCell : -1);
    const _ref = ((_rootProps$slotProps = rootProps.slotProps) == null ? void 0 : _rootProps$slotProps.row) || {}, {
      style: rootRowStyle
    } = _ref, rootRowProps = _objectWithoutPropertiesLoose$1(_ref, _excluded$d);
    const invalidatesCachedRowStyle = prevGetRowProps.current !== getRowProps || prevRootRowStyle.current !== rootRowStyle;
    if (invalidatesCachedRowStyle) {
      rowStyleCache.current = /* @__PURE__ */ Object.create(null);
    }
    const rows = [];
    for (let i2 = 0; i2 < renderedRows.length; i2 += 1) {
      var _currentPage$range5;
      const {
        id,
        model
      } = renderedRows[i2];
      const isRowNotVisible = isRowWithFocusedCellNotInRange && cellFocus.id === id;
      const lastVisibleRowIndex = isRowWithFocusedCellNotInRange ? firstRowToRender + i2 === currentPage.rows.length : firstRowToRender + i2 === currentPage.rows.length - 1;
      const baseRowHeight = !apiRef2.current.rowHasAutoHeight(id) ? apiRef2.current.unstable_getRowHeight(id) : "auto";
      let isSelected;
      if (selectedRowsLookup[id] == null) {
        isSelected = false;
      } else {
        isSelected = apiRef2.current.isRowSelectable(id);
      }
      if (onRowRender) {
        onRowRender(id);
      }
      const focusedCell = cellFocus !== null && cellFocus.id === id ? cellFocus.field : null;
      const columnWithFocusedCellNotInRange = focusedCellColumnIndexNotInRange !== void 0 && visibleColumns[focusedCellColumnIndexNotInRange];
      const renderedColumnsWithFocusedCell = columnWithFocusedCellNotInRange && focusedCell ? [columnWithFocusedCellNotInRange, ...renderedColumns] : renderedColumns;
      let tabbableCell = null;
      if (cellTabIndex !== null && cellTabIndex.id === id) {
        const cellParams = apiRef2.current.getCellParams(id, cellTabIndex.field);
        tabbableCell = cellParams.cellMode === "view" ? cellTabIndex.field : null;
      }
      const _ref2 = typeof getRowProps === "function" && getRowProps(id, model) || {}, {
        style: rowStyle
      } = _ref2, rowProps = _objectWithoutPropertiesLoose$1(_ref2, _excluded2);
      if (!rowStyleCache.current[id]) {
        const style = _extends$1({}, rowStyle, rootRowStyle);
        rowStyleCache.current[id] = style;
      }
      rows.push(/* @__PURE__ */ jsxRuntimeExports.jsx(rootProps.slots.row, _extends$1({
        row: model,
        rowId: id,
        focusedCellColumnIndexNotInRange,
        isNotVisible: isRowNotVisible,
        rowHeight: baseRowHeight,
        focusedCell,
        tabbableCell,
        renderedColumns: renderedColumnsWithFocusedCell,
        visibleColumns,
        firstColumnToRender,
        lastColumnToRender,
        selected: isSelected,
        index: rowIndexOffset + ((currentPage == null || (_currentPage$range5 = currentPage.range) == null ? void 0 : _currentPage$range5.firstRowIndex) || 0) + firstRowToRender + i2,
        containerWidth: availableSpace,
        isLastVisible: lastVisibleRowIndex,
        position
      }, rowProps, rootRowProps, {
        style: rowStyleCache.current[id]
      }), id));
    }
    prevGetRowProps.current = getRowProps;
    prevRootRowStyle.current = rootRowStyle;
    return rows;
  };
  const needsHorizontalScrollbar = containerDimensions.width && columnsTotalWidth >= containerDimensions.width;
  const contentSize = reactExports.useMemo(() => {
    const height = Math.max(rowsMeta.currentPageTotalHeight, 1);
    let shouldExtendContent = false;
    if (rootRef != null && rootRef.current && height <= (rootRef == null ? void 0 : rootRef.current.clientHeight)) {
      shouldExtendContent = true;
    }
    const size = {
      width: needsHorizontalScrollbar ? columnsTotalWidth : "auto",
      height,
      minHeight: shouldExtendContent ? "100%" : "auto"
    };
    if (rootProps.autoHeight && currentPage.rows.length === 0) {
      size.height = getMinimalContentHeight(apiRef2, rootProps.rowHeight);
    }
    return size;
  }, [apiRef2, rootRef, columnsTotalWidth, rowsMeta.currentPageTotalHeight, needsHorizontalScrollbar, rootProps.autoHeight, rootProps.rowHeight, currentPage.rows.length]);
  reactExports.useEffect(() => {
    apiRef2.current.publishEvent("virtualScrollerContentSizeChange");
  }, [apiRef2, contentSize]);
  const rootStyle = reactExports.useMemo(() => {
    const style = {};
    if (!needsHorizontalScrollbar) {
      style.overflowX = "hidden";
    }
    if (rootProps.autoHeight) {
      style.overflowY = "hidden";
    }
    return style;
  }, [needsHorizontalScrollbar, rootProps.autoHeight]);
  const getRenderContext = reactExports.useCallback(() => {
    return prevRenderContext.current;
  }, []);
  apiRef2.current.register("private", {
    getRenderContext
  });
  return {
    renderContext,
    updateRenderZonePosition,
    getRows,
    getRootProps: (inputProps = {}) => _extends$1({
      ref: handleRef,
      onScroll: handleScroll,
      onWheel: handleWheel,
      onTouchMove: handleTouchMove
    }, inputProps, {
      style: inputProps.style ? _extends$1({}, inputProps.style, rootStyle) : rootStyle,
      role: "presentation"
    }),
    getContentProps: ({
      style
    } = {}) => ({
      style: style ? _extends$1({}, style, contentSize) : contentSize,
      role: "presentation"
    }),
    getRenderZoneProps: () => ({
      ref: renderZoneRef,
      role: "rowgroup"
    })
  };
};
const useUtilityClasses$9 = (ownerState) => {
  const {
    classes: classes2,
    headerAlign,
    isDragging,
    showColumnBorder,
    groupId
  } = ownerState;
  const slots = {
    root: ["columnHeader", headerAlign === "left" && "columnHeader--alignLeft", headerAlign === "center" && "columnHeader--alignCenter", headerAlign === "right" && "columnHeader--alignRight", isDragging && "columnHeader--moving", showColumnBorder && "columnHeader--showColumnBorder", showColumnBorder && "columnHeader--withRightBorder", "withBorderColor", groupId === null ? "columnHeader--emptyGroup" : "columnHeader--filledGroup"],
    draggableContainer: ["columnHeaderDraggableContainer"],
    titleContainer: ["columnHeaderTitleContainer", "withBorderColor"],
    titleContainerContent: ["columnHeaderTitleContainerContent"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
function GridColumnGroupHeader(props) {
  var _columnGroupsLookup$g;
  const {
    groupId,
    width,
    depth,
    maxDepth,
    fields,
    height,
    colIndex,
    hasFocus,
    tabIndex,
    isLastColumn
  } = props;
  const rootProps = useGridRootProps();
  const headerCellRef = reactExports.useRef(null);
  const apiRef2 = useGridApiContext();
  const columnGroupsLookup = useGridSelector(apiRef2, gridColumnGroupsLookupSelector);
  const group = groupId ? columnGroupsLookup[groupId] : {};
  const {
    headerName = groupId != null ? groupId : "",
    description = "",
    headerAlign = void 0
  } = group;
  let headerComponent;
  const render = groupId && ((_columnGroupsLookup$g = columnGroupsLookup[groupId]) == null ? void 0 : _columnGroupsLookup$g.renderHeaderGroup);
  const renderParams = reactExports.useMemo(() => ({
    groupId,
    headerName,
    description,
    depth,
    maxDepth,
    fields,
    colIndex,
    isLastColumn
  }), [groupId, headerName, description, depth, maxDepth, fields, colIndex, isLastColumn]);
  if (groupId && render) {
    headerComponent = render(renderParams);
  }
  const showColumnBorder = rootProps.showColumnVerticalBorder;
  const ownerState = _extends$1({}, props, {
    classes: rootProps.classes,
    showColumnBorder,
    headerAlign,
    depth,
    isDragging: false
  });
  const label = headerName != null ? headerName : groupId;
  const id = useId();
  const elementId = groupId === null ? `empty-group-cell-${id}` : groupId;
  const classes2 = useUtilityClasses$9(ownerState);
  reactExports.useLayoutEffect(() => {
    if (hasFocus) {
      const focusableElement = headerCellRef.current.querySelector('[tabindex="0"]');
      const elementToFocus = focusableElement || headerCellRef.current;
      elementToFocus == null || elementToFocus.focus();
    }
  }, [apiRef2, hasFocus]);
  const publish = reactExports.useCallback(
    (eventName) => (event) => {
      if (!event.currentTarget.contains(event.target)) {
        return;
      }
      apiRef2.current.publishEvent(eventName, renderParams, event);
    },
    // For now this is stupid, because renderParams change all the time.
    // Need to move it's computation in the api, such that for a given depth+columnField, I can get the group parameters
    [apiRef2, renderParams]
  );
  const mouseEventsHandlers = reactExports.useMemo(() => ({
    onKeyDown: publish("columnGroupHeaderKeyDown"),
    onFocus: publish("columnGroupHeaderFocus"),
    onBlur: publish("columnGroupHeaderBlur")
  }), [publish]);
  const headerClassName = typeof group.headerClassName === "function" ? group.headerClassName(renderParams) : group.headerClassName;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridGenericColumnHeaderItem, _extends$1({
    ref: headerCellRef,
    classes: classes2,
    columnMenuOpen: false,
    colIndex,
    height,
    isResizing: false,
    sortDirection: null,
    hasFocus: false,
    tabIndex,
    isDraggable: false,
    headerComponent,
    headerClassName,
    description,
    elementId,
    width,
    columnMenuIconButton: null,
    columnTitleIconButtons: null,
    resizable: false,
    label,
    "aria-colspan": fields.length,
    "data-fields": `|-${fields.join("-|-")}-|`
  }, mouseEventsHandlers));
}
const GridColumnHeaderRow = styled("div", {
  name: "MuiDataGrid",
  slot: "ColumnHeaderRow",
  overridesResolver: (props, styles2) => styles2.columnHeaderRow
})(() => ({
  display: "flex"
}));
function isUIEvent(event) {
  return !!event.target;
}
const useGridColumnHeaders = (props) => {
  const {
    innerRef: innerRefProp,
    minColumnIndex = 0,
    visibleColumns,
    sortColumnLookup,
    filterColumnLookup,
    columnPositions,
    columnHeaderTabIndexState,
    columnGroupHeaderTabIndexState,
    columnHeaderFocus,
    columnGroupHeaderFocus,
    densityFactor,
    headerGroupingMaxDepth,
    columnMenuState,
    columnVisibility,
    columnGroupsHeaderStructure,
    hasOtherElementInTabSequence
  } = props;
  const theme = useTheme$2();
  const [dragCol, setDragCol] = reactExports.useState("");
  const [resizeCol, setResizeCol] = reactExports.useState("");
  const apiRef2 = useGridPrivateApiContext();
  const rootProps = useGridRootProps();
  const innerRef = reactExports.useRef(null);
  const handleInnerRef = useForkRef$1(innerRefProp, innerRef);
  const [renderContext, setRenderContextRaw] = reactExports.useState(null);
  const prevRenderContext = reactExports.useRef(renderContext);
  const prevScrollLeft = reactExports.useRef(0);
  const currentPage = useGridVisibleRows(apiRef2, rootProps);
  const totalHeaderHeight = getTotalHeaderHeight(apiRef2, rootProps.columnHeaderHeight);
  const headerHeight = Math.floor(rootProps.columnHeaderHeight * densityFactor);
  const setRenderContext = reactExports.useCallback((nextRenderContext) => {
    if (renderContext && nextRenderContext && areRenderContextsEqual(renderContext, nextRenderContext)) {
      return;
    }
    setRenderContextRaw(nextRenderContext);
  }, [renderContext]);
  reactExports.useEffect(() => {
    apiRef2.current.columnHeadersContainerElementRef.current.scrollLeft = 0;
  }, [apiRef2]);
  const getFirstColumnIndexToRenderRef = reactExports.useRef(defaultMemoize(getFirstColumnIndexToRender, {
    equalityCheck: (a2, b) => ["firstColumnIndex", "minColumnIndex", "columnBuffer"].every((key) => a2[key] === b[key])
  }));
  const updateInnerPosition = reactExports.useCallback((nextRenderContext) => {
    const [firstRowToRender, lastRowToRender] = getRenderableIndexes({
      firstIndex: nextRenderContext.firstRowIndex,
      lastIndex: nextRenderContext.lastRowIndex,
      minFirstIndex: 0,
      maxLastIndex: currentPage.rows.length,
      buffer: rootProps.rowBuffer
    });
    const firstColumnToRender = getFirstColumnIndexToRenderRef.current({
      firstColumnIndex: nextRenderContext.firstColumnIndex,
      minColumnIndex,
      columnBuffer: rootProps.columnBuffer,
      firstRowToRender,
      lastRowToRender,
      apiRef: apiRef2,
      visibleRows: currentPage.rows
    });
    const direction2 = theme.direction === "ltr" ? 1 : -1;
    const offset2 = firstColumnToRender > 0 ? prevScrollLeft.current - direction2 * columnPositions[firstColumnToRender] : prevScrollLeft.current;
    innerRef.current.style.transform = `translate3d(${-offset2}px, 0px, 0px)`;
  }, [columnPositions, minColumnIndex, rootProps.columnBuffer, apiRef2, currentPage.rows, rootProps.rowBuffer, theme.direction]);
  reactExports.useLayoutEffect(() => {
    if (renderContext) {
      updateInnerPosition(renderContext);
    }
  }, [renderContext, updateInnerPosition]);
  const handleScroll = reactExports.useCallback(({
    left: left2,
    renderContext: nextRenderContext = null
  }, event) => {
    var _prevRenderContext$cu, _prevRenderContext$cu2;
    if (!innerRef.current) {
      return;
    }
    if (prevScrollLeft.current === left2 && ((_prevRenderContext$cu = prevRenderContext.current) == null ? void 0 : _prevRenderContext$cu.firstColumnIndex) === (nextRenderContext == null ? void 0 : nextRenderContext.firstColumnIndex) && ((_prevRenderContext$cu2 = prevRenderContext.current) == null ? void 0 : _prevRenderContext$cu2.lastColumnIndex) === (nextRenderContext == null ? void 0 : nextRenderContext.lastColumnIndex)) {
      return;
    }
    prevScrollLeft.current = left2;
    let canUpdateInnerPosition = false;
    if (nextRenderContext !== prevRenderContext.current || !prevRenderContext.current) {
      if (isUIEvent(event)) {
        reactDomExports.flushSync(() => {
          setRenderContext(nextRenderContext);
        });
        canUpdateInnerPosition = true;
      } else {
        setRenderContext(nextRenderContext);
      }
      prevRenderContext.current = nextRenderContext;
    } else {
      canUpdateInnerPosition = true;
    }
    if (nextRenderContext && canUpdateInnerPosition) {
      updateInnerPosition(nextRenderContext);
    }
  }, [updateInnerPosition, setRenderContext]);
  const handleColumnResizeStart = reactExports.useCallback((params) => setResizeCol(params.field), []);
  const handleColumnResizeStop = reactExports.useCallback(() => setResizeCol(""), []);
  const handleColumnReorderStart = reactExports.useCallback((params) => setDragCol(params.field), []);
  const handleColumnReorderStop = reactExports.useCallback(() => setDragCol(""), []);
  useGridApiEventHandler(apiRef2, "columnResizeStart", handleColumnResizeStart);
  useGridApiEventHandler(apiRef2, "columnResizeStop", handleColumnResizeStop);
  useGridApiEventHandler(apiRef2, "columnHeaderDragStart", handleColumnReorderStart);
  useGridApiEventHandler(apiRef2, "columnHeaderDragEnd", handleColumnReorderStop);
  useGridApiEventHandler(apiRef2, "scrollPositionChange", handleScroll);
  const getColumnsToRender = (params) => {
    const {
      renderContext: nextRenderContext = renderContext,
      minFirstColumn = minColumnIndex,
      maxLastColumn = visibleColumns.length
    } = params || {};
    if (!nextRenderContext) {
      return null;
    }
    const [firstRowToRender, lastRowToRender] = getRenderableIndexes({
      firstIndex: nextRenderContext.firstRowIndex,
      lastIndex: nextRenderContext.lastRowIndex,
      minFirstIndex: 0,
      maxLastIndex: currentPage.rows.length,
      buffer: rootProps.rowBuffer
    });
    const firstColumnToRender = getFirstColumnIndexToRenderRef.current({
      firstColumnIndex: nextRenderContext.firstColumnIndex,
      minColumnIndex: minFirstColumn,
      columnBuffer: rootProps.columnBuffer,
      apiRef: apiRef2,
      firstRowToRender,
      lastRowToRender,
      visibleRows: currentPage.rows
    });
    const lastColumnToRender = Math.min(nextRenderContext.lastColumnIndex + rootProps.columnBuffer, maxLastColumn);
    const renderedColumns = visibleColumns.slice(firstColumnToRender, lastColumnToRender);
    return {
      renderedColumns,
      firstColumnToRender,
      lastColumnToRender,
      minFirstColumn,
      maxLastColumn
    };
  };
  const getColumnHeaders = (params, other = {}) => {
    const columnsToRender = getColumnsToRender(params);
    if (columnsToRender == null) {
      return null;
    }
    const {
      renderedColumns,
      firstColumnToRender
    } = columnsToRender;
    const columns = [];
    for (let i2 = 0; i2 < renderedColumns.length; i2 += 1) {
      const colDef = renderedColumns[i2];
      const columnIndex = firstColumnToRender + i2;
      const isFirstColumn = columnIndex === 0;
      const tabIndex = columnHeaderTabIndexState !== null && columnHeaderTabIndexState.field === colDef.field || isFirstColumn && !hasOtherElementInTabSequence ? 0 : -1;
      const hasFocus = columnHeaderFocus !== null && columnHeaderFocus.field === colDef.field;
      const open = columnMenuState.open && columnMenuState.field === colDef.field;
      columns.push(/* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnHeaderItem, _extends$1({}, sortColumnLookup[colDef.field], {
        columnMenuOpen: open,
        filterItemsCounter: filterColumnLookup[colDef.field] && filterColumnLookup[colDef.field].length,
        headerHeight,
        isDragging: colDef.field === dragCol,
        colDef,
        colIndex: columnIndex,
        isResizing: resizeCol === colDef.field,
        hasFocus,
        tabIndex
      }, other), colDef.field));
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnHeaderRow, {
      role: "row",
      "aria-rowindex": headerGroupingMaxDepth + 1,
      ownerState: rootProps,
      children: columns
    });
  };
  const getColumnGroupHeaders = (params) => {
    if (headerGroupingMaxDepth === 0) {
      return null;
    }
    const columnsToRender = getColumnsToRender(params);
    if (columnsToRender == null || columnsToRender.renderedColumns.length === 0) {
      return null;
    }
    const {
      firstColumnToRender,
      lastColumnToRender
    } = columnsToRender;
    const columns = [];
    const headerToRender = [];
    for (let depth = 0; depth < headerGroupingMaxDepth; depth += 1) {
      var _apiRef$current$unsta, _apiRef$current$unsta2;
      const rowStructure = columnGroupsHeaderStructure[depth];
      const firstColumnFieldToRender = visibleColumns[firstColumnToRender].field;
      const firstGroupToRender = (_apiRef$current$unsta = apiRef2.current.unstable_getColumnGroupPath(firstColumnFieldToRender)[depth]) != null ? _apiRef$current$unsta : null;
      const firstGroupIndex = rowStructure.findIndex(({
        groupId,
        columnFields
      }) => groupId === firstGroupToRender && columnFields.includes(firstColumnFieldToRender));
      const lastColumnFieldToRender = visibleColumns[lastColumnToRender - 1].field;
      const lastGroupToRender = (_apiRef$current$unsta2 = apiRef2.current.unstable_getColumnGroupPath(lastColumnFieldToRender)[depth]) != null ? _apiRef$current$unsta2 : null;
      const lastGroupIndex = rowStructure.findIndex(({
        groupId,
        columnFields
      }) => groupId === lastGroupToRender && columnFields.includes(lastColumnFieldToRender));
      const visibleColumnGroupHeader = rowStructure.slice(firstGroupIndex, lastGroupIndex + 1).map((groupStructure) => {
        return _extends$1({}, groupStructure, {
          columnFields: groupStructure.columnFields.filter((field) => columnVisibility[field] !== false)
        });
      }).filter((groupStructure) => groupStructure.columnFields.length > 0);
      const firstVisibleColumnIndex = visibleColumnGroupHeader[0].columnFields.indexOf(firstColumnFieldToRender);
      const hiddenGroupColumns = visibleColumnGroupHeader[0].columnFields.slice(0, firstVisibleColumnIndex);
      const leftOverflow = hiddenGroupColumns.reduce((acc, field) => {
        var _column$computedWidth;
        const column = apiRef2.current.getColumn(field);
        return acc + ((_column$computedWidth = column.computedWidth) != null ? _column$computedWidth : 0);
      }, 0);
      let columnIndex = firstColumnToRender;
      const elements = visibleColumnGroupHeader.map(({
        groupId,
        columnFields
      }) => {
        const hasFocus = columnGroupHeaderFocus !== null && columnGroupHeaderFocus.depth === depth && columnFields.includes(columnGroupHeaderFocus.field);
        const tabIndex = columnGroupHeaderTabIndexState !== null && columnGroupHeaderTabIndexState.depth === depth && columnFields.includes(columnGroupHeaderTabIndexState.field) ? 0 : -1;
        const headerInfo = {
          groupId,
          width: columnFields.reduce((acc, field) => acc + apiRef2.current.getColumn(field).computedWidth, 0),
          fields: columnFields,
          colIndex: columnIndex,
          hasFocus,
          tabIndex
        };
        columnIndex += columnFields.length;
        return headerInfo;
      });
      headerToRender.push({
        leftOverflow,
        elements
      });
    }
    headerToRender.forEach((depthInfo, depthIndex) => {
      columns.push(/* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnHeaderRow, {
        style: {
          height: `${headerHeight}px`,
          transform: `translateX(-${depthInfo.leftOverflow}px)`
        },
        role: "row",
        "aria-rowindex": depthIndex + 1,
        ownerState: rootProps,
        children: depthInfo.elements.map(({
          groupId,
          width,
          fields,
          colIndex,
          hasFocus,
          tabIndex
        }, groupIndex) => {
          return /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnGroupHeader, {
            groupId,
            width,
            fields,
            colIndex,
            depth: depthIndex,
            isLastColumn: colIndex === visibleColumns.length - fields.length,
            maxDepth: headerToRender.length,
            height: headerHeight,
            hasFocus,
            tabIndex
          }, groupIndex);
        })
      }, depthIndex));
    });
    return columns;
  };
  const rootStyle = {
    minHeight: totalHeaderHeight,
    maxHeight: totalHeaderHeight,
    lineHeight: `${headerHeight}px`
  };
  return {
    renderContext,
    getColumnHeaders,
    getColumnsToRender,
    getColumnGroupHeaders,
    isDragging: !!dragCol,
    getRootProps: (other = {}) => _extends$1({
      style: rootStyle
    }, other),
    getInnerProps: () => ({
      ref: handleInnerRef,
      role: "rowgroup"
    }),
    headerHeight
  };
};
const _excluded$c = ["className"];
const useUtilityClasses$8 = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["columnHeaders", "withBorderColor"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridColumnHeadersRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "ColumnHeaders",
  overridesResolver: (props, styles2) => styles2.columnHeaders
})({
  position: "relative",
  overflow: "hidden",
  display: "flex",
  alignItems: "center",
  boxSizing: "border-box",
  borderBottom: "1px solid",
  borderTopLeftRadius: "var(--unstable_DataGrid-radius)",
  borderTopRightRadius: "var(--unstable_DataGrid-radius)"
});
const GridBaseColumnHeaders = /* @__PURE__ */ reactExports.forwardRef(function GridColumnHeaders2(props, ref) {
  const {
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$c);
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$8(rootProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnHeadersRoot, _extends$1({
    ref,
    className: clsx$1(className, classes2.root),
    ownerState: rootProps
  }, other, {
    role: "presentation"
  }));
});
const _excluded$b = ["isDragging", "className"];
const useUtilityClasses$7 = (ownerState) => {
  const {
    isDragging,
    hasScrollX,
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["columnHeadersInner", isDragging && "columnHeaderDropZone", hasScrollX && "columnHeadersInner--scrollable"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const GridColumnHeadersInnerRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "columnHeadersInner",
  overridesResolver: (props, styles2) => [{
    [`&.${gridClasses.columnHeaderDropZone}`]: styles2.columnHeaderDropZone
  }, styles2.columnHeadersInner]
})(() => ({
  display: "flex",
  alignItems: "flex-start",
  flexDirection: "column",
  [`&.${gridClasses.columnHeaderDropZone} .${gridClasses.columnHeaderDraggableContainer}`]: {
    cursor: "move"
  },
  [`&.${gridClasses["columnHeadersInner--scrollable"]} .${gridClasses.columnHeader}:last-child`]: {
    borderRight: "none"
  }
}));
const GridColumnHeadersInner = /* @__PURE__ */ reactExports.forwardRef(function GridColumnHeadersInner2(props, ref) {
  var _apiRef$current$getRo, _apiRef$current$getRo2;
  const {
    isDragging,
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$b);
  const apiRef2 = useGridApiContext();
  const rootProps = useGridRootProps();
  const ownerState = _extends$1({}, rootProps, {
    isDragging,
    hasScrollX: (_apiRef$current$getRo = (_apiRef$current$getRo2 = apiRef2.current.getRootDimensions()) == null ? void 0 : _apiRef$current$getRo2.hasScrollX) != null ? _apiRef$current$getRo : false
  });
  const classes2 = useUtilityClasses$7(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridColumnHeadersInnerRoot, _extends$1({
    ref,
    className: clsx$1(className, classes2.root),
    ownerState
  }, other));
});
const _excluded$a = ["innerRef", "className", "visibleColumns", "sortColumnLookup", "filterColumnLookup", "columnPositions", "columnHeaderTabIndexState", "columnGroupHeaderTabIndexState", "columnHeaderFocus", "columnGroupHeaderFocus", "densityFactor", "headerGroupingMaxDepth", "columnMenuState", "columnVisibility", "columnGroupsHeaderStructure", "hasOtherElementInTabSequence"];
const GridColumnHeaders = /* @__PURE__ */ reactExports.forwardRef(function GridColumnsHeaders(props, ref) {
  const {
    innerRef,
    visibleColumns,
    sortColumnLookup,
    filterColumnLookup,
    columnPositions,
    columnHeaderTabIndexState,
    columnGroupHeaderTabIndexState,
    columnHeaderFocus,
    columnGroupHeaderFocus,
    densityFactor,
    headerGroupingMaxDepth,
    columnMenuState,
    columnVisibility,
    columnGroupsHeaderStructure,
    hasOtherElementInTabSequence
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$a);
  const {
    isDragging,
    getRootProps,
    getInnerProps,
    getColumnHeaders,
    getColumnGroupHeaders
  } = useGridColumnHeaders({
    innerRef,
    visibleColumns,
    sortColumnLookup,
    filterColumnLookup,
    columnPositions,
    columnHeaderTabIndexState,
    columnGroupHeaderTabIndexState,
    columnHeaderFocus,
    columnGroupHeaderFocus,
    densityFactor,
    headerGroupingMaxDepth,
    columnMenuState,
    columnVisibility,
    columnGroupsHeaderStructure,
    hasOtherElementInTabSequence
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridBaseColumnHeaders, _extends$1({
    ref
  }, getRootProps(other), {
    children: /* @__PURE__ */ jsxRuntimeExports.jsxs(GridColumnHeadersInner, _extends$1({
      isDragging
    }, getInnerProps(), {
      children: [getColumnGroupHeaders(), getColumnHeaders()]
    }))
  }));
});
const MemoizedGridColumnHeaders = fastMemo(GridColumnHeaders);
const GridNoResultsOverlay = /* @__PURE__ */ reactExports.forwardRef(function GridNoResultsOverlay2(props, ref) {
  const apiRef2 = useGridApiContext();
  const noResultsOverlayLabel = apiRef2.current.getLocaleText("noResultsOverlayLabel");
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridOverlay, _extends$1({
    ref
  }, props, {
    children: noResultsOverlayLabel
  }));
});
const CheckBoxOutlineBlankIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"
}), "CheckBoxOutlineBlank");
const CheckBoxIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"
}), "CheckBox");
const IndeterminateCheckBoxIcon = createSvgIcon$1(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10H7v-2h10v2z"
}), "IndeterminateCheckBox");
function getCheckboxUtilityClass(slot) {
  return generateUtilityClass("MuiCheckbox", slot);
}
const checkboxClasses = generateUtilityClasses("MuiCheckbox", ["root", "checked", "disabled", "indeterminate", "colorPrimary", "colorSecondary", "sizeSmall", "sizeMedium"]);
const checkboxClasses$1 = checkboxClasses;
const _excluded$9 = ["checkedIcon", "color", "icon", "indeterminate", "indeterminateIcon", "inputProps", "size", "className"];
const useUtilityClasses$6 = (ownerState) => {
  const {
    classes: classes2,
    indeterminate,
    color,
    size
  } = ownerState;
  const slots = {
    root: ["root", indeterminate && "indeterminate", `color${capitalize(color)}`, `size${capitalize(size)}`]
  };
  const composedClasses = composeClasses(slots, getCheckboxUtilityClass, classes2);
  return _extends$1({}, classes2, composedClasses);
};
const CheckboxRoot = styled$1(SwitchBase$1, {
  shouldForwardProp: (prop) => rootShouldForwardProp(prop) || prop === "classes",
  name: "MuiCheckbox",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, ownerState.indeterminate && styles2.indeterminate, ownerState.color !== "default" && styles2[`color${capitalize(ownerState.color)}`]];
  }
})(({
  theme,
  ownerState
}) => _extends$1({
  color: (theme.vars || theme).palette.text.secondary
}, !ownerState.disableRipple && {
  "&:hover": {
    backgroundColor: theme.vars ? `rgba(${ownerState.color === "default" ? theme.vars.palette.action.activeChannel : theme.vars.palette.primary.mainChannel} / ${theme.vars.palette.action.hoverOpacity})` : alpha(ownerState.color === "default" ? theme.palette.action.active : theme.palette[ownerState.color].main, theme.palette.action.hoverOpacity),
    // Reset on touch devices, it doesn't add specificity
    "@media (hover: none)": {
      backgroundColor: "transparent"
    }
  }
}, ownerState.color !== "default" && {
  [`&.${checkboxClasses$1.checked}, &.${checkboxClasses$1.indeterminate}`]: {
    color: (theme.vars || theme).palette[ownerState.color].main
  },
  [`&.${checkboxClasses$1.disabled}`]: {
    color: (theme.vars || theme).palette.action.disabled
  }
}));
const defaultCheckedIcon = /* @__PURE__ */ jsxRuntimeExports.jsx(CheckBoxIcon, {});
const defaultIcon = /* @__PURE__ */ jsxRuntimeExports.jsx(CheckBoxOutlineBlankIcon, {});
const defaultIndeterminateIcon = /* @__PURE__ */ jsxRuntimeExports.jsx(IndeterminateCheckBoxIcon, {});
const Checkbox = /* @__PURE__ */ reactExports.forwardRef(function Checkbox2(inProps, ref) {
  var _icon$props$fontSize, _indeterminateIcon$pr;
  const props = useThemeProps({
    props: inProps,
    name: "MuiCheckbox"
  });
  const {
    checkedIcon = defaultCheckedIcon,
    color = "primary",
    icon: iconProp = defaultIcon,
    indeterminate = false,
    indeterminateIcon: indeterminateIconProp = defaultIndeterminateIcon,
    inputProps,
    size = "medium",
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$9);
  const icon = indeterminate ? indeterminateIconProp : iconProp;
  const indeterminateIcon = indeterminate ? indeterminateIconProp : checkedIcon;
  const ownerState = _extends$1({}, props, {
    color,
    indeterminate,
    size
  });
  const classes2 = useUtilityClasses$6(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(CheckboxRoot, _extends$1({
    type: "checkbox",
    inputProps: _extends$1({
      "data-indeterminate": indeterminate
    }, inputProps),
    icon: /* @__PURE__ */ reactExports.cloneElement(icon, {
      fontSize: (_icon$props$fontSize = icon.props.fontSize) != null ? _icon$props$fontSize : size
    }),
    checkedIcon: /* @__PURE__ */ reactExports.cloneElement(indeterminateIcon, {
      fontSize: (_indeterminateIcon$pr = indeterminateIcon.props.fontSize) != null ? _indeterminateIcon$pr : size
    }),
    ownerState,
    ref,
    className: clsx$1(classes2.root, className)
  }, other, {
    classes: classes2
  }));
});
const MUICheckbox = Checkbox;
function getInputAdornmentUtilityClass(slot) {
  return generateUtilityClass("MuiInputAdornment", slot);
}
const inputAdornmentClasses = generateUtilityClasses("MuiInputAdornment", ["root", "filled", "standard", "outlined", "positionStart", "positionEnd", "disablePointerEvents", "hiddenLabel", "sizeSmall"]);
const inputAdornmentClasses$1 = inputAdornmentClasses;
var _span;
const _excluded$8 = ["children", "className", "component", "disablePointerEvents", "disableTypography", "position", "variant"];
const overridesResolver = (props, styles2) => {
  const {
    ownerState
  } = props;
  return [styles2.root, styles2[`position${capitalize(ownerState.position)}`], ownerState.disablePointerEvents === true && styles2.disablePointerEvents, styles2[ownerState.variant]];
};
const useUtilityClasses$5 = (ownerState) => {
  const {
    classes: classes2,
    disablePointerEvents,
    hiddenLabel,
    position,
    size,
    variant
  } = ownerState;
  const slots = {
    root: ["root", disablePointerEvents && "disablePointerEvents", position && `position${capitalize(position)}`, variant, hiddenLabel && "hiddenLabel", size && `size${capitalize(size)}`]
  };
  return composeClasses(slots, getInputAdornmentUtilityClass, classes2);
};
const InputAdornmentRoot = styled$1("div", {
  name: "MuiInputAdornment",
  slot: "Root",
  overridesResolver
})(({
  theme,
  ownerState
}) => _extends$1({
  display: "flex",
  height: "0.01em",
  // Fix IE11 flexbox alignment. To remove at some point.
  maxHeight: "2em",
  alignItems: "center",
  whiteSpace: "nowrap",
  color: (theme.vars || theme).palette.action.active
}, ownerState.variant === "filled" && {
  // Styles applied to the root element if `variant="filled"`.
  [`&.${inputAdornmentClasses$1.positionStart}&:not(.${inputAdornmentClasses$1.hiddenLabel})`]: {
    marginTop: 16
  }
}, ownerState.position === "start" && {
  // Styles applied to the root element if `position="start"`.
  marginRight: 8
}, ownerState.position === "end" && {
  // Styles applied to the root element if `position="end"`.
  marginLeft: 8
}, ownerState.disablePointerEvents === true && {
  // Styles applied to the root element if `disablePointerEvents={true}`.
  pointerEvents: "none"
}));
const InputAdornment = /* @__PURE__ */ reactExports.forwardRef(function InputAdornment2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiInputAdornment"
  });
  const {
    children,
    className,
    component = "div",
    disablePointerEvents = false,
    disableTypography = false,
    position,
    variant: variantProp
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$8);
  const muiFormControl = useFormControl() || {};
  let variant = variantProp;
  if (variantProp && muiFormControl.variant)
    ;
  if (muiFormControl && !variant) {
    variant = muiFormControl.variant;
  }
  const ownerState = _extends$1({}, props, {
    hiddenLabel: muiFormControl.hiddenLabel,
    size: muiFormControl.size,
    disablePointerEvents,
    position,
    variant
  });
  const classes2 = useUtilityClasses$5(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(FormControlContext.Provider, {
    value: null,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(InputAdornmentRoot, _extends$1({
      as: component,
      ownerState,
      className: clsx$1(classes2.root, className),
      ref
    }, other, {
      children: typeof children === "string" && !disableTypography ? /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, {
        color: "text.secondary",
        children
      }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, {
        children: [position === "start" ? (
          /* notranslate needed while Google Translate will not fix zero-width space issue */
          _span || (_span = /* @__PURE__ */ jsxRuntimeExports.jsx("span", {
            className: "notranslate",
            children: "​"
          }))
        ) : null, children]
      })
    }))
  });
});
const MUIInputAdornment = InputAdornment;
function getTooltipUtilityClass(slot) {
  return generateUtilityClass("MuiTooltip", slot);
}
const tooltipClasses = generateUtilityClasses("MuiTooltip", ["popper", "popperInteractive", "popperArrow", "popperClose", "tooltip", "tooltipArrow", "touch", "tooltipPlacementLeft", "tooltipPlacementRight", "tooltipPlacementTop", "tooltipPlacementBottom", "arrow"]);
const tooltipClasses$1 = tooltipClasses;
const _excluded$7 = ["arrow", "children", "classes", "components", "componentsProps", "describeChild", "disableFocusListener", "disableHoverListener", "disableInteractive", "disableTouchListener", "enterDelay", "enterNextDelay", "enterTouchDelay", "followCursor", "id", "leaveDelay", "leaveTouchDelay", "onClose", "onOpen", "open", "placement", "PopperComponent", "PopperProps", "slotProps", "slots", "title", "TransitionComponent", "TransitionProps"];
function round(value) {
  return Math.round(value * 1e5) / 1e5;
}
const useUtilityClasses$4 = (ownerState) => {
  const {
    classes: classes2,
    disableInteractive,
    arrow: arrow2,
    touch,
    placement
  } = ownerState;
  const slots = {
    popper: ["popper", !disableInteractive && "popperInteractive", arrow2 && "popperArrow"],
    tooltip: ["tooltip", arrow2 && "tooltipArrow", touch && "touch", `tooltipPlacement${capitalize(placement.split("-")[0])}`],
    arrow: ["arrow"]
  };
  return composeClasses(slots, getTooltipUtilityClass, classes2);
};
const TooltipPopper = styled$1(MUIPopper, {
  name: "MuiTooltip",
  slot: "Popper",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.popper, !ownerState.disableInteractive && styles2.popperInteractive, ownerState.arrow && styles2.popperArrow, !ownerState.open && styles2.popperClose];
  }
})(({
  theme,
  ownerState,
  open
}) => _extends$1({
  zIndex: (theme.vars || theme).zIndex.tooltip,
  pointerEvents: "none"
}, !ownerState.disableInteractive && {
  pointerEvents: "auto"
}, !open && {
  pointerEvents: "none"
}, ownerState.arrow && {
  [`&[data-popper-placement*="bottom"] .${tooltipClasses$1.arrow}`]: {
    top: 0,
    marginTop: "-0.71em",
    "&::before": {
      transformOrigin: "0 100%"
    }
  },
  [`&[data-popper-placement*="top"] .${tooltipClasses$1.arrow}`]: {
    bottom: 0,
    marginBottom: "-0.71em",
    "&::before": {
      transformOrigin: "100% 0"
    }
  },
  [`&[data-popper-placement*="right"] .${tooltipClasses$1.arrow}`]: _extends$1({}, !ownerState.isRtl ? {
    left: 0,
    marginLeft: "-0.71em"
  } : {
    right: 0,
    marginRight: "-0.71em"
  }, {
    height: "1em",
    width: "0.71em",
    "&::before": {
      transformOrigin: "100% 100%"
    }
  }),
  [`&[data-popper-placement*="left"] .${tooltipClasses$1.arrow}`]: _extends$1({}, !ownerState.isRtl ? {
    right: 0,
    marginRight: "-0.71em"
  } : {
    left: 0,
    marginLeft: "-0.71em"
  }, {
    height: "1em",
    width: "0.71em",
    "&::before": {
      transformOrigin: "0 0"
    }
  })
}));
const TooltipTooltip = styled$1("div", {
  name: "MuiTooltip",
  slot: "Tooltip",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.tooltip, ownerState.touch && styles2.touch, ownerState.arrow && styles2.tooltipArrow, styles2[`tooltipPlacement${capitalize(ownerState.placement.split("-")[0])}`]];
  }
})(({
  theme,
  ownerState
}) => _extends$1({
  backgroundColor: theme.vars ? theme.vars.palette.Tooltip.bg : alpha(theme.palette.grey[700], 0.92),
  borderRadius: (theme.vars || theme).shape.borderRadius,
  color: (theme.vars || theme).palette.common.white,
  fontFamily: theme.typography.fontFamily,
  padding: "4px 8px",
  fontSize: theme.typography.pxToRem(11),
  maxWidth: 300,
  margin: 2,
  wordWrap: "break-word",
  fontWeight: theme.typography.fontWeightMedium
}, ownerState.arrow && {
  position: "relative",
  margin: 0
}, ownerState.touch && {
  padding: "8px 16px",
  fontSize: theme.typography.pxToRem(14),
  lineHeight: `${round(16 / 14)}em`,
  fontWeight: theme.typography.fontWeightRegular
}, {
  [`.${tooltipClasses$1.popper}[data-popper-placement*="left"] &`]: _extends$1({
    transformOrigin: "right center"
  }, !ownerState.isRtl ? _extends$1({
    marginRight: "14px"
  }, ownerState.touch && {
    marginRight: "24px"
  }) : _extends$1({
    marginLeft: "14px"
  }, ownerState.touch && {
    marginLeft: "24px"
  })),
  [`.${tooltipClasses$1.popper}[data-popper-placement*="right"] &`]: _extends$1({
    transformOrigin: "left center"
  }, !ownerState.isRtl ? _extends$1({
    marginLeft: "14px"
  }, ownerState.touch && {
    marginLeft: "24px"
  }) : _extends$1({
    marginRight: "14px"
  }, ownerState.touch && {
    marginRight: "24px"
  })),
  [`.${tooltipClasses$1.popper}[data-popper-placement*="top"] &`]: _extends$1({
    transformOrigin: "center bottom",
    marginBottom: "14px"
  }, ownerState.touch && {
    marginBottom: "24px"
  }),
  [`.${tooltipClasses$1.popper}[data-popper-placement*="bottom"] &`]: _extends$1({
    transformOrigin: "center top",
    marginTop: "14px"
  }, ownerState.touch && {
    marginTop: "24px"
  })
}));
const TooltipArrow = styled$1("span", {
  name: "MuiTooltip",
  slot: "Arrow",
  overridesResolver: (props, styles2) => styles2.arrow
})(({
  theme
}) => ({
  overflow: "hidden",
  position: "absolute",
  width: "1em",
  height: "0.71em",
  boxSizing: "border-box",
  color: theme.vars ? theme.vars.palette.Tooltip.bg : alpha(theme.palette.grey[700], 0.9),
  "&::before": {
    content: '""',
    margin: "auto",
    display: "block",
    width: "100%",
    height: "100%",
    backgroundColor: "currentColor",
    transform: "rotate(45deg)"
  }
}));
let hystersisOpen = false;
let hystersisTimer = null;
let cursorPosition = {
  x: 0,
  y: 0
};
function composeEventHandler(handler, eventHandler) {
  return (event) => {
    if (eventHandler) {
      eventHandler(event);
    }
    handler(event);
  };
}
const Tooltip = /* @__PURE__ */ reactExports.forwardRef(function Tooltip2(inProps, ref) {
  var _ref, _slots$popper, _ref2, _ref3, _slots$transition, _ref4, _slots$tooltip, _ref5, _slots$arrow, _slotProps$popper, _ref6, _slotProps$popper2, _slotProps$transition, _slotProps$tooltip, _ref7, _slotProps$tooltip2, _slotProps$arrow, _ref8, _slotProps$arrow2;
  const props = useThemeProps({
    props: inProps,
    name: "MuiTooltip"
  });
  const {
    arrow: arrow2 = false,
    children: childrenProp,
    components = {},
    componentsProps = {},
    describeChild = false,
    disableFocusListener = false,
    disableHoverListener = false,
    disableInteractive: disableInteractiveProp = false,
    disableTouchListener = false,
    enterDelay = 100,
    enterNextDelay = 0,
    enterTouchDelay = 700,
    followCursor = false,
    id: idProp,
    leaveDelay = 0,
    leaveTouchDelay = 1500,
    onClose,
    onOpen,
    open: openProp,
    placement = "bottom",
    PopperComponent: PopperComponentProp,
    PopperProps = {},
    slotProps = {},
    slots = {},
    title,
    TransitionComponent: TransitionComponentProp = Grow,
    TransitionProps
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$7);
  const children = /* @__PURE__ */ reactExports.isValidElement(childrenProp) ? childrenProp : /* @__PURE__ */ jsxRuntimeExports.jsx("span", {
    children: childrenProp
  });
  const theme = useTheme$1();
  const isRtl = theme.direction === "rtl";
  const [childNode, setChildNode] = reactExports.useState();
  const [arrowRef, setArrowRef] = reactExports.useState(null);
  const ignoreNonTouchEvents = reactExports.useRef(false);
  const disableInteractive = disableInteractiveProp || followCursor;
  const closeTimer = reactExports.useRef();
  const enterTimer = reactExports.useRef();
  const leaveTimer = reactExports.useRef();
  const touchTimer = reactExports.useRef();
  const [openState, setOpenState] = useControlled({
    controlled: openProp,
    default: false,
    name: "Tooltip",
    state: "open"
  });
  let open = openState;
  const id = useId(idProp);
  const prevUserSelect = reactExports.useRef();
  const stopTouchInteraction = reactExports.useCallback(() => {
    if (prevUserSelect.current !== void 0) {
      document.body.style.WebkitUserSelect = prevUserSelect.current;
      prevUserSelect.current = void 0;
    }
    clearTimeout(touchTimer.current);
  }, []);
  reactExports.useEffect(() => {
    return () => {
      clearTimeout(closeTimer.current);
      clearTimeout(enterTimer.current);
      clearTimeout(leaveTimer.current);
      stopTouchInteraction();
    };
  }, [stopTouchInteraction]);
  const handleOpen = (event) => {
    clearTimeout(hystersisTimer);
    hystersisOpen = true;
    setOpenState(true);
    if (onOpen && !open) {
      onOpen(event);
    }
  };
  const handleClose = useEventCallback$1(
    /**
     * @param {React.SyntheticEvent | Event} event
     */
    (event) => {
      clearTimeout(hystersisTimer);
      hystersisTimer = setTimeout(() => {
        hystersisOpen = false;
      }, 800 + leaveDelay);
      setOpenState(false);
      if (onClose && open) {
        onClose(event);
      }
      clearTimeout(closeTimer.current);
      closeTimer.current = setTimeout(() => {
        ignoreNonTouchEvents.current = false;
      }, theme.transitions.duration.shortest);
    }
  );
  const handleEnter = (event) => {
    if (ignoreNonTouchEvents.current && event.type !== "touchstart") {
      return;
    }
    if (childNode) {
      childNode.removeAttribute("title");
    }
    clearTimeout(enterTimer.current);
    clearTimeout(leaveTimer.current);
    if (enterDelay || hystersisOpen && enterNextDelay) {
      enterTimer.current = setTimeout(() => {
        handleOpen(event);
      }, hystersisOpen ? enterNextDelay : enterDelay);
    } else {
      handleOpen(event);
    }
  };
  const handleLeave = (event) => {
    clearTimeout(enterTimer.current);
    clearTimeout(leaveTimer.current);
    leaveTimer.current = setTimeout(() => {
      handleClose(event);
    }, leaveDelay);
  };
  const {
    isFocusVisibleRef,
    onBlur: handleBlurVisible,
    onFocus: handleFocusVisible,
    ref: focusVisibleRef
  } = useIsFocusVisible();
  const [, setChildIsFocusVisible] = reactExports.useState(false);
  const handleBlur = (event) => {
    handleBlurVisible(event);
    if (isFocusVisibleRef.current === false) {
      setChildIsFocusVisible(false);
      handleLeave(event);
    }
  };
  const handleFocus = (event) => {
    if (!childNode) {
      setChildNode(event.currentTarget);
    }
    handleFocusVisible(event);
    if (isFocusVisibleRef.current === true) {
      setChildIsFocusVisible(true);
      handleEnter(event);
    }
  };
  const detectTouchStart = (event) => {
    ignoreNonTouchEvents.current = true;
    const childrenProps2 = children.props;
    if (childrenProps2.onTouchStart) {
      childrenProps2.onTouchStart(event);
    }
  };
  const handleMouseOver = handleEnter;
  const handleMouseLeave = handleLeave;
  const handleTouchStart = (event) => {
    detectTouchStart(event);
    clearTimeout(leaveTimer.current);
    clearTimeout(closeTimer.current);
    stopTouchInteraction();
    prevUserSelect.current = document.body.style.WebkitUserSelect;
    document.body.style.WebkitUserSelect = "none";
    touchTimer.current = setTimeout(() => {
      document.body.style.WebkitUserSelect = prevUserSelect.current;
      handleEnter(event);
    }, enterTouchDelay);
  };
  const handleTouchEnd = (event) => {
    if (children.props.onTouchEnd) {
      children.props.onTouchEnd(event);
    }
    stopTouchInteraction();
    clearTimeout(leaveTimer.current);
    leaveTimer.current = setTimeout(() => {
      handleClose(event);
    }, leaveTouchDelay);
  };
  reactExports.useEffect(() => {
    if (!open) {
      return void 0;
    }
    function handleKeyDown(nativeEvent) {
      if (nativeEvent.key === "Escape" || nativeEvent.key === "Esc") {
        handleClose(nativeEvent);
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [handleClose, open]);
  const handleRef = useForkRef$1(children.ref, focusVisibleRef, setChildNode, ref);
  if (!title && title !== 0) {
    open = false;
  }
  const popperRef = reactExports.useRef();
  const handleMouseMove = (event) => {
    const childrenProps2 = children.props;
    if (childrenProps2.onMouseMove) {
      childrenProps2.onMouseMove(event);
    }
    cursorPosition = {
      x: event.clientX,
      y: event.clientY
    };
    if (popperRef.current) {
      popperRef.current.update();
    }
  };
  const nameOrDescProps = {};
  const titleIsString = typeof title === "string";
  if (describeChild) {
    nameOrDescProps.title = !open && titleIsString && !disableHoverListener ? title : null;
    nameOrDescProps["aria-describedby"] = open ? id : null;
  } else {
    nameOrDescProps["aria-label"] = titleIsString ? title : null;
    nameOrDescProps["aria-labelledby"] = open && !titleIsString ? id : null;
  }
  const childrenProps = _extends$1({}, nameOrDescProps, other, children.props, {
    className: clsx$1(other.className, children.props.className),
    onTouchStart: detectTouchStart,
    ref: handleRef
  }, followCursor ? {
    onMouseMove: handleMouseMove
  } : {});
  const interactiveWrapperListeners = {};
  if (!disableTouchListener) {
    childrenProps.onTouchStart = handleTouchStart;
    childrenProps.onTouchEnd = handleTouchEnd;
  }
  if (!disableHoverListener) {
    childrenProps.onMouseOver = composeEventHandler(handleMouseOver, childrenProps.onMouseOver);
    childrenProps.onMouseLeave = composeEventHandler(handleMouseLeave, childrenProps.onMouseLeave);
    if (!disableInteractive) {
      interactiveWrapperListeners.onMouseOver = handleMouseOver;
      interactiveWrapperListeners.onMouseLeave = handleMouseLeave;
    }
  }
  if (!disableFocusListener) {
    childrenProps.onFocus = composeEventHandler(handleFocus, childrenProps.onFocus);
    childrenProps.onBlur = composeEventHandler(handleBlur, childrenProps.onBlur);
    if (!disableInteractive) {
      interactiveWrapperListeners.onFocus = handleFocus;
      interactiveWrapperListeners.onBlur = handleBlur;
    }
  }
  const popperOptions = reactExports.useMemo(() => {
    var _PopperProps$popperOp;
    let tooltipModifiers = [{
      name: "arrow",
      enabled: Boolean(arrowRef),
      options: {
        element: arrowRef,
        padding: 4
      }
    }];
    if ((_PopperProps$popperOp = PopperProps.popperOptions) != null && _PopperProps$popperOp.modifiers) {
      tooltipModifiers = tooltipModifiers.concat(PopperProps.popperOptions.modifiers);
    }
    return _extends$1({}, PopperProps.popperOptions, {
      modifiers: tooltipModifiers
    });
  }, [arrowRef, PopperProps]);
  const ownerState = _extends$1({}, props, {
    isRtl,
    arrow: arrow2,
    disableInteractive,
    placement,
    PopperComponentProp,
    touch: ignoreNonTouchEvents.current
  });
  const classes2 = useUtilityClasses$4(ownerState);
  const PopperComponent = (_ref = (_slots$popper = slots.popper) != null ? _slots$popper : components.Popper) != null ? _ref : TooltipPopper;
  const TransitionComponent = (_ref2 = (_ref3 = (_slots$transition = slots.transition) != null ? _slots$transition : components.Transition) != null ? _ref3 : TransitionComponentProp) != null ? _ref2 : Grow;
  const TooltipComponent = (_ref4 = (_slots$tooltip = slots.tooltip) != null ? _slots$tooltip : components.Tooltip) != null ? _ref4 : TooltipTooltip;
  const ArrowComponent = (_ref5 = (_slots$arrow = slots.arrow) != null ? _slots$arrow : components.Arrow) != null ? _ref5 : TooltipArrow;
  const popperProps = appendOwnerState(PopperComponent, _extends$1({}, PopperProps, (_slotProps$popper = slotProps.popper) != null ? _slotProps$popper : componentsProps.popper, {
    className: clsx$1(classes2.popper, PopperProps == null ? void 0 : PopperProps.className, (_ref6 = (_slotProps$popper2 = slotProps.popper) != null ? _slotProps$popper2 : componentsProps.popper) == null ? void 0 : _ref6.className)
  }), ownerState);
  const transitionProps = appendOwnerState(TransitionComponent, _extends$1({}, TransitionProps, (_slotProps$transition = slotProps.transition) != null ? _slotProps$transition : componentsProps.transition), ownerState);
  const tooltipProps = appendOwnerState(TooltipComponent, _extends$1({}, (_slotProps$tooltip = slotProps.tooltip) != null ? _slotProps$tooltip : componentsProps.tooltip, {
    className: clsx$1(classes2.tooltip, (_ref7 = (_slotProps$tooltip2 = slotProps.tooltip) != null ? _slotProps$tooltip2 : componentsProps.tooltip) == null ? void 0 : _ref7.className)
  }), ownerState);
  const tooltipArrowProps = appendOwnerState(ArrowComponent, _extends$1({}, (_slotProps$arrow = slotProps.arrow) != null ? _slotProps$arrow : componentsProps.arrow, {
    className: clsx$1(classes2.arrow, (_ref8 = (_slotProps$arrow2 = slotProps.arrow) != null ? _slotProps$arrow2 : componentsProps.arrow) == null ? void 0 : _ref8.className)
  }), ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, {
    children: [/* @__PURE__ */ reactExports.cloneElement(children, childrenProps), /* @__PURE__ */ jsxRuntimeExports.jsx(PopperComponent, _extends$1({
      as: PopperComponentProp != null ? PopperComponentProp : MUIPopper,
      placement,
      anchorEl: followCursor ? {
        getBoundingClientRect: () => ({
          top: cursorPosition.y,
          left: cursorPosition.x,
          right: cursorPosition.x,
          bottom: cursorPosition.y,
          width: 0,
          height: 0
        })
      } : childNode,
      popperRef,
      open: childNode ? open : false,
      id,
      transition: true
    }, interactiveWrapperListeners, popperProps, {
      popperOptions,
      children: ({
        TransitionProps: TransitionPropsInner
      }) => /* @__PURE__ */ jsxRuntimeExports.jsx(TransitionComponent, _extends$1({
        timeout: theme.transitions.duration.shorter
      }, TransitionPropsInner, transitionProps, {
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TooltipComponent, _extends$1({}, tooltipProps, {
          children: [title, arrow2 ? /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowComponent, _extends$1({}, tooltipArrowProps, {
            ref: setArrowRef
          })) : null]
        }))
      }))
    }))]
  });
});
const Tooltip$1 = Tooltip;
const _excluded$6 = ["sortingOrder"];
const GridColumnUnsortedIcon = /* @__PURE__ */ reactExports.memo(function GridColumnHeaderSortIcon2(props) {
  const {
    sortingOrder
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$6);
  const rootProps = useGridRootProps();
  const [nextSortDirection] = sortingOrder;
  const Icon = nextSortDirection === "asc" ? rootProps.slots.columnSortedAscendingIcon : rootProps.slots.columnSortedDescendingIcon;
  return Icon ? /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, _extends$1({}, other)) : null;
});
const _excluded$5 = ["native"];
function MUISelectOption(_ref) {
  let {
    native
  } = _ref, props = _objectWithoutPropertiesLoose$1(_ref, _excluded$5);
  if (native) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("option", _extends$1({}, props));
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(MUIMenuItem, _extends$1({}, props));
}
const iconSlots = {
  BooleanCellTrueIcon: GridCheckIcon,
  BooleanCellFalseIcon: GridCloseIcon,
  ColumnMenuIcon: GridTripleDotsVerticalIcon,
  OpenFilterButtonIcon: GridFilterListIcon,
  FilterPanelDeleteIcon: GridCloseIcon,
  ColumnFilteredIcon: GridFilterAltIcon,
  ColumnSelectorIcon: GridColumnIcon,
  ColumnUnsortedIcon: GridColumnUnsortedIcon,
  ColumnSortedAscendingIcon: GridArrowUpwardIcon,
  ColumnSortedDescendingIcon: GridArrowDownwardIcon,
  ColumnResizeIcon: GridSeparatorIcon,
  DensityCompactIcon: GridViewHeadlineIcon,
  DensityStandardIcon: GridTableRowsIcon,
  DensityComfortableIcon: GridViewStreamIcon,
  ExportIcon: GridSaveAltIcon,
  MoreActionsIcon: GridMoreVertIcon,
  TreeDataCollapseIcon: GridExpandMoreIcon,
  TreeDataExpandIcon: GridKeyboardArrowRight,
  GroupingCriteriaCollapseIcon: GridExpandMoreIcon,
  GroupingCriteriaExpandIcon: GridKeyboardArrowRight,
  DetailPanelExpandIcon: GridAddIcon,
  DetailPanelCollapseIcon: GridRemoveIcon,
  RowReorderIcon: GridDragIcon,
  QuickFilterIcon: GridSearchIcon,
  QuickFilterClearIcon: GridCloseIcon,
  ColumnMenuHideIcon: GridVisibilityOffIcon,
  ColumnMenuSortAscendingIcon: GridArrowUpwardIcon,
  ColumnMenuSortDescendingIcon: GridArrowDownwardIcon,
  ColumnMenuFilterIcon: GridFilterAltIcon,
  ColumnMenuManageColumnsIcon: GridViewColumnIcon,
  ColumnMenuClearIcon: GridClearIcon,
  LoadIcon: GridLoadIcon,
  FilterPanelAddIcon: GridAddIcon,
  FilterPanelRemoveAllIcon: GridDeleteForeverIcon,
  ColumnReorderIcon: GridDragIcon
};
const materialSlots = _extends$1({}, iconSlots, {
  BaseCheckbox: MUICheckbox,
  BaseTextField: TextField,
  BaseFormControl: MUIFormControl,
  BaseSelect: MUISelect,
  BaseSwitch: MUISwitch,
  BaseButton: Button,
  BaseIconButton: IconButton$1,
  BaseInputAdornment: MUIInputAdornment,
  BaseTooltip: Tooltip$1,
  BasePopper: MUIPopper,
  BaseInputLabel: MUIInputLabel,
  BaseSelectOption: MUISelectOption,
  BaseChip: MUIChip
});
const materialSlots$1 = materialSlots;
const DATA_GRID_DEFAULT_SLOTS_COMPONENTS = _extends$1({}, materialSlots$1, {
  Cell: MemoizedGridCellV7,
  SkeletonCell: GridSkeletonCell,
  ColumnHeaderFilterIconButton: GridColumnHeaderFilterIconButton,
  ColumnMenu: GridColumnMenu,
  ColumnHeaders: MemoizedGridColumnHeaders,
  Footer: GridFooter,
  FooterRowCount: GridRowCount,
  Toolbar: null,
  PreferencesPanel: GridPreferencesPanel,
  LoadingOverlay: GridLoadingOverlay,
  NoResultsOverlay: GridNoResultsOverlay,
  NoRowsOverlay: GridNoRowsOverlay,
  Pagination: GridPagination,
  FilterPanel: GridFilterPanel,
  ColumnsPanel: GridColumnsPanel,
  Panel: GridPanel,
  Row: MemoizedGridRow
});
const uncapitalizeObjectKeys = (capitalizedObject) => {
  if (capitalizedObject === void 0) {
    return void 0;
  }
  return Object.keys(capitalizedObject).reduce((acc, key) => _extends$1({}, acc, {
    [`${key.charAt(0).toLowerCase()}${key.slice(1)}`]: capitalizedObject[key]
  }), {});
};
function computeSlots({
  defaultSlots: defaultSlots2,
  slots,
  components
}) {
  const overrides = slots != null ? slots : components ? uncapitalizeObjectKeys(components) : null;
  if (!overrides || Object.keys(overrides).length === 0) {
    return defaultSlots2;
  }
  return _extends$1({}, defaultSlots2, overrides);
}
const _excluded$4 = ["components", "componentsProps"];
function groupForwardedProps(props) {
  var _props$forwardedProps;
  const keys = Object.keys(props);
  if (!keys.some((key) => key.startsWith("aria-") || key.startsWith("data-"))) {
    return props;
  }
  const newProps = {};
  const forwardedProps = (_props$forwardedProps = props.forwardedProps) != null ? _props$forwardedProps : {};
  for (let i2 = 0; i2 < keys.length; i2 += 1) {
    const key = keys[i2];
    if (key.startsWith("aria-") || key.startsWith("data-")) {
      forwardedProps[key] = props[key];
    } else {
      newProps[key] = props[key];
    }
  }
  newProps.forwardedProps = forwardedProps;
  return newProps;
}
function useProps(allProps) {
  return reactExports.useMemo(() => {
    const {
      components,
      componentsProps
    } = allProps, themedProps = _objectWithoutPropertiesLoose$1(allProps, _excluded$4);
    return [components, componentsProps, groupForwardedProps(themedProps)];
  }, [allProps]);
}
const DATA_GRID_FORCED_PROPS = {
  disableMultipleColumnsFiltering: true,
  disableMultipleColumnsSorting: true,
  disableMultipleRowSelection: true,
  throttleRowsMs: void 0,
  hideFooterRowCount: false,
  pagination: true,
  checkboxSelectionVisibleOnly: false,
  disableColumnReorder: true,
  disableColumnResize: true,
  keepColumnPositionIfDraggedOutside: false,
  signature: "DataGrid"
};
const DATA_GRID_PROPS_DEFAULT_VALUES = {
  autoHeight: false,
  autoPageSize: false,
  checkboxSelection: false,
  checkboxSelectionVisibleOnly: false,
  columnBuffer: 3,
  rowBuffer: 3,
  columnThreshold: 3,
  rowThreshold: 3,
  rowSelection: true,
  density: "standard",
  disableColumnFilter: false,
  disableColumnMenu: false,
  disableColumnSelector: false,
  disableDensitySelector: false,
  disableEval: false,
  disableMultipleColumnsFiltering: false,
  disableMultipleRowSelection: false,
  disableMultipleColumnsSorting: false,
  disableRowSelectionOnClick: false,
  disableVirtualization: false,
  editMode: GridEditModes.Cell,
  filterMode: "client",
  filterDebounceMs: 150,
  columnHeaderHeight: 56,
  hideFooter: false,
  hideFooterPagination: false,
  hideFooterRowCount: false,
  hideFooterSelectedRowCount: false,
  logger: console,
  logLevel: "error",
  pagination: false,
  paginationMode: "client",
  rowHeight: 52,
  pageSizeOptions: [25, 50, 100],
  rowSpacingType: "margin",
  showCellVerticalBorder: false,
  showColumnVerticalBorder: false,
  sortingOrder: ["asc", "desc", null],
  sortingMode: "client",
  throttleRowsMs: 0,
  disableColumnReorder: false,
  disableColumnResize: false,
  keepNonExistentRowsSelected: false,
  keepColumnPositionIfDraggedOutside: false,
  unstable_ignoreValueFormatterDuringExport: false,
  clipboardCopyCellDelimiter: "	"
};
const defaultSlots = uncapitalizeObjectKeys(DATA_GRID_DEFAULT_SLOTS_COMPONENTS);
const useDataGridProps = (inProps) => {
  const [components, componentsProps, themedProps] = useProps(useThemeProps({
    props: inProps,
    name: "MuiDataGrid"
  }));
  const localeText = reactExports.useMemo(() => _extends$1({}, GRID_DEFAULT_LOCALE_TEXT, themedProps.localeText), [themedProps.localeText]);
  const slots = reactExports.useMemo(() => computeSlots({
    defaultSlots,
    slots: themedProps.slots,
    components
  }), [components, themedProps.slots]);
  return reactExports.useMemo(() => {
    var _themedProps$slotProp;
    return _extends$1({}, DATA_GRID_PROPS_DEFAULT_VALUES, themedProps, {
      localeText,
      slots,
      slotProps: (_themedProps$slotProp = themedProps.slotProps) != null ? _themedProps$slotProp : componentsProps
    }, DATA_GRID_FORCED_PROPS);
  }, [themedProps, localeText, slots, componentsProps]);
};
const rowsMetaStateInitializer = (state) => _extends$1({}, state, {
  rowsMeta: {
    currentPageTotalHeight: 0,
    positions: []
  }
});
const getValidRowHeight = (rowHeightProp, defaultRowHeight, warningMessage) => {
  if (typeof rowHeightProp === "number" && rowHeightProp > 0) {
    return rowHeightProp;
  }
  return defaultRowHeight;
};
const useGridRowsMeta = (apiRef2, props) => {
  const {
    getRowHeight: getRowHeightProp,
    getRowSpacing,
    getEstimatedRowHeight
  } = props;
  const rowsHeightLookup = reactExports.useRef(/* @__PURE__ */ Object.create(null));
  const lastMeasuredRowIndex = reactExports.useRef(-1);
  const hasRowWithAutoHeight = reactExports.useRef(false);
  const densityFactor = useGridSelector(apiRef2, gridDensityFactorSelector);
  const filterModel2 = useGridSelector(apiRef2, gridFilterModelSelector);
  const paginationState = useGridSelector(apiRef2, gridPaginationSelector);
  const sortModel = useGridSelector(apiRef2, gridSortModelSelector);
  const currentPage = useGridVisibleRows(apiRef2, props);
  const pinnedRows = useGridSelector(apiRef2, gridPinnedRowsSelector);
  const validRowHeight = getValidRowHeight(props.rowHeight, DATA_GRID_PROPS_DEFAULT_VALUES.rowHeight);
  const rowHeight = Math.floor(validRowHeight * densityFactor);
  const hydrateRowsMeta = reactExports.useCallback(() => {
    var _pinnedRows$top, _pinnedRows$bottom;
    hasRowWithAutoHeight.current = false;
    const calculateRowProcessedSizes = (row) => {
      if (!rowsHeightLookup.current[row.id]) {
        rowsHeightLookup.current[row.id] = {
          sizes: {
            baseCenter: rowHeight
          },
          isResized: false,
          autoHeight: false,
          needsFirstMeasurement: true
          // Assume all rows will need to be measured by default
        };
      }
      const {
        isResized,
        needsFirstMeasurement,
        sizes
      } = rowsHeightLookup.current[row.id];
      let baseRowHeight = typeof rowHeight === "number" && rowHeight > 0 ? rowHeight : 52;
      const existingBaseRowHeight = sizes.baseCenter;
      if (isResized) {
        baseRowHeight = existingBaseRowHeight;
      } else if (getRowHeightProp) {
        const rowHeightFromUser = getRowHeightProp(_extends$1({}, row, {
          densityFactor
        }));
        if (rowHeightFromUser === "auto") {
          if (needsFirstMeasurement) {
            const estimatedRowHeight = getEstimatedRowHeight ? getEstimatedRowHeight(_extends$1({}, row, {
              densityFactor
            })) : rowHeight;
            baseRowHeight = estimatedRowHeight != null ? estimatedRowHeight : rowHeight;
          } else {
            baseRowHeight = existingBaseRowHeight;
          }
          hasRowWithAutoHeight.current = true;
          rowsHeightLookup.current[row.id].autoHeight = true;
        } else {
          baseRowHeight = getValidRowHeight(rowHeightFromUser, rowHeight);
          rowsHeightLookup.current[row.id].needsFirstMeasurement = false;
          rowsHeightLookup.current[row.id].autoHeight = false;
        }
      } else {
        rowsHeightLookup.current[row.id].needsFirstMeasurement = false;
      }
      const initialHeights = {};
      for (const key in sizes) {
        if (/^base[A-Z]/.test(key)) {
          initialHeights[key] = sizes[key];
        }
      }
      initialHeights.baseCenter = baseRowHeight;
      if (getRowSpacing) {
        var _spacing$top, _spacing$bottom;
        const indexRelativeToCurrentPage = apiRef2.current.getRowIndexRelativeToVisibleRows(row.id);
        const spacing = getRowSpacing(_extends$1({}, row, {
          isFirstVisible: indexRelativeToCurrentPage === 0,
          isLastVisible: indexRelativeToCurrentPage === currentPage.rows.length - 1,
          indexRelativeToCurrentPage
        }));
        initialHeights.spacingTop = (_spacing$top = spacing.top) != null ? _spacing$top : 0;
        initialHeights.spacingBottom = (_spacing$bottom = spacing.bottom) != null ? _spacing$bottom : 0;
      }
      const processedSizes = apiRef2.current.unstable_applyPipeProcessors("rowHeight", initialHeights, row);
      rowsHeightLookup.current[row.id].sizes = processedSizes;
      return processedSizes;
    };
    const positions = [];
    const currentPageTotalHeight = currentPage.rows.reduce((acc, row) => {
      positions.push(acc);
      let maximumBaseSize = 0;
      let otherSizes = 0;
      const processedSizes = calculateRowProcessedSizes(row);
      for (const key in processedSizes) {
        const value = processedSizes[key];
        if (/^base[A-Z]/.test(key)) {
          maximumBaseSize = value > maximumBaseSize ? value : maximumBaseSize;
        } else {
          otherSizes += value;
        }
      }
      return acc + maximumBaseSize + otherSizes;
    }, 0);
    pinnedRows == null || (_pinnedRows$top = pinnedRows.top) == null || _pinnedRows$top.forEach((row) => {
      calculateRowProcessedSizes(row);
    });
    pinnedRows == null || (_pinnedRows$bottom = pinnedRows.bottom) == null || _pinnedRows$bottom.forEach((row) => {
      calculateRowProcessedSizes(row);
    });
    apiRef2.current.setState((state) => {
      return _extends$1({}, state, {
        rowsMeta: {
          currentPageTotalHeight,
          positions
        }
      });
    });
    if (!hasRowWithAutoHeight.current) {
      lastMeasuredRowIndex.current = Infinity;
    }
    apiRef2.current.forceUpdate();
  }, [apiRef2, currentPage.rows, rowHeight, getRowHeightProp, getRowSpacing, getEstimatedRowHeight, pinnedRows, densityFactor]);
  const getRowHeight = reactExports.useCallback((rowId) => {
    const height = rowsHeightLookup.current[rowId];
    return height ? height.sizes.baseCenter : rowHeight;
  }, [rowHeight]);
  const getRowInternalSizes = (rowId) => {
    var _rowsHeightLookup$cur;
    return (_rowsHeightLookup$cur = rowsHeightLookup.current[rowId]) == null ? void 0 : _rowsHeightLookup$cur.sizes;
  };
  const setRowHeight = reactExports.useCallback((id, height) => {
    rowsHeightLookup.current[id].sizes.baseCenter = height;
    rowsHeightLookup.current[id].isResized = true;
    rowsHeightLookup.current[id].needsFirstMeasurement = false;
    hydrateRowsMeta();
  }, [hydrateRowsMeta]);
  const debouncedHydrateRowsMeta = reactExports.useMemo(() => debounce$2(hydrateRowsMeta), [hydrateRowsMeta]);
  const storeMeasuredRowHeight = reactExports.useCallback((id, height, position) => {
    if (!rowsHeightLookup.current[id] || !rowsHeightLookup.current[id].autoHeight) {
      return;
    }
    const needsHydration = rowsHeightLookup.current[id].sizes[`base${capitalize(position)}`] !== height;
    rowsHeightLookup.current[id].needsFirstMeasurement = false;
    rowsHeightLookup.current[id].sizes[`base${capitalize(position)}`] = height;
    if (needsHydration) {
      debouncedHydrateRowsMeta();
    }
  }, [debouncedHydrateRowsMeta]);
  const rowHasAutoHeight = reactExports.useCallback((id) => {
    var _rowsHeightLookup$cur2;
    return ((_rowsHeightLookup$cur2 = rowsHeightLookup.current[id]) == null ? void 0 : _rowsHeightLookup$cur2.autoHeight) || false;
  }, []);
  const getLastMeasuredRowIndex = reactExports.useCallback(() => {
    return lastMeasuredRowIndex.current;
  }, []);
  const setLastMeasuredRowIndex = reactExports.useCallback((index) => {
    if (hasRowWithAutoHeight.current && index > lastMeasuredRowIndex.current) {
      lastMeasuredRowIndex.current = index;
    }
  }, []);
  const resetRowHeights = reactExports.useCallback(() => {
    rowsHeightLookup.current = {};
    hydrateRowsMeta();
  }, [hydrateRowsMeta]);
  reactExports.useEffect(() => {
    hydrateRowsMeta();
  }, [rowHeight, filterModel2, paginationState, sortModel, hydrateRowsMeta]);
  useGridRegisterPipeApplier(apiRef2, "rowHeight", hydrateRowsMeta);
  const rowsMetaApi = {
    unstable_setLastMeasuredRowIndex: setLastMeasuredRowIndex,
    unstable_getRowHeight: getRowHeight,
    unstable_getRowInternalSizes: getRowInternalSizes,
    unstable_setRowHeight: setRowHeight,
    unstable_storeRowHeightMeasurement: storeMeasuredRowHeight,
    resetRowHeights
  };
  const rowsMetaPrivateApi = {
    getLastMeasuredRowIndex,
    rowHasAutoHeight
  };
  useGridApiMethod(apiRef2, rowsMetaApi, "public");
  useGridApiMethod(apiRef2, rowsMetaPrivateApi, "private");
};
const useGridStatePersistence = (apiRef2) => {
  const exportState = reactExports.useCallback((params = {}) => {
    const stateToExport = apiRef2.current.unstable_applyPipeProcessors("exportState", {}, params);
    return stateToExport;
  }, [apiRef2]);
  const restoreState = reactExports.useCallback((stateToRestore) => {
    const response = apiRef2.current.unstable_applyPipeProcessors("restoreState", {
      callbacks: []
    }, {
      stateToRestore
    });
    response.callbacks.forEach((callback) => {
      callback();
    });
    apiRef2.current.forceUpdate();
  }, [apiRef2]);
  const statePersistenceApi = {
    exportState,
    restoreState
  };
  useGridApiMethod(apiRef2, statePersistenceApi, "public");
};
const useGridColumnSpanning = (apiRef2) => {
  const lookup = reactExports.useRef({});
  const setCellColSpanInfo = reactExports.useCallback((rowId, columnIndex, cellColSpanInfo) => {
    const sizes = lookup.current;
    if (!sizes[rowId]) {
      sizes[rowId] = {};
    }
    sizes[rowId][columnIndex] = cellColSpanInfo;
  }, []);
  const getCellColSpanInfo = reactExports.useCallback((rowId, columnIndex) => {
    var _lookup$current$rowId;
    return (_lookup$current$rowId = lookup.current[rowId]) == null ? void 0 : _lookup$current$rowId[columnIndex];
  }, []);
  const calculateCellColSpan = reactExports.useCallback((params) => {
    const {
      columnIndex,
      rowId,
      minFirstColumnIndex,
      maxLastColumnIndex,
      columns
    } = params;
    const columnsLength = columns.length;
    const column = columns[columnIndex];
    const colSpan = typeof column.colSpan === "function" ? column.colSpan(apiRef2.current.getCellParams(rowId, column.field)) : column.colSpan;
    if (!colSpan || colSpan === 1) {
      setCellColSpanInfo(rowId, columnIndex, {
        spannedByColSpan: false,
        cellProps: {
          colSpan: 1,
          width: column.computedWidth
        }
      });
      return {
        colSpan: 1
      };
    }
    let width = column.computedWidth;
    for (let j = 1; j < colSpan; j += 1) {
      const nextColumnIndex = columnIndex + j;
      if (nextColumnIndex >= minFirstColumnIndex && nextColumnIndex < maxLastColumnIndex) {
        const nextColumn = columns[nextColumnIndex];
        width += nextColumn.computedWidth;
        setCellColSpanInfo(rowId, columnIndex + j, {
          spannedByColSpan: true,
          rightVisibleCellIndex: Math.min(columnIndex + colSpan, columnsLength - 1),
          leftVisibleCellIndex: columnIndex
        });
      }
      setCellColSpanInfo(rowId, columnIndex, {
        spannedByColSpan: false,
        cellProps: {
          colSpan,
          width
        }
      });
    }
    return {
      colSpan
    };
  }, [apiRef2, setCellColSpanInfo]);
  const calculateColSpan = reactExports.useCallback(({
    rowId,
    minFirstColumn,
    maxLastColumn,
    columns
  }) => {
    for (let i2 = minFirstColumn; i2 < maxLastColumn; i2 += 1) {
      const cellProps = calculateCellColSpan({
        columnIndex: i2,
        rowId,
        minFirstColumnIndex: minFirstColumn,
        maxLastColumnIndex: maxLastColumn,
        columns
      });
      if (cellProps.colSpan > 1) {
        i2 += cellProps.colSpan - 1;
      }
    }
  }, [calculateCellColSpan]);
  const columnSpanningPublicApi = {
    unstable_getCellColSpanInfo: getCellColSpanInfo
  };
  const columnSpanningPrivateApi = {
    calculateColSpan
  };
  useGridApiMethod(apiRef2, columnSpanningPublicApi, "public");
  useGridApiMethod(apiRef2, columnSpanningPrivateApi, "private");
  const handleColumnReorderChange = reactExports.useCallback(() => {
    lookup.current = {};
  }, []);
  useGridApiEventHandler(apiRef2, "columnOrderChange", handleColumnReorderChange);
};
const recurrentUnwrapGroupingColumnModel = (columnGroupNode, parents, unwrappedGroupingModelToComplete) => {
  if (isLeaf(columnGroupNode)) {
    if (unwrappedGroupingModelToComplete[columnGroupNode.field] !== void 0) {
      throw new Error([`MUI: columnGroupingModel contains duplicated field`, `column field ${columnGroupNode.field} occurs two times in the grouping model:`, `- ${unwrappedGroupingModelToComplete[columnGroupNode.field].join(" > ")}`, `- ${parents.join(" > ")}`].join("\n"));
    }
    unwrappedGroupingModelToComplete[columnGroupNode.field] = parents;
    return;
  }
  const {
    groupId,
    children
  } = columnGroupNode;
  children.forEach((child) => {
    recurrentUnwrapGroupingColumnModel(child, [...parents, groupId], unwrappedGroupingModelToComplete);
  });
};
const unwrapGroupingColumnModel = (columnGroupingModel) => {
  if (!columnGroupingModel) {
    return {};
  }
  const unwrappedSubTree = {};
  columnGroupingModel.forEach((columnGroupNode) => {
    recurrentUnwrapGroupingColumnModel(columnGroupNode, [], unwrappedSubTree);
  });
  return unwrappedSubTree;
};
const getColumnGroupsHeaderStructure = (orderedColumns, unwrappedGroupingModel) => {
  const getParents = (field) => {
    var _unwrappedGroupingMod;
    return (_unwrappedGroupingMod = unwrappedGroupingModel[field]) != null ? _unwrappedGroupingMod : [];
  };
  const groupingHeaderStructure = [];
  const maxDepth = Math.max(...orderedColumns.map((field) => getParents(field).length));
  const haveSameParents = (field1, field2, depth) => isDeepEqual(getParents(field1).slice(0, depth + 1), getParents(field2).slice(0, depth + 1));
  for (let depth = 0; depth < maxDepth; depth += 1) {
    const depthStructure = orderedColumns.reduce((structure, newField) => {
      var _getParents$depth;
      const groupId = (_getParents$depth = getParents(newField)[depth]) != null ? _getParents$depth : null;
      if (structure.length === 0) {
        return [{
          columnFields: [newField],
          groupId
        }];
      }
      const lastGroup = structure[structure.length - 1];
      const prevField = lastGroup.columnFields[lastGroup.columnFields.length - 1];
      const prevGroupId = lastGroup.groupId;
      if (prevGroupId !== groupId || !haveSameParents(prevField, newField, depth)) {
        return [...structure, {
          columnFields: [newField],
          groupId
        }];
      }
      return [...structure.slice(0, structure.length - 1), {
        columnFields: [...lastGroup.columnFields, newField],
        groupId
      }];
    }, []);
    groupingHeaderStructure.push(depthStructure);
  }
  return groupingHeaderStructure;
};
const _excluded$3 = ["groupId", "children"];
const createGroupLookup = (columnGroupingModel) => {
  let groupLookup = {};
  columnGroupingModel.forEach((node) => {
    if (isLeaf(node)) {
      return;
    }
    const {
      groupId,
      children
    } = node, other = _objectWithoutPropertiesLoose$1(node, _excluded$3);
    if (!groupId) {
      throw new Error("MUI: An element of the columnGroupingModel does not have either `field` or `groupId`.");
    }
    if (!children) {
      console.warn(`MUI: group groupId=${groupId} has no children.`);
    }
    const groupParam = _extends$1({}, other, {
      groupId
    });
    const subTreeLookup = createGroupLookup(children);
    if (subTreeLookup[groupId] !== void 0 || groupLookup[groupId] !== void 0) {
      throw new Error(`MUI: The groupId ${groupId} is used multiple times in the columnGroupingModel.`);
    }
    groupLookup = _extends$1({}, groupLookup, subTreeLookup, {
      [groupId]: groupParam
    });
  });
  return _extends$1({}, groupLookup);
};
const columnGroupsStateInitializer = (state, props, apiRef2) => {
  var _props$experimentalFe, _props$columnGrouping, _props$columnGrouping2;
  if (!((_props$experimentalFe = props.experimentalFeatures) != null && _props$experimentalFe.columnGrouping)) {
    return state;
  }
  const columnFields = gridColumnFieldsSelector(apiRef2);
  const visibleColumnFields = gridVisibleColumnFieldsSelector(apiRef2);
  const groupLookup = createGroupLookup((_props$columnGrouping = props.columnGroupingModel) != null ? _props$columnGrouping : []);
  const unwrappedGroupingModel = unwrapGroupingColumnModel((_props$columnGrouping2 = props.columnGroupingModel) != null ? _props$columnGrouping2 : []);
  const columnGroupsHeaderStructure = getColumnGroupsHeaderStructure(columnFields, unwrappedGroupingModel);
  const maxDepth = visibleColumnFields.length === 0 ? 0 : Math.max(...visibleColumnFields.map((field) => {
    var _unwrappedGroupingMod, _unwrappedGroupingMod2;
    return (_unwrappedGroupingMod = (_unwrappedGroupingMod2 = unwrappedGroupingModel[field]) == null ? void 0 : _unwrappedGroupingMod2.length) != null ? _unwrappedGroupingMod : 0;
  }));
  return _extends$1({}, state, {
    columnGrouping: {
      lookup: groupLookup,
      unwrappedGroupingModel,
      headerStructure: columnGroupsHeaderStructure,
      maxDepth
    }
  });
};
const useGridColumnGrouping = (apiRef2, props) => {
  var _props$experimentalFe3;
  const getColumnGroupPath = reactExports.useCallback((field) => {
    var _unwrappedGroupingMod3;
    const unwrappedGroupingModel = gridColumnGroupsUnwrappedModelSelector(apiRef2);
    return (_unwrappedGroupingMod3 = unwrappedGroupingModel[field]) != null ? _unwrappedGroupingMod3 : [];
  }, [apiRef2]);
  const getAllGroupDetails = reactExports.useCallback(() => {
    const columnGroupLookup = gridColumnGroupsLookupSelector(apiRef2);
    return columnGroupLookup;
  }, [apiRef2]);
  const columnGroupingApi = {
    unstable_getColumnGroupPath: getColumnGroupPath,
    unstable_getAllGroupDetails: getAllGroupDetails
  };
  useGridApiMethod(apiRef2, columnGroupingApi, "public");
  const handleColumnIndexChange = reactExports.useCallback(() => {
    var _props$columnGrouping3;
    const unwrappedGroupingModel = unwrapGroupingColumnModel((_props$columnGrouping3 = props.columnGroupingModel) != null ? _props$columnGrouping3 : []);
    apiRef2.current.setState((state) => {
      var _state$columns$ordere, _state$columns;
      const orderedFields = (_state$columns$ordere = (_state$columns = state.columns) == null ? void 0 : _state$columns.orderedFields) != null ? _state$columns$ordere : [];
      const columnGroupsHeaderStructure = getColumnGroupsHeaderStructure(orderedFields, unwrappedGroupingModel);
      return _extends$1({}, state, {
        columnGrouping: _extends$1({}, state.columnGrouping, {
          headerStructure: columnGroupsHeaderStructure
        })
      });
    });
  }, [apiRef2, props.columnGroupingModel]);
  const updateColumnGroupingState = reactExports.useCallback((columnGroupingModel) => {
    var _props$experimentalFe2;
    if (!((_props$experimentalFe2 = props.experimentalFeatures) != null && _props$experimentalFe2.columnGrouping)) {
      return;
    }
    const columnFields = gridColumnFieldsSelector(apiRef2);
    const visibleColumnFields = gridVisibleColumnFieldsSelector(apiRef2);
    const groupLookup = createGroupLookup(columnGroupingModel != null ? columnGroupingModel : []);
    const unwrappedGroupingModel = unwrapGroupingColumnModel(columnGroupingModel != null ? columnGroupingModel : []);
    const columnGroupsHeaderStructure = getColumnGroupsHeaderStructure(columnFields, unwrappedGroupingModel);
    const maxDepth = visibleColumnFields.length === 0 ? 0 : Math.max(...visibleColumnFields.map((field) => {
      var _unwrappedGroupingMod4, _unwrappedGroupingMod5;
      return (_unwrappedGroupingMod4 = (_unwrappedGroupingMod5 = unwrappedGroupingModel[field]) == null ? void 0 : _unwrappedGroupingMod5.length) != null ? _unwrappedGroupingMod4 : 0;
    }));
    apiRef2.current.setState((state) => {
      return _extends$1({}, state, {
        columnGrouping: {
          lookup: groupLookup,
          unwrappedGroupingModel,
          headerStructure: columnGroupsHeaderStructure,
          maxDepth
        }
      });
    });
  }, [apiRef2, (_props$experimentalFe3 = props.experimentalFeatures) == null ? void 0 : _props$experimentalFe3.columnGrouping]);
  useGridApiEventHandler(apiRef2, "columnIndexChange", handleColumnIndexChange);
  useGridApiEventHandler(apiRef2, "columnsChange", () => {
    updateColumnGroupingState(props.columnGroupingModel);
  });
  useGridApiEventHandler(apiRef2, "columnVisibilityModelChange", () => {
    updateColumnGroupingState(props.columnGroupingModel);
  });
  reactExports.useEffect(() => {
    updateColumnGroupingState(props.columnGroupingModel);
  }, [updateColumnGroupingState, props.columnGroupingModel]);
};
const useDataGridComponent = (inputApiRef, props) => {
  const privateApiRef = useGridInitialization(inputApiRef, props);
  useGridRowSelectionPreProcessors(privateApiRef, props);
  useGridRowsPreProcessors(privateApiRef);
  useGridInitializeState(rowSelectionStateInitializer, privateApiRef, props);
  useGridInitializeState(columnsStateInitializer, privateApiRef, props);
  useGridInitializeState(rowsStateInitializer, privateApiRef, props);
  useGridInitializeState(editingStateInitializer, privateApiRef, props);
  useGridInitializeState(focusStateInitializer, privateApiRef, props);
  useGridInitializeState(sortingStateInitializer, privateApiRef, props);
  useGridInitializeState(preferencePanelStateInitializer, privateApiRef, props);
  useGridInitializeState(filterStateInitializer, privateApiRef, props);
  useGridInitializeState(densityStateInitializer, privateApiRef, props);
  useGridInitializeState(paginationStateInitializer, privateApiRef, props);
  useGridInitializeState(rowsMetaStateInitializer, privateApiRef, props);
  useGridInitializeState(columnMenuStateInitializer, privateApiRef, props);
  useGridInitializeState(columnGroupsStateInitializer, privateApiRef, props);
  useGridKeyboardNavigation(privateApiRef, props);
  useGridRowSelection(privateApiRef, props);
  useGridColumns(privateApiRef, props);
  useGridRows(privateApiRef, props);
  useGridParamsApi(privateApiRef, props);
  useGridColumnSpanning(privateApiRef);
  useGridColumnGrouping(privateApiRef, props);
  useGridEditing(privateApiRef, props);
  useGridFocus(privateApiRef, props);
  useGridPreferencesPanel(privateApiRef, props);
  useGridFilter(privateApiRef, props);
  useGridSorting(privateApiRef, props);
  useGridDensity(privateApiRef, props);
  useGridPagination(privateApiRef, props);
  useGridRowsMeta(privateApiRef, props);
  useGridScroll(privateApiRef, props);
  useGridColumnMenu(privateApiRef);
  useGridCsvExport(privateApiRef, props);
  useGridPrintExport(privateApiRef, props);
  useGridClipboard(privateApiRef, props);
  useGridDimensions(privateApiRef, props);
  useGridEvents(privateApiRef, props);
  useGridStatePersistence(privateApiRef);
  return privateApiRef;
};
const useUtilityClasses$3 = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["virtualScroller"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const VirtualScrollerRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "VirtualScroller",
  overridesResolver: (props, styles2) => styles2.virtualScroller
})({
  overflow: "auto",
  height: "100%",
  // See https://github.com/mui/mui-x/issues/4360
  position: "relative",
  "@media print": {
    overflow: "hidden"
  }
});
const GridVirtualScroller = /* @__PURE__ */ reactExports.forwardRef(function GridVirtualScroller2(props, ref) {
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$3(rootProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(VirtualScrollerRoot, _extends$1({
    ref
  }, props, {
    className: clsx$1(classes2.root, props.className),
    ownerState: rootProps
  }));
});
const useUtilityClasses$2 = (props, overflowedContent) => {
  const {
    classes: classes2
  } = props;
  const slots = {
    root: ["virtualScrollerContent", overflowedContent && "virtualScrollerContent--overflowed"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const VirtualScrollerContentRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "VirtualScrollerContent",
  overridesResolver: (props, styles2) => styles2.virtualScrollerContent
})({});
const GridVirtualScrollerContent = /* @__PURE__ */ reactExports.forwardRef(function GridVirtualScrollerContent2(props, ref) {
  var _props$style;
  const rootProps = useGridRootProps();
  const overflowedContent = !rootProps.autoHeight && ((_props$style = props.style) == null ? void 0 : _props$style.minHeight) === "auto";
  const classes2 = useUtilityClasses$2(rootProps, overflowedContent);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(VirtualScrollerContentRoot, _extends$1({
    ref
  }, props, {
    ownerState: rootProps,
    className: clsx$1(classes2.root, props.className)
  }));
});
const _excluded$2 = ["className"];
const useUtilityClasses$1 = (ownerState) => {
  const {
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["virtualScrollerRenderZone"]
  };
  return composeClasses(slots, getDataGridUtilityClass, classes2);
};
const VirtualScrollerRenderZoneRoot = styled("div", {
  name: "MuiDataGrid",
  slot: "VirtualScrollerRenderZone",
  overridesResolver: (props, styles2) => styles2.virtualScrollerRenderZone
})({
  position: "absolute",
  display: "flex",
  // Prevents margin collapsing when using `getRowSpacing`
  flexDirection: "column"
});
const GridVirtualScrollerRenderZone = /* @__PURE__ */ reactExports.forwardRef(function GridVirtualScrollerRenderZone2(props, ref) {
  const {
    className
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$2);
  const rootProps = useGridRootProps();
  const classes2 = useUtilityClasses$1(rootProps);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(VirtualScrollerRenderZoneRoot, _extends$1({
    ref,
    className: clsx$1(classes2.root, className),
    ownerState: rootProps
  }, other));
});
const _excluded$1 = ["className", "disableVirtualization"];
const DataGridVirtualScroller = /* @__PURE__ */ reactExports.forwardRef(function DataGridVirtualScroller2(props, ref) {
  const {
    className,
    disableVirtualization
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded$1);
  const {
    getRootProps,
    getContentProps,
    getRenderZoneProps,
    getRows
  } = useGridVirtualScroller({
    ref,
    disableVirtualization
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(GridVirtualScroller, _extends$1({
    className
  }, getRootProps(other), {
    children: [/* @__PURE__ */ jsxRuntimeExports.jsx(GridOverlays, {}), /* @__PURE__ */ jsxRuntimeExports.jsx(GridVirtualScrollerContent, _extends$1({}, getContentProps(), {
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(GridVirtualScrollerRenderZone, _extends$1({}, getRenderZoneProps(), {
        children: getRows()
      }))
    }))]
  }));
});
const DataGridRaw = /* @__PURE__ */ reactExports.forwardRef(function DataGrid2(inProps, ref) {
  const props = useDataGridProps(inProps);
  const privateApiRef = useDataGridComponent(props.apiRef, props);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(GridContextProvider, {
    privateApiRef,
    props,
    children: /* @__PURE__ */ jsxRuntimeExports.jsxs(GridRoot, _extends$1({
      className: props.className,
      style: props.style,
      sx: props.sx,
      ref
    }, props.forwardedProps, {
      children: [/* @__PURE__ */ jsxRuntimeExports.jsx(GridHeader, {}), /* @__PURE__ */ jsxRuntimeExports.jsx(GridBody, {
        VirtualScrollerComponent: DataGridVirtualScroller
      }), /* @__PURE__ */ jsxRuntimeExports.jsx(GridFooterPlaceholder, {})]
    }))
  });
});
const DataGrid = /* @__PURE__ */ reactExports.memo(DataGridRaw);
DATA_GRID_PROPS_DEFAULT_VALUES.filterDebounceMs;
DATA_GRID_PROPS_DEFAULT_VALUES.filterDebounceMs;
DataGridRaw.propTypes = {
  // ----------------------------- Warning --------------------------------
  // | These PropTypes are generated from the TypeScript type definitions |
  // | To update them edit the TypeScript types and run "yarn proptypes"  |
  // ----------------------------------------------------------------------
  /**
   * The ref object that allows grid manipulation. Can be instantiated with `useGridApiRef()`.
   */
  apiRef: PropTypes.shape({
    current: PropTypes.object.isRequired
  }),
  /**
   * The label of the grid.
   */
  "aria-label": PropTypes.string,
  /**
   * The id of the element containing a label for the grid.
   */
  "aria-labelledby": PropTypes.string,
  /**
   * If `true`, the grid height is dynamic and follow the number of rows in the grid.
   * @default false
   */
  autoHeight: PropTypes.bool,
  /**
   * If `true`, the pageSize is calculated according to the container size and the max number of rows to avoid rendering a vertical scroll bar.
   * @default false
   */
  autoPageSize: PropTypes.bool,
  /**
   * Controls the modes of the cells.
   */
  cellModesModel: PropTypes.object,
  /**
   * If `true`, the grid get a first column with a checkbox that allows to select rows.
   * @default false
   */
  checkboxSelection: PropTypes.bool,
  /**
   * Override or extend the styles applied to the component.
   */
  classes: PropTypes.object,
  /**
   * The character used to separate cell values when copying to the clipboard.
   * @default '\t'
   */
  clipboardCopyCellDelimiter: PropTypes.string,
  /**
   * Number of extra columns to be rendered before/after the visible slice.
   * @default 3
   */
  columnBuffer: PropTypes.number,
  columnGroupingModel: PropTypes.arrayOf(PropTypes.object),
  /**
   * Sets the height in pixel of the column headers in the grid.
   * @default 56
   */
  columnHeaderHeight: PropTypes.number,
  /**
   * Set of columns of type [[GridColDef[]]].
   */
  columns: chainPropTypes(PropTypes.array.isRequired),
  /**
   * Number of rows from the `columnBuffer` that can be visible before a new slice is rendered.
   * @default 3
   */
  columnThreshold: PropTypes.number,
  /**
   * Set the column visibility model of the grid.
   * If defined, the grid will ignore the `hide` property in [[GridColDef]].
   */
  columnVisibilityModel: PropTypes.object,
  /**
   * Overridable components.
   * @deprecated Use `slots` instead.
   */
  components: PropTypes.object,
  /**
   * Overridable components props dynamically passed to the component at rendering.
   * @deprecated Use the `slotProps` prop instead.
   */
  componentsProps: PropTypes.object,
  /**
   * Set the density of the grid.
   * @default "standard"
   */
  density: PropTypes.oneOf(["comfortable", "compact", "standard"]),
  /**
   * If `true`, column filters are disabled.
   * @default false
   */
  disableColumnFilter: PropTypes.bool,
  /**
   * If `true`, the column menu is disabled.
   * @default false
   */
  disableColumnMenu: PropTypes.bool,
  /**
   * If `true`, hiding/showing columns is disabled.
   * @default false
   */
  disableColumnSelector: PropTypes.bool,
  /**
   * If `true`, the density selector is disabled.
   * @default false
   */
  disableDensitySelector: PropTypes.bool,
  /**
   * If `true`, `eval()` is not used for performance optimization.
   * @default false
   * @ignore - do not document
   */
  disableEval: PropTypes.bool,
  /**
   * If `true`, the selection on click on a row or cell is disabled.
   * @default false
   */
  disableRowSelectionOnClick: PropTypes.bool,
  /**
   * If `true`, the virtualization is disabled.
   * @default false
   */
  disableVirtualization: PropTypes.bool,
  /**
   * Controls whether to use the cell or row editing.
   * @default "cell"
   */
  editMode: PropTypes.oneOf(["cell", "row"]),
  /**
   * Unstable features, breaking changes might be introduced.
   * For each feature, if the flag is not explicitly set to `true`, the feature will be fully disabled and any property / method call will not have any effect.
   */
  experimentalFeatures: PropTypes.shape({
    ariaV7: PropTypes.bool,
    columnGrouping: PropTypes.bool,
    warnIfFocusStateIsNotSynced: PropTypes.bool
  }),
  /**
   * The milliseconds delay to wait after a keystroke before triggering filtering.
   * @default 150
   */
  filterDebounceMs: PropTypes.number,
  /**
   * Filtering can be processed on the server or client-side.
   * Set it to 'server' if you would like to handle filtering on the server-side.
   * @default "client"
   */
  filterMode: PropTypes.oneOf(["client", "server"]),
  /**
   * Set the filter model of the grid.
   */
  filterModel: PropTypes.shape({
    items: PropTypes.arrayOf(PropTypes.shape({
      field: PropTypes.string.isRequired,
      id: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
      operator: PropTypes.string.isRequired,
      value: PropTypes.any
    })).isRequired,
    logicOperator: PropTypes.oneOf(["and", "or"]),
    quickFilterExcludeHiddenColumns: PropTypes.bool,
    quickFilterLogicOperator: PropTypes.oneOf(["and", "or"]),
    quickFilterValues: PropTypes.array
  }),
  /**
   * Forwarded props for the grid root element.
   * @ignore - do not document.
   */
  forwardedProps: PropTypes.object,
  /**
   * Function that applies CSS classes dynamically on cells.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @returns {string} The CSS class to apply to the cell.
   */
  getCellClassName: PropTypes.func,
  /**
   * Function that returns the element to render in row detail.
   * @param {GridRowParams} params With all properties from [[GridRowParams]].
   * @returns {React.JSX.Element} The row detail element.
   */
  getDetailPanelContent: PropTypes.func,
  /**
   * Function that returns the estimated height for a row.
   * Only works if dynamic row height is used.
   * Once the row height is measured this value is discarded.
   * @param {GridRowHeightParams} params With all properties from [[GridRowHeightParams]].
   * @returns {number | null} The estimated row height value. If `null` or `undefined` then the default row height, based on the density, is applied.
   */
  getEstimatedRowHeight: PropTypes.func,
  /**
   * Function that applies CSS classes dynamically on rows.
   * @param {GridRowClassNameParams} params With all properties from [[GridRowClassNameParams]].
   * @returns {string} The CSS class to apply to the row.
   */
  getRowClassName: PropTypes.func,
  /**
   * Function that sets the row height per row.
   * @param {GridRowHeightParams} params With all properties from [[GridRowHeightParams]].
   * @returns {GridRowHeightReturnValue} The row height value. If `null` or `undefined` then the default row height is applied. If "auto" then the row height is calculated based on the content.
   */
  getRowHeight: PropTypes.func,
  /**
   * Return the id of a given [[GridRowModel]].
   */
  getRowId: PropTypes.func,
  /**
   * Function that allows to specify the spacing between rows.
   * @param {GridRowSpacingParams} params With all properties from [[GridRowSpacingParams]].
   * @returns {GridRowSpacing} The row spacing values.
   */
  getRowSpacing: PropTypes.func,
  /**
   * If `true`, the footer component is hidden.
   * @default false
   */
  hideFooter: PropTypes.bool,
  /**
   * If `true`, the pagination component in the footer is hidden.
   * @default false
   */
  hideFooterPagination: PropTypes.bool,
  /**
   * If `true`, the selected row count in the footer is hidden.
   * @default false
   */
  hideFooterSelectedRowCount: PropTypes.bool,
  /**
   * The initial state of the DataGrid.
   * The data in it will be set in the state on initialization but will not be controlled.
   * If one of the data in `initialState` is also being controlled, then the control state wins.
   */
  initialState: PropTypes.object,
  /**
   * Callback fired when a cell is rendered, returns true if the cell is editable.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @returns {boolean} A boolean indicating if the cell is editable.
   */
  isCellEditable: PropTypes.func,
  /**
   * Determines if a row can be selected.
   * @param {GridRowParams} params With all properties from [[GridRowParams]].
   * @returns {boolean} A boolean indicating if the cell is selectable.
   */
  isRowSelectable: PropTypes.func,
  /**
   * If `true`, the selection model will retain selected rows that do not exist.
   * Useful when using server side pagination and row selections need to be retained
   * when changing pages.
   * @default false
   */
  keepNonExistentRowsSelected: PropTypes.bool,
  /**
   * If `true`, a  loading overlay is displayed.
   */
  loading: PropTypes.bool,
  /**
   * Set the locale text of the grid.
   * You can find all the translation keys supported in [the source](https://github.com/mui/mui-x/blob/HEAD/packages/grid/x-data-grid/src/constants/localeTextConstants.ts) in the GitHub repository.
   */
  localeText: PropTypes.object,
  /**
   * Pass a custom logger in the components that implements the [[Logger]] interface.
   * @default console
   */
  logger: PropTypes.shape({
    debug: PropTypes.func.isRequired,
    error: PropTypes.func.isRequired,
    info: PropTypes.func.isRequired,
    warn: PropTypes.func.isRequired
  }),
  /**
   * Allows to pass the logging level or false to turn off logging.
   * @default "error" ("warn" in dev mode)
   */
  logLevel: PropTypes.oneOf(["debug", "error", "info", "warn", false]),
  /**
   * Nonce of the inline styles for [Content Security Policy](https://www.w3.org/TR/2016/REC-CSP2-20161215/#script-src-the-nonce-attribute).
   */
  nonce: PropTypes.string,
  /**
   * Callback fired when any cell is clicked.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onCellClick: PropTypes.func,
  /**
   * Callback fired when a double click event comes from a cell element.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onCellDoubleClick: PropTypes.func,
  /**
   * Callback fired when the cell turns to edit mode.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @param {MuiEvent<React.KeyboardEvent | React.MouseEvent>} event The event that caused this prop to be called.
   */
  onCellEditStart: PropTypes.func,
  /**
   * Callback fired when the cell turns to view mode.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @param {MuiEvent<MuiBaseEvent>} event The event that caused this prop to be called.
   */
  onCellEditStop: PropTypes.func,
  /**
   * Callback fired when a keydown event comes from a cell element.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @param {MuiEvent<React.KeyboardEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onCellKeyDown: PropTypes.func,
  /**
   * Callback fired when the `cellModesModel` prop changes.
   * @param {GridCellModesModel} cellModesModel Object containing which cells are in "edit" mode.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onCellModesModelChange: PropTypes.func,
  /**
   * Callback called when the data is copied to the clipboard.
   * @param {string} data The data copied to the clipboard.
   */
  onClipboardCopy: PropTypes.func,
  /**
   * Callback fired when a click event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onColumnHeaderClick: PropTypes.func,
  /**
   * Callback fired when a double click event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onColumnHeaderDoubleClick: PropTypes.func,
  /**
   * Callback fired when a mouse enter event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onColumnHeaderEnter: PropTypes.func,
  /**
   * Callback fired when a mouse leave event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onColumnHeaderLeave: PropTypes.func,
  /**
   * Callback fired when a mouseout event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onColumnHeaderOut: PropTypes.func,
  /**
   * Callback fired when a mouseover event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onColumnHeaderOver: PropTypes.func,
  /**
   * Callback fired when a column is reordered.
   * @param {GridColumnOrderChangeParams} params With all properties from [[GridColumnOrderChangeParams]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onColumnOrderChange: PropTypes.func,
  /**
   * Callback fired when the column visibility model changes.
   * @param {GridColumnVisibilityModel} model The new model.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onColumnVisibilityModelChange: PropTypes.func,
  /**
   * Callback fired when the Filter model changes before the filters are applied.
   * @param {GridFilterModel} model With all properties from [[GridFilterModel]].
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onFilterModelChange: PropTypes.func,
  /**
   * Callback fired when the menu is closed.
   * @param {GridMenuParams} params With all properties from [[GridMenuParams]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onMenuClose: PropTypes.func,
  /**
   * Callback fired when the menu is opened.
   * @param {GridMenuParams} params With all properties from [[GridMenuParams]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onMenuOpen: PropTypes.func,
  /**
   * Callback fired when the pagination model has changed.
   * @param {GridPaginationModel} model Updated pagination model.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onPaginationModelChange: PropTypes.func,
  /**
   * Callback fired when the preferences panel is closed.
   * @param {GridPreferencePanelParams} params With all properties from [[GridPreferencePanelParams]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onPreferencePanelClose: PropTypes.func,
  /**
   * Callback fired when the preferences panel is opened.
   * @param {GridPreferencePanelParams} params With all properties from [[GridPreferencePanelParams]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onPreferencePanelOpen: PropTypes.func,
  /**
   * Callback called when `processRowUpdate` throws an error or rejects.
   * @param {any} error The error thrown.
   */
  onProcessRowUpdateError: PropTypes.func,
  /**
   * Callback fired when the grid is resized.
   * @param {ElementSize} containerSize With all properties from [[ElementSize]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onResize: PropTypes.func,
  /**
   * Callback fired when a row is clicked.
   * Not called if the target clicked is an interactive element added by the built-in columns.
   * @param {GridRowParams} params With all properties from [[GridRowParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onRowClick: PropTypes.func,
  /**
   * Callback fired when a double click event comes from a row container element.
   * @param {GridRowParams} params With all properties from [[RowParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onRowDoubleClick: PropTypes.func,
  /**
   * Callback fired when the row changes are committed.
   * @param {GridRowId} id The row id.
   * @param {MuiEvent<MuiBaseEvent>} event The event that caused this prop to be called.
   */
  onRowEditCommit: PropTypes.func,
  /**
   * Callback fired when the row turns to edit mode.
   * @param {GridRowParams} params With all properties from [[GridRowParams]].
   * @param {MuiEvent<React.KeyboardEvent | React.MouseEvent>} event The event that caused this prop to be called.
   */
  onRowEditStart: PropTypes.func,
  /**
   * Callback fired when the row turns to view mode.
   * @param {GridRowParams} params With all properties from [[GridRowParams]].
   * @param {MuiEvent<MuiBaseEvent>} event The event that caused this prop to be called.
   */
  onRowEditStop: PropTypes.func,
  /**
   * Callback fired when the `rowModesModel` prop changes.
   * @param {GridRowModesModel} rowModesModel Object containing which rows are in "edit" mode.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onRowModesModelChange: PropTypes.func,
  /**
   * Callback fired when the selection state of one or multiple rows changes.
   * @param {GridRowSelectionModel} rowSelectionModel With all the row ids [[GridSelectionModel]].
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onRowSelectionModelChange: PropTypes.func,
  /**
   * Callback fired when the sort model changes before a column is sorted.
   * @param {GridSortModel} model With all properties from [[GridSortModel]].
   * @param {GridCallbackDetails} details Additional details for this callback.
   */
  onSortModelChange: PropTypes.func,
  /**
   * Callback fired when the state of the grid is updated.
   * @param {GridState} state The new state.
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   * @ignore - do not document.
   */
  onStateChange: PropTypes.func,
  /**
   * Select the pageSize dynamically using the component UI.
   * @default [25, 50, 100]
   */
  pageSizeOptions: PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.number, PropTypes.shape({
    label: PropTypes.string.isRequired,
    value: PropTypes.number.isRequired
  })]).isRequired),
  pagination: (props) => {
    if (props.pagination === false) {
      return new Error(["MUI: `<DataGrid pagination={false} />` is not a valid prop.", "Infinite scrolling is not available in the MIT version.", "", "You need to upgrade to DataGridPro or DataGridPremium component to disable the pagination."].join("\n"));
    }
    return null;
  },
  /**
   * Pagination can be processed on the server or client-side.
   * Set it to 'client' if you would like to handle the pagination on the client-side.
   * Set it to 'server' if you would like to handle the pagination on the server-side.
   * @default "client"
   */
  paginationMode: PropTypes.oneOf(["client", "server"]),
  /**
   * The pagination model of type [[GridPaginationModel]] which refers to current `page` and `pageSize`.
   */
  paginationModel: PropTypes.shape({
    page: PropTypes.number.isRequired,
    pageSize: PropTypes.number.isRequired
  }),
  /**
   * Callback called before updating a row with new values in the row and cell editing.
   * @template R
   * @param {R} newRow Row object with the new values.
   * @param {R} oldRow Row object with the old values.
   * @returns {Promise<R> | R} The final values to update the row.
   */
  processRowUpdate: PropTypes.func,
  /**
   * Number of extra rows to be rendered before/after the visible slice.
   * @default 3
   */
  rowBuffer: PropTypes.number,
  /**
   * Set the total number of rows, if it is different from the length of the value `rows` prop.
   * If some rows have children (for instance in the tree data), this number represents the amount of top level rows.
   */
  rowCount: PropTypes.number,
  /**
   * Sets the height in pixel of a row in the grid.
   * @default 52
   */
  rowHeight: PropTypes.number,
  /**
   * Controls the modes of the rows.
   */
  rowModesModel: PropTypes.object,
  /**
   * Set of rows of type [[GridRowsProp]].
   */
  rows: PropTypes.arrayOf(PropTypes.object).isRequired,
  /**
   * If `false`, the row selection mode is disabled.
   * @default true
   */
  rowSelection: PropTypes.bool,
  /**
   * Sets the row selection model of the grid.
   */
  rowSelectionModel: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired), PropTypes.number, PropTypes.string]),
  /**
   * Sets the type of space between rows added by `getRowSpacing`.
   * @default "margin"
   */
  rowSpacingType: PropTypes.oneOf(["border", "margin"]),
  /**
   * Number of rows from the `rowBuffer` that can be visible before a new slice is rendered.
   * @default 3
   */
  rowThreshold: PropTypes.number,
  /**
   * Override the height/width of the grid inner scrollbar.
   */
  scrollbarSize: PropTypes.number,
  /**
   * If `true`, the vertical borders of the cells are displayed.
   * @default false
   */
  showCellVerticalBorder: PropTypes.bool,
  /**
   * If `true`, the right border of the column headers are displayed.
   * @default false
   */
  showColumnVerticalBorder: PropTypes.bool,
  /**
   * Overridable components props dynamically passed to the component at rendering.
   */
  slotProps: PropTypes.object,
  /**
   * Overridable components.
   */
  slots: PropTypes.object,
  /**
   * Sorting can be processed on the server or client-side.
   * Set it to 'client' if you would like to handle sorting on the client-side.
   * Set it to 'server' if you would like to handle sorting on the server-side.
   * @default "client"
   */
  sortingMode: PropTypes.oneOf(["client", "server"]),
  /**
   * The order of the sorting sequence.
   * @default ['asc', 'desc', null]
   */
  sortingOrder: PropTypes.arrayOf(PropTypes.oneOf(["asc", "desc"])),
  /**
   * Set the sort model of the grid.
   */
  sortModel: PropTypes.arrayOf(PropTypes.shape({
    field: PropTypes.string.isRequired,
    sort: PropTypes.oneOf(["asc", "desc"])
  })),
  /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */
  sx: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.func, PropTypes.object, PropTypes.bool])), PropTypes.func, PropTypes.object]),
  /**
   * If `true`, the grid will not use `valueFormatter` when exporting to CSV or copying to clipboard.
   * If an object is provided, you can choose to ignore the `valueFormatter` for CSV export or clipboard export.
   * @default: false
   */
  unstable_ignoreValueFormatterDuringExport: PropTypes.oneOfType([PropTypes.shape({
    clipboardExport: PropTypes.bool,
    csvExport: PropTypes.bool
  }), PropTypes.bool])
};
const OptionContent = () => {
  const dataGridApi = useGridApiRef();
  return /* @__PURE__ */ jsxRuntimeExports.jsx(OptionContentImpl, { dataGridApi });
};
class OptionContentImpl extends reactExports.Component {
  constructor(props) {
    super(props);
    __privateAdd(this, _saveTimeout, void 0);
    __privateAdd(this, _columns, void 0);
    this.state = { rowModesModel: {} };
    this.writeMentions = this.writeMentions.bind(this);
    this.readMentions = this.readMentions.bind(this);
    this.handleSyncStorageChange = this.handleSyncStorageChange.bind(this);
    this.handleEditClick = this.handleEditClick.bind(this);
    this.handleDeleteClick = this.handleDeleteClick.bind(this);
    this.handleCancelClick = this.handleCancelClick.bind(this);
    this.handleSaveClick = this.handleSaveClick.bind(this);
    this.handleRowModesModelChange = this.handleRowModesModelChange.bind(this);
    this.processRowUpdate = this.processRowUpdate.bind(this);
    this.actionsRender = this.actionsRender.bind(this);
  }
  writeMentions() {
    const mentions = JSON.parse(JSON.stringify(this.state.mentions));
    if (__privateGet(this, _saveTimeout))
      clearTimeout(__privateGet(this, _saveTimeout));
    __privateSet(this, _saveTimeout, setTimeout(() => {
      __privateSet(this, _saveTimeout, void 0);
      write$1(mentions).then(() => {
        enqueueSnackbar({ variant: "success", message: i18n("SAVED") });
      });
    }, 250));
  }
  /** chrome.storage.syncのデータを読んで、stateに反映する */
  async readMentions() {
    const mentions = await readAsLenient();
    const changed = this.state.mentions != null && JSON.stringify(this.state.mentions) !== JSON.stringify(mentions);
    if (changed) {
      const api = this.props.dataGridApi.current;
      for (const id of this.state.mentions.map((m) => m.id)) {
        if (api.getRowMode(id) === "edit")
          api.stopRowEditMode({ id, ignoreModifications: true });
      }
    }
    this.setState({ mentions }, () => {
      if (changed)
        enqueueSnackbar({ variant: "info", message: i18n("MENTION_RELOADED") });
    });
  }
  handleSyncStorageChange(changes) {
    if (KEY in changes)
      this.readMentions();
  }
  handleEditClick(id) {
    const next = { ...this.state.rowModesModel, [id]: { mode: GridRowModes.Edit } };
    this.setState({ rowModesModel: next });
  }
  handleDeleteClick(id) {
    var _a;
    const next = (_a = this.state.mentions) == null ? void 0 : _a.filter((m) => m.id !== id);
    this.setState({ mentions: next }, this.writeMentions);
  }
  handleCancelClick(id) {
    const next = { ...this.state.rowModesModel, [id]: { mode: GridRowModes.View, ignoreModifications: true } };
    this.setState({ rowModesModel: next });
  }
  handleSaveClick(id) {
    const next = { ...this.state.rowModesModel, [id]: { mode: GridRowModes.View } };
    this.setState({ rowModesModel: next });
  }
  handleRowModesModelChange(rowModesModel) {
    this.setState({ rowModesModel });
  }
  processRowUpdate(newRow, oldRow) {
    var _a, _b;
    const others = (_a = this.state.mentions) == null ? void 0 : _a.filter((m) => m.id !== newRow.id);
    const canceler = () => {
      const props = { mode: GridRowModes.Edit, fieldToFocus: "env" };
      const next = { ...this.state.rowModesModel, [newRow.id]: props };
      setTimeout(() => this.setState({ rowModesModel: next }), 0);
    };
    if (someEmpty(newRow)) {
      enqueueSnackbar({ variant: "error", message: i18n("NOT_ALLOW_BLANK") });
      canceler();
      return fillEmpty(newRow, oldRow);
    }
    if (others && exists(others, newRow)) {
      enqueueSnackbar({ variant: "warning", message: i18n("ALREADY_EXIST_ENV_KEY") });
      canceler();
      return newRow;
    }
    if (JSON.stringify(newRow) !== JSON.stringify(oldRow)) {
      const mentions = (_b = this.state.mentions) == null ? void 0 : _b.map((m) => m.id === newRow.id ? newRow : m);
      this.setState({ mentions }, this.writeMentions);
    }
    return newRow;
  }
  actionsRender(params) {
    var _a;
    const id = params.id;
    const editing = ((_a = this.state.rowModesModel[id]) == null ? void 0 : _a.mode) === GridRowModes.Edit;
    return editing ? [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        GridActionsCellItem,
        {
          icon: /* @__PURE__ */ jsxRuntimeExports.jsx(default_1, {}),
          label: "Save",
          sx: { color: "primary.main" },
          onClick: this.handleSaveClick.bind(null, id)
        },
        "save"
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        GridActionsCellItem,
        {
          icon: /* @__PURE__ */ jsxRuntimeExports.jsx(default_1$3, {}),
          label: "Cancel",
          color: "inherit",
          className: "textPrimary",
          onClick: this.handleCancelClick.bind(null, id)
        },
        "cancel"
      )
    ] : [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        GridActionsCellItem,
        {
          icon: /* @__PURE__ */ jsxRuntimeExports.jsx(default_1$1, {}),
          label: "Edit",
          color: "inherit",
          className: "textPrimary",
          onClick: this.handleEditClick.bind(null, id)
        },
        "edit"
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        GridActionsCellItem,
        {
          icon: /* @__PURE__ */ jsxRuntimeExports.jsx(default_1$2, {}),
          label: "Delete",
          color: "inherit",
          onClick: this.handleDeleteClick.bind(null, id)
        },
        "delete"
      )
    ];
  }
  get columns() {
    if (__privateGet(this, _columns))
      return __privateGet(this, _columns);
    const common = { type: "string", editable: true };
    return __privateSet(this, _columns, [
      { ...common, field: "env", headerName: i18n("TYPES_MENTION_ENV"), flex: 1 },
      { ...common, field: "key", headerName: i18n("TYPES_MENTION_KEY"), flex: 1 },
      { ...common, field: "name", headerName: i18n("TYPES_MENTION_NAME"), flex: 1 },
      { ...common, field: "sfid", headerName: i18n("TYPES_MENTION_SFID"), width: 180 },
      { type: "actions", field: "actions", headerName: "", width: 100, getActions: this.actionsRender }
    ]);
  }
  // add/removeListenerをするなら、クラスコンポーネントのほうが良い
  componentDidMount() {
    chrome.storage.sync.onChanged.addListener(this.handleSyncStorageChange);
    this.readMentions();
  }
  componentWillUnmount() {
    chrome.storage.sync.onChanged.removeListener(this.handleSyncStorageChange);
  }
  render() {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { flexGrow: 1, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      DataGrid,
      {
        apiRef: this.props.dataGridApi,
        autoPageSize: true,
        disableColumnSelector: true,
        disableRowSelectionOnClick: true,
        editMode: "row",
        rows: this.state.mentions ?? [],
        rowModesModel: this.state.rowModesModel,
        columns: this.columns,
        onRowModesModelChange: this.handleRowModesModelChange,
        processRowUpdate: this.processRowUpdate,
        loading: this.state.mentions == null,
        localeText: LOCALE_TEXT
      }
    ) });
  }
}
_saveTimeout = new WeakMap();
_columns = new WeakMap();
const LOCALE_TEXT = {
  columnMenuLabel: i18n("DATAGRID_COLUMN_MENU_LABEL"),
  columnHeaderSortIconLabel: i18n("DATAGRID_COLUMN_HEADER_SORT_ICON_LABEL"),
  columnMenuSortAsc: i18n("DATAGRID_COLUMN_MENU_SORT_ASC"),
  columnMenuSortDesc: i18n("DATAGRID_COLUMN_MENU_SORT_DESC"),
  columnMenuUnsort: i18n("DATAGRID_COLUMN_MENU_UNSORT"),
  columnMenuFilter: i18n("DATAGRID_COLUMN_MENU_FILTER"),
  columnHeaderFiltersTooltipActive: (c2) => i18n("DATAGRID_COLUMN_HEADER_FILTERS_TOOLTIP_ACTIVE", `${c2}`),
  filterPanelColumns: i18n("DATAGRID_FILTER_PANEL_COLUMNS"),
  filterPanelOperator: i18n("DATAGRID_FILTER_PANEL_OPERATOR"),
  filterPanelInputLabel: i18n("DATAGRID_FILTER_PANEL_INPUT_LABEL"),
  filterPanelInputPlaceholder: i18n("DATAGRID_FILTER_PANEL_INPUT_PLACEHOLDER"),
  filterOperatorContains: i18n("DATAGRID_FILTER_OPERATOR_CONTAINS"),
  filterOperatorEquals: i18n("DATAGRID_FILTER_OPERATOR_EQUALS"),
  filterOperatorStartsWith: i18n("DATAGRID_FILTER_OPERATOR_STARTS_WITH"),
  filterOperatorEndsWith: i18n("DATAGRID_FILTER_OPERATOR_ENDS_WITH"),
  filterOperatorIsEmpty: i18n("DATAGRID_FILTER_OPERATOR_IS_EMPTY"),
  filterOperatorIsNotEmpty: i18n("DATAGRID_FILTER_OPERATOR_IS_NOT_EMPTY"),
  filterOperatorIsAnyOf: i18n("DATAGRID_FILTER_OPERATOR_IS_ANY_OF")
};
function getAppBarUtilityClass(slot) {
  return generateUtilityClass("MuiAppBar", slot);
}
generateUtilityClasses("MuiAppBar", ["root", "positionFixed", "positionAbsolute", "positionSticky", "positionStatic", "positionRelative", "colorDefault", "colorPrimary", "colorSecondary", "colorInherit", "colorTransparent"]);
const _excluded = ["className", "color", "enableColorOnDark", "position"];
const useUtilityClasses = (ownerState) => {
  const {
    color,
    position,
    classes: classes2
  } = ownerState;
  const slots = {
    root: ["root", `color${capitalize(color)}`, `position${capitalize(position)}`]
  };
  return composeClasses(slots, getAppBarUtilityClass, classes2);
};
const joinVars = (var1, var2) => var1 ? `${var1 == null ? void 0 : var1.replace(")", "")}, ${var2})` : var2;
const AppBarRoot = styled$1(Paper, {
  name: "MuiAppBar",
  slot: "Root",
  overridesResolver: (props, styles2) => {
    const {
      ownerState
    } = props;
    return [styles2.root, styles2[`position${capitalize(ownerState.position)}`], styles2[`color${capitalize(ownerState.color)}`]];
  }
})(({
  theme,
  ownerState
}) => {
  const backgroundColorDefault = theme.palette.mode === "light" ? theme.palette.grey[100] : theme.palette.grey[900];
  return _extends$1({
    display: "flex",
    flexDirection: "column",
    width: "100%",
    boxSizing: "border-box",
    // Prevent padding issue with the Modal and fixed positioned AppBar.
    flexShrink: 0
  }, ownerState.position === "fixed" && {
    position: "fixed",
    zIndex: (theme.vars || theme).zIndex.appBar,
    top: 0,
    left: "auto",
    right: 0,
    "@media print": {
      // Prevent the app bar to be visible on each printed page.
      position: "absolute"
    }
  }, ownerState.position === "absolute" && {
    position: "absolute",
    zIndex: (theme.vars || theme).zIndex.appBar,
    top: 0,
    left: "auto",
    right: 0
  }, ownerState.position === "sticky" && {
    // ⚠️ sticky is not supported by IE11.
    position: "sticky",
    zIndex: (theme.vars || theme).zIndex.appBar,
    top: 0,
    left: "auto",
    right: 0
  }, ownerState.position === "static" && {
    position: "static"
  }, ownerState.position === "relative" && {
    position: "relative"
  }, !theme.vars && _extends$1({}, ownerState.color === "default" && {
    backgroundColor: backgroundColorDefault,
    color: theme.palette.getContrastText(backgroundColorDefault)
  }, ownerState.color && ownerState.color !== "default" && ownerState.color !== "inherit" && ownerState.color !== "transparent" && {
    backgroundColor: theme.palette[ownerState.color].main,
    color: theme.palette[ownerState.color].contrastText
  }, ownerState.color === "inherit" && {
    color: "inherit"
  }, theme.palette.mode === "dark" && !ownerState.enableColorOnDark && {
    backgroundColor: null,
    color: null
  }, ownerState.color === "transparent" && _extends$1({
    backgroundColor: "transparent",
    color: "inherit"
  }, theme.palette.mode === "dark" && {
    backgroundImage: "none"
  })), theme.vars && _extends$1({}, ownerState.color === "default" && {
    "--AppBar-background": ownerState.enableColorOnDark ? theme.vars.palette.AppBar.defaultBg : joinVars(theme.vars.palette.AppBar.darkBg, theme.vars.palette.AppBar.defaultBg),
    "--AppBar-color": ownerState.enableColorOnDark ? theme.vars.palette.text.primary : joinVars(theme.vars.palette.AppBar.darkColor, theme.vars.palette.text.primary)
  }, ownerState.color && !ownerState.color.match(/^(default|inherit|transparent)$/) && {
    "--AppBar-background": ownerState.enableColorOnDark ? theme.vars.palette[ownerState.color].main : joinVars(theme.vars.palette.AppBar.darkBg, theme.vars.palette[ownerState.color].main),
    "--AppBar-color": ownerState.enableColorOnDark ? theme.vars.palette[ownerState.color].contrastText : joinVars(theme.vars.palette.AppBar.darkColor, theme.vars.palette[ownerState.color].contrastText)
  }, {
    backgroundColor: "var(--AppBar-background)",
    color: ownerState.color === "inherit" ? "inherit" : "var(--AppBar-color)"
  }, ownerState.color === "transparent" && {
    backgroundImage: "none",
    backgroundColor: "transparent",
    color: "inherit"
  }));
});
const AppBar = /* @__PURE__ */ reactExports.forwardRef(function AppBar2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiAppBar"
  });
  const {
    className,
    color = "primary",
    enableColorOnDark = false,
    position = "fixed"
  } = props, other = _objectWithoutPropertiesLoose$1(props, _excluded);
  const ownerState = _extends$1({}, props, {
    color,
    position,
    enableColorOnDark
  });
  const classes2 = useUtilityClasses(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AppBarRoot, _extends$1({
    square: true,
    component: "header",
    ownerState,
    elevation: 4,
    className: clsx$1(classes2.root, className, position === "fixed" && "mui-fixed"),
    ref
  }, other));
});
const AppBar$1 = AppBar;
const OptionHeader = reactExports.memo(() => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AppBar$1, { position: "static", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Toolbar$1, { variant: "dense", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { variant: "h6", component: "div", color: "inherit", children: i18n("OPTIONS") }) }) });
});
OptionHeader.displayName = "OptionHeader";
(function main2() {
  const container = document.getElementById("container");
  if (!container)
    throw new Error("$(#container) not found.");
  const root = createRoot(container);
  root.render(
    /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CssBaseline, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(SnackbarProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack, { direction: "column", height: "100vh", width: "100vw", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(OptionHeader, {}),
        /* @__PURE__ */ jsxRuntimeExports.jsx(OptionContent, {})
      ] }) })
    ] })
  );
})();
