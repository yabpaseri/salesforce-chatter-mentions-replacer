var __accessCheck = (obj, member, msg) => {
  if (!member.has(obj))
    throw TypeError("Cannot " + msg);
};
var __privateGet = (obj, member, getter) => {
  __accessCheck(obj, member, "read from private field");
  return getter ? getter.call(obj) : member.get(obj);
};
var __privateAdd = (obj, member, value) => {
  if (member.has(obj))
    throw TypeError("Cannot add the same private member more than once");
  member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
};
var __privateMethod = (obj, member, method) => {
  __accessCheck(obj, member, "access private method");
  return method;
};
var _handleEnvChange, _handleKeyChange, _handleNameChange, _handleSfidChange, _handleChange, handleChange_fn, _readyToSave, readyToSave_get;
import { q as generateUtilityClass, t as generateUtilityClasses, B as styled, F as Paper, r as reactExports, E as useThemeProps, y as _objectWithoutPropertiesLoose, _ as _extends, p as jsxRuntimeExports, x as clsx, w as composeClasses, aj as Backdrop, T as Typography, ag as Box, ab as Button, a3 as CircularProgress, a9 as TextField, X as Stack, af as exists, ah as createRoot, ai as CssBaseline } from "./Button.js";
import "./index.ts.js";
import { i as i18n, a as readAsLenient, w as write } from "./mention-dao.js";
function getCardUtilityClass(slot) {
  return generateUtilityClass("MuiCard", slot);
}
generateUtilityClasses("MuiCard", ["root"]);
const _excluded$1 = ["className", "raised"];
const useUtilityClasses$1 = (ownerState) => {
  const {
    classes
  } = ownerState;
  const slots = {
    root: ["root"]
  };
  return composeClasses(slots, getCardUtilityClass, classes);
};
const CardRoot = styled(Paper, {
  name: "MuiCard",
  slot: "Root",
  overridesResolver: (props, styles) => styles.root
})(() => {
  return {
    overflow: "hidden"
  };
});
const Card = /* @__PURE__ */ reactExports.forwardRef(function Card2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiCard"
  });
  const {
    className,
    raised = false
  } = props, other = _objectWithoutPropertiesLoose(props, _excluded$1);
  const ownerState = _extends({}, props, {
    raised
  });
  const classes = useUtilityClasses$1(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(CardRoot, _extends({
    className: clsx(classes.root, className),
    elevation: raised ? 8 : void 0,
    ref,
    ownerState
  }, other));
});
const Card$1 = Card;
function getCardContentUtilityClass(slot) {
  return generateUtilityClass("MuiCardContent", slot);
}
generateUtilityClasses("MuiCardContent", ["root"]);
const _excluded = ["className", "component"];
const useUtilityClasses = (ownerState) => {
  const {
    classes
  } = ownerState;
  const slots = {
    root: ["root"]
  };
  return composeClasses(slots, getCardContentUtilityClass, classes);
};
const CardContentRoot = styled("div", {
  name: "MuiCardContent",
  slot: "Root",
  overridesResolver: (props, styles) => styles.root
})(() => {
  return {
    padding: 16,
    "&:last-child": {
      paddingBottom: 24
    }
  };
});
const CardContent = /* @__PURE__ */ reactExports.forwardRef(function CardContent2(inProps, ref) {
  const props = useThemeProps({
    props: inProps,
    name: "MuiCardContent"
  });
  const {
    className,
    component = "div"
  } = props, other = _objectWithoutPropertiesLoose(props, _excluded);
  const ownerState = _extends({}, props, {
    component
  });
  const classes = useUtilityClasses(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(CardContentRoot, _extends({
    as: component,
    className: clsx(classes.root, className),
    ownerState,
    ref
  }, other));
});
const CardContent$1 = CardContent;
const BackdropMessage = reactExports.memo(({ message, ...props }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Backdrop, { open: message != null, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Card$1, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SCardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { ...props, children: message }) }) }) });
});
BackdropMessage.displayName = "BackdropMessage";
const SCardContent = styled(CardContent$1)({
  "&:last-child": {
    paddingBottom: "16px"
    // last-childは24pxになっているので、打消し
  }
});
const useDidMountEffect = (effect) => {
  return reactExports.useEffect(effect, []);
};
const ProgressButton = reactExports.memo(({ progress, progressProps, ...props }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { display: "flex", position: "relative", justifyContent: "center", alignItems: "center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { ...props }),
    progress && /* @__PURE__ */ jsxRuntimeExports.jsx(CenteringCircularProgress, { ...progressProps })
  ] });
});
ProgressButton.displayName = "ProgressButton";
const CenteringCircularProgress = styled(CircularProgress)({
  position: "absolute"
});
const TextInput = reactExports.memo(({ onChange, ...props }) => {
  const handleChange = reactExports.useCallback((ev) => onChange(ev.target.value), [onChange]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(TextField, { onChange: handleChange, ...props });
});
TextInput.displayName = "TextInput";
class Register extends reactExports.Component {
  constructor(props) {
    super(props);
    __privateAdd(this, _handleChange);
    __privateAdd(this, _readyToSave);
    __privateAdd(this, _handleEnvChange, __privateMethod(this, _handleChange, handleChange_fn).bind(this, "env"));
    __privateAdd(this, _handleKeyChange, __privateMethod(this, _handleChange, handleChange_fn).bind(this, "key"));
    __privateAdd(this, _handleNameChange, __privateMethod(this, _handleChange, handleChange_fn).bind(this, "name"));
    __privateAdd(this, _handleSfidChange, __privateMethod(this, _handleChange, handleChange_fn).bind(this, "sfid"));
    this.state = { status: "EDITING" };
    this.save = this.save.bind(this);
  }
  reset(value) {
    this.setState({ env: value.env, key: value.key, name: value.name, sfid: value.sfid });
  }
  error(error) {
    this.setState({ error });
  }
  async save() {
    if (!__privateGet(this, _readyToSave, readyToSave_get) || !this.props.onSave)
      return;
    await new Promise((ok) => this.setState({ status: "SAVING" }, ok));
    const { env, key, name, sfid } = this.state;
    const mention = { id: crypto.randomUUID(), env, key, name, sfid };
    try {
      await this.props.onSave(mention);
      this.setState({ status: "SAVED" });
    } catch (e) {
      console.log(e);
      let error = "error occured";
      if (typeof e === "string") {
        error = e;
      } else if (e instanceof Error) {
        error = e.message;
      }
      this.setState({ status: "EDITING", error });
    }
  }
  render() {
    const { env, key, name, sfid, error, status } = this.state;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack, { direction: "column", spacing: 1.5, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        TextInput,
        {
          fullWidth: true,
          required: true,
          label: i18n("TYPES_MENTION_ENV"),
          value: env ?? "",
          onChange: __privateGet(this, _handleEnvChange),
          error: env === "",
          disabled: status !== "EDITING",
          InputLabelProps: { shrink: true }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        TextInput,
        {
          fullWidth: true,
          required: true,
          label: i18n("TYPES_MENTION_KEY"),
          value: key ?? "",
          onChange: __privateGet(this, _handleKeyChange),
          error: key === "",
          disabled: status !== "EDITING",
          InputLabelProps: { shrink: true }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        TextInput,
        {
          fullWidth: true,
          required: true,
          label: i18n("TYPES_MENTION_NAME"),
          value: name ?? "",
          onChange: __privateGet(this, _handleNameChange),
          error: name === "",
          disabled: status !== "EDITING",
          InputLabelProps: { shrink: true }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        TextInput,
        {
          fullWidth: true,
          required: true,
          label: i18n("TYPES_MENTION_SFID"),
          value: sfid ?? "",
          onChange: __privateGet(this, _handleSfidChange),
          error: sfid === "",
          disabled: status !== "EDITING",
          InputLabelProps: { shrink: true }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Stack, { direction: "row", spacing: 1, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ErrorText, { error }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          ProgressButton,
          {
            tabIndex: -1,
            onClick: this.save,
            disabled: !__privateGet(this, _readyToSave, readyToSave_get),
            variant: "contained",
            progress: status === "SAVING",
            progressProps: { size: "28px" },
            children: i18n("ADD")
          }
        )
      ] })
    ] });
  }
}
_handleEnvChange = new WeakMap();
_handleKeyChange = new WeakMap();
_handleNameChange = new WeakMap();
_handleSfidChange = new WeakMap();
_handleChange = new WeakSet();
handleChange_fn = function(key, value) {
  const state = { [key]: value.trim(), error: void 0 };
  this.setState(state);
};
_readyToSave = new WeakSet();
readyToSave_get = function() {
  const { env, key, name, sfid, error, status } = this.state;
  return status === "EDITING" && error == null && [env, key, name, sfid].every((v) => v != null && v.length > 0);
};
const ErrorText = reactExports.memo(({ error }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { flex: "1 1 0", position: "relative", children: error && /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { color: "red", variant: "caption", position: "absolute", right: "0", bottom: "0", children: error }) });
});
ErrorText.displayName = "ErrorText";
const Popup = ({ _env, _key, _name, _sfid }) => {
  const [successMessage, setSuccessMessage] = reactExports.useState();
  const registerRef = reactExports.createRef();
  useDidMountEffect(() => {
    var _a;
    (_a = registerRef.current) == null ? void 0 : _a.reset({ env: _env, key: _key, name: _name, sfid: _sfid });
  });
  const handleSave = reactExports.useCallback(async (mention) => {
    const data = await readAsLenient();
    if (exists(data, mention)) {
      throw new Error(i18n("ALREADY_EXIST_ENV_KEY"));
    }
    data.push(mention);
    await write(data);
    setSuccessMessage(i18n("ADDED"));
    setTimeout(window.close.bind(window), 2e3);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Register, { ref: registerRef, onSave: handleSave }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(BackdropMessage, { message: successMessage })
  ] });
};
(function main() {
  const container = document.getElementById("container");
  if (!container)
    throw new Error("$(#container) not found.");
  const root = createRoot(container);
  const params = new URLSearchParams(location.search);
  const props = {
    _env: params.get("env") ?? void 0,
    _key: params.get("key") ?? void 0,
    _name: params.get("name") ?? void 0,
    _sfid: params.get("sfid") ?? void 0
  };
  root.render(
    /* @__PURE__ */ jsxRuntimeExports.jsxs(reactExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CssBaseline, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { padding: "20px 5px 10px", minWidth: "450px", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Popup, { ...props }) })
    ] })
  );
})();
