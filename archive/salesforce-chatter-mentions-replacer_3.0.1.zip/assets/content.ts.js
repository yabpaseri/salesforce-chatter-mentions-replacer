var __accessCheck = (obj, member, msg) => {
  if (!member.has(obj))
    throw TypeError("Cannot " + msg);
};
var __privateGet = (obj, member, getter) => {
  __accessCheck(obj, member, "read from private field");
  return getter ? getter.call(obj) : member.get(obj);
};
var __privateAdd = (obj, member, value) => {
  if (member.has(obj))
    throw TypeError("Cannot add the same private member more than once");
  member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
};
var __privateSet = (obj, member, value, setter) => {
  __accessCheck(obj, member, "write to private field");
  setter ? setter.call(obj, value) : member.set(obj, value);
  return value;
};
var __privateMethod = (obj, member, method) => {
  __accessCheck(obj, member, "access private method");
  return method;
};
var _pos, _isDescendantOf, isDescendantOf_fn, _createRange, createRange_fn, _keys, _mentions, _update, update_fn, _EDITORS_CLASSES, _match, match_fn, _installEventHandler, installEventHandler_fn, _execute, execute_fn, _elements, elements_fn, _texts, texts_fn, _textSplitWithKey, textSplitWithKey_fn, _createMentionElement, createMentionElement_fn, _a;
import { K as KEY, r as readAsStrict } from "./mention-dao.js";
class Caret {
  constructor(container) {
    __privateAdd(this, _isDescendantOf);
    __privateAdd(this, _createRange);
    __privateAdd(this, _pos, void 0);
    this.container = container;
    if (!container.isContentEditable)
      throw new Error("target is not contenteditable");
  }
  clear() {
    __privateSet(this, _pos, void 0);
  }
  /**
   * 読み込まれたキャレット位置を調整にoffset値を足す(調整用)
   * TODO: 変換後にキャレット位置はズレるが、変換前後の文字数は計算できるからどうにかならないかな...という希望
   * @param offset
   * @returns 調整後のpos
   */
  setOffset(offset) {
    if (__privateGet(this, _pos) == null)
      return -1;
    return __privateSet(this, _pos, Math.max(0, __privateGet(this, _pos) + offset));
  }
  save() {
    var _a2;
    this.clear();
    const selection = window.getSelection();
    if ((selection == null ? void 0 : selection.focusNode) == null || !__privateMethod(this, _isDescendantOf, isDescendantOf_fn).call(this, selection.focusNode, this.container)) {
      return;
    }
    for (let node = selection.focusNode, charCount = selection.focusOffset; node != null; ) {
      if (node == this.container) {
        __privateSet(this, _pos, charCount);
        break;
      }
      if (node.previousSibling != null) {
        node = node.previousSibling;
        charCount += ((_a2 = node.textContent) == null ? void 0 : _a2.length) ?? 0;
      } else {
        if (node.parentNode == null) {
          __privateSet(this, _pos, charCount);
          break;
        }
        node = node.parentNode;
      }
    }
  }
  load() {
    if (__privateGet(this, _pos) == null || __privateGet(this, _pos) < 0)
      return;
    const selection = window.getSelection();
    const range = __privateMethod(this, _createRange, createRange_fn).call(this, this.container, { count: __privateGet(this, _pos) });
    if (range != null) {
      range.collapse(false);
      selection == null ? void 0 : selection.removeAllRanges();
      selection == null ? void 0 : selection.addRange(range);
    }
  }
}
_pos = new WeakMap();
_isDescendantOf = new WeakSet();
isDescendantOf_fn = function(node, parent) {
  while (node != null) {
    if (node == parent)
      return true;
    node = node.parentNode;
  }
  return false;
};
_createRange = new WeakSet();
createRange_fn = function(node, chars, range) {
  if (range == null) {
    range = window.document.createRange();
    range.selectNode(node);
    range.setStart(node, 0);
  }
  if (chars.count === 0) {
    range.setEnd(node, chars.count);
  } else if (node != null && chars.count > 0) {
    if (node.nodeType === Node.TEXT_NODE) {
      if (node.textContent.length < chars.count) {
        chars.count -= node.textContent.length;
      } else {
        range.setEnd(node, chars.count);
        chars.count = 0;
      }
    } else {
      for (let g = 0; g < node.childNodes.length; ) {
        range = __privateMethod(this, _createRange, createRange_fn).call(this, node.childNodes[++g], chars, range);
        if (chars.count === 0)
          break;
      }
    }
  }
  return range;
};
(_a = class {
  constructor() {
    __privateAdd(this, _update);
    __privateAdd(this, _match);
    __privateAdd(this, _installEventHandler);
    __privateAdd(this, _execute);
    __privateAdd(this, _elements);
    __privateAdd(this, _texts);
    /**
     * Textをkeyに完全一致する箇所で区切り返却する  \
     * Text="fizzbuzzfoofizzbar", key="fizz" だとすると、
     * {matched: ["fizz", "fizz"], others: ["buzzfoo", "bar"]}
     * が返却される
     * @param text
     * @param key
     * @returns 分割結果
     */
    __privateAdd(this, _textSplitWithKey);
    __privateAdd(this, _createMentionElement);
    __privateAdd(this, _keys, []);
    __privateAdd(this, _mentions, /* @__PURE__ */ new Map());
    __privateAdd(this, _EDITORS_CLASSES, ["ql-editor", "slds-rich-text-area__content"]);
  }
  static async main() {
    var _a2, _b;
    const instance = new _a();
    chrome.storage.sync.onChanged.addListener((changes) => {
      var _a3;
      if (KEY in changes)
        __privateMethod(_a3 = instance, _update, update_fn).call(_a3);
    });
    await __privateMethod(_a2 = instance, _update, update_fn).call(_a2);
    __privateMethod(_b = instance, _installEventHandler, installEventHandler_fn).call(_b);
  }
}, _keys = new WeakMap(), _mentions = new WeakMap(), _update = new WeakSet(), update_fn = async function() {
  const origin = window.location.origin;
  const keys = [];
  const mentions = (await readAsStrict()).reduce((map, mention) => {
    if (mention.env === origin || mention.env === `${origin}/`) {
      keys.push(mention.key);
      map.set(mention.key, mention);
    }
    return map;
  }, /* @__PURE__ */ new Map());
  __privateSet(this, _keys, keys);
  __privateSet(this, _mentions, mentions);
}, _EDITORS_CLASSES = new WeakMap(), _match = new WeakSet(), match_fn = function(event) {
  if (!(event.target instanceof HTMLElement))
    return false;
  for (const c of __privateGet(this, _EDITORS_CLASSES)) {
    if (!event.target.classList.contains(c))
      return false;
  }
  return true;
}, _installEventHandler = new WeakSet(), installEventHandler_fn = function() {
  window.document.body.addEventListener("focusout", (ev) => {
    if (__privateMethod(this, _match, match_fn).call(this, ev))
      __privateMethod(this, _execute, execute_fn).call(this, ev.target);
  });
  window.document.body.addEventListener(
    "keydown",
    (ev) => {
      if (!__privateMethod(this, _match, match_fn).call(this, ev))
        return;
      if (ev.key === "Enter" && ev.commandKey) {
        __privateMethod(this, _execute, execute_fn).call(this, ev.target);
        return;
      }
      if (ev.key === "@" && ev.altKey) {
        ev.preventDefault();
        ev.stopPropagation();
        const target = ev.target;
        const caret = new Caret(target);
        caret.save();
        __privateMethod(this, _execute, execute_fn).call(this, target);
        caret.load();
      }
    },
    true
  );
}, _execute = new WeakSet(), execute_fn = function(root) {
  const childNodes = root.childNodes;
  for (const node of childNodes) {
    switch (node.nodeType) {
      case Node.ELEMENT_NODE:
        __privateMethod(this, _elements, elements_fn).call(this, node);
        break;
      case Node.TEXT_NODE:
        __privateMethod(this, _texts, texts_fn).call(this, node);
        break;
    }
  }
}, _elements = new WeakSet(), elements_fn = function(element) {
  switch (true) {
    case element instanceof HTMLAnchorElement:
    case element instanceof HTMLBRElement:
    case element instanceof HTMLImageElement:
    case element instanceof HTMLPreElement:
    case (element instanceof HTMLSpanElement && element.classList.contains("ql-chatter-mention")):
    case element.tagName === "CODE":
      return;
    default:
      __privateMethod(this, _execute, execute_fn).call(this, element);
  }
}, _texts = new WeakSet(), texts_fn = function(text) {
  if (text.textContent == null)
    return;
  const matched = /* @__PURE__ */ new Set();
  const remain = /* @__PURE__ */ new Set([text]);
  for (const key of __privateGet(this, _keys)) {
    const mirror = [...remain];
    remain.clear();
    for (const re of mirror) {
      const res = __privateMethod(this, _textSplitWithKey, textSplitWithKey_fn).call(this, re, key);
      for (const m of res.matched)
        matched.add(m);
      for (const o of res.others)
        remain.add(o);
    }
  }
  for (const target of matched) {
    const data = __privateGet(this, _mentions).get(target.textContent ?? "");
    if (data)
      target.replaceWith(__privateMethod(this, _createMentionElement, createMentionElement_fn).call(this, data));
  }
}, _textSplitWithKey = new WeakSet(), textSplitWithKey_fn = function(text, key) {
  const matched = /* @__PURE__ */ new Set();
  const others = /* @__PURE__ */ new Set();
  const searchRegex = new RegExp(`(^${key}(?=\\s)|(?<=\\s)${key}$|(?<=\\s)${key}(?=\\s)|^${key}$)`);
  const process = (text2) => {
    if (text2.textContent == null || text2.textContent === "")
      return;
    const index = text2.textContent.search(searchRegex);
    if (index < 0) {
      others.add(text2);
      return;
    }
    const target = (() => {
      if (index === 0)
        return text2;
      const t = text2.splitText(index);
      others.add(text2);
      return t;
    })();
    const remain = target.splitText(key.length);
    matched.add(target);
    process(remain);
  };
  process(text);
  return { matched, others };
}, _createMentionElement = new WeakSet(), createMentionElement_fn = function(mention) {
  const span = document.createElement("span");
  span.classList.add("ql-chatter-mention", "quill_widget_element");
  span.contentEditable = "false";
  span.tabIndex = -1;
  span.setAttribute("data-widget", "chatterMention");
  span.setAttribute("data-mention", mention.sfid);
  span.textContent = `@[${mention.name}]`;
  return span;
}, _a).main();
